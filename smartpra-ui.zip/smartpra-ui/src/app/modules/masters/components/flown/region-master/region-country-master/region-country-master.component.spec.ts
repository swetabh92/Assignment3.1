import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegionCountryMasterComponent } from './region-country-master.component';

describe('RegionCountryMasterComponent', () => {
  let component: RegionCountryMasterComponent;
  let fixture: ComponentFixture<RegionCountryMasterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegionCountryMasterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegionCountryMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
