package com.sgl.smartpra.batch.global.app.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "inbound_file_log")
public class InboundFileLogEntity {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="inbound_file_id")
	private Integer inboundFileId;
	
	@Column(name="inbound_file_name")
	private String inboundFileName;
	
	@Column(name="file_type")
	private String fileType;
	
	@Column(name="file_record_count")
	private Integer fileRecordCount;
	
	@Column(name="upload_starttime")
	private Timestamp uploadStarttime;
	
	@Column(name="upload_endtime")
	private Timestamp uploadEndtime;
	
	@Column(name="load_status")
	private String loadStatus;
	
	@Column(name="error_code")
	private String errorCode;
	
	@Column(name="error_desc")
	private String errorDesc;
	
	public Integer getInboundFileId() {
		return inboundFileId;
	}

	public void setInboundFileId(Integer inboundFileId) {
		this.inboundFileId = inboundFileId;
	}

	public String getInboundFileName() {
		return inboundFileName;
	}

	public void setInboundFileName(String inboundFileName) {
		this.inboundFileName = inboundFileName;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public Integer getFileRecordCount() {
		return fileRecordCount;
	}

	public void setFileRecordCount(Integer fileRecordCount) {
		this.fileRecordCount = fileRecordCount;
	}

	public Timestamp getUploadStarttime() {
		return uploadStarttime;
	}

	public void setUploadStarttime(Timestamp uploadStarttime) {
		this.uploadStarttime = uploadStarttime;
	}

	public Timestamp getUploadEndtime() {
		return uploadEndtime;
	}

	public void setUploadEndtime(Timestamp uploadEndtime) {
		this.uploadEndtime = uploadEndtime;
	}

	public String getLoadStatus() {
		return loadStatus;
	}

	public void setLoadStatus(String loadStatus) {
		this.loadStatus = loadStatus;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorDesc() {
		return errorDesc;
	}

	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}
}
