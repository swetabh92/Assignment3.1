package com.sgl.smartpra.batch.amadeus.app.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.batch.amadeus.app.common.AmadeusRecCounts;
import com.sgl.smartpra.batch.amadeus.app.common.AppConstants;
import com.sgl.smartpra.batch.amadeus.app.common.DocumentIdsReader;
import com.sgl.smartpra.batch.amadeus.app.common.DocumentIdsWriter;
import com.sgl.smartpra.batch.amadeus.app.config.FeignConfiguration.BatchGlobalFeignClient;
import com.sgl.smartpra.batch.amadeus.app.config.FeignConfiguration.FlownFeignClient;
import com.sgl.smartpra.batch.amadeus.app.config.FeignConfiguration.MasterFeignClient;
import com.sgl.smartpra.batch.amadeus.app.utils.AmadeusCommonUtils;
import com.sgl.smartpra.batch.global.model.FileErrorLog;
import com.sgl.smartpra.batch.global.model.FileLogging;
import com.sgl.smartpra.common.util.FileLoggingConstants;
import com.sgl.smartpra.common.util.SmartpraFileUtility;

@Service
public class AmadeusBatchJobService {
	@Autowired
	JobLauncher jobLauncher;

	@Autowired
	@Qualifier(value = "importAmadeusStgJob")
	Job importAmadeusStgJob;

	@Autowired
	@Qualifier(value = "importAmadeusETLProdJob")
	Job importAmadeusETLProdJob;

	@Autowired
	@Qualifier(value = "importAmadeusEMDProdJob")
	Job importAmadeusEMDProdJob;

	@Value("${batch.directory.amadeus.duplicate}")
	private String batchDuplicateDir;

	@Value("${batch.directory.amadeus.input}")
	private String batchInputDir;

	@Value("${batch.directory.amadeus.failed}")
	private String batchFailedDir;

	@Autowired
	MasterFeignClient masterFeignClient;

	@Autowired
	BatchGlobalFeignClient batchGlobalFeignClient;

	@Autowired
	FlownFeignClient flownFeignClient;

	@Autowired
	FlightDataPaxCountService flightDataPaxCountService;

	private static final Logger LOGGER = LoggerFactory.getLogger(AmadeusBatchJobService.class);

	private SmartpraFileUtility smartpraFileUtility = new SmartpraFileUtility();

	/**
	 * This method is used to invoke the batch job to parse the input flat file and
	 * store it into DB(Staging and then Production for ETL & EMD).
	 * 
	 * @param inboundFileName
	 * @return
	 * @throws Exception
	 */
	public String executeAmadeusBatchLoad(String inboundFileName, String processedBy) throws Exception {

		String pax = "PAX";
		// File not found while invoking this service from controller.
		if (!smartpraFileUtility.fileExists(batchInputDir + inboundFileName)) {
			return "Batch input file not found (" + batchInputDir + inboundFileName + ")";
		}
		String fileFirstLine = smartpraFileUtility.readFirstLine(batchInputDir + "/" + inboundFileName);
		String hostCarrDesigCode = AmadeusCommonUtils.getHostCarrierDesigCode(masterFeignClient);
		String hostCarrierCode = AmadeusCommonUtils.getHostCarrierCode(masterFeignClient);
		String flightNoLen = AmadeusCommonUtils.getFlightNumberOption(masterFeignClient);
		String validDtReqOut=AmadeusCommonUtils.validateDtRequestOut(masterFeignClient);
		String dtStr = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		FileLogging fileLogging = AmadeusCommonUtils.initFileLogging();
		fileLogging.setModuleName("FLOWN"); // NEED TO BE DERIVED FROM LOV TABLE
		fileLogging.setClientId(hostCarrDesigCode);
		fileLogging.setFileName(inboundFileName);
		fileLogging.setProcessedBy(processedBy);
		fileLogging.setJobName(importAmadeusStgJob.getName());
		fileLogging.setFileSize(SmartpraFileUtility.getFileSize(batchInputDir + inboundFileName));
		fileLogging.setFileType(FileLoggingConstants.FILELOGGING_FILETYPE_AMADEUS_ETL_IN);
		FileErrorLog fileErrorLog;
		ArrayList<FileErrorLog> fileErrorLogList;

		// IF file is empty
		if (SmartpraFileUtility.isEmptyFile(batchInputDir + inboundFileName)) {
			String errorMsg = "Input file " + batchInputDir + inboundFileName + " is empty....";
			SmartpraFileUtility.moveFile(batchInputDir + inboundFileName, batchFailedDir + inboundFileName + dtStr);
			fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_TECHFAILED);
			fileLogging.setRemarks(errorMsg);
			fileLogging.setIsMovedToRelevantFolder("Y");
			fileErrorLog = new FileErrorLog();
			fileErrorLog.setFileId(fileLogging.getFileId());
			fileErrorLog.setErrorDetail("File is empty");
			fileErrorLog.setErrorDescription(errorMsg);
			fileErrorLogList = new ArrayList<FileErrorLog>();
			fileErrorLogList.add(fileErrorLog);
			fileLogging.setFileErrorLog(fileErrorLogList);
			fileLogging.setFileType("AMADEUS");
			fileLogging = batchGlobalFeignClient.createFileLog(fileLogging);
			return errorMsg;
		}
		if (fileFirstLine.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_ETL)) {
			fileLogging.setFileType(FileLoggingConstants.FILELOGGING_FILETYPE_AMADEUS_ETL_IN);
		} else if (fileFirstLine.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_EMD)) {
			fileLogging.setFileType(FileLoggingConstants.FILELOGGING_FILETYPE_AMADEUS_EMD_IN);
		} else {
			String errorMsg = "Amadeus filetype not identified from the first line (ETL Ref: "
					+ AppConstants.FILETYPE_IDENTIFICATION_STRING_ETL + " or EMD Ref: "
					+ AppConstants.FILETYPE_IDENTIFICATION_STRING_EMD + ")";
			SmartpraFileUtility.moveFile(batchInputDir + inboundFileName, batchFailedDir + inboundFileName + dtStr);
			fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_TECHFAILED);
			fileLogging.setRemarks(errorMsg);
			fileLogging.setIsMovedToRelevantFolder("Y");
			fileErrorLog = new FileErrorLog();
			fileErrorLog.setFileId(fileLogging.getFileId());
			fileErrorLog.setErrorDetail("Amadeus file type not identified (ETL/EMD)");
			fileErrorLog.setErrorDescription(errorMsg);
			fileErrorLogList = new ArrayList<FileErrorLog>();
			fileErrorLogList.add(fileErrorLog);
			fileLogging.setFileErrorLog(fileErrorLogList);
			fileLogging.setFileType("AMADEUS");
			fileLogging = batchGlobalFeignClient.createFileLog(fileLogging);
			return errorMsg;
		}
		/*
		 * //File prefix check with host carrier code
		 * if(!fileUtil.isValidFile(hostCarrDesigCode, inboundFileName,
		 * OneWorldConstants.ESAL_FILENAME_CONSTANT)) { String errorMsg = "Input file "+
		 * inboundFileName
		 * +" invalid (file name pattern should be XXESAL2CC_YYYYMMDD_HHMM.txt)" ;
		 * OneWorldFileValidationsUtil.moveFile(batchInputDir + inboundFileName,
		 * batchFailedDir + inboundFileName + dtStr);
		 * fileLogging.setFileStatus(OneWorldConstants.FILELOGGING_FILESTATUS_ERRORED);
		 * fileLogging.setRemarks(errorMsg);
		 * fileLogging.setIsMovedToRelevantFolder("Y"); fileErrorLog = new
		 * FileErrorLog(); fileErrorLog.setFileId(fileLogging.getFileId());
		 * fileErrorLog.setErrorDetail("Invalid File Input");
		 * fileErrorLog.setErrorDescription(errorMsg); fileErrorLogList = new
		 * ArrayList(); fileErrorLogList.add(fileErrorLog);
		 * fileLogging.setFileErrorLog(fileErrorLogList); fileLogging =
		 * batchGlobalFeignClient.createFileLog(fileLogging); return errorMsg; } //File
		 * duplicate check List<FileLogging> fileList =
		 * batchGlobalFeignClient.getFileLogByFileName(inboundFileName); if(fileList
		 * !=null && fileList.size()>0) { String errorMsg = "Input file "+
		 * inboundFileName +" duplicated with fileID " + fileList.get(0).getFileId();
		 * OneWorldFileValidationsUtil.moveFile(batchInputDir + inboundFileName,
		 * batchDuplicateDir + inboundFileName + dtStr);
		 * fileLogging.setFileStatus(OneWorldConstants.FILELOGGING_FILESTATUS_DUPLICATE)
		 * ; fileLogging.setRemarks(errorMsg);
		 * fileLogging.setIsMovedToRelevantFolder("Y"); fileErrorLog = new
		 * FileErrorLog(); fileErrorLog.setFileId(fileLogging.getFileId());
		 * fileErrorLog.setErrorDetail("Invalid File Input");
		 * fileErrorLog.setErrorDescription(errorMsg); fileErrorLogList = new
		 * ArrayList(); fileErrorLogList.add(fileErrorLog);
		 * fileLogging.setFileErrorLog(fileErrorLogList); fileLogging =
		 * batchGlobalFeignClient.createFileLog(fileLogging); return
		 * "Batch ESAL-IN job not started because the file already loaded into the system (Duplicate file loading).."
		 * ; }
		 * 
		 */

		fileLogging = batchGlobalFeignClient.createFileLog(fileLogging);
		AmadeusRecCounts.resetCounts();
		DocumentIdsWriter.clear();
		DocumentIdsReader.clear();
		// Loading the data into staging irrespective of E
		// @formatter:off
		JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis())
				.addString("inboundFileName", fileLogging.getFileName())
				.addLong("inboundFileId", fileLogging.getFileId().longValue())
				.addString("carrieNumericCode", hostCarrierCode).addString("careerDesignatorCode", hostCarrDesigCode)
				.addString("flightNoLen", flightNoLen).addString("amadeusVersion", fileFirstLine.substring(25))
				.toJobParameters();
		// @formatter:oN
		JobExecution jobExecution = jobLauncher.run(importAmadeusStgJob, jobParameters);
		if (jobExecution.getExitStatus().equals(ExitStatus.COMPLETED)) {
			LOGGER.info(
					"Batch Amadeus-IN job for staging completed successfully and Production load job triggered.......");
			if (fileFirstLine.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_ETL)) {
				
				
				LOGGER.info("Triggering Actual Pax Count Calculation(including flight status)");
				flightDataPaxCountService.updateFlightDataDetail(fileLogging.getFileId(), pax);
				LOGGER.info("Triggering Flown Coupon Validation start");
				flownFeignClient.validateCouponsForFileId((fileLogging.getFileId().intValue()));
				LOGGER.info("Triggering Flown Coupon Validation end");
				return "Batch Amadeus-IN Job invoked and load data into staging and ETL production load completed successfully....";
		
				
				
				
				// @formatter:off

				/*
				jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis())
						.addString("inboundFileName", fileLogging.getFileName())
						.addLong("inboundFileId", fileLogging.getFileId().longValue())
						.addString("carrieNumericCode", hostCarrierCode)
						.addString("careerDesignatorCode", hostCarrDesigCode).addString("flightNoLen", flightNoLen)
						.addString("validDtReqOut", validDtReqOut)
						.addString("amadeusVersion", fileFirstLine.substring(25)).toJobParameters();
				// @formatter:oN
				JobExecution prodJobExecution = jobLauncher.run(importAmadeusETLProdJob, jobParameters);
				if (prodJobExecution.getExitStatus().equals(ExitStatus.COMPLETED)) {
					
					LOGGER.info("Triggering Actual Pax Count Calculation(including flight status)");
					
					flightDataPaxCountService.updateFlightDataDetail(fileLogging.getFileId(), pax);
					
					LOGGER.info("Triggering Flown Coupon Validation start");
					
					flownFeignClient.validateCouponsForFileId((fileLogging.getFileId().intValue()));

					LOGGER.info("Triggering Flown Coupon Validation end");

					return "Batch Amadeus-IN Job invoked and load data into staging and ETL production load completed successfully....";
				} else {
					return "Batch Amadeus-IN Job invoked and load data into staging completed but ETL production load failed.....";
				}
				
				*/
				
				
				
			} else if (fileFirstLine.contains(AppConstants.FILETYPE_IDENTIFICATION_STRING_EMD)) {
				// @formatter:off
				jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis())
						.addString("inboundFileName", fileLogging.getFileName())
						.addLong("inboundFileId", fileLogging.getFileId().longValue())
						.addString("carrieNumericCode", hostCarrierCode)
						.addString("careerDesignatorCode", hostCarrDesigCode).addString("flightNoLen", flightNoLen)
						.addString("amadeusVersion", fileFirstLine.substring(25)).toJobParameters();
				// @formatter:oN
				JobExecution prodJobExecution = jobLauncher.run(importAmadeusEMDProdJob, jobParameters);
				if (prodJobExecution.getExitStatus().equals(ExitStatus.COMPLETED)) {
					LOGGER.info("Triggering Flown Coupon Validation");
					flownFeignClient.validateCouponsForFileId((fileLogging.getFileId().intValue()));
					return "Batch Amadeus-IN Job invoked and load data into staging and EMD production load completed successfully....";
				} else {
					return "Batch Amadeus-IN Job invoked and load data into staging completed but EMD production load failed.....";
				}
			} else {
				return "Batch Amadeus-IN Job invoked and load data into staging completed but loading into production failed due to unidentified filetype.....";
			}

		} else {
			return "Batch Amadeus-IN job has been invoked and execution failed...";
		}
	}
}
