import { Component, OnInit,OnDestroy} from '@angular/core';
import { GeneralService } from '../../../../commons/services/general.service';
import { FlownService } from '../services/flown.service'
import { FormBuilder,FormGroup, Validators } from '@angular/forms';
import {CommonService} from '../../../masters/services/commons/common.service';
import {FlownListModel,couponStatusList} from '../model/flown-model';
import {timer} from 'rxjs';
import { couponList} from './couponList'
import { LovService }  from '../../../masters/services/LOV/lov.service';
import { Subscription } from 'rxjs/Subscription';
import { HotkeyService ,Command} from '../services/hotkey.service';
@Component({
  selector: 'app-flown-dashboard',
  templateUrl: './flown-dashboard.component.html',
  styleUrls: ['./flown-dashboard.component.css']
})
export class FlownDashboardComponent implements OnInit,OnDestroy {
  subscription: Subscription;
  couponList = couponList;
  couponStatus = couponStatusList;
  searchForm: FormGroup;
  advanceSearchForm: FormGroup; 
  searchParams:any;
  searchSubmitted = false;
  checkBoxValues={};
  toMinDate:any;
  fromMaxDate:any;
  collapseAdvanceForm = true;
  scrollListEnabled:boolean = true;
  flightMaxLength:number;
  flownLovs:object = {}
  constructor(private hotkeyService:HotkeyService,private lov:LovService,private commonService:CommonService,private formBuilder:FormBuilder,private flownService:FlownService, private Gservice: GeneralService) { 
    this.subscription = this.hotkeyService.commands.subscribe(c => {
      this.handleCommand(c)
    });
  }
  handleCommand(command: Command) {
    if(command.module != 'FlownDashboardComponent') return false;
    console.log(command.module)
    switch (command.name) {
      case 'FlownDashboardComponent.search': {
        this.searchFlown();
         break;
      } 
      case 'FlownDashboardComponent.clear': {
        this.resetForm(); 
        break;
      }  
      case 'FlownDashboardComponent.advanceSearch': {
        this.searchFlown('advance'); 
        break;
      }
      case 'FlownDashboardComponent.advanceClear': {
        this.resetForm('advance'); 
        break;
      }
    }
  }
   setScrollStyle(elem) {
    let temp = {};
    let footer = document.getElementsByClassName("page_footer");
    if(elem) temp["top"] = elem.offsetHeight+elem.offsetTop+4;
    if(footer && footer.length) temp["bottom"] = footer[0]["offsetHeight"];
    return temp;
  }
  createAdvanceForm(){
    return this.formBuilder.group({
      flightNumber			   : [''],
      flightCategory       : [''],
      paxType              : [''],
      cabin                : [''],
      journyType           : [''],
      bookingClass         : [''],
      fareBasis            : [''],
      fileName             : [''],
      documentType         : [''],
      reconsillition       : [''],
      flightType           : [''],
      flightDirection      : [''],
      nightSector          : [''],
      geography            : [''],
      selfOAlCoupon        : [''],
      issueAirline         : [''],
      documentNumber       : [''],
      couponNo             : [''],
      pnrNo                : [''],
      couponStatus         : [''],
    });
  }
  ngOnInit() {
    this.lov.initLovDDS('flown_dashboard').then((res) => {
      this.flownLovs["flightStatus"] = this.lov.getData('flight_status','flown_dashboard');
      this.flownLovs["flightCategory"] = this.lov.getData('service_type','flown_dashboard');
    });
    this.searchForm = this.formBuilder.group({
        flightStatus	   : ['',[Validators.required]],
        flightDateFrom	 : ['',[Validators.required]],
        flightDateTo	   : ['',[Validators.required]],
        departure		     : [''],
        arrival	    	   : ['']
    });  
    this.advanceSearchForm = this.createAdvanceForm();
    
    this.searchForm.controls['flightDateFrom'].valueChanges.subscribe((minDate) => {
        this.toMinDate = minDate;
    });
    this.searchForm.controls['flightDateTo'].valueChanges.subscribe((maxDate) => {
          this.fromMaxDate = maxDate;
    }); 
    /*get decimal precission */
    this.flownService.getCabinRbdList().subscribe((res)=>{
      this.flownService.cabinRbdList = res;
    })
    this.flownService.getCurrencyDP().subscribe((res:any)=> {
      if(res && res["parameterRangeFrom"]) this.flownService.currencyDecimalPression = res["parameterRangeFrom"];
    })
    this.flownService.getCurrencyCode().subscribe((res:any)=> {
      if(res && res["parameterRangeFrom"]) this.flownService.currencyCode = res["parameterRangeFrom"];
    })
    this.flownService.getFlightLength().subscribe((res:any)=> {
      if(res && res["parameterRangeFrom"]) this.flightMaxLength = res["parameterRangeFrom"];        
    })
  }
  
  couponValidate(val){
    const ctrl = this.advanceSearchForm.get('couponNo');
    if(this.commonService.isEmpty(val)) {
      ctrl.setValue(null);
      ctrl.disable();
    } 
    else  ctrl.enable();
  }
  swipeDistinArrival(){
    const dep = this.searchForm.get('departure');
    const arr = this.searchForm.get('arrival');
    let temp = arr.value;
    arr.setValue(dep.value);
    dep.setValue(temp);
  }
  get sf(){
    return this.searchForm.controls;
  }
  get as(){
    return this.advanceSearchForm.controls;
  }
  resetForm(type?:string){
    this.advanceSearchForm = this.createAdvanceForm();
    if(type == 'advance') return false;
    this.searchForm.reset();
    this.searchParams = undefined;
    this.collapseAdvanceForm = this.searchSubmitted = false;
    setTimeout(()=>{
      this.collapseAdvanceForm = true;
    },10) 
  }
  searchFlown(type?:any){
    this.searchSubmitted = true;
    if(this.searchForm.invalid) return false;
    let data = this.searchForm.value;
    if(type == 'advance')  {
      let deleteKeys = ['flightType','flightDirection','nightSector','geography'];
      data = Object.assign({},this.searchForm.value,this.advanceSearchForm.value);
      for (let key of deleteKeys) {
        delete data[key];
      }
    }
    this.flownService.viewFlown = this.searchParams = undefined;
    timer(10).subscribe(()=>{
      this.searchParams = data;
      this.triggerScroll();
    })
  } 
 
  // future use
  changeValue(type,e){
      let value = e.target.value;
      if(e.target.checked) {
        if(!this.checkBoxValues.hasOwnProperty(type)) this.checkBoxValues[type] = [];
        this.checkBoxValues[type].push(value)
      }
      else {
        let index = this.checkBoxValues[type].indexOf(value);
        if (index !== -1) this.checkBoxValues[type].splice(index, 1);
      }
  }
  triggerScroll(){
    this.scrollListEnabled = true;
    timer(10).subscribe(()=>{
      this.scrollListEnabled = false;
    })
  }
  ngOnDestroy() { 
    this.subscription.unsubscribe();
  }
}

