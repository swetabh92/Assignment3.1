package com.sgl.smartpra.batch.sales.validator.app.config;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.global.master.model.Airport;
import com.sgl.smartpra.global.master.model.Carrier;
import com.sgl.smartpra.global.master.model.Currency;
import com.sgl.smartpra.master.model.AgencyMaster;
import com.sgl.smartpra.master.model.CarrierAlliance;
import com.sgl.smartpra.master.model.SystemParameter;

/**
 * 
 * @author mansound1
 *
 */
@Configuration
public class FeignConfiguration {

	@FeignClient(value = "smartpra-global-master-app")
	public interface SmartpraGlobalMasterAppClient {

		@GetMapping("/carriers/{carrierCode}")
		public Carrier getCarrierByCarrierCode(@PathVariable(value = "carrierCode") String carrierCode);

		@GetMapping("/carriers/getCarrierCode/{carrierDesignatorCode}")
		public String getCarrrierCodeByCarrierDesignatorCode(
				@PathVariable(value = "carrierDesignatorCode") String carrierDesignatorCode);

		@GetMapping("/currencies")
		public List<Currency> getAllcurrencies(
				@RequestParam(value = "currencyCode", required = false) String currencyCode,
				@RequestParam(value = "currencyName", required = false) String currencyName);

		@GetMapping("/currencies/{currencyCode}")
		public Currency getCurrencyByCurrencyCode(@PathVariable(value = "currencyCode") String currencyCode);

		@PostMapping("/carriers/carrierDetails")
		public List<Carrier> carrierDetails(@RequestBody List<String> carrierCodeList);
		
		@GetMapping("/airports/{airportCode}")
		public Airport getAirportByAirportCode(@PathVariable(value = "airportCode") String airportCode);
		
		@GetMapping("/airports/cityCode/{cityCode}/isValid")
		public boolean isValidCityCode(@PathVariable(value="cityCode")String cityCode);
		
		
		@GetMapping("/airports")
		public List<Airport> getAllAirport(@RequestParam(value = "airportCode", required = false) String airportCode,
				@RequestParam(value = "airportName", required = false) String airportName,
				@RequestParam(value = "cityCode", required = false) String cityCode,
				@RequestParam(value = "cityName", required = false) String cityName,
				@RequestParam(value = "countryCode", required = false) String countryCode);
			
		
	}

	@FeignClient(value = "smartpra-master-app")
	public interface SmartpraMasterAppClient {

		@GetMapping("/carrier-alliance/effectiveDate")
		public List<CarrierAlliance> getAllCarrierAllianceByEffectiveDate(
				@RequestParam(value = "allianceName", required = false) String allianceName,
				@RequestParam(value = "carrierCode", required = false) String carrierCode,
				@RequestParam(value = "effectiveDate", required = false) String effectiveDate);

		@GetMapping("/system-parameters-with-date/{parameterName}")
		public List<SystemParameter> getSystemParameterByparameterName(
				@PathVariable(value = "parameterName") String parameterName);
		

		@GetMapping("/agency-master")
		public List<AgencyMaster> getAllAgency(@RequestParam(value = "agencyCode", required = true) String agencyCode,
				@RequestParam(value = "reportingAgency", required = false) String reportingAgency,
				@RequestParam(value = "agencyType", required = false) String agencyType,
				@RequestParam(value = "areaOfOperation", required = true) String areaOfOperation,
				@RequestParam(value = "reportingAgencyType", required = true) String reportingAgencyType);
	}
	
	@FeignClient(value = "smartpra-exception-transaction-integration")
	public interface SmartpraExceptionMasterAppClient {

		@GetMapping("/api/init-exceptionmessage")
		public void initExceptionTrasaction(@RequestBody ExceptionTransactionModel exceptionTransactionModel);
	}

}