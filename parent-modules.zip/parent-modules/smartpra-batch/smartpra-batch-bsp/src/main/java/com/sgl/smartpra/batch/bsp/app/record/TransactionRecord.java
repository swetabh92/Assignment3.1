package com.sgl.smartpra.batch.bsp.app.record;

import java.util.ArrayList;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.LineTokenizer;

/**
 * This class represents the logical transaction records
 */
public class TransactionRecord extends BSPBaseRecord {

	@Override
	public String getRecordType() {
		return BSPRecordType.TRANSACTION_RECORD;
	}

	private ArrayList<String> record;
	private TransactionHeader transactionHeader;
	private ArrayList<TicketDocumentIdentification> ticketDocumentIdentificationList;
	private ArrayList<StdDocumentAmounts> stdDocumentAmountsList;
	private ArrayList<CouponTaxInformation> couponTaxInformationList;
	private ArrayList<Commission> commissionList;
	private ArrayList<TaxOnCommission> taxOnCommissionList;
	private ArrayList<RelatedTicketDocumentInfo> relatedTicketDocumentInfoList;
	private ArrayList<QualIssueInfo> qualIssueInfoList;
	private ArrayList<NettingValues> nettingValuesList;
	private ArrayList<UnticketedPointInfo> unticketedPointInfo;
	private ArrayList<AdditionalItineraryData> additionalItineraryDataList;
	private ArrayList<ItineraryDataSegment> itineraryDataSegmentList;
	private DocumentAmounts documentAmounts;
	private AddlInfoPassenger addlInfoPassenger;
	private ArrayList<AddlInfoFormOfPayment> addlInfoFormOfPaymentList;
	private ArrayList<AddlTaxesInfo> addlTaxesInfoList;
	private ArrayList<EMDCouponDetail> emdCouponDetailList;
	private ArrayList<EMDRemarks> emdRemarksList;
	private ArrayList<FareCalculation> fareCalculationList;
	private ArrayList<AdditionalCardInfo> additionalCardInfoList;
	private ArrayList<CardAuthInfo> cardAuthInfoList;
	private ArrayList<TDSCardAuthInfo> tdsCardAuthInfoList;
	private ArrayList<FormOfPayment> formOfPaymentList;

	public ArrayList<String> getRecord() {
		return record;
	}

	public void setRecord(ArrayList<String> record) {
		this.record = record;
	}

	public void addLine(String line) {
		if (this.record == null) {
			this.record = new ArrayList<String>();
		}

		this.record.add(line);
	}

	public TransactionHeader getTransactionHeader() {
		return transactionHeader;
	}

	public void setTransactionHeader(TransactionHeader transactionHeader) {
		this.transactionHeader = transactionHeader;
	}

	public ArrayList<TicketDocumentIdentification> getTicketDocumentIdentificationList() {
		return ticketDocumentIdentificationList;
	}

	public void setTicketDocumentIdentificationList(
			ArrayList<TicketDocumentIdentification> ticketDocumentIdentificationList) {
		this.ticketDocumentIdentificationList = ticketDocumentIdentificationList;
	}

	public void addTicketDocumentIdentification(TicketDocumentIdentification ticketDocumentIdentification) {
		if (this.ticketDocumentIdentificationList == null) {
			this.ticketDocumentIdentificationList = new ArrayList<TicketDocumentIdentification>();
		}

		this.ticketDocumentIdentificationList.add(ticketDocumentIdentification);
	}

	public ArrayList<StdDocumentAmounts> getStdDocumentAmountsList() {
		return stdDocumentAmountsList;
	}

	public void setStdDocumentAmountsList(ArrayList<StdDocumentAmounts> stdDocumentAmountsList) {
		this.stdDocumentAmountsList = stdDocumentAmountsList;
	}

	public void addStdDocumentAmounts(StdDocumentAmounts stdDocumentAmounts) {
		if (this.stdDocumentAmountsList == null) {
			this.stdDocumentAmountsList = new ArrayList<StdDocumentAmounts>();
		}

		this.stdDocumentAmountsList.add(stdDocumentAmounts);
	}

	public ArrayList<CouponTaxInformation> getCouponTaxInformationList() {
		return couponTaxInformationList;
	}

	public void setCouponTaxInformationList(ArrayList<CouponTaxInformation> couponTaxInformationList) {
		this.couponTaxInformationList = couponTaxInformationList;
	}

	public void addCouponTaxInformation(CouponTaxInformation couponTaxInformation) {
		if (this.couponTaxInformationList == null) {
			this.couponTaxInformationList = new ArrayList<CouponTaxInformation>();
		}

		this.couponTaxInformationList.add(couponTaxInformation);
	}

	public ArrayList<Commission> getCommissionList() {
		return commissionList;
	}

	public void setCommissionList(ArrayList<Commission> commissionList) {
		this.commissionList = commissionList;
	}

	public void addCommission(Commission commission) {
		if (this.commissionList == null) {
			this.commissionList = new ArrayList<Commission>();
		}

		this.commissionList.add(commission);
	}

	public ArrayList<TaxOnCommission> getTaxOnCommissionList() {
		return taxOnCommissionList;
	}

	public void setTaxOnCommissionList(ArrayList<TaxOnCommission> taxOnCommissionList) {
		this.taxOnCommissionList = taxOnCommissionList;
	}

	public void addTaxOnCommission(TaxOnCommission taxOnCommission) {
		if (this.taxOnCommissionList == null) {
			this.taxOnCommissionList = new ArrayList<TaxOnCommission>();
		}

		this.taxOnCommissionList.add(taxOnCommission);
	}

	public ArrayList<RelatedTicketDocumentInfo> getRelatedTicketDocumentInfoList() {
		return relatedTicketDocumentInfoList;
	}

	public void setRelatedTicketDocumentInfoList(ArrayList<RelatedTicketDocumentInfo> relatedTicketDocumentInfoList) {
		this.relatedTicketDocumentInfoList = relatedTicketDocumentInfoList;
	}

	public void addRelatedTicketDocumentInfo(RelatedTicketDocumentInfo relatedTicketDocumentInfo) {
		if (this.relatedTicketDocumentInfoList == null) {
			this.relatedTicketDocumentInfoList = new ArrayList<RelatedTicketDocumentInfo>();
		}

		this.relatedTicketDocumentInfoList.add(relatedTicketDocumentInfo);
	}

	public ArrayList<QualIssueInfo> getQualIssueInfoList() {
		return qualIssueInfoList;
	}

	public void setQualIssueInfoList(ArrayList<QualIssueInfo> qualIssueInfoList) {
		this.qualIssueInfoList = qualIssueInfoList;
	}

	public void addQualIssueInfo(QualIssueInfo qualIssueInfo) {
		if (this.qualIssueInfoList == null) {
			this.qualIssueInfoList = new ArrayList<QualIssueInfo>();
		}

		this.qualIssueInfoList.add(qualIssueInfo);
	}

	public ArrayList<NettingValues> getNettingValuesList() {
		return nettingValuesList;
	}

	public void setNettingValuesList(ArrayList<NettingValues> nettingValuesList) {
		this.nettingValuesList = nettingValuesList;
	}

	public void addNettingValues(NettingValues nettingValues) {
		if (this.nettingValuesList == null) {
			this.nettingValuesList = new ArrayList<NettingValues>();
		}

		this.nettingValuesList.add(nettingValues);
	}

	public ArrayList<UnticketedPointInfo> getUnticketedPointInfo() {
		return unticketedPointInfo;
	}

	public void setUnticketedPointInfo(ArrayList<UnticketedPointInfo> unticketedPointInfo) {
		this.unticketedPointInfo = unticketedPointInfo;
	}

	public void addUnticketedPointInfo(UnticketedPointInfo unticketedPointInfo) {
		if (this.unticketedPointInfo == null) {
			this.unticketedPointInfo = new ArrayList<UnticketedPointInfo>();
		}

		this.unticketedPointInfo.add(unticketedPointInfo);
	}

	public ArrayList<AdditionalItineraryData> getAdditionalItineraryDataList() {
		return additionalItineraryDataList;
	}

	public void setAdditionalItineraryDataList(ArrayList<AdditionalItineraryData> additionalItineraryDataList) {
		this.additionalItineraryDataList = additionalItineraryDataList;
	}

	public void addAdditionalItineraryData(AdditionalItineraryData additionalItineraryData) {
		if (this.additionalItineraryDataList == null) {
			this.additionalItineraryDataList = new ArrayList<AdditionalItineraryData>();
		}

		this.additionalItineraryDataList.add(additionalItineraryData);
	}

	public ArrayList<ItineraryDataSegment> getItineraryDataSegmentList() {
		return itineraryDataSegmentList;
	}

	public void setItineraryDataSegmentList(ArrayList<ItineraryDataSegment> itineraryDataSegmentList) {
		this.itineraryDataSegmentList = itineraryDataSegmentList;
	}

	public void addItineraryDataSegment(ItineraryDataSegment itineraryDataSegment) {
		if (this.itineraryDataSegmentList == null) {
			this.itineraryDataSegmentList = new ArrayList<ItineraryDataSegment>();
		}

		this.itineraryDataSegmentList.add(itineraryDataSegment);
	}

	public DocumentAmounts getDocumentAmounts() {
		return documentAmounts;
	}

	public void setDocumentAmounts(DocumentAmounts documentAmounts) {
		this.documentAmounts = documentAmounts;
	}

	public AddlInfoPassenger getAddlInfoPassenger() {
		return addlInfoPassenger;
	}

	public void setAddlInfoPassenger(AddlInfoPassenger addlInfoPassenger) {
		this.addlInfoPassenger = addlInfoPassenger;
	}

	public ArrayList<AddlInfoFormOfPayment> getAddlInfoFormOfPaymentList() {
		return addlInfoFormOfPaymentList;
	}

	public void setAddlInfoFormOfPaymentList(ArrayList<AddlInfoFormOfPayment> addlInfoFormOfPaymentList) {
		this.addlInfoFormOfPaymentList = addlInfoFormOfPaymentList;
	}

	public void addAddlInfoFormOfPayment(AddlInfoFormOfPayment addlInfoFormOfPayment) {
		if (this.addlInfoFormOfPaymentList == null) {
			this.addlInfoFormOfPaymentList = new ArrayList<AddlInfoFormOfPayment>();
		}

		this.addlInfoFormOfPaymentList.add(addlInfoFormOfPayment);
	}

	public ArrayList<AddlTaxesInfo> getAddlTaxesInfoList() {
		return addlTaxesInfoList;
	}

	public void setAddlTaxesInfoList(ArrayList<AddlTaxesInfo> addlTaxesInfoList) {
		this.addlTaxesInfoList = addlTaxesInfoList;
	}

	public void addAddlTaxesInfo(AddlTaxesInfo addlTaxesInfo) {
		if (this.addlTaxesInfoList == null) {
			this.addlTaxesInfoList = new ArrayList<AddlTaxesInfo>();
		}

		this.addlTaxesInfoList.add(addlTaxesInfo);
	}

	public ArrayList<EMDCouponDetail> getEmdCouponDetailList() {
		return emdCouponDetailList;
	}

	public void setEmdCouponDetailList(ArrayList<EMDCouponDetail> emdCouponDetailList) {
		this.emdCouponDetailList = emdCouponDetailList;
	}

	public void addEMDCouponDetail(EMDCouponDetail emdCouponDetail) {
		if (this.emdCouponDetailList == null) {
			this.emdCouponDetailList = new ArrayList<EMDCouponDetail>();
		}

		this.emdCouponDetailList.add(emdCouponDetail);
	}

	public ArrayList<EMDRemarks> getEmdRemarksList() {
		return emdRemarksList;
	}

	public void setEmdRemarksList(ArrayList<EMDRemarks> emdRemarksList) {
		this.emdRemarksList = emdRemarksList;
	}

	public void addEMDRemarks(EMDRemarks emdRemarks) {
		if (this.emdRemarksList == null) {
			this.emdRemarksList = new ArrayList<EMDRemarks>();
		}

		this.emdRemarksList.add(emdRemarks);
	}

	public ArrayList<FareCalculation> getFareCalculationList() {
		return fareCalculationList;
	}

	public void setFareCalculationList(ArrayList<FareCalculation> fareCalculationList) {
		this.fareCalculationList = fareCalculationList;
	}

	public void addFareCalculation(FareCalculation fareCalculation) {
		if (this.fareCalculationList == null) {
			this.fareCalculationList = new ArrayList<FareCalculation>();
		}

		this.fareCalculationList.add(fareCalculation);
	}

	public ArrayList<AdditionalCardInfo> getAdditionalCardInfoList() {
		return additionalCardInfoList;
	}

	public void setAdditionalCardInfoList(ArrayList<AdditionalCardInfo> additionalCardInfoList) {
		this.additionalCardInfoList = additionalCardInfoList;
	}

	public void addAdditionalCardInfo(AdditionalCardInfo additionalCardInfo) {
		if (this.additionalCardInfoList == null) {
			this.additionalCardInfoList = new ArrayList<AdditionalCardInfo>();
		}

		this.additionalCardInfoList.add(additionalCardInfo);
	}

	public ArrayList<CardAuthInfo> getCardAuthInfoList() {
		return cardAuthInfoList;
	}

	public void setCardAuthInfoList(ArrayList<CardAuthInfo> cardAuthInfoList) {
		this.cardAuthInfoList = cardAuthInfoList;
	}

	public void addCardAuthInfo(CardAuthInfo cardAuthInfo) {
		if (this.cardAuthInfoList == null) {
			this.cardAuthInfoList = new ArrayList<CardAuthInfo>();
		}

		this.cardAuthInfoList.add(cardAuthInfo);
	}

	public ArrayList<TDSCardAuthInfo> getTdsCardAuthInfoList() {
		return tdsCardAuthInfoList;
	}

	public void setTdsCardAuthInfoList(ArrayList<TDSCardAuthInfo> tdsCardAuthInfoList) {
		this.tdsCardAuthInfoList = tdsCardAuthInfoList;
	}

	public void addTDSCardAuthInfo(TDSCardAuthInfo tdsCardAuthInfo) {
		if (this.tdsCardAuthInfoList == null) {
			this.tdsCardAuthInfoList = new ArrayList<TDSCardAuthInfo>();
		}

		this.tdsCardAuthInfoList.add(tdsCardAuthInfo);
	}

	public ArrayList<FormOfPayment> getFormOfPaymentList() {
		return formOfPaymentList;
	}

	public void setFormOfPaymentList(ArrayList<FormOfPayment> formOfPaymentList) {
		this.formOfPaymentList = formOfPaymentList;
	}

	public void addFormOfPayment(FormOfPayment formOfPayment) {
		if (this.formOfPaymentList == null) {
			this.formOfPaymentList = new ArrayList<FormOfPayment>();
		}

		this.formOfPaymentList.add(formOfPayment);
	}

	@Override
	public LineTokenizer lineTokenizer(String handbookRevisionNumber) {
		return null;
	}

	@Override
	public FieldSetMapper<BSPBaseRecord> fieldSetMapper() {
		return null;
	}
}