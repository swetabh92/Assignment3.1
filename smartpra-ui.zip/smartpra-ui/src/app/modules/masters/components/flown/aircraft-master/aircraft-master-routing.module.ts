import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AircraftMasterComponent } from './aircraft-master.component';

const routes: Routes = [
  {path:'',component:AircraftMasterComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AircraftMasterRoutingModule { }
