import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InwardDashboardRoutingModule } from './inward-dashboard-routing.module';
import { InwardDashboardComponent } from './inward-dashboard.component';
import { SharedModule } from '../../../shared/shared.module';
import { CoreDataModule } from '../../../core-data/core-data.module';
import { InwardSearchComponent } from './inward-search/inward-search.component'
import { SummarizedDataComponent } from './summarized-data/summarized-data.component';
import { InvoicesComponent } from './invoices/invoices.component';
import { BatchesComponent } from './batches/batches.component';
import { TransactionsComponent } from './transactions/transactions.component';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    CoreDataModule,
    InwardDashboardRoutingModule
  ],
  declarations: [
    InwardDashboardComponent,
    InwardSearchComponent,
    SummarizedDataComponent,
    InvoicesComponent,
    BatchesComponent,
    TransactionsComponent
  ]
})
export class InwardDashboardModule { }
