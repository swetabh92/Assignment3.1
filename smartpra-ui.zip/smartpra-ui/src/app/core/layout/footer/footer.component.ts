import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'; 
@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {

year = new Date();
routeUrl  : string;
defaultText :string='';
flownText :string='Flown Accounting completed for';
flownDate: string = '1-Aug-19 till 7-Aug-19 on 9-Aug-19';
flownTeamLead: string = 'by Team Lead Jason Roy';
miscText: string = 'File MXMLT-15720181001.XML  got loaded Successfully at';
standAloneProrationText: string = '';
showRollingDisplay:boolean = true;
defaultRollingFlag:boolean = true;
flownRollingFlag:boolean = false;
miscBillingRollingFlag:boolean = false;
prorationRollingFlag:boolean = false;
test =  [{'key':'flownDashboard','value':'Flown Accounting completed for 1-Aug-19 till 7-Aug-19 on 9-Aug-19 by Team Lead Jason Roy'},{'key':'flownDashboard','value':'test flown'},{'key':'miscellaneous','value':'test flown'}];

  constructor(private route:Router ) { }

  ngOnInit() {
    this.routeUrl = this.route.url
    if(this.routeUrl === "/dashboard/flownDashboard"){
      this.flownRollingFlag = true;
      this.miscBillingRollingFlag = false;
      this.prorationRollingFlag = false;
      this.defaultRollingFlag = false;
    }else if(this.routeUrl === "/miscellaneous/misc-billing"){
      this.flownRollingFlag = false;
      this.miscBillingRollingFlag = true;
      this.prorationRollingFlag = false;
      this.defaultRollingFlag = false;
    }else if(this.routeUrl === "/dashboard/standalone-proration"){
      this.showRollingDisplay = false;
      // this.defaultRollingFlag = false;
      // this.flownRollingFlag = false;
      // this.miscBillingRollingFlag = false;
      // this.prorationRollingFlag = false;
      // this.defaultRollingFlag = false;
    }
    else{
      this.flownRollingFlag = false;
      this.miscBillingRollingFlag = false;
      this.prorationRollingFlag = false;
      this.defaultRollingFlag = true;
    }
    
  }

}
