import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChargeCodeMasterComponent } from './charge-code-master.component';

describe('ChargeCodeMasterComponent', () => {
  let component: ChargeCodeMasterComponent;
  let fixture: ComponentFixture<ChargeCodeMasterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChargeCodeMasterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChargeCodeMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
