package com.sgl.smartpra.allocation.master.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@JsonInclude(Include.NON_NULL)
public class InwardAllocation extends AllocationMaster {

		private static final long serialVersionUID = 3547491282584797842L;

		private String billingMonth;

		private List<String> billingCurrency;

		private List<String> sourceCode;

		private List<String> listingCurrency;

		private List<String> zones;

		private List<String> billingCarrier;
		
		private List<String> allianceName ;
	}


