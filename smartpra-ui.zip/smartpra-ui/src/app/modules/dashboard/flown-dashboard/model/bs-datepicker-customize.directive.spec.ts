import { BsDatepickerCustomizeDirective } from './bs-datepicker-customize.directive';

describe('BsDatepickerCustomizeDirective', () => {
  it('should create an instance', () => {
    const directive = new BsDatepickerCustomizeDirective();
    expect(directive).toBeTruthy();
  });
});
