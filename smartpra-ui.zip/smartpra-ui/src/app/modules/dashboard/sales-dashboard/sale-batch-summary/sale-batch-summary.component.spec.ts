import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SaleBatchSummaryComponent } from './sale-batch-summary.component';

describe('SaleBatchSummaryComponent', () => {
  let component: SaleBatchSummaryComponent;
  let fixture: ComponentFixture<SaleBatchSummaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SaleBatchSummaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SaleBatchSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
