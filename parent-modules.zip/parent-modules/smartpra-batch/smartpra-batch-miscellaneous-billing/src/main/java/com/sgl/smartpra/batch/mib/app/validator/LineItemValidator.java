package com.sgl.smartpra.batch.mib.app.validator;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.collections4.map.HashedMap;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.collect.Multimap;
import com.sgl.smartpra.batch.mib.app.config.FeignConfiguration;
import com.sgl.smartpra.batch.mib.app.enums.ErrorCode;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingConstants;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.model.Airport;
import com.sgl.smartpra.global.master.model.ChargeCodeType;
import com.sgl.smartpra.master.model.OutwardBillingPeriods;
import com.sgl.smartpra.mib.entity.MiscBillingInvLineitemDtlEntity;
import com.sgl.smartpra.mib.entity.MiscBillingInvLineitemEntity;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class LineItemValidator {

    @Autowired
    private FeignConfiguration.SmartpraGlobalMasterAppClient smartpraGlobalMasterAppClient;

    @Autowired 
    private FeignConfiguration.SmartpraMasterAppClient smartpraMasterAppClient;
    
    @Autowired
    private LineItemDetailValidator lineItemDetailValidator;
    
    @Autowired
    private TaxDetailsValidator taxDetailValidator;
    
    @Autowired
    private AddOnChargeDetailsValidator addOnChargeDetailsValidator;

    @Autowired
    private CommonValidator commonValidator;
    
    public void validateLineItems(MiscBillingInvLineitemEntity lineitemEntity, Multimap<String,ExceptionTransactionModel> mErrorCode){
    	
		Map<String, String> m = Collections.emptyMap();
		String invoiceNo = commonValidator.getInvoiceNo();
		String chargeCategory = commonValidator.getChargeCategory();
		String chargeCode = lineitemEntity.getChargeCode();		

		if (!validateChargeCode()) {
			m = new HashedMap<>();
			m.put("Charge Code", String.valueOf(chargeCode));
			m.put("Invoice No.", invoiceNo);
			commonValidator.setErrorCode(mErrorCode, m, ErrorCode.MISC1012);
		}
		if (commonValidator.isRequired(commonValidator.getChargeCodeObj(), MiscBillingPredicates.isChargeCodeTypeRequired())) {
			commonValidator.requiredValidation(MiscBillingConstants.CHARGE_CODE_TYPE, lineitemEntity.getChargeCodeType(), mErrorCode, MiscBillingPredicates.isEmptyObject());
		}
		commonValidator.requiredValidation(MiscBillingConstants.DESCRIPTION,
				lineitemEntity.getDescription(), mErrorCode, MiscBillingPredicates.isEmptyObject());
		commonValidator.requiredValidation(MiscBillingConstants.START_DATE,
				lineitemEntity.getStartDate(), mErrorCode, MiscBillingPredicates.isEmptyObject());
		commonValidator.requiredValidation(MiscBillingConstants.END_DATE,
				lineitemEntity.getEndDate(), mErrorCode, MiscBillingPredicates.isEmptyObject());
		commonValidator.requiredValidation(MiscBillingConstants.LOCATION_CODE,
				lineitemEntity.getLocationCode(), mErrorCode, MiscBillingPredicates.isEmptyObject());
		commonValidator.requiredValidation(MiscBillingConstants.QUANTITY,
				lineitemEntity.getQuantity(), mErrorCode, MiscBillingPredicates.isEmptyObject());
		commonValidator.requiredValidation(MiscBillingConstants.UNIT_PRICE,
				lineitemEntity.getUnitPrice(), mErrorCode, MiscBillingPredicates.isEmptyObject());
		commonValidator.requiredValidation(MiscBillingConstants.CHARGE_AMOUNT,
				lineitemEntity.getChargeAmount(), mErrorCode, MiscBillingPredicates.isEmptyObject());
		commonValidator.requiredValidation(MiscBillingConstants.TOTAL_NET_AMOUNT,
				lineitemEntity.getTotalNetAmount(), mErrorCode, MiscBillingPredicates.isEmptyObject());

		if (!validateChargeCodeType(chargeCategory, chargeCode, lineitemEntity.getChargeCodeType())) {
			m = new HashedMap<>();
			m.put("Charge Code", String.valueOf(chargeCode));
			m.put("Invoice No.", invoiceNo);
			commonValidator.setErrorCode(mErrorCode, m, ErrorCode.MISC1103);
		}
		if (!validateRejection(lineitemEntity.getRejectionReasonCode(),
				lineitemEntity.getMiscBillingTrnInvoice().getRejectionFlag())) {
			m = new HashedMap<>();
			m.put("Invoice No.", invoiceNo);
			commonValidator.setErrorCode(mErrorCode, m, ErrorCode.MISC1104);
		}
		if (!validateStartDate(lineitemEntity.getStartDate(), lineitemEntity.getEndDate())) {
			m = new HashedMap<>();
			m.put("Start Date", String.valueOf(lineitemEntity.getStartDate()));
			m.put("End Date", String.valueOf(lineitemEntity.getEndDate()));
			m.put("Invoice No.", invoiceNo);
			commonValidator.setErrorCode(mErrorCode, m, ErrorCode.MISC1105);
		}
		if (!validateEndDate(lineitemEntity.getStartDate(), lineitemEntity.getEndDate(),
				lineitemEntity.getMiscBillingTrnInvoice().getBillingMonth(), 
				lineitemEntity.getMiscBillingTrnInvoice().getBillingPeriod(), m = new HashMap<>())) {
			m.put("Invoice No.", invoiceNo);
			commonValidator.setErrorCode(mErrorCode, m, ErrorCode.MISC1106);
		}
		if (isInValidLocationCode(lineitemEntity.getLocationCode())) {
			m = new HashedMap<>();
			m.put("Location Code", String.valueOf(lineitemEntity.getLocationCode()));
			m.put("Invoice No.", invoiceNo);
			commonValidator.setErrorCode(mErrorCode, m, ErrorCode.MISC1107);
		}
		if (!validateChargeAmount(lineitemEntity.getQuantity(),
				lineitemEntity.getUnitPrice(), lineitemEntity.getChargeAmount())) {
			m = new HashedMap<>();
			m.put("Charge Amount", String.valueOf(lineitemEntity.getChargeAmount()));
			m.put("Invoice No.", invoiceNo);
			m.put("Quantity", String.valueOf(lineitemEntity.getQuantity()));
			m.put("Unit Price", String.valueOf(lineitemEntity.getUnitPrice()));
			commonValidator.setErrorCode(mErrorCode, m, ErrorCode.MISC1108);
		}
		if (!validateTotalNetAmount(lineitemEntity.getChargeAmount(),
				lineitemEntity.getTotalTaxAmount(), lineitemEntity.getTotalVatAmount(),
				lineitemEntity.getTotalAddonChargeAmount(),
				lineitemEntity.getTotalNetAmount())) {
			m = new HashedMap<>();
			m.put("Invoice No.", invoiceNo);
			m.put("Line item No.", String.valueOf(lineitemEntity.getLineItemNumber()));
			commonValidator.setErrorCode(mErrorCode, m, ErrorCode.MISC1109);
		}

		if (lineitemEntity.getMiscBillingLineitemDetails() != null
				&& !lineitemEntity.getMiscBillingLineitemDetails().isEmpty()) {
			if (!validateDetailCount(lineitemEntity.getMiscBillingLineitemDetails().size(),
					lineitemEntity.getDetailCount())) {
				m = new HashedMap<>();
				m.put("Line item Detail Count", String.valueOf(lineitemEntity.getDetailCount()));
				m.put("No. of Line item Details", String.valueOf(lineitemEntity.getMiscBillingLineitemDetails().size()));
				m.put("Invoice No.", invoiceNo);
				m.put("Line Item No.", String.valueOf(lineitemEntity.getLineItemNumber()));
				commonValidator.setErrorCode(mErrorCode, m, ErrorCode.MISC1110);
			}
		}
	
	
		if (commonValidator.isRequired(commonValidator.getChargeCodeObj(), MiscBillingPredicates.isLocationCodeRequiredForChargeCode())) {
			if(commonValidator.isValueEmpty(lineitemEntity.getLocationCode(), MiscBillingPredicates.isEmptyObject())) {
				m = new HashedMap<>();
				m.put("Charge Code",commonValidator.getChargeCode());
				m.put("Invoice No.",commonValidator.getInvoiceNo());
				commonValidator.setErrorCode(mErrorCode, m, ErrorCode.MISC2014);
			}
		}
		if (commonValidator.isRequired(commonValidator.getChargeCodeObj(), MiscBillingPredicates.isPoLineItemRequired())){
			if(commonValidator.isValueEmpty(lineitemEntity.getPoLineItemNumber(), MiscBillingPredicates.isEmptyObject())) {
				m = new HashedMap<>();
				m.put("Charge Code",commonValidator.getChargeCode());
				m.put("Invoice No.",commonValidator.getInvoiceNo());
				commonValidator.setErrorCode(mErrorCode, m, ErrorCode.MISC2015);
			}
		}
		if (!commonValidator.isRequired(commonValidator.getChargeCodeObj(), MiscBillingPredicates.isProductIdRequired())) {
			if(commonValidator.isValueEmpty(lineitemEntity.getProductId(), MiscBillingPredicates.isEmptyObject())) {
				m = new HashedMap<>();
				m.put("Charge Code",commonValidator.getChargeCode());
				m.put("Invoice No.",commonValidator.getInvoiceNo());
				commonValidator.setErrorCode(mErrorCode, m, ErrorCode.MISC2016);
			}	
		}
		for (MiscBillingInvLineitemDtlEntity lineItemDtlEntity : lineitemEntity.getMiscBillingLineitemDetails()) {
			lineItemDetailValidator.validateLineItemsDetails(lineItemDtlEntity, mErrorCode);
		}
		taxDetailValidator.validateTaxDetails(lineitemEntity.getMiscBillingTaxDetails(), mErrorCode, MiscBillingConstants.LINE_ITEM);
		addOnChargeDetailsValidator.validateAddOnDetails(lineitemEntity.getMiscBillingAddOnChargeDtl(), mErrorCode, MiscBillingConstants.LINE_ITEM);
    }

    public Boolean validateChargeCode(){
        return commonValidator.getChargeCodeObj() != null ? Boolean.TRUE : Boolean.FALSE;
    }

     public Boolean validateRejection(String reason, String reasonF){
         if (StringUtils.equalsIgnoreCase(reasonF,"Y") ){
                 return StringUtils.isNotBlank(reason);
         } else {
             return Boolean.TRUE;
         }
     }

     public Boolean validateChargeCodeType(String chargeCodeCategory, String chargeCode, String chargeCodeType){
        if (StringUtils.isBlank(chargeCodeType)){
            return Boolean.TRUE;
        }
        Optional<ChargeCodeType> optionalChargeCodeType = Optional.empty();
		try {
			/*
			optionalChargeCodeType = Optional.of(smartpraGlobalMasterAppClient
			        .getAllChargeCodeTypeByChargeCodeType(Optional.of(chargeCodeCategory),Optional.of(chargeCode),
			                Optional.of(chargeCodeType)));
			*/
			optionalChargeCodeType = Optional.of(smartpraGlobalMasterAppClient
			        .getAllChargeCodeTypeByChargeCodeType(chargeCodeCategory,chargeCode,chargeCodeType));
		} catch (RecordNotFoundException rnfEx) {
        	log.debug("chargeCodeType " + chargeCodeType + " not found in master.");
		} catch (Exception e) {
			log.debug("Exception thrown while getting chargeCodeType. Value does not exist in master.");
			e.printStackTrace();
		}

        return optionalChargeCodeType.isPresent();
    }

     public Boolean validateStartDate(Date startDate, Date endDate){
        if (startDate == null || endDate == null) {
            return Boolean.TRUE;
        }
         LocalDate localStartDate = convertDateToLocalDate(startDate);
         LocalDate localEndDate = convertDateToLocalDate(endDate);
         if (localEndDate.isAfter(localStartDate)) {
             return Boolean.TRUE;
         } else if (localEndDate.isEqual(localStartDate)) {
             return Boolean.TRUE;
         }
        return Boolean.FALSE;
    }

    public Boolean validateEndDate(Date startDate, Date endDate, String billMonth, Integer billPeriod, Map<String, String> m){
        List<OutwardBillingPeriods> alOutwardBillingPeriods = null;
        try {
            alOutwardBillingPeriods = smartpraMasterAppClient.getOutwardBillingPeriodsUsingBillingMonthAndBillingPeriodV(billMonth, billPeriod);
        } catch (Exception e) {
            log.error("validateEndDate: ", e.getMessage());
        }
        if (alOutwardBillingPeriods != null && !alOutwardBillingPeriods.isEmpty()){
            OutwardBillingPeriods outwardBillingPeriods = alOutwardBillingPeriods.get(0);
            m.put("Start Date",String.valueOf(startDate));
            m.put("End Date",String.valueOf(endDate));
            m.put("Billing Period End date",String.valueOf(outwardBillingPeriods.getEndDate()));

            if(endDate != null) {
            	//LocalDate localStartDate = convertDateToLocalDate(startDate);
	            LocalDate localEndDate = convertDateToLocalDate(endDate);
	            LocalDate localBillEndDate = convertDateToLocalDate(new Date(outwardBillingPeriods.getEndDate().getTime()));
	            //if (localStartDate.isBefore(localBillEndDate) && localEndDate.isBefore(localBillEndDate)){
	            if (localEndDate.isBefore(localBillEndDate)){	
	                return Boolean.TRUE;
	            } else {
	                return Boolean.FALSE;
	            }
            }
        }
        return Boolean.FALSE;
    }

     public Boolean isInValidLocationCode(String locationCode){
    	 
    	Boolean isValid = new Boolean(false);
        if (StringUtils.isNotBlank(locationCode)){
	        try {
				Airport airport = smartpraGlobalMasterAppClient.getAirportByAirportCode(locationCode);
				if(airport != null) {
					isValid = Boolean.TRUE;
				}
	        } catch (RecordNotFoundException rnfEx) {
	        	log.debug("Airport Code " + locationCode + " not found in master.");
	        } catch (Exception e) {
	        	log.debug("Exception thrown while getting Airport Code " + locationCode + " from master.");
				e.printStackTrace();
			} 
        }   
       	return isValid;
    }

     public Boolean validateChargeAmount(BigDecimal quantity, BigDecimal unitPrice, BigDecimal chargeAmount){
        quantity = quantity == null ? BigDecimal.ZERO : quantity;
        unitPrice = unitPrice == null ? BigDecimal.ZERO : unitPrice;
        chargeAmount = chargeAmount == null ? BigDecimal.ZERO : chargeAmount;
        BigDecimal calculateAmount = quantity.multiply(unitPrice);
        return (calculateAmount.compareTo(chargeAmount) == 0);
    }

     public Boolean validateTotalNetAmount(BigDecimal chargeAmount, BigDecimal totalTax,
                                           BigDecimal totalVat, BigDecimal addOn , BigDecimal  totalNetAmount){
        chargeAmount = chargeAmount == null ? BigDecimal.ZERO : chargeAmount;
        totalTax = totalTax == null ? BigDecimal.ZERO : totalTax;
        totalVat = totalVat == null ? BigDecimal.ZERO : totalVat;
        addOn = addOn == null ? BigDecimal.ZERO : addOn;
        totalNetAmount = totalNetAmount == null ? BigDecimal.ZERO : totalNetAmount;
        BigDecimal totalAmount = totalTax.add(totalVat).add(chargeAmount).add(addOn);
        return (totalAmount.compareTo(totalNetAmount) == 0);
    }

    public Boolean validateDetailCount(int lineItemDetailCount, int lineItemDetailSize){
        return lineItemDetailCount == lineItemDetailSize;
    }

    public Boolean validateTaxCode(String taxCode) {
        return Boolean.FALSE;
    }

    private LocalDate convertDateToLocalDate(Date date) {
        return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    }    
}
