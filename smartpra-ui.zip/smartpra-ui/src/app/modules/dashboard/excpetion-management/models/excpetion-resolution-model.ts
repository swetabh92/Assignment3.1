import * as _ from 'underscore';
import {Validators} from "@angular/forms";
import {DatePipe} from '@angular/common';
import {ExceptionConstant} from "../constants/exception-contants";

export interface ExcpetionResolutionModel {
  issueAirline: string;
  airlineType: string;
  countryCode: string;
  exceptionCode: string;
  exceptionType: string;
  ticketNumber: string;
  exceptionDesc: string;
  aging: number;
  exceptionDate: string;
  moduleLovId: number;
  moduleName: string;
  exceptionSeverity: string;
  parameterValue: string;
  parameterName: string;
  exceptionTransactionId: string;
  clientId: string;
  orderId: number;
  issuedCarrier: string;
  documentNumber: string;
  couponNumber: number;
  documentUniqueId: string;
  fileId: number;
  fileTypeMapping: string;
  parametersValueList: any;
  createdBy: string;
  lastUpdatedBy: string;
  createdDate: string;
  lastUpdatedDate: string;
  transactionIds: any;
  groupId: number;
  teamId: number;
  userId: number;
  reassign: boolean;
  assignedDate: string;
  assignedBy: string;
  assignedType: string;
  expStatus: string;
  flightDatePeriod: string;
  flightNumberRange: string;
  fromRegion: string;
  toRegion: string;
  issuePeriod: string;
  reportingPeriod: string;
  reportingAgency: string;
  saleAgency: string;
  placeOfSale: string;
  exceptionFromDate: string;
  exceptionToDate: string;
  billingMonthPeriod: string;
  issueDatePeriod: string;
  zone: string;
  billingCarrier: string;
  ichAch: string;
}


export function exceptionTypes() {
  return {
    "open_exception": "OPEN",
    "assigned_execption": "ASSIGNED",
    "closed_execption": "CLOSED"
  }
}

export function getModuleCodeMap(lovData: any, key: any) {
  let lovName: any = _.find(lovData, {"lovId": key});
  let moduleCodeMap = {
    "Sales": "SALE",
    "Sale": "SALE",
    "Flown": "FLOWN",
    "Inward":"INWARD",
    "Interline": "INTERLINE",
    "Others": "OTHER",
    "Outward":"OUTWARD",
    "Miscellaneous":"MISC"
  };
  return moduleCodeMap[lovName.fieldShortDescription];
}

export function filterOtherModuleKeys(searchParams: any) {
  for (let param in searchParams) {
    if (searchParams.moduleName == ExceptionConstant.SALE && !ExceptionConstant.SALE_PARAMS.includes(param)) {
      delete searchParams[param];
    } else if (searchParams.moduleName == ExceptionConstant.FLOWN && !ExceptionConstant.FLOWN_PARAMS.includes(param)) {
      delete searchParams[param];
    }
    if (searchParams[param] instanceof Date) {
      const datePipe = new DatePipe('en-US');
      searchParams[param] = datePipe.transform(searchParams[param], ExceptionConstant.SIMPLE_DATE_FORMAT);
    }
  }
  return searchParams;
}

export function getExceptionForm() {
  return {
    moduleId: ['', [Validators.required]],
    moduleName: [''],
    exceptionStatus: [null],
    exceptionSeverity: ['', [Validators.required]],
    fromDate: [null],
    toDate: [null],
    sortOrder: ['', [Validators.required]],
    documentUniqueId: [null],
    batchType: [null],
    batchNumber: [null],
    reportingCurrency: [null],
    fromReportingPeriod: [null],
    toReporingPeriod: [null],
    flightNumber: [null],
    fromAirport: [null],
    toAirport: [null],
    upliftStation: [null],
    departureDate: [null],
    flightCreationDate: [null],
    exceptionCode: [null],
    exceptionCategory: [null],
    exceptionType: [null],
    airlineType: [null],
    environment: [null],
    aging: [null],
    billingCarrier:[null],
    billedCarrier:[null],
    sourceCode:[null],
    invoiceNo:[null],
    invoiceDate:[null],
    billingDate:[null],
    chargeCategory:[null]

  };
}

export function getUserForm() {
  return {
    groupId: ['', [Validators.required]],
    teamId: ['', [Validators.required]],
    userId: [],
  };
}

export function getExceptionDateConfig() {
  return {
    displayFormat: 'YYYY/MM/DD',
    format: 'YYYY/MM/DD',
    useEmptyBarTitle: false,
    addClass: 'currency-date-picker',
    fieldId: 'currency-date-picker-id',
    addStyle: {'width': '100%'},
    maxDate: new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0),
  };
}

export function ModulesEnum() {
  return {
    'SALES': 'SALE',
    'FLOWN': 'FLOWN',
    'INWARD':'INWARD',
    'INTERLINE': 'INTERLINE',
    'OTHERS': 'OTHERS',
    'OUTWARD':'OUTWARD',
    "MISC":"MISC"
  }
}


export const ExceptionStatus = {
  OPEN: 'OPEN',
  ASSIGNED: 'ASSIGNED',
  CLOSED: 'CLOSED'
};

export function getExceptionValidationMessage() {

  return {
    'moduleId': [
      {type: 'required', message: 'Please select a module'},
    ],
    'exceptionStatus': [
      {type: 'required', message: 'Please select a Exception Status'},
    ],
    'exceptionSeverity': [
      {type: 'required', message: 'Please select a Severity'},
    ],
    'fromDate': [
      {type: 'required', message: 'Please select a from date'},
    ],
    'toDate': [
      {type: 'required', message: 'Please select a to date'}
    ],
    'sortOrder': [
      {type: 'required', message: 'Please select a Aging'}
    ]
  }
}

export function getAssignExceptionErrorMsg() {

  return {
    'groupId': [
      {type: 'required', message: 'Please select a group'},
    ],
    'teamId': [
      {type: 'required', message: 'Please select a team'},
    ],
    'userId': [
      {type: 'required', message: 'Please select a user'},
    ]
  }
}
