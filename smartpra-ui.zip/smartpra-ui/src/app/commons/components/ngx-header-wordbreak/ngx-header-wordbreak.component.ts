import {Component, OnInit, Input, ElementRef, ViewChild, AfterViewInit} from '@angular/core';
import { setTime } from 'ngx-bootstrap/chronos/utils/date-setters';

@Component({
  selector: 'app-ngx-header-wordbreak',
  templateUrl: './ngx-header-wordbreak.component.html',
  styleUrls: ['./ngx-header-wordbreak.component.css']
})
export class NgxHeaderWordbreakComponent implements OnInit ,AfterViewInit{
  @ViewChild('breakname') breakname: ElementRef;
  constructor() {
    
   }
	@Input() sortDir:string;
	@Input() sortable:boolean;
	@Input() headerName:string;
  name:string=" ";
  ngOnInit() {
  }
  ngAfterViewInit(){
    setTimeout(()=>{
      this.name = this.headerName.replace("<br>", " ");
    },100)
    
    this.breakname.nativeElement.innerHTML = this.headerName;
  }

}
