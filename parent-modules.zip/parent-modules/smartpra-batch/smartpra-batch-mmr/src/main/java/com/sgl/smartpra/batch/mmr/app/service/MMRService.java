package com.sgl.smartpra.batch.mmr.app.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.global.model.FileErrorLog;
import com.sgl.smartpra.batch.global.model.FileLogging;
import com.sgl.smartpra.batch.global.model.RecordErrorLog;
import com.sgl.smartpra.batch.mmr.app.config.FeignConfiguration.BatchGlobalFeignClient;
import com.sgl.smartpra.batch.mmr.app.config.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.batch.mmr.app.utils.MMRCommonUtil;
import com.sgl.smartpra.batch.mmr.app.utils.MMRConstants;
import com.sgl.smartpra.common.util.FileLoggingConstants;

@Component
public class MMRService {

	private static final Logger LOGGER = LoggerFactory.getLogger(MMRService.class);

	@Autowired
	JobLauncher jobLauncher;

	@Autowired
	@Qualifier(value = "importMmrJob")
	Job importMmrJob;

	@Autowired
	SmartpraMasterAppClient smartpraMasterAppClient;

	@Autowired
	BatchGlobalFeignClient batchGlobalFeignClient;

	@Value("${batch.directory.mmr.failed}")
	private String failedDir;

	@Value("${batch.directory.mmr.input}")
	private String inputDir;

	@Value("${batch.directory.mmr.duplicate}")
	private String duplicateDir;

	public String executeMMRStgInboundJob(String fileName, String processedBy) throws Exception {

		LOGGER.info("MMRService : executeProvisoStgInboundJob");

		String clientId = MMRCommonUtil.getHostCarrierDesigCode(smartpraMasterAppClient);

		clientId = StringUtils.isEmpty(clientId) ? MMRConstants.DEFAULT_CLIENT_ID : clientId;

		LOGGER.info("MMRService : clientId : " + clientId);

		FileLogging fileLogging = MMRCommonUtil.initFileLogging();

		fileLogging.setInterfaceType(FileLoggingConstants.FILELOGGING_INTERFACE_INPUT);
		fileLogging.setFileName(fileName);
		fileLogging.setProcessedBy(processedBy);
		fileLogging.setFileType(MMRConstants.FILELOGGING_FILETYPE_MMR_IN);
		fileLogging.setClientId(clientId);
		fileLogging.setJobName(importMmrJob.getName());

		FileErrorLog fileErrorLog;
		List<FileErrorLog> fileErrorLogList;

		List<FileLogging> fileList = batchGlobalFeignClient.getFileLogByFileName(fileName);

		if (CollectionUtils.isNotEmpty(fileList)) {
			String tmpName = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
			String errorMsg = "File with same name " + fileName + " has been already loaded in system with file id "
					+ fileList.get(0).getFileId();

			MMRCommonUtil.moveFile(inputDir + fileName, duplicateDir + fileName + tmpName);
			fileLogging.setIsMovedToRelevantFolder("Y");
			fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_TECHFAILED);
			fileLogging.setClientId(clientId);
			fileLogging.setRemarks(errorMsg);
			fileErrorLog = new FileErrorLog();
			fileErrorLog.setFileId(fileLogging.getFileId());
			fileErrorLog.setErrorDetail("Invalid File Input");
			fileErrorLog.setErrorDescription(errorMsg);
			fileErrorLogList = new ArrayList<>();
			fileErrorLogList.add(fileErrorLog);
			fileLogging.setFileErrorLog(fileErrorLogList);
			fileLogging = batchGlobalFeignClient.createFileLog(fileLogging);
			return errorMsg;
		}

		// Validate file
		String valdationMessage = MMRCommonUtil.validateFile(inputDir + fileName);
		if (StringUtils.isNotEmpty(valdationMessage)) {
			String tmpName = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
			MMRCommonUtil.moveFile(inputDir + fileName, failedDir + fileName + tmpName);
			fileLogging.setIsMovedToRelevantFolder("Y");
			fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_TECHFAILED);
			fileLogging.setClientId(clientId);
			fileLogging.setRemarks(valdationMessage);
			fileErrorLog = new FileErrorLog();
			fileErrorLog.setFileId(fileLogging.getFileId());
			fileErrorLog.setErrorDetail("Invalid File Input");
			fileErrorLog.setErrorDescription(valdationMessage);
			fileErrorLogList = new ArrayList<>();
			fileErrorLogList.add(fileErrorLog);
			fileLogging.setFileErrorLog(fileErrorLogList);
			fileLogging = batchGlobalFeignClient.createFileLog(fileLogging);
			return valdationMessage;
		}

		Map<String, Object> recordMap = MMRCommonUtil.getFileHeader(inputDir + fileName);
		RecordErrorLog recordErrorLog;
		List<RecordErrorLog> recordErrorLogList;
		// Header validation
		if (recordMap.isEmpty()) {
			String tmpName = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());

			String errorMsg = "Input file " + fileName + " error in header ";
			MMRCommonUtil.moveFile(inputDir + fileName, failedDir + fileName + tmpName);

			fileLogging.setIsMovedToRelevantFolder("Y");
			fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_TECHFAILED);
			fileLogging.setRemarks(errorMsg);
			recordErrorLog = new RecordErrorLog();
			recordErrorLog.setRecordNumber(0);
			recordErrorLog.setRecordValue("Header");
			recordErrorLog.setRecordStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_TECHFAILED);
			recordErrorLog.setFileId(fileLogging.getFileId());
			recordErrorLog.setErrorDetail("Invalid File Input");
			recordErrorLog.setErrorDescription(errorMsg);
			recordErrorLogList = new ArrayList<>();
			recordErrorLogList.add(recordErrorLog);
			fileLogging.setRecordErrorLog(recordErrorLogList);
			fileLogging = batchGlobalFeignClient.createFileLog(fileLogging);
			return errorMsg;
		}

		fileLogging = batchGlobalFeignClient.createFileLog(fileLogging);

		JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis())
				.addString("fileName", fileName).addString("clientId", clientId)
				.addLong("fileId", fileLogging.getFileId().longValue()).toJobParameters();
		jobLauncher.run(importMmrJob, jobParameters);

		return "Batch job has been invoked";
	}
}
