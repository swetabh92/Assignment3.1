import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import swal from 'sweetalert2';

import { environment } from '../../../../environments/environment';
import { Modules } from '../models/modules';
import { MessageBoxService } from '../../masters/services/commons/message-box.service';
const httpOptions = {
 // headers: new HttpHeaders({ 'Content-Type': 'multipart/form-data' })
};
const httpOptions1 = {
  headers: new HttpHeaders({ 'Content-Type': 'multipart/form-data' })
 };

@Injectable({
  providedIn: 'root'
})
export class ModulesService {
  globalUrl = environment.apiUrlGlobal;
  masterUrl = environment.apiUrlMaster;
  authUrl = environment.apiUrlauth;
  constructor(private http: HttpClient, private messageBoxService: MessageBoxService) { }
  getModulesAll(): Observable<Modules[]> {
    return this.http.get<Modules[]>(this.authUrl + 'mas-modules')
      .pipe(
        tap(_ => this.log('fetched Modules details')),
        catchError(this.handleError('getAllModules', []))
      );
  }
  ModulesByModulesId(masModuleId: string): Observable<Modules> {
    return this.http.get<Modules>(this.authUrl + 'mas-modules/' + masModuleId).pipe(
      tap(_ => this.log(`fetched Modules masModuleId=${masModuleId}`)),
      catchError(this.handleError<Modules>(`ModulesByModulesId masModuleId=${masModuleId}`))
    );
  }
  searchModules(parms: string): Observable<Modules> {
    return this.http.get<Modules>(this.authUrl + parms).pipe(
      tap(_ => this.log(`search Modules masModuleId by ${parms}`)),
      catchError(this.handleError<Modules>(`search Modules masModuleId by ${parms}`))
    );
  }
  /** POST: add a new Modules to the server */
  addModules(formdata): Observable<Modules> {
    // console.log(formdata); return;
    return this.http.post<Modules>(this.authUrl + 'mas-modules/', formdata, httpOptions).pipe(
      tap(_ => this.log(`added Modules masModuleId=`)),
      catchError(this.handleError<Modules>('addModules'))
    );
  }
  updateModules(modules: Modules): Observable<any> {
   // console.log(Modules.masModuleId);
    // console.log(Modules);
    return this.http.put<Modules>(this.authUrl + 'mas-modules/' + modules.masModuleId, Modules, httpOptions).pipe(
      tap(_ => this.log(`updated Modules masModuleId=${modules.masModuleId}`)),
      catchError(this.handleError<Modules>('addModules'))
    );
  }
  activateModules(masModuleId: string): Observable<Modules> {
    return this.http.put<Modules>(this.authUrl + 'mas-modules/activateordeactivate/' + masModuleId , httpOptions).pipe(
      tap(_ => this.log(`activate Modules masModuleId=${masModuleId}`)),
      catchError(this.handleError<Modules>('activateModules'))
    );
  }
  deactivateModules(masModuleId: string): Observable<Modules> {
    return this.http.put<Modules>(this.authUrl + 'mas-modules/activateordeactivate/' + masModuleId , httpOptions).pipe(
      tap(_ => this.log(`deactivate Modules masModuleId=${masModuleId}`)),
      catchError(this.handleError<Modules>('deactvateModules'))
    );
  }
  private handleError<T>(operation = 'operation', result?: T) {
    return (e: any): Observable<T> => {
      console.log(e);
      const error = e.error.message || e.error.error || e.error.error_description || 'Could not connect server';
      console.log(error);
      this.messageBoxService.getErrorMessage('ERROR', error);
      return of(result as T);
    };
  }
  private log(error: any) {
    console.log(error);
    if (error.message) {
      this.messageBoxService.getErrorMessage('ERROR', error.message);
    }
  }

}


