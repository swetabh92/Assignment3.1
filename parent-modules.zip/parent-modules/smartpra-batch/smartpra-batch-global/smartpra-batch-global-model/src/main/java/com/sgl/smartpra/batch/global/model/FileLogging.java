package com.sgl.smartpra.batch.global.model;

import java.io.Serializable;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.sgl.smartpra.common.model.BaseMaster;

@JsonInclude(Include.NON_NULL)
public class FileLogging extends BaseMaster implements Serializable {

	private static final long serialVersionUID = 2426242363252501332L;

	private BigInteger fileId;

	private String clientId;

	private String interfaceType;

	private String fileCategory;

	private String fileName;

	private String processedBy;

	private String fileStatus;

	private Timestamp scheduleDateTime;

	private Timestamp startDateTime;

	private Timestamp endDateTime;

	private Integer totalCounts;

	private Integer headerCounts;

	private Integer detailCounts;

	private Integer errorCounts;

	private Integer transferredCounts;

	private String fileSize;

	private String moduleName;

	private Integer moduleId;

	private Integer skippedRecordCount;

	private String fileType;

	private String cityCode;

	private String source;

	private String isEncryptedPostSuccess;

	private String isEncryptedPriorLoading;

	private String isRenamedPostSuccess;

	private String isMovedToRelevantFolder;

	private String isNotificationSent;

	private String remarks;

	private String jobName;

	private List<FieldErrorLog> fieldErrorLog;

	private List<FileErrorLog> fileErrorLog;

	private List<RecordErrorLog> recordErrorLog;

	public Integer getSkippedRecordCount() {
		return skippedRecordCount;
	}

	public void setSkippedRecordCount(Integer skippedRecordCount) {
		this.skippedRecordCount = skippedRecordCount;
	}

	public BigInteger getFileId() {
		return fileId;
	}

	public void setFileId(BigInteger fileId) {
		this.fileId = fileId;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getInterfaceType() {
		return interfaceType;
	}

	public void setInterfaceType(String interfaceType) {
		this.interfaceType = interfaceType;
	}

	public String getFileCategory() {
		return fileCategory;
	}

	public void setFileCategory(String fileCategory) {
		this.fileCategory = fileCategory;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getProcessedBy() {
		return processedBy;
	}

	public void setProcessedBy(String processedBy) {
		this.processedBy = processedBy;
	}

	public String getFileStatus() {
		return fileStatus;
	}

	public void setFileStatus(String fileStatus) {
		this.fileStatus = fileStatus;
	}

	public Timestamp getScheduleDateTime() {
		return scheduleDateTime;
	}

	public void setScheduleDateTime(Timestamp scheduleDateTime) {
		this.scheduleDateTime = scheduleDateTime;
	}

	public Timestamp getStartDateTime() {
		return startDateTime;
	}

	public void setStartDateTime(Timestamp startDateTime) {
		this.startDateTime = startDateTime;
	}

	public Timestamp getEndDateTime() {
		return endDateTime;
	}

	public void setEndDateTime(Timestamp endDateTime) {
		this.endDateTime = endDateTime;
	}

	public Integer getTotalCounts() {
		return totalCounts;
	}

	public void setTotalCounts(Integer totalCounts) {
		this.totalCounts = totalCounts;
	}

	public Integer getHeaderCounts() {
		return headerCounts;
	}

	public void setHeaderCounts(Integer headerCounts) {
		this.headerCounts = headerCounts;
	}

	public Integer getDetailCounts() {
		return detailCounts;
	}

	public void setDetailCounts(Integer detailCounts) {
		this.detailCounts = detailCounts;
	}

	public Integer getErrorCounts() {
		return errorCounts;
	}

	public void setErrorCounts(Integer errorCounts) {
		this.errorCounts = errorCounts;
	}

	public Integer getTransferredCounts() {
		return transferredCounts;
	}

	public void setTransferredCounts(Integer transferredCounts) {
		this.transferredCounts = transferredCounts;
	}

	public String getFileSize() {
		return fileSize;
	}

	public void setFileSize(String fileSize) {
		this.fileSize = fileSize;
	}

	public Integer getModuleId() {
		return moduleId;
	}

	public void setModuleId(Integer moduleId) {
		this.moduleId = moduleId;
	}

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public String getCityCode() {
		return cityCode;
	}

	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getIsEncryptedPostSuccess() {
		return isEncryptedPostSuccess;
	}

	public void setIsEncryptedPostSuccess(String isEncryptedPostSuccess) {
		this.isEncryptedPostSuccess = isEncryptedPostSuccess;
	}

	public String getIsEncryptedPriorLoading() {
		return isEncryptedPriorLoading;
	}

	public void setIsEncryptedPriorLoading(String isEncryptedPriorLoading) {
		this.isEncryptedPriorLoading = isEncryptedPriorLoading;
	}

	public String getIsRenamedPostSuccess() {
		return isRenamedPostSuccess;
	}

	public void setIsRenamedPostSuccess(String isRenamedPostSuccess) {
		this.isRenamedPostSuccess = isRenamedPostSuccess;
	}

	public String getIsMovedToRelevantFolder() {
		return isMovedToRelevantFolder;
	}

	public void setIsMovedToRelevantFolder(String isMovedToRelevantFolder) {
		this.isMovedToRelevantFolder = isMovedToRelevantFolder;
	}

	public String getIsNotificationSent() {
		return isNotificationSent;
	}

	public void setIsNotificationSent(String isNotificationSent) {
		this.isNotificationSent = isNotificationSent;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public List<FieldErrorLog> getFieldErrorLog() {
		return fieldErrorLog;
	}

	public void setFieldErrorLog(List<FieldErrorLog> fieldErrorLog) {
		this.fieldErrorLog = fieldErrorLog;
	}

	public List<FileErrorLog> getFileErrorLog() {
		return fileErrorLog;
	}

	public void setFileErrorLog(List<FileErrorLog> fileErrorLog) {
		this.fileErrorLog = fileErrorLog;
	}

	public List<RecordErrorLog> getRecordErrorLog() {
		return recordErrorLog;
	}

	public void setRecordErrorLog(List<RecordErrorLog> recordErrorLog) {
		this.recordErrorLog = recordErrorLog;
	}

}
