package com.sgl.smartpra.batch.bhr.app.listener;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.bhr.app.config.FeignConfiguration.BatchGlobalFeignClient;
import com.sgl.smartpra.batch.bhr.app.util.BHRCommonUtil;
import com.sgl.smartpra.batch.bhr.app.util.BHRConstants;
import com.sgl.smartpra.batch.bhr.app.util.BHRCountReader;
import com.sgl.smartpra.batch.global.model.FileErrorLog;
import com.sgl.smartpra.batch.global.model.FileLogging;
import com.sgl.smartpra.common.util.FileLoggingConstants;
import com.sgl.smartpra.common.util.SmartpraFileUtility;

@Component
public class JobCompletionNotificationListener extends JobExecutionListenerSupport {

	private static final Logger LOGGER = LoggerFactory.getLogger(JobCompletionNotificationListener.class);

	@Value("${batch.directory.bhr.processed}")
	private String processedDir;

	@Value("${batch.directory.bhr.input}")
	private String inputDir;

	@Value("${batch.directory.bhr.failed}")
	private String failedDir;

	@Autowired
	BatchGlobalFeignClient batchGlobalFeignClient;

	@Override
	public void afterJob(JobExecution jobExecution) {
		StepExecution stepExecution = jobExecution.getStepExecutions().stream().findAny().get();

		// Integer totalCount = stepExecution.getReadCount();
		Integer totalCount = BHRCountReader.getTotalCount();
		JobParameters jobParameters = jobExecution.getJobParameters();
		Integer errorCount = BHRCountReader.getErrorCount();
		Integer transferCount = BHRCountReader.getTransferCount();

		// Integer errorCount =
		// (Integer)stepExecution.getExecutionContext().get("errorCount") != null ?
		// (Integer)stepExecution.getExecutionContext().get("errorCount") : 0;
		long fileId = jobParameters.getLong("fileId");
		String fileName = jobParameters.getString("fileName");

		FileLogging fileLogging = batchGlobalFeignClient.getFileLogByFileId(BigInteger.valueOf(fileId));
		fileName = StringUtils.isNotEmpty(fileName) ? fileName : fileLogging.getFileName();
		if (jobExecution.getStatus() == BatchStatus.COMPLETED) {
			fileLogging.setEndDateTime(new Timestamp(new Date().getTime()));
			fileLogging.setTotalCounts(totalCount);
			fileLogging.setHeaderCounts(0);
			fileLogging.setDetailCounts(totalCount);
			fileLogging.setTransferredCounts(transferCount);
			fileLogging.setErrorCounts(errorCount);
			fileLogging.setJobName(stepExecution.getStepName());
			fileLogging.setFileSize(
					StringUtils.isEmpty(fileLogging.getFileSize()) ? BHRCommonUtil.getFileSize(inputDir + fileName)
							: fileLogging.getFileSize());

			if (BHRConstants.PROD_JOB_NAME.equals(stepExecution.getStepName())) {
				if (transferCount == totalCount) {
					fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_TRANSFERRED);
				} else if (errorCount == totalCount) {
					fileLogging.setTotalCounts(totalCount);
					fileLogging.setDetailCounts(0);
					fileLogging.setTransferredCounts(0);
					fileLogging.setErrorCounts(totalCount);
					fileLogging.setJobName(stepExecution.getStepName());
					fileLogging.setFileSize(StringUtils.isEmpty(fileLogging.getFileSize())
							? BHRCommonUtil.getFileSize(inputDir + fileName)
							: fileLogging.getFileSize());
					fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_ERRONEOUS);
					fileLogging.setRemarks(FileLoggingConstants.FILELOGGING_FAILED_REMARK);
					FileErrorLog fileErrorLog = new FileErrorLog();
					fileErrorLog.setFileId(fileLogging.getFileId());
					fileErrorLog.setErrorDetail(jobExecution.getStatus().toString());
					fileErrorLog.setErrorDescription(jobExecution.getFailureExceptions().toString());
					ArrayList<FileErrorLog> fileErrorLogList = new ArrayList<>();
					fileErrorLogList.add(fileErrorLog);
					fileLogging.setFileErrorLog(fileErrorLogList);
					String tmpName = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
					BHRCommonUtil.moveFile(inputDir + fileName, failedDir + fileName + tmpName);

					fileLogging.setIsMovedToRelevantFolder("Y");
					LOGGER.info("!!! JOB FINISHED -FAILED ! Time to verify the results");
				} else {
					fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_PARTTRANSFERRED);
				}
				if (SmartpraFileUtility.fileExists(inputDir + fileName)) {
					BHRCommonUtil.moveFile(inputDir + fileName, processedDir + fileName);
					LOGGER.info("!!! JOB FINISHED! Time to verify the results");
				}
				fileLogging.setIsMovedToRelevantFolder("Y");
			}

		} else {
			fileLogging.setTotalCounts(totalCount);
			fileLogging.setDetailCounts(0);
			fileLogging.setTransferredCounts(0);
			fileLogging.setErrorCounts(totalCount);
			fileLogging.setJobName(stepExecution.getStepName());
			fileLogging.setFileSize(
					StringUtils.isEmpty(fileLogging.getFileSize()) ? BHRCommonUtil.getFileSize(inputDir + fileName)
							: fileLogging.getFileSize());
			fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_ERRONEOUS);
			fileLogging.setRemarks(FileLoggingConstants.FILELOGGING_FAILED_REMARK);
			FileErrorLog fileErrorLog = new FileErrorLog();
			fileErrorLog.setFileId(fileLogging.getFileId());
			fileErrorLog.setErrorDetail(jobExecution.getStatus().toString());
			fileErrorLog.setErrorDescription(jobExecution.getFailureExceptions().toString());
			ArrayList<FileErrorLog> fileErrorLogList = new ArrayList<>();
			fileErrorLogList.add(fileErrorLog);
			fileLogging.setFileErrorLog(fileErrorLogList);
			String tmpName = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
			BHRCommonUtil.moveFile(inputDir + fileName, failedDir + fileName + tmpName);

			fileLogging.setIsMovedToRelevantFolder("Y");
			LOGGER.info("!!! JOB FINISHED -FAILED ! Time to verify the results");
		}
		fileLogging = batchGlobalFeignClient.updateFileLog(BigInteger.valueOf(fileId), fileLogging);

	}

}