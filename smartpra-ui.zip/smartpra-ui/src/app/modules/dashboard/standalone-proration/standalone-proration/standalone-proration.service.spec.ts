import { TestBed } from '@angular/core/testing';

import { StandaloneProrationService } from './standalone-proration.service';

describe('StandaloneProrationService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: StandaloneProrationService = TestBed.get(StandaloneProrationService);
    expect(service).toBeTruthy();
  });
});
