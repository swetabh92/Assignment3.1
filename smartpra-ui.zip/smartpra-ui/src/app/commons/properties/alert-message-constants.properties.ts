export const AlertMessageConstants = {
    CLOSE_ALERT_TIME : 6000,
}