package com.sgl.smartpra.batch.amadeus.app.utils;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.amadeus.app.common.AppConstants;
import com.sgl.smartpra.batch.amadeus.app.config.FeignConfiguration.MasterFeignClient;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusRecordStaging;
import com.sgl.smartpra.batch.global.model.FileLogging;
import com.sgl.smartpra.common.util.FileLoggingConstants;
import com.sgl.smartpra.common.util.SmartPRACommonUtil;
import com.sgl.smartpra.exception.txn.enums.EnvironmentEnum;
import com.sgl.smartpra.exception.txn.enums.ExceptionStatusEnum;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.master.model.SystemParameter;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Component
public class AmadeusCommonUtils {

	public static String getHostCarrierDesigCode(MasterFeignClient masterFeignClient) {
		String hostCarrierDesigCode = null;
		ArrayList<SystemParameter> systemParameterList = (ArrayList<SystemParameter>) masterFeignClient
				.getSystemParameterByparameterName(AppConstants.PARAM_DEFAULT_CARRIER_ALPHA_CODE);
		if (systemParameterList != null && !systemParameterList.isEmpty()) {
			hostCarrierDesigCode = systemParameterList.get(0).getParameterRangeFrom().get();
		}
		return hostCarrierDesigCode;
	}

	public static String getHostCarrierCode(MasterFeignClient masterFeignClient) {
		String hostCarrierCode = null;
		ArrayList<SystemParameter> systemParameterList = (ArrayList<SystemParameter>) masterFeignClient
				.getSystemParameterByparameterName(AppConstants.PARAM_DEFAULT_CARRIER_NUMERIC_CODE);
		if (systemParameterList != null && !systemParameterList.isEmpty()) {
			hostCarrierCode = systemParameterList.get(0).getParameterRangeFrom().get();
		}

		return hostCarrierCode;
	}

	/*
	 * public static Date getFromDate(MasterFeignClient masterFeignClient) throws
	 * ParseException { Date fromDate = null; ArrayList<SystemParameter>
	 * systemParameterList = (ArrayList<SystemParameter>) masterFeignClient
	 * .getSystemParameterByparameterName(AppConstants.ONEWORLD_MIGRATION_PERIOD);
	 * if (systemParameterList != null && !systemParameterList.isEmpty()) { fromDate
	 * = dateFormat.parse(systemParameterList.get(0).getEffectiveFromDate().get());
	 * }
	 * 
	 * return fromDate; }
	 * 
	 * public static Date getToDate(MasterFeignClient masterFeignClient) throws
	 * ParseException { Date toDate = null; // DateFormat dateFormat = new
	 * SimpleDateFormat("yyyy-MM-dd"); ArrayList<SystemParameter>
	 * systemParameterList = (ArrayList<SystemParameter>) masterFeignClient
	 * .getSystemParameterByparameterName(AppConstants.ONEWORLD_MIGRATION_PERIOD);
	 * if (systemParameterList != null && !systemParameterList.isEmpty()) { toDate =
	 * dateFormat.parse(systemParameterList.get(0).getEffectiveToDate().get()); }
	 * 
	 * return toDate; }
	 */

	public static String validateDtRequestOut(MasterFeignClient masterFeignClient) throws ParseException {
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date toDate = null;
		Date fromDate = null;
		Date currentDate = new Date();
		String flag = AppConstants.FLAG_N;
		ArrayList<SystemParameter> systemParameterList = (ArrayList<SystemParameter>) masterFeignClient
				.getSystemParameterByparameterName(AppConstants.ONEWORLD_MIGRATION_PERIOD);
		if (systemParameterList != null && !systemParameterList.isEmpty()) {
			fromDate = dateFormat.parse(systemParameterList.get(0).getEffectiveFromDate().get());
			toDate = dateFormat.parse(systemParameterList.get(0).getEffectiveToDate().get());
			if (currentDate.after(fromDate) && currentDate.before(toDate)) {
				flag = AppConstants.FLAG_Y;
			}

		}
		return flag;

	}

	public static String getFlightNumberOption(MasterFeignClient masterFeignClient) {
		String flightNumberLength = null;
		ArrayList<SystemParameter> systemParameterList = (ArrayList<SystemParameter>) masterFeignClient
				.getSystemParameterByparameterName(AppConstants.PARAM_FLIGHT_NUMBER_OPTION);
		if (systemParameterList != null && !systemParameterList.isEmpty()) {
			flightNumberLength = systemParameterList.get(0).getParameterRangeFrom().get();
		}
		return flightNumberLength;
	}

	/**
	 * This method will initialize the filelogging object with basic data.
	 * 
	 * @return
	 */
	public static FileLogging initFileLogging() {
		FileLogging fileLogging = new FileLogging();
		fileLogging.setFileCategory(FileLoggingConstants.FILELOGGING_FILECATEGORY_TEXT);
		fileLogging.setScheduleDateTime(new Timestamp(new Date().getTime()));
		fileLogging.setStartDateTime(new Timestamp(new Date().getTime()));
		fileLogging.setSource(FileLoggingConstants.FILELOGGING_SOURCE_AMADEUS);
		fileLogging.setCreatedBy(FileLoggingConstants.FILELOGGING_CREATEDBY_AMADEUS);
		fileLogging.setCreatedDate(new Timestamp(new Date().getTime()));
		fileLogging.setModuleId(FileLoggingConstants.FILELOGGING_MODULEID_AMADEUS);

		// may not be mandatory
		fileLogging.setInterfaceType(FileLoggingConstants.FILELOGGING_INTERFACE_INPUT);
		fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_STARTED);
		//fileLogging.setEndDateTime(new Timestamp(new Date().getTime()));
		fileLogging.setTotalCounts(0);
		fileLogging.setHeaderCounts(0);
		fileLogging.setDetailCounts(0);
		fileLogging.setErrorCounts(0);
		fileLogging.setTransferredCounts(0);
		fileLogging.setIsEncryptedPostSuccess("N");
		fileLogging.setIsEncryptedPriorLoading("N");
		fileLogging.setIsRenamedPostSuccess("N");
		fileLogging.setIsMovedToRelevantFolder("N");
		fileLogging.setIsNotificationSent("N");
		return fileLogging;
	}

	public static ExceptionTransactionModel initExceptionTransactionModel(AmadeusRecordStaging amadeusRecordStaging,
			String documentUniqueId) {
		ExceptionTransactionModel exceptionTransactionModel = new ExceptionTransactionModel();
		exceptionTransactionModel.setOrderId(2);// for future use
		// exceptionTransactionModel.setEnvironment(EnvironmentEnum.Production);
		exceptionTransactionModel.setEnvironment("S");
		// exceptionTransactionModel.setExceptionStatus(ExceptionStatusEnum.FAILED);
		// exceptionTransactionModel.setExceptionTime(new Timestamp(new
		// Date().getTime()));
		exceptionTransactionModel.setExceptionTransactionId(1L);
		// exceptionTransactionModel.setExceptionType("E");
		exceptionTransactionModel.setCreatedBy(amadeusRecordStaging.getCreatedBy());
		LocalDateTime dateTime = LocalDateTime.now();
		dateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSSSS"));
		exceptionTransactionModel.setExceptionDate(dateTime);
		exceptionTransactionModel.setFileId(Long.valueOf(amadeusRecordStaging.getFileId()));
		exceptionTransactionModel.setIssuedCarrier(amadeusRecordStaging.getIssAirline());
		if (amadeusRecordStaging.getUsageDocNumber() != null) {
			exceptionTransactionModel.setMainDocument(amadeusRecordStaging.getUsageDocNumber().substring(0, 10));
		}
		exceptionTransactionModel.setDocumentNumber(amadeusRecordStaging.getDocumentNumber());
		//exceptionTransactionModel.setDateOfIssue(SmartPRACommonUtil.convertStrToLocalDate(amadeusRecordStaging.getIssueDate(), "ddMMyy"));
		exceptionTransactionModel.setDocumentUniqueId(documentUniqueId);
		exceptionTransactionModel.setStagingReferenceId((long) amadeusRecordStaging.getAmadeusLoadId());
		
		if (amadeusRecordStaging.getCouponNumber() != null
				&& amadeusRecordStaging.getCouponNumber().trim().length() > 0) {
			exceptionTransactionModel.setCouponNumber(Integer.parseInt(amadeusRecordStaging.getCouponNumber()));
		}
		return exceptionTransactionModel;
	}

	public static String convDateFormat(String dtStr, String dtCurrFormat, String dtNewFormat) {
		DateTimeFormatter dtFormatterCurr = DateTimeFormatter.ofPattern(dtCurrFormat);
		DateTimeFormatter dtFormatterNew = DateTimeFormatter.ofPattern(dtNewFormat);
		if (dtStr != null && dtStr.trim().length() > 0) {
			LocalDateTime ldateTime = LocalDate.parse(dtStr, dtFormatterCurr).atStartOfDay();
			return dtFormatterNew.format(ldateTime);
		} else {
			return dtStr;
		}
	}

}
