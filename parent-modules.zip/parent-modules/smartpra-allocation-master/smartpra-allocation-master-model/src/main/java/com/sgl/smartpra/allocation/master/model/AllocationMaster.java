package com.sgl.smartpra.allocation.master.model;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.sgl.smartpra.common.model.BaseModel;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@JsonInclude(Include.NON_NULL)
public class AllocationMaster extends BaseModel {

	private static final long serialVersionUID = -3506522756218990473L;

	private Integer allocationMasterId;

	@NotNull
	private Long moduleLovId;

	@NotNull
	private String clientId;

	@NotNull
	private Integer groupId;

	@NotNull
	private Integer teamId;

}
