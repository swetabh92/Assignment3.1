﻿import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, CanLoad } from '@angular/router';
import { Cookie } from 'ng2-cookies';
@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate , CanLoad {

    constructor(private router: Router) { }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot):boolean {
        // return true; // comment this line for authentication
        const access = localStorage.getItem('access_token');
        if (access) {
            // logged in so return true
            return true;
        }
        // not logged in so redirect to login page with the return url
        this.router.navigate(['/login'], { queryParams: { returnUrl: state.url } });
        return false;
    }

    canLoad() {
        const access = localStorage.getItem('access_token');        
        if (access) {
            return true;
        } else {
            this.router.navigate(['/login']);
            return false;
        }
    }
}
