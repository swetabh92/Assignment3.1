import {Component, OnInit, Output, EventEmitter, ViewChild, ElementRef} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {GeneralService} from '../../../../commons/services/general.service';
import {InwardDashboardService} from '../inward-dashboard.service';
import {DatePipe} from '@angular/common';
import { BsDatepickerConfig, BsDatepickerViewMode } from 'ngx-bootstrap/datepicker';
import { InterlineConstant } from '../constants/interline-constants';

declare var moment: any;


@Component({
  selector: 'app-inward-search',
  templateUrl: './inward-search.component.html',
  styleUrls: ['../inward-dashboard.component.css']
})
export class InwardSearchComponent implements OnInit {
  searchDownArrow:boolean = true;
  submittedSearch:boolean = false;
  searchInwardForm: FormGroup;
  minMode: BsDatepickerViewMode = 'month';
  bsConfig: Partial<BsDatepickerConfig>;
  maxDate = new Date(Date.now());
  @Output() inwardSearchParams = new EventEmitter<any>();
  zonesDatas: any;
  carriers: any;
  currentBillingMonth: string;
  @ViewChild('carrier_name') carrier_name: ElementRef;
  constructor(private formBuilder: FormBuilder, private service: InwardDashboardService) {

  }


  ngOnInit() {
    this.searchInwardForm = this.formBuilder.group({
      area: ['', Validators.required],
      billingMonth: ['', Validators.required],
      billingPeriod:[''],
      carrierGroup: [''],
      settlementIndicator:[''],
      billingCarrier: ['']
    });
    this.bsConfig = Object.assign({}, {
      minMode : this.minMode,
      maxDate: this.maxDate,
      dateInputFormat: 'MMM YY'
    });
    this.service.getListofValues().subscribe((response:any)=> {
      if (response) {
        this.currentBillingMonth = response.billingMonth;
        this.searchInwardForm.get('billingMonth').setValue(this.currentBillingMonth);
        this.zonesDatas = response.carriers;
        this.carriers = this.zonesDatas;
        let obj = {carrierCode: "ALL", carrierName: ""};
        this.carriers.unshift(obj);
      }
    });
    this.setDefaultParams();
  }
  get inds() { return this.searchInwardForm.controls; }

  setDefaultParams(){
    this.submittedSearch = false;
    this.searchInwardForm.get('area').setValue('Staging');
    this.searchInwardForm.get('billingMonth').setValue(this.currentBillingMonth);
    this.searchInwardForm.get('billingPeriod').setValue('');
    this.searchInwardForm.get('carrierGroup').setValue('');
    this.searchInwardForm.get('settlementIndicator').setValue('');
    this.searchInwardForm.get('billingCarrier').setValue('ALL');
  }

  changeDateFormat(date:any) {
    let d = new Date(date);
    if(typeof date != "object" && date.indexOf("-") != -1){
      let year = date.split('-');
      return (moment(d).format('MMM')).toUpperCase()+"-"+moment(year[1],'YY').format('YY');
    } else {
      return (moment(d).format('MMM-YY')).toUpperCase();
    }
  }

  clearGroup() {
    this.carriers = this.zonesDatas;
    let obj = {carrierCode: "ALL", carrierName: ""};
  }

  onSearch(){
    this.submittedSearch = true;
    if(this.searchInwardForm.get('billingCarrier').value == 'ALL')
      this.searchInwardForm.get('billingCarrier').setValue(null);
    if (this.searchInwardForm.valid) {
      this.searchInwardForm.value.billingMonth = this.changeDateFormat(this.searchInwardForm.value.billingMonth);
      this.inwardSearchParams.emit(this.searchInwardForm.value);
    }
  }

  groupChange(event:any) {
    if(event){
      this.carriers = this.zonesDatas.filter(function (value) {
        return value.zone == event;
      });
      let obj = {carrierCode: "ALL", carrierName: ""};
      this.carriers.unshift(obj);
    } else {
      this.clearGroup();
    }
  }

  onResetSearch(){
    this.searchInwardForm.reset();
    this.carrier_name.nativeElement.value = '';
    this.setDefaultParams();
    this.onSearch();

  }

  showSearchBox(): void {
    this.searchDownArrow = !this.searchDownArrow;
  }
}

