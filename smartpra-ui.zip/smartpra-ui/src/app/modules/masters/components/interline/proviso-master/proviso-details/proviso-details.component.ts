import { Component, OnInit, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { ProvisoDetail } from 'src/app/modules/masters/models/interline/proviso-detail';
import { ProvisoDetailService } from 'src/app/modules/masters/services/interline/proviso-master-main/proviso-detail.service';
import { ProvisoMainService } from 'src/app/modules/masters/services/interline/proviso-master-main/proviso-main.service';
import { MessageBoxService } from '../../../../services/commons/message-box.service';
import { PaginationService } from '../../../../../../commons/services/pagination/pagination.service';
import { GeneralService } from '../../../../../../commons/services/general.service';
import { ProvisoRoutingService } from 'src/app/modules/masters/services/interline/proviso-master-main/proviso-routing.service';
import { ProvisoRouting } from 'src/app/modules/masters/models/interline/proviso-routing';



@Component({
  selector: 'app-proviso-details',
  templateUrl: './proviso-details.component.html',
  styleUrls: ['./proviso-details.component.css']
})
export class ProvisoDetailsComponent implements OnInit {
  @Input('triggerProvisoSector')
  set triggerProvisoSector(val: any) {
    if (val != undefined) {
      this.getAllProvisoDetails(val);
    }
  }
  public renderDT = false;
  successResult: any;
  provisoDetail: ProvisoDetail[]=[];
  provisoDetails: any;
  triggerProvisoRouting: any;
  marked = false;
  provisoID: number;
  showProvisoRouting: Boolean = false;
  provisoRoute: ProvisoRouting[]=[];
  selectedRow : Number;
  setClickedRow : Function;
  provisoDetailIdRow : any;
  editProvisoDetail: FormGroup;
  formObj = {
		carrierNumCode: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(3)]],
    provisoSeqNumber: ['', [Validators.required]],
    provisoDetailId: ['', [Validators.required]],
    detailRecNumber: [''],
    subParaReference: [''],
    fbGroupCode: [''],
    sectorFbFlag: [''],
    sectorFrom: [''],
    sectorTo: [''],
    percentage: [''],
    articleC: [''],
    exceptionIndicator: [''],
    exceptionFromRecord: [''],
    exceptionToRecord: [''],
    clientId: [''],
  };
  error: any = { isError: false, errorMessage: '' };
  page: any = this.paginateService.setCustomPaginationConfig({"pageSize": 10});
  getActiveClass = (row) => { return { 'selelcted': row.provisoDetailId == this.provisoDetailIdRow}}
  constructor(private paginateService: PaginationService,private generalService: GeneralService, private provisoDetailService: ProvisoDetailService,
    private formBuilder: FormBuilder, private router: Router, private messageBoxService: MessageBoxService,private provisoMain: ProvisoMainService, private provisoRouteService: ProvisoRoutingService) { }

  ngOnInit() {
    this.onClickProvisoMainId();
    this.setClickedRow = function(index){
      this.selectedRow = index;
    }
    let editForm = Object.assign({}, this.formObj);
		editForm['provisoMainId'] = "";
		this.editProvisoDetail = this.formBuilder.group(editForm);
  }

  onClickProvisoMainId(){
    this.provisoMain.onClickProvisoMain.subscribe((res)=>{
      if (res != null) {
        this.getAllProvisoDetails(res);
      }
    })
  }

  getAllProvisoDetails(resId) {
    this.renderDT = false;
    this.showProvisoRouting = false;
    this.provisoDetailService.getProvisoDetailById(resId).subscribe((res: ProvisoDetail[]) => {
      this.provisoDetail = res;
      setTimeout(() => {
        this.renderDT = true;
      }, 100);
    });
  }

  openProvisoDetail(carrierCode: number, serialNumber: number, provisoRecId: number, provisoDetailId: number): void{
    this.provisoDetailIdRow = provisoDetailId;
     this.provisoRouteService.getProvisoRouteById(carrierCode, serialNumber,provisoRecId).subscribe((res: ProvisoRouting[]) => {
        this.showProvisoRouting = true;
        this.triggerProvisoRouting = res;
    });
  }

  showEditValues(id, type) {
		//if(type == 'update')this.resetForm('edit');else if(type=='add')this.resetForm('add');
		this.provisoDetailService.getProvisoDetailRecordById(id).subscribe((res:any) => {
			if (type == 'update') {
				let result = Object.assign({}, res);
				this.editProvisoDetail.patchValue(result);
				this['setProvisoObj']['clientId'] = res['clientId'];
			}
			else {
				let result = Object.assign({}, res);
			}
		})
  }

  showRoute(){
    this.showProvisoRouting = false;
  }
 
}
