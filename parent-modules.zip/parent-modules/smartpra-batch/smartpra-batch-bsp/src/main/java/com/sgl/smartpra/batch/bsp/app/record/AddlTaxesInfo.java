package com.sgl.smartpra.batch.bsp.app.record;

import java.util.ArrayList;

import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;
import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;

public class AddlTaxesInfo extends BSPBaseRecord {

	@Override
	public String getRecordType() {
		return BSPRecordType.ADDITIONAL_TAX_INFO;
	}

	// Layout of Additional Taxes Info Record
	class AddlInfoTaxesLayout extends FixedLengthRecordLayout {
		public AddlInfoTaxesLayout() {
			fixedLengthFieldLayoutList = new ArrayList<FixedLengthFieldLayout>();

			// entire line
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("line", 1, 136));

			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdMessageIdentifier", 1, 3));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("seqNumber", 4, 11));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdNumericQuaifier", 12, 13));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("dateOfIssue", 14, 19));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("transactionNumber", 20, 25));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("tktDocNumber", 26, 39));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("checkDigit", 40, 40));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("taxInfoSeqNumber", 41, 42));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("taxInfoIdentifier", 43, 46));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("addlTaxInfo", 47, 116));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("filler", 117, 136));
		}
	}

	@Override
	public LineTokenizer lineTokenizer(String handbookRevisionNumber) {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		AddlInfoTaxesLayout addlInfoTaxesLayout = new AddlInfoTaxesLayout();
		tokenizer.setColumns(addlInfoTaxesLayout.getColumns());
		tokenizer.setNames(addlInfoTaxesLayout.getNames());
		return tokenizer;
	}

	@Override
	public FieldSetMapper<BSPBaseRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<BSPBaseRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<BSPBaseRecord>();
		fieldSetMapper.setTargetType(this.getClass());
		return fieldSetMapper;
	}

	// Variables to hold record values
	private String stdMessageIdentifier;
	private String seqNumber;
	private String stdNumericQuaifier;
	private String dateOfIssue;
	private String transactionNumber;
	private String tktDocNumber;
	private String checkDigit;
	private String taxInfoSeqNumber;
	private String taxInfoIdentifier;
	private String addlTaxInfo;
	private String filler;

	public String getStdMessageIdentifier() {
		return stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getSeqNumber() {
		return seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdNumericQuaifier() {
		return stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getDateOfIssue() {
		return dateOfIssue;
	}

	public void setDateOfIssue(String dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}

	public String getTransactionNumber() {
		return transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

	public String getTktDocNumber() {
		return tktDocNumber;
	}

	public void setTktDocNumber(String tktDocNumber) {
		this.tktDocNumber = tktDocNumber;
	}

	public String getCheckDigit() {
		return checkDigit;
	}

	public void setCheckDigit(String checkDigit) {
		this.checkDigit = checkDigit;
	}

	public String getTaxInfoSeqNumber() {
		return taxInfoSeqNumber;
	}

	public void setTaxInfoSeqNumber(String taxInfoSeqNumber) {
		this.taxInfoSeqNumber = taxInfoSeqNumber;
	}

	public String getTaxInfoIdentifier() {
		return taxInfoIdentifier;
	}

	public void setTaxInfoIdentifier(String taxInfoIdentifier) {
		this.taxInfoIdentifier = taxInfoIdentifier;
	}

	public String getAddlTaxInfo() {
		return addlTaxInfo;
	}

	public void setAddlTaxInfo(String addlTaxInfo) {
		this.addlTaxInfo = addlTaxInfo;
	}

	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}
}
