import {Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {DatepickerOptions} from 'ng2-datepicker';
import {ExceptionMasterService} from "../others/exception-master/exception-master-service";
import {FormBuilder, FormGroup} from "@angular/forms";
import * as _ from 'underscore';
import {PaginationService} from "../../../../commons/services/pagination/pagination.service";
import {AllocationMasterService} from "./allocation-master-service";
import {
  AllocationMasterEnums,
  getDateOptions,
  getFileTypes,
  getFormObj,
  allocationMasterConstant
} from "./allocation-master-enums";
import {UserDefinedAreaGlobalMasterService} from "../../services/proration/user-defined-Area/user-defined-area-global-master.service";
import {AirportmasterService} from "../../services/flown/airport-master/airportmasterservice.service";
import {
  getModuleCodeMap,
  ModulesEnum
} from 'src/app/modules/dashboard/excpetion-management/models/excpetion-resolution-model';
import {MessageBoxService} from "../../services/commons/message-box.service";
import { ACTION_MODE } from '../others/exception-master/exception-master-model';


declare var moment: any;


@Component({
  selector: 'app-allocation-master',
  templateUrl: './allocation-master.component.html',
  styleUrls: ['./allocation-master.component.css']
})
export class AllocationMasterComponent implements OnInit {
  lovModules: any;
  showSearchForm = false;
  assignAllocationForm: FormGroup;
  searchAllocationForm: FormGroup;
  groups: any;
  teams: any;
  referenceLabelName: any;
  referenceData: any;
  stationList: any;
  regionList: any;
  dateOptions: DatepickerOptions = getDateOptions();
  formObj = getFormObj();
  page: any = this.paginateService.getPageinateConfig();
  fileTypes: any;
  moduleName: any;
  moduleEnum = ModulesEnum();
  groupModules = [];
  teamName: any;
  flightStatus: any;
  model: any;
  @ViewChild('closeModalAdd') closeModalAdd: ElementRef;
  allocationList: any | any[];
  moduleId: any;
  allocationMasterId: any;
  actionMode: any;
  @ViewChild('closeModalEdit') closeModalEdit: ElementRef;
  productionMode: any;

  constructor(public exceptionService: ExceptionMasterService, public formBuilder: FormBuilder,
              public paginateService: PaginationService, public allocationService: AllocationMasterService,
              private stationService: UserDefinedAreaGlobalMasterService, private airportService: AirportmasterService,
              private messageBoxService: MessageBoxService) {
  };


  ngOnInit() {
    this.assignAllocationForm = this.formBuilder.group(this.formObj);
    this.searchAllocationForm = this.formBuilder.group(this.formObj);
    this.getAllModules();
    // this.getAllAllocations();
    this.getAllStations();
    this.getAllGroup();
    this.getAllteam();
  }


  getAllModules() {
    this.exceptionService.getAllModules().subscribe((response: any) => {
      this.lovModules = response
    })
  }

  getAllGroup() {
    this.exceptionService.getPreLoadData().subscribe((response: any) => {
      this.groupModules = response.groupList;
      console.log(this.groupModules);
    })
  }

  getAllteam() {
    this.exceptionService.getPreLoadData().subscribe((response: any) => {
      this.teamName = response.teamList;
    })
  }

  ngOnDestroy(): void {

  }

  onChangeModuleName(event, form) {
    this.moduleName = getModuleCodeMap(this.lovModules, form.get('moduleLovId').value);
    this.allocationService.getAllModulesChange(this.moduleName).subscribe((response: any) => {
      this.assignAllocationForm.patchValue(response);
    })
  }


  getGroupsByLovId(form) {
    let lovId = form.value.referenceKey;
    this.exceptionService.getGroupsByLovId(lovId).subscribe((response: any) => {
      this.groups = response;
      this.teams = [];
    });
  }

  getAllReferenceData(event, form) {

    let lovId = parseInt(form.value.referenceKey);
    let moduleName: any = _.findWhere(this.lovModules, {"lovId": lovId});
    let referenceObj = {
      "moduleLovId": lovId,
      "moduleName": moduleName.fieldShortDescription.toUpperCase()
    };

    this.allocationService.getAllReferenceData(referenceObj).subscribe((response: any) => {
      this.referenceLabelName = AllocationMasterEnums[response.referenceTableName];
      this.populateReferenceData(this.referenceLabelName);
    })
  }

  populateReferenceData(referenceLabelName: any) {
    this.regionList = [];
    switch (referenceLabelName) {
      case AllocationMasterEnums.mas_list_of_values:
        this.getAllZones();
        break;
      case AllocationMasterEnums.mas_pos:
        this.referenceData = this.stationList;
        break;
      case AllocationMasterEnums.mas_region:
        this.referenceData = this.regionList;
        break;
      default:
        break;
    }
  }


  onSelectGroup(groupId: any) {
    this.exceptionService.getTeamsByGroupId(parseInt(groupId)).subscribe((res: any) => {
      this.teams = res;
    })
  }

  getAllStations() {
    this.airportService.getAirportAll().subscribe((response: any) => {
      this.stationList = response;
    })
  }

  getAllZones() {
    this.referenceData = ["A", "B", "C", "D"]
  }

  onAssignAllocation() {
    let allocationForm: any = this.parseAllocationForm();
    if (!this.assignAllocationForm.invalid) {
      let requestObject = _.pick(allocationForm.value, allocationMasterConstant()[this.moduleName]);
      this.allocationService.assignAllocationSave(requestObject, this.moduleName).subscribe((response: any) => {
        this.messageBoxService.getSuccessMessage('Success', "Assigned Succesfully")
        this.closeModalAdd.nativeElement.click();
      })
    }
  }

  parseAllocationForm() {
    this.assignAllocationForm.value.effectiveFromDate = moment(this.assignAllocationForm.value.effectiveFromDate).format("YYYY-MM-DD");
    this.assignAllocationForm.value.effectiveToDate = moment(this.assignAllocationForm.value.effectiveToDate).format("YYYY-MM-DD");
    this.assignAllocationForm.value.flightFromDate = moment(this.assignAllocationForm.value.flightFromDate).format("YYYY-MM-DD");
    this.assignAllocationForm.value.flightToDate = moment(this.assignAllocationForm.value.flightToDate).format("YYYY-MM-DD");
    return this.assignAllocationForm;
  }
 
  
 onUpdateAllocation(){
        
          if (this.searchAllocationForm.valid) {
            this.allocationService.updateAllocation(this.searchAllocationForm.value).subscribe((response:any)=> {
              if (response.error == "Bad Request") {
                this.messageBoxService.getSuccessMessage('Error','Try Again');
              } else {
                this.messageBoxService.getSuccessMessage('Success','Updated Successfully');
              }
            });
          }
         
        }
    
  
  
  onCancelChange(){
    this.closeModalEdit.nativeElement.click();
  }
  editAllocationRecords(){

  }
  changeExceptionStatus(exception, e) {

  }

  onClickSearch() {
    this.showSearchForm = !this.showSearchForm;
    this.groups = [];
    this.teams = [];
  }


  private getFileTypesById(form: any) {
    let lovId = parseInt(form.value.referenceKey);
    let moduleName: any = _.findWhere(this.lovModules, {"lovId": lovId});
    const fileType = getFileTypes();
    this.fileTypes = fileType[moduleName.fieldShortDescription.toUpperCase()]

  }

  onResetAdd(): void {

  }


  onResetEdit(): void {

  }


  onResetSearch() {


  }


  onDuplicateException(actionMode, data): void {


  }

  closeAlertValidation() {

  }


  public findInvalidControls(form: any) {

  }

  get a() {
    return null;
  }

  get u() {
    return null;
  }

  get s() {
    return null;
  }


  onSelectAllocationSearch() {
    this.allocationService.getAllExceptionAllocation(this.searchAllocationForm.value.moduleLovId).subscribe(value => {
      this.allocationList = value;
    })
  }


  getAllAllocations() {
    /*Add lov here*/


  }
}
