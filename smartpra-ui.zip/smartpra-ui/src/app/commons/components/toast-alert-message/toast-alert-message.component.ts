import { Component, OnInit ,Input,Output,EventEmitter } from '@angular/core';
import { AlertMessageConstants } from '../../properties/alert-message-constants.properties';
import { timer } from 'rxjs';
export interface AlertMessage {
  isSuccess:boolean;
  successMessage:string;
}
@Component({
  selector: 'app-toast-alert-message',
  templateUrl: './toast-alert-message.component.html',
  styleUrls: ['./toast-alert-message.component.css']
})
export class ToastAlertMessageComponent implements OnInit {
  success:AlertMessage;
  constructor() { }
  timer:any;
  @Input('message')  message:string;
  @Input('type')  type:string;
  @Input('showToast')
  set showToast(val:boolean){
    if(val){
      this.success.isSuccess = val;
      if(this.timer) this.timer.unsubscribe();
      this.closeAlertValidation() ;
      timer(100).subscribe(()=>{
        this.showToastChange.emit(!val);
      });
    } 
  }
  @Output() showToastChange = new EventEmitter();
  ngOnInit() {
    this.resetAlert();
  }
  closeAlertValidation() {
    this.timer = timer(AlertMessageConstants.CLOSE_ALERT_TIME).subscribe(()=>{
      this.resetAlert();
    })
  }
  resetAlert(){
    this.success = { isSuccess: false, successMessage: '' };
  }
}
