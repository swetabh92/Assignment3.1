package com.sgl.smartpra.allocation.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.allocation.master.app.entity.AllocationMasterEntity;
import com.sgl.smartpra.allocation.master.model.AllocationMaster;
import com.sgl.smartpra.allocation.master.model.SaleAllocationResponce;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface AllocationMasterMapper extends BaseMapper<AllocationMaster, AllocationMasterEntity> {

	AllocationMasterEntity mapToEntity(AllocationMaster allocationMaster);

	AllocationMasterEntity mapToEntity(AllocationMaster allocationMaster,
			@MappingTarget AllocationMasterEntity allocationMasterEntity);

	@Mapping(source="allocationKey1", target="stationName")
	@Mapping(source="allocationKey2", target="fileType")
	@Mapping(source="allocationKey3", target="exceptionCreatedFrom")
	@Mapping(source="allocationKey4", target="exceptionCreatedTo")
	@Mapping(source="allocationKey5", target="salesFromDate")
	@Mapping(source="allocationKey6", target="salesToDate")
	@Mapping(source="allocationKey7", target="utilizationFromDate")
	@Mapping(source="allocationKey8", target="utilizationToDate")
	SaleAllocationResponce mapToSaleModel(AllocationMasterEntity allocationMasterEntity,
			@MappingTarget SaleAllocationResponce saleAllocationResponce);

}
