package com.sgl.smartpra.batch.mmr.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.batch.mmr.app.service.MMRService;

@RestController
public class MMRController {

	@Autowired
	MMRService mmrService;

	@RequestMapping("/mmr/invoke-job")
	public String handle(@RequestParam("fileName") String fileName) throws Exception {

		return mmrService.executeMMRStgInboundJob(fileName, "Manual");
	}
}
