package com.sgl.smartpra.batch.sales.validator.app.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.batch.sales.validator.app.domain.TaxCommissionStg;

@Repository
public interface TaxCommissionStgRepository  extends JpaRepository<TaxCommissionStg, Integer>{

}