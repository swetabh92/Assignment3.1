import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  { path: 'aircraftMaster', loadChildren:'./aircraft-master/aircraft-master.module#AircraftMasterModule'},
  { path: 'NewAirportMaster', loadChildren:'./new-airport-master/new-airport-master.module#NewAirportMasterModule'},
  { path: 'bookingClassMaster', loadChildren:'./booking-class-master/booking-class-master.module#BookingClassMasterModule'},  
  { path: 'flightControlMaster', loadChildren:'./flight-control-master/flight-control-master.module#FlightControlMasterModule'},
  { path: 'regionMaster', loadChildren:'./region-master/region-master.module#RegionMasterModule'},
  { path: 'routeCodeMaster', loadChildren:'./route-code-master/route-code-master.module#RouteCodeMasterModule'},


];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FlownRoutingModule { }
