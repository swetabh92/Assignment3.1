import { Component, OnInit, Input, Output, EventEmitter, OnDestroy, ElementRef, ViewChild, Renderer2 } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { GeneralService } from '../../../../commons/services/general.service';
import { TeamService } from '../../services/team.service';
import { UserprofileService } from '../../services/userprofile.service';
import { GroupService } from '../../services/group.service';
import { Team } from '../../models/team';
import { Subject } from 'rxjs';
import swal from 'sweetalert2';


@Component({
  selector: 'app-team',
  templateUrl: './team.component.html',
  styleUrls: ['./team.component.css']
})
export class TeamComponent implements OnInit, OnDestroy {
  @ViewChild('closeModalAdd') closeModalAdd: ElementRef;
  @ViewChild('closeModalEdit') closeModalEdit: ElementRef;
  dtOptions: any = {};
  // We use this trigger because fetching the list of persons can be quite long,
  // thus we ensure the data is fetched before rendering
  dtTrigger: Subject<any> = new Subject<any>();
  public renderDT = false;
  createdBy = 'admin';
  lastUpdatedBy = 'admin';
  clientId = 'null';
  defaultisActive = true;
  collapse_search_form = true;
  box_search_status = true;
  addNewForm: FormGroup;
  addNewsubmitted = false;
  editNewForm: FormGroup;
  editsubmitted = false;
  searchForm: FormGroup;
  searchsubmitted = false;
  searchresult = false;
  searchstring = '';
  checkdata: any;
  teamsList$: any;
  teamdetail: any;
  previewUrl = '';
  isactiveArray: any;
  isactiveSelected: any;
  groupArray: any;
  groupSelected: any;
  managerArray: any;
  managerSelected: any;
  availableGroups = [];
  assignedGroups = [];
  tempAvailableGroups = [];
  tempAssignedGroups = [];
  assignedTeams : any;
  constructor(private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder,
    private generalService: GeneralService,
    private teamservice: TeamService,
    private userservice: UserprofileService,
    private groupservice: GroupService,
    private render: Renderer2,
  ) { }

  ngOnInit() {
    // this.isactiveArray =  [{id: 'true', name: 'active'}, {id: 'false', name: 'inactive'}];
    // this.managerArray =  [{id: '1', name: 'soundar'}, {id: '2', name: 'saravanan'}];
    // this.groupArray =  [{id: '1', name: 'soundar'}, {id: '2', name: 'saravanan'}];

    this.dtOptions = {
      searching: false, // to hide the search field in the data table top
      pagingType: 'full_numbers',
      lengthMenu: [[5, 10, 25, 50, -1], [5, 10, 25, 50, 'All']], // used to display records size( no of rows)
      language: {
        lengthMenu: 'Page size _MENU_',
        paginate: {
          next: '<i style="color:#0079c1" class="fa fa-angle-right fa-lg"></i>',
          previous: '<i style="color:#0079c1" class="fa fa-angle-left fa-lg"></i>',
          first: '<i style="color:#0079c1" class="fa fa-step-backward"></i>',
          last: '<i style="color:#0079c1" class="fa fa-step-forward"></i>'
        }
      },
      dom: 'tflrp<"datatableclass"i>',
      // used for fixed columns
      // scrollX: true,
      // scrollY: 'auto',
      // scrollCollapse: true,
      // fixedColumns:   {
      //   leftColumns: 2,
      //   rightColumns: 2
      // },
      // end of fixed columns
      // disable search and order
      // aoColumnDefs: [{ bSortable: false, aTargets: [0, 4, 5] }],
      columnDefs: [
        {
          'searchable': false,
          'orderable': false,
          'targets': [-1, -2]
        }
      ],
      // end of disable search and order
    };
    this.GetAllteams();
    this.GetAllmanager();
    this.GetAllgroup();
    this.addNewForm = this.formBuilder.group({
      createdBy: [''], // , Validators.required],
      clientId: [''], // , Validators.required],
      groupId: [''], // , Validators.required],
      teamManagerId: [''], // , Validators.required],
      teamName: [''], // , Validators.required],
      isActive: [''] , // Validators.required],
    });
    this.editNewForm = this.formBuilder.group({
      lastUpdatedBy: [''],
      clientId: [''], // , Validators.required],
      groupId: [''], // , Validators.required],
      teamId: [''], // , Validators.required],
      teamManagerId: [''], // , Validators.required],
      teamName: [''], // , Validators.required],
      isActive: [''] , // Validators.required],
      createdBy: [''], // , Validators.required],
    });
    this.searchForm = this.formBuilder.group({
      active: ['', ],
    });
  }
  showSearchBox(e) {
    this.box_search_status = !this.box_search_status;
    this.collapse_search_form = true;
  }
  collapseSearchform(event) {
    const targetclass = event.target.className;
    // console.log(targetclass);
    // this.collapse_search_form = !this.collapse_search_form;
    if (targetclass === 'btn btn-box-tool fa fa-angle-up') {
      this.collapse_search_form = !this.collapse_search_form;
      event.target.className = 'btn btn-box-tool fa fa-angle-down';
    } else if (targetclass === 'btn btn-box-tool fa fa-angle-down') {
      this.collapse_search_form = !this.collapse_search_form;
      event.target.className = 'btn btn-box-tool fa fa-angle-up';
    }
  }
  onResetSearch() {
    this.searchForm.reset();
    this.renderDT = false;
    this.GetAllteams();
  }
  onSearch() {

  }
  GetAllmanager() {
    this.userservice.UserprofileByUserRoleName('Manager').subscribe((res: any[]) => {
      this.managerArray = res;
    });
  }
  GetAllgroup() {
    this.groupservice.getGroupAll().subscribe((res: any[]) => {
      this.groupArray = res;
      this.availableGroups = res;
    });
  }
  GetAllteams() {
    this.renderDT = false;
    this.teamservice.getTeamAll().subscribe((res: any[]) => {
      this.teamsList$ = res;
      setTimeout(() => {
        this.renderDT = true;
      }, 100);
    });
  }
  get f() { return this.addNewForm.controls; }

  onResetAdd() {
    this.addNewForm.reset();
  }
  addNewTeam(): void {
    this.addNewsubmitted = true;
    // stop here if form is invalid
    if (this.addNewForm.invalid) {
      return;
    } else {
      this.teamservice.addTeam(this.addNewForm.value).subscribe(
        teamservice => {
          // console.log(teamservice);
          if (!!teamservice && teamservice.teamId) {
            this.GetAllteams();
            this.closeModalAdd.nativeElement.click();
            swal(
              'Success',
              'New Records Addeded',
              'success'
            );
            this.onResetAdd();
          }
        });
    }
  }
  get u() { return this.editNewForm.controls; }
  showEditvalues(getId) {
    this.teamservice.TeamByTeamId(getId).subscribe(
      teamservice => {
        if (!!teamservice && teamservice.teamId) {
          this.teamdetail = teamservice;
          this.managerSelected = teamservice.teamManagerId;
          this.groupSelected = teamservice.groupId;
        } else {
          swal(
            'Error',
            'Error fetching record',
            'error'
          );
        }
      });
  }
  onResetEdit() {
  }
  editNewTeam() {
    this.editsubmitted = true;
    // console.log(this.editNewForm);
    // stop here if form is invalid
    if (this.editNewForm.invalid) {
      swal(
        'Error',
        'sorry error in the form',
        'error'
      );
      return;
    } else {
      // console.log(this.editNewForm.value); return;
      this.teamservice.updateTeam(this.editNewForm.value).subscribe(
        teamservice => {
          if (!!teamservice && teamservice.teamId) {
            this.GetAllteams();
            this.closeModalEdit.nativeElement.click();
            swal(
              'Updated!',
              'Team has been Updated.',
              'success'
            );
          }
        });
    }
  }
  removeafterDeactivate(user: Team): void {
    this.teamsList$ = this.teamsList$.filter(h => h !== user);
  }
  changeStatusTeam(team, e, Id) {
    if (e.target.checked) {
      swal({
        type: 'warning',
        title: 'Are you sure to activate this team?',
        text: 'You will not be able to recover the data of teamsprofile',
        showCancelButton: true,
        confirmButtonColor: '#049F0C',
        cancelButtonColor: '#ff0000',
        confirmButtonText: 'Yes, activate it!',
        cancelButtonText: 'No, keep it deactivated',
        closeOnClickOutside: false,
        closeOnEsc: false,
        allowOutsideClick: false,
      } as any).then((result) => {
        if (result.value) {
          team.isActive = 'true';
          this.teamservice.updateTeam(team).subscribe(
            teamservice => {
              if (!!teamservice && teamservice.teamId) {
                this.GetAllteams();
                swal(
                  'Activated!',
                  'team has been activated.',
                  'success'
                );
              }
            });
        } else if (
          // Read more about handling dismissals
          result.dismiss === swal.DismissReason.cancel
        ) {
          e.target.checked = false;
          swal(
            'Cancelled',
            'teamsprofile is status unchanged',
            'error'
          );
        }
      });
    } else {
      swal({
        type: 'warning',
        title: 'Are you sure to deactivate this team?',
        text: 'You will not be able to recover the data of teamsprofile',
        showCancelButton: true,
        confirmButtonColor: '#049F0C',
        cancelButtonColor: '#ff0000',
        confirmButtonText: 'Yes, deactivate it!',
        cancelButtonText: 'No, keep it as active',
        closeOnClickOutside: false,
        closeOnEsc: false,
        allowOutsideClick: false,
      } as any).then((result) => {
        if (result.value) {
          team.isActive = 'false';
          this.teamservice.updateTeam(team).subscribe(
            teamservice => {
              if (!!teamservice && teamservice.teamId) {
                this.GetAllteams();
                swal(
                  'Activated!',
                  'team has been deactivated.',
                  'success'
                );
              }
            });
        } else if (
          // Read more about handling dismissals
          result.dismiss === swal.DismissReason.cancel
        ) {
          e.target.checked = true;
          swal(
            'Cancelled',
            'teamsprofile is status unchanged',
            'error'
          );
        }
      });
    }
  }

  onSelectGroup(group) {
    // TODO get user role and prepopulate
  }
  onSelectAvailableGroup(event, data) {
    // AV -> Available Roles
    const className = event.currentTarget.className;

    if (className.includes('active')) {
        event.currentTarget.classList.remove('active');
        this.filterGroupByType(data, 'AV');
    } else {
        this.render.addClass(event.target, 'active');
        this.tempAvailableGroups.push(data);
    }
  }
  onSelectAssignedGroup(event, data) {
    const className = event.currentTarget.className;

    // AS -> Assigned Roles
    if (className.includes('active')) {
        event.currentTarget.classList.remove('active');
        this.filterGroupByType(data, 'AS');
    } else {
        this.render.addClass(event.target, 'active');
        this.tempAssignedGroups.push(data);
    }
  }
  filterGroupByType(data, arrayType) {
    if (arrayType === 'AS') {
        const index = this.tempAssignedGroups.indexOf(data);
        if (index > -1) {
            this.tempAssignedGroups.splice(index, 1);
        }
    } else {
        const index = this.tempAvailableGroups.indexOf(data);
        if (index > -1) {
            this.tempAvailableGroups.splice(index, 1);
        }
    }
 }
 updateAssignedGroup() {
  for (let i = 0; i < this.tempAssignedGroups.length; i++) {
    this.availableGroups.push(this.tempAssignedGroups[i]);
  }

  this.assignedGroups = this.assignedGroups.filter(val => !this.tempAssignedGroups.includes(val));
  this.tempAssignedGroups = [];
}

updateAvailableGroup() {
      for (let i = 0; i < this.tempAvailableGroups.length; i++) {
        this.assignedGroups.push(this.tempAvailableGroups[i]);
    }

    this.availableGroups = this.availableGroups.filter(val => !this.tempAvailableGroups.includes(val));
    this.tempAvailableGroups = [];
}

  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }

}
