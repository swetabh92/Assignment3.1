export class Userprofile {
  categoryLevel: string;
  airLineCode: string;
  departmentName: string;
  organizationName: string;
  createInstant: string;
  createdBy: string;
  displayName: string;
  email: string;
  firstName: string;
  instantOfJoining: string;
  isActive: true;
  langKey: string;
  lastName: string;
  lastUpInstantdBy: string;
  lastUpInstantdInstant: string;
  masUsersId: number;
  masUserId: number;
  userId: number;
  middleName: string;
  passwordHash: string;
  preferredLanguage: string;
  processName: string;
  shiftEndTime: string;
  shiftStartTime: string;
  userAddress1: string;
  userAddress2: string;
  userAddress3: string;
  userEmail: string;
  userFullName: string;
  userGroupId: number;
  userManagerId: number;
  userModuleId: number;
  userName: string;
  userPhoto: string;
  userPwdId: number;
  userRemarks: string;
  userRoleId: number;
  userTeamId: number;
  userTelephone: string;
  voiceProfile: string;

    constructor() { }
  }
