import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NewAirportMasterComponent } from './new-airport-master.component';

const routes: Routes = [
  {path:'',component:NewAirportMasterComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class NewAirportMasterRoutingModule { }
