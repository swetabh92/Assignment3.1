package com.sgl.smartpra.batch.sales.validator.app.domain;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the itinerary_data_segment_stg database table.
 * 
 */
@Entity
@Table(name="itinerary_data_segment_stg")
public class ItineraryDataSegmentStg  extends BSPRecord implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="itery_data_segment_auto_id")
	private int iteryDataSegmentAutoId;

	@Column(name="baggage_allowance")
	private String baggageAllowance;

	private String carrier;

	@Column(name="change_of_guage_indicator")
	private String changeOfGuageIndicator;

	@Column(name="check_digit")
	private String checkDigit;

	@Column(name="created_by")
	private String createdBy;

	@Column(name="created_date")
	private Timestamp createdDate;

	@Column(name="date_of_issue")
	private String dateOfIssue;

	@Column(name="dest_airport_city_code")
	private String destAirportCityCode;

	@Column(name="equipment_code")
	private String equipmentCode;

	@Column(name="fare_basis_tkt_designator")
	private String fareBasisTktDesignator;

	@Column(name="fare_com_proces_pass_type_code")
	private String fareComProcesPassTypeCode;

	private String filler;

	@Column(name="flight_booking_status")
	private String flightBookingStatus;

	@Column(name="flight_date")
	private String flightDate;

	@Column(name="flight_depart_time")
	private String flightDepartTime;

	@Column(name="flight_number")
	private String flightNumber;

	@Column(name="frequent_flyer_reference")
	private String frequentFlyerReference;

	@Column(name="last_updated_by")
	private String lastUpdatedBy;

	@Column(name="last_updated_date")
	private Timestamp lastUpdatedDate;

	@Column(name="not_valid_after_date")
	private String notValidAfterDate;

	@Column(name="not_valid_before_date")
	private String notValidBeforeDate;

	@Column(name="orgin_airport_city_code")
	private String orginAirportCityCode;

	@Column(name="reservation_booking_designator")
	private String reservationBookingDesignator;

	@Column(name="segment_identifier")
	private String segmentIdentifier;

	@Column(name="seq_number")
	private String seqNumber;

	@Column(name="sold_passenger_cabin")
	private String soldPassengerCabin;

	@Column(name="std_message_identifier")
	private String stdMessageIdentifier;

	@Column(name="std_numeric_quaifier")
	private String stdNumericQuaifier;

	@Column(name="stopover_code")
	private String stopoverCode;

	@Column(name="tkt_doc_number")
	private String tktDocNumber;

	@Column(name="transaction_number")
	private String transactionNumber;

	//bi-directional many-to-one association to TransactionHdrStg
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.MERGE)
	@JoinColumn(name="transaction_hdr_id")
	private TransactionHdrStg transactionHdrStg;

	public ItineraryDataSegmentStg() {
	}

	public int getIteryDataSegmentAutoId() {
		return this.iteryDataSegmentAutoId;
	}

	public void setIteryDataSegmentAutoId(int iteryDataSegmentAutoId) {
		this.iteryDataSegmentAutoId = iteryDataSegmentAutoId;
	}

	public String getBaggageAllowance() {
		return this.baggageAllowance;
	}

	public void setBaggageAllowance(String baggageAllowance) {
		this.baggageAllowance = baggageAllowance;
	}

	public String getCarrier() {
		return this.carrier;
	}

	public void setCarrier(String carrier) {
		this.carrier = carrier;
	}

	public String getChangeOfGuageIndicator() {
		return this.changeOfGuageIndicator;
	}

	public void setChangeOfGuageIndicator(String changeOfGuageIndicator) {
		this.changeOfGuageIndicator = changeOfGuageIndicator;
	}

	public String getCheckDigit() {
		return this.checkDigit;
	}

	public void setCheckDigit(String checkDigit) {
		this.checkDigit = checkDigit;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDateOfIssue() {
		return this.dateOfIssue;
	}

	public void setDateOfIssue(String dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}

	public String getDestAirportCityCode() {
		return this.destAirportCityCode;
	}

	public void setDestAirportCityCode(String destAirportCityCode) {
		this.destAirportCityCode = destAirportCityCode;
	}

	public String getEquipmentCode() {
		return this.equipmentCode;
	}

	public void setEquipmentCode(String equipmentCode) {
		this.equipmentCode = equipmentCode;
	}

	public String getFareBasisTktDesignator() {
		return this.fareBasisTktDesignator;
	}

	public void setFareBasisTktDesignator(String fareBasisTktDesignator) {
		this.fareBasisTktDesignator = fareBasisTktDesignator;
	}

	public String getFareComProcesPassTypeCode() {
		return this.fareComProcesPassTypeCode;
	}

	public void setFareComProcesPassTypeCode(String fareComProcesPassTypeCode) {
		this.fareComProcesPassTypeCode = fareComProcesPassTypeCode;
	}

	public String getFiller() {
		return this.filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}

	public String getFlightBookingStatus() {
		return this.flightBookingStatus;
	}

	public void setFlightBookingStatus(String flightBookingStatus) {
		this.flightBookingStatus = flightBookingStatus;
	}

	public String getFlightDate() {
		return this.flightDate;
	}

	public void setFlightDate(String flightDate) {
		this.flightDate = flightDate;
	}

	public String getFlightDepartTime() {
		return this.flightDepartTime;
	}

	public void setFlightDepartTime(String flightDepartTime) {
		this.flightDepartTime = flightDepartTime;
	}

	public String getFlightNumber() {
		return this.flightNumber;
	}

	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}

	public String getFrequentFlyerReference() {
		return this.frequentFlyerReference;
	}

	public void setFrequentFlyerReference(String frequentFlyerReference) {
		this.frequentFlyerReference = frequentFlyerReference;
	}

	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getLastUpdatedDate() {
		return this.lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getNotValidAfterDate() {
		return this.notValidAfterDate;
	}

	public void setNotValidAfterDate(String notValidAfterDate) {
		this.notValidAfterDate = notValidAfterDate;
	}

	public String getNotValidBeforeDate() {
		return this.notValidBeforeDate;
	}

	public void setNotValidBeforeDate(String notValidBeforeDate) {
		this.notValidBeforeDate = notValidBeforeDate;
	}

	public String getOrginAirportCityCode() {
		return this.orginAirportCityCode;
	}

	public void setOrginAirportCityCode(String orginAirportCityCode) {
		this.orginAirportCityCode = orginAirportCityCode;
	}

	public String getReservationBookingDesignator() {
		return this.reservationBookingDesignator;
	}

	public void setReservationBookingDesignator(String reservationBookingDesignator) {
		this.reservationBookingDesignator = reservationBookingDesignator;
	}

	public String getSegmentIdentifier() {
		return this.segmentIdentifier;
	}

	public void setSegmentIdentifier(String segmentIdentifier) {
		this.segmentIdentifier = segmentIdentifier;
	}

	public String getSeqNumber() {
		return this.seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getSoldPassengerCabin() {
		return this.soldPassengerCabin;
	}

	public void setSoldPassengerCabin(String soldPassengerCabin) {
		this.soldPassengerCabin = soldPassengerCabin;
	}

	public String getStdMessageIdentifier() {
		return this.stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getStdNumericQuaifier() {
		return this.stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getStopoverCode() {
		return this.stopoverCode;
	}

	public void setStopoverCode(String stopoverCode) {
		this.stopoverCode = stopoverCode;
	}

	public String getTktDocNumber() {
		return this.tktDocNumber;
	}

	public void setTktDocNumber(String tktDocNumber) {
		this.tktDocNumber = tktDocNumber;
	}

	public String getTransactionNumber() {
		return this.transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

	public TransactionHdrStg getTransactionHdrStg() {
		return this.transactionHdrStg;
	}

	public void setTransactionHdrStg(TransactionHdrStg transactionHdrStg) {
		this.transactionHdrStg = transactionHdrStg;
	}
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
/*	@Override
	public LineTokenizer lineTokenizer() {

		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		ItineraryDataSegmentStgLayout itineraryDataSegmentStgLayout = new ItineraryDataSegmentStgLayout();
		tokenizer.setColumns(itineraryDataSegmentStgLayout.getColumns());
		tokenizer.setNames(itineraryDataSegmentStgLayout.getNames());
		return tokenizer;

	}

	@Override
	public FieldSetMapper<BSPRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<BSPRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<BSPRecord>();
		fieldSetMapper.setTargetType(ItineraryDataSegmentStg.class);
		return fieldSetMapper;
	}

	@Override
	public ItemProcessor<? extends BSPRecord, ? extends BSPRecord> processor() {
		return new ItineraryDataSegmentStgProcessor();
	}

	@Override
	public ItemWriter<? super BSPRecord> writer() {
		return new ItineraryDataSegmentStgWriter();
	}*/

}