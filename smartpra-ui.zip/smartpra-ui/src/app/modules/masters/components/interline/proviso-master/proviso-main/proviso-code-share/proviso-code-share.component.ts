import { Component, OnInit, ViewChild, Input, Output, ElementRef, OnDestroy, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { GeneralService } from '../../../../../../../commons/services/general.service';
import swal from 'sweetalert2';
import { ProvisoCodeShare } from '../../../../../models/interline/proviso-code-share';
import { MessageBoxService } from '../../../../../services/commons/message-box.service';
import { PaginationService } from '../../../../../../../commons/services/pagination/pagination.service';
import { ProvisoCodeShareService } from 'src/app/modules/masters/services/interline/proviso-master-main/proviso-code-share.service';
import * as _ from 'underscore';
import { UserDefinedAreaMasterComponent } from '../../../../proration/user-defined-area-master/user-defined-area-master.component';
@Component({
  selector: 'app-proviso-code-share',
  templateUrl: './proviso-code-share.component.html',
  styleUrls: ['./proviso-code-share.component.css']
})
export class ProvisoCodeShareComponent implements OnInit {
  @Input('triggerCodeShare')
  set triggerCodeShare(val: any) {
    if (val != undefined) {
      this.provisoCodeShare = val
    }
  }
  @Output() showCodeShare = new EventEmitter();
  @ViewChild('closeModalEdit') closeModalEdit: ElementRef;
  @ViewChild(UserDefinedAreaMasterComponent) userDefinedAreaView: UserDefinedAreaMasterComponent;
  successResult: any;
  provisoCodeShare: ProvisoCodeShare[]=[];
  marked = false;
  provisoID: number;
  error: any = { isError: false, errorMessage: '' };
  page: any = this.paginateService.getPageinateConfig();
  editProvisoCode: FormGroup;
  areaFlag: any = "";
  formObj = {
		carrierNumCode: [''],
    provisoSeqNumber: ['',],
    areaFrom: ['',],
    areaTo: [''],
    codeshareRecNumber: [''],
    //provisoSection: [''],
    codeshareCxr: [''],
   // viceVersaFlag: [''],
    clientId: [''],
  };
  setProvisoCodeObj: any = {};
  constructor(private paginateService: PaginationService,private generalService: GeneralService, private provisoCodeShareService: ProvisoCodeShareService,
    private formBuilder: FormBuilder, private router: Router, private messageBoxService: MessageBoxService) { }

  ngOnInit() {
    //this.getAllProvisoCode(this.provisoID);
    let editForm = Object.assign({}, this.formObj);
    editForm['provisoCodeshareId'] = "";
    editForm['provisoMainId'] = "";
		this.editProvisoCode = this.formBuilder.group(editForm);
  }

  getAllProvisoCode(provisoID: any) {
    this.provisoCodeShareService.getProvisoCodeShareDetailId(provisoID).subscribe((res: ProvisoCodeShare[]) => {
      this.provisoCodeShare = res;
      console.log(this.provisoCodeShare);
      if(res.length == 0){
        this.showCodeShare.emit(false);
      }else{
        this.showCodeShare.emit(true);
      }
      
    });
  }

  showEditValues(id, type) {
		//if(type == 'update')this.resetForm('edit');else if(type=='add')this.resetForm('add');
		this.provisoCodeShareService.getProvisoCodeShareById(id).subscribe((res:any) => {
			if (type == 'update') {
				let result = Object.assign({}, res);
        this.editProvisoCode.patchValue(result);
        this['setProvisoCodeObj']['provisoMainId'] = res['provisoMainId'];
				this['setProvisoCodeObj']['provisoCodeshareId'] = res['provisoCodeshareId'];
				this['setProvisoCodeObj']['clientId'] = res['clientId'];
			}
			else {
				let result = Object.assign({}, res);
			}
		})
  }
  onCancelChange() {
		this.closeModalEdit.nativeElement.click();
  }
  
  viewFromAndToArea(value, row, flag) {
    if (parseInt(value.substring(0, 1), 0) === 1) {
      this.userDefinedAreaView.viewCityFromAndToArea(value);
    } else if (parseInt(value.substring(0, 1), 0) === 2) {
      this.userDefinedAreaView.viewCountryFromAndToArea(value);
    } else if (parseInt(value.substring(0, 1), 0) === 3) {
      this.userDefinedAreaView.viewStandardFromAndToArea(value);
    } else if (parseInt(value.substring(0, 1), 0) === 4) {
      this.userDefinedAreaView.viewUserDefFromAndToArea(value, row);
    } else if (parseInt(value.substring(0, 1), 0) === 5) {
      this.userDefinedAreaView.viewStateFromAndToArea(value);
    }
  }
}
