package com.sgl.smartpra.batch.bsp.app.record;

import java.util.ArrayList;

import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;
import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;

public class FileTotals extends BSPBaseRecord {

	@Override
	public String getRecordType() {
		return BSPRecordType.FILE_TOTALS_PER_CURRTYPE;
	}

	// Layout of File Totals Record
	public class FileTotalsLayout extends FixedLengthRecordLayout {
		public FileTotalsLayout() {
			fixedLengthFieldLayoutList = new ArrayList<FixedLengthFieldLayout>();

			// entire line
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("line", 1, 136));

			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdMessageIdentifier", 1, 3));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("seqNumber", 4, 11));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdNumericQuaifier", 12, 13));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("bspIdentifier", 14, 16));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("officeCount", 17, 21));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("grossValueAmt", 22, 36));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("totalRemittanceAmt", 37, 51));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("totalCommissionValueAmt", 52, 66));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("totalTaxMiscFeeAmt", 67, 81));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("totalTaxOnCommissionAmt", 82, 96));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("reservedSpace", 97, 132));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("currencyType", 133, 136));
		}
	}

	@Override
	public LineTokenizer lineTokenizer(String handbookRevisionNumber) {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		FileTotalsLayout fileTotalsLayout = new FileTotalsLayout();
		tokenizer.setColumns(fileTotalsLayout.getColumns());
		tokenizer.setNames(fileTotalsLayout.getNames());
		return tokenizer;
	}

	@Override
	public FieldSetMapper<BSPBaseRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<BSPBaseRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<BSPBaseRecord>();
		fieldSetMapper.setTargetType(this.getClass());
		return fieldSetMapper;
	}

	// Variables to hold the record values
	private String stdMessageIdentifier;
	private String seqNumber;
	private String stdNumericQuaifier;
	private String bspIdentifier;
	private String officeCount;
	private String grossValueAmt;
	private String totalRemittanceAmt;
	private String totalCommissionValueAmt;
	private String totalTaxMiscFeeAmt;
	private String totalTaxOnCommissionAmt;
	private String reservedSpace;
	private String currencyType;

	public String getStdMessageIdentifier() {
		return stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getSeqNumber() {
		return seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdNumericQuaifier() {
		return stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getBspIdentifier() {
		return bspIdentifier;
	}

	public void setBspIdentifier(String bspIdentifier) {
		this.bspIdentifier = bspIdentifier;
	}

	public String getOfficeCount() {
		return officeCount;
	}

	public void setOfficeCount(String officeCount) {
		this.officeCount = officeCount;
	}

	public String getGrossValueAmt() {
		return grossValueAmt;
	}

	public void setGrossValueAmt(String grossValueAmt) {
		this.grossValueAmt = grossValueAmt;
	}

	public String getTotalRemittanceAmt() {
		return totalRemittanceAmt;
	}

	public void setTotalRemittanceAmt(String totalRemittanceAmt) {
		this.totalRemittanceAmt = totalRemittanceAmt;
	}

	public String getTotalCommissionValueAmt() {
		return totalCommissionValueAmt;
	}

	public void setTotalCommissionValueAmt(String totalCommissionValueAmt) {
		this.totalCommissionValueAmt = totalCommissionValueAmt;
	}

	public String getTotalTaxMiscFeeAmt() {
		return totalTaxMiscFeeAmt;
	}

	public void setTotalTaxMiscFeeAmt(String totalTaxMiscFeeAmt) {
		this.totalTaxMiscFeeAmt = totalTaxMiscFeeAmt;
	}

	public String getTotalTaxOnCommissionAmt() {
		return totalTaxOnCommissionAmt;
	}

	public void setTotalTaxOnCommissionAmt(String totalTaxOnCommissionAmt) {
		this.totalTaxOnCommissionAmt = totalTaxOnCommissionAmt;
	}

	public String getReservedSpace() {
		return reservedSpace;
	}

	public void setReservedSpace(String reservedSpace) {
		this.reservedSpace = reservedSpace;
	}

	public String getCurrencyType() {
		return currencyType;
	}

	public void setCurrencyType(String currencyType) {
		this.currencyType = currencyType;
	}
}