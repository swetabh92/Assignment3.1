package com.sgl.smartpra.batch.bsp.app.mapper;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.hazelcast.util.StringUtil;
import com.sgl.smartpra.batch.bsp.app.config.FeignConfiguration.CarrierMasterFeignClient;
import com.sgl.smartpra.batch.bsp.app.config.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.batch.bsp.app.domain.staging.AgentRegisterStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.OfficeHeaderStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.OfficeHeaderWrapperStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.OfficeSubtotalsStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TransactionRecordStg;
import com.sgl.smartpra.batch.bsp.app.record.OfficeHeader;
import com.sgl.smartpra.batch.bsp.app.util.BSPUtil;


public class OfficeHeaderMapper {

	public static  OfficeHeaderWrapperStg mapOfficeHeaderRecord(OfficeHeader officeHeader, String stationCode,
			String effectiveDateIF ,SmartpraMasterAppClient smartpraMasterAppClient, CarrierMasterFeignClient carrierMasterFeignClient
			,String clientId) {
		
		
		if (officeHeader == null) {
			return null;
		}

		OfficeHeaderWrapperStg officeHeaderWrapperStg = new OfficeHeaderWrapperStg();
		mapOfficeHeader(officeHeaderWrapperStg, officeHeader);
		mapTransactionRecordList(officeHeaderWrapperStg, officeHeader);
		mapOfficeSubtotalsList(officeHeaderWrapperStg, officeHeader);

		int precision = 0;

		try {
			if (!StringUtil.isNullOrEmpty(officeHeader.getCurrencyType())
					&& officeHeader.getCurrencyType().length() > 3) {
				// precision = Integer.parseInt(officeHeader.getCurrencyType().substring(3, 4));
				BSPUtil bspUtil = new BSPUtil();
//				String clientId = stepExecution.getJobExecution().getExecutionContext().getString("clientId");
//				String clientId = "QR";
				String decimalUnitValue = officeHeader.getCurrencyType().substring(3, 4);
				String currencyCode = officeHeader.getCurrencyType().substring(0, 3);
				String effectiveDategiven = officeHeader.getRemittancePeriodEndDate();
				String effectiveDate = null;
				String effectiveDateForIF = null;
				try {
					effectiveDate = bspUtil.getFormattedDate(effectiveDategiven, "yyMMdd", "yyyy-MM-dd");
					effectiveDateForIF = bspUtil.getFormattedDate(effectiveDateIF, "yyMMdd", "yyyy-MM-dd");
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				// to get from BSPUtil once the method is fixed
//				precision = 2;
				precision = bspUtil.getDecimalPrecision(smartpraMasterAppClient, Optional.of(stationCode),
						carrierMasterFeignClient, decimalUnitValue, currencyCode, Optional.of(effectiveDate),
						Optional.of(clientId), Optional.of(effectiveDateForIF));
			}
		} catch (NumberFormatException nfe) {
			// fall back method below will be used
		}

		mapAgentRegisterList(officeHeaderWrapperStg, precision);

		return officeHeaderWrapperStg;
	}

	private static void mapOfficeHeader(OfficeHeaderWrapperStg officeHeaderWrapperStg, OfficeHeader officeHeader) {

		OfficeHeaderStg officeHeaderStg = BSPRecordMapper.INSTANCE.mapOfficeHeaderRecord(officeHeader);

		officeHeaderWrapperStg.setOfficeHeaderStg(officeHeaderStg);
	}

	private static void mapTransactionRecordList(OfficeHeaderWrapperStg officeHeaderWrapperStg,
			OfficeHeader officeHeader) {
		if (officeHeader.getTransactionRecordList() == null) {
			return;
		}

		ArrayList<TransactionRecordStg> transactionRecordStgList = new ArrayList<TransactionRecordStg>();

		officeHeader.getTransactionRecordList().forEach(item -> {
			TransactionRecordStg transactionRecordStg = TransactionRecordMapper.mapTransactionRecord(item);
			transactionRecordStgList.add(transactionRecordStg);
		});

		if (transactionRecordStgList.size() > 0) {
			officeHeaderWrapperStg.setTransactionRecordStgList(transactionRecordStgList);
		}
	}

	private static void mapOfficeSubtotalsList(OfficeHeaderWrapperStg officeHeaderWrapperStg,
			OfficeHeader officeHeader) {
		if (officeHeader.getOfficeSubtotalsList() == null) {
			return;
		}

		ArrayList<OfficeSubtotalsStg> officeSubtotalsStgList = new ArrayList<OfficeSubtotalsStg>();

		officeHeader.getOfficeSubtotalsList().forEach(item -> {
			OfficeSubtotalsStg officeSubtotalsStg = BSPRecordMapper.INSTANCE.mapOfficeSubtotalsRecord(item);
			officeSubtotalsStgList.add(officeSubtotalsStg);
		});

		if (officeSubtotalsStgList.size() > 0) {
			officeHeaderWrapperStg.setOfficeSubtotalsStgList(officeSubtotalsStgList);
		}
	}

	private static void mapAgentRegisterList(OfficeHeaderWrapperStg officeHeaderWrapperStg, int finalPrecisionValue) {
		if (officeHeaderWrapperStg.getOfficeSubtotalsStgList() == null) {
			return;
		}

		Map<String, AgentRegisterStg> agentRegisterMap = new HashMap<String, AgentRegisterStg>();

		officeHeaderWrapperStg.getOfficeSubtotalsStgList().forEach(officeSubtotalsStg -> {
			String transactionType = officeSubtotalsStg.getTransactionType();
			String currencyType = officeSubtotalsStg.getCurrencyType();
			String key = transactionType + ":" + currencyType;

			if (agentRegisterMap.containsKey(key)) {
				AgentRegisterStg agentRegisterStg = agentRegisterMap.get(key);
				agentRegisterStg.addGrossValueAmt(
						BSPUtil.getSignedFieldStringValue(officeSubtotalsStg.getGrossValueAmt(), finalPrecisionValue));
				agentRegisterStg.addTotalRemittanceAmount(BSPUtil
						.getSignedFieldStringValue(officeSubtotalsStg.getTotalRemittanceAmount(), finalPrecisionValue));
				agentRegisterStg.addTotalCommissionValueAmt(BSPUtil.getSignedFieldStringValue(
						officeSubtotalsStg.getTotalCommissionValueAmt(), finalPrecisionValue));
				agentRegisterStg.addTotalTaxMiscFeeAmt(BSPUtil
						.getSignedFieldStringValue(officeSubtotalsStg.getTotalTaxMiscFeeAmt(), finalPrecisionValue));
				agentRegisterStg.addTotalTaxOnCommissionAmt(BSPUtil.getSignedFieldStringValue(
						officeSubtotalsStg.getTotalTaxOnCommissionAmt(), finalPrecisionValue));
				agentRegisterMap.replace(key, agentRegisterStg);

			} else {
				AgentRegisterStg agentRegisterStg = new AgentRegisterStg();
				agentRegisterStg
						.setAgentNumericCode(BSPUtil.getSignedFieldValue(officeSubtotalsStg.getAgentNumericCode()));
				agentRegisterStg.setRemittancePeriodEndDate(
						BSPUtil.getSignedFieldValue(officeSubtotalsStg.getRemittancePeriodEndDate()));
				agentRegisterStg.setCurrencyType(officeSubtotalsStg.getCurrencyType());
				agentRegisterStg.setTransactionType(officeSubtotalsStg.getTransactionType());
				agentRegisterStg.setGrossValueAmt(
						BSPUtil.getSignedFieldStringValue(officeSubtotalsStg.getGrossValueAmt(), finalPrecisionValue));
				agentRegisterStg.setTotalRemittanceAmount(BSPUtil
						.getSignedFieldStringValue(officeSubtotalsStg.getTotalRemittanceAmount(), finalPrecisionValue));
				agentRegisterStg.setTotalCommissionValueAmt(BSPUtil.getSignedFieldStringValue(
						officeSubtotalsStg.getTotalCommissionValueAmt(), finalPrecisionValue));
				agentRegisterStg.setTotalTaxMiscFeeAmt(BSPUtil
						.getSignedFieldStringValue(officeSubtotalsStg.getTotalTaxMiscFeeAmt(), finalPrecisionValue));
				agentRegisterStg.setTotalTaxOnCommissionAmt(BSPUtil.getSignedFieldStringValue(
						officeSubtotalsStg.getTotalTaxOnCommissionAmt(), finalPrecisionValue));
				agentRegisterMap.put(key, agentRegisterStg);

			}
		});

		officeHeaderWrapperStg.setAgentRegisterStgList(new ArrayList<AgentRegisterStg>(agentRegisterMap.values()));
	}

}
