import { Component, OnInit } from '@angular/core';
import {PaginationService} from '../../../../commons/services/pagination/pagination.service';
import { BsDatepickerConfig, BsDatepickerViewMode } from 'ngx-bootstrap/datepicker';
import { DateConstant } from '../../../../commons/properties/date-constant.properties';
@Component({
  selector: 'app-outward-dashboard-search',
  templateUrl: './outward-dashboard-search.component.html',
  styleUrls: ['./outward-dashboard-search.component.css']
})
export class OutwardDashboardSearchComponent implements OnInit {
  flownList:any = [{},{},{},{},{},{}];
  selectedFlownList:any = [];
  bsConfig: Partial<BsDatepickerConfig>;
  page: any = this.paginateService.getPageinateConfig();
  minMode: BsDatepickerViewMode = 'month';
  constructor(private paginateService: PaginationService) { }

  ngOnInit() {

    this.bsConfig = Object.assign({}, {
      minMode : this.minMode,
      //MONTHYEAR : 'MMM-YY'
       dateInputFormat : DateConstant.MONTHYEAR,
       maxDate : new Date()
    });
  }


  onSelect($event: any, all?: any, data?: any) {
    
  }
}
