import { AlphanumericDirective } from './alphanumeric.directive';

describe('AlphanumericDirective', () => {
  it('should create an instance', () => {
    const directive = new AlphanumericDirective();
    expect(directive).toBeTruthy();
  });
});
