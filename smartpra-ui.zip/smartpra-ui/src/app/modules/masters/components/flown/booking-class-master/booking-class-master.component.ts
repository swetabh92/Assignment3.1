import { Component, ViewChild, ElementRef, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BookingClassService } from '../../../services/flown/booking-class/booking-class.service';
import { GeneralService } from '../../../../../commons/services/general.service';
import { DatepickerOptions } from 'ng2-datepicker';
import { NewAirportMasterService } from '../../../services/flown/new-airport-master/new-airport-master.service';
import { MessageBoxService } from '../../../services/commons/message-box.service';
import { PaginationService } from '../../../../../commons/services/pagination/pagination.service';
import { LovService } from '../../../services/LOV/lov.service';
import { HotkeysService } from 'angular2-hotkeys/src/hotkeys.service';
import { Hotkey } from 'angular2-hotkeys/src/hotkey.model';
import { MasterHotkeys } from '../../../../../commons/properties/master/master-hotkeys.enum'
import { AlertMessageConstants } from '../../../../../commons/properties/alert-message-constants.properties';
import { DateConstant } from '../../../../../commons/properties/date-constant.properties';
import {CommonService} from "../../../../masters/services/commons/common.service";
import { DatePipe } from '@angular/common';
import * as _ from 'underscore';
import { CarrierMasterService } from '../../../services/others/carrier-master/carrier-master.service';
@Component({
	selector: 'app-booking-class-master',
	templateUrl: './booking-class-master.component.html',
	styleUrls: ['./booking-class-master.component.css']
})
export class BookingClassMasterComponent implements OnInit {
	@ViewChild('closeModalAdd') closeModalAdd: ElementRef;
	@ViewChild('closeModalEdit') closeModalEdit: ElementRef;
	@ViewChild('closeModalSearch') closeModalSearch: ElementRef;
	addBookingDet: FormGroup;
	editBookingDet: FormGroup;
	searchForm: FormGroup;
	bookingDet: any = [];
	resetDate = true;
	resetSearchDate = true;
	date = "";
	editsubmitted = false;
	addsubmitted = false;
	searchsubmitted = false;
	airportFromArray: any = [];
	airportToArray: any = [];
	operatingCarrierArray: any=[];
	marketingCarrierArray: any=[];
	formFlag: string = "";
	currentDate : Date = new Date();
	DATE_FORMAT = DateConstant.DATE;
	formObj = {
		operatingCarrier: ['', [Validators.minLength(2)]],
		utilEffectiveFromDate: ['', [Validators.required]],
		utilEffectiveToDate: ['', [Validators.required]],
		rbd: ['', [Validators.required]],
		cabin: ['', [Validators.required]],
		salesEffectiveFromDate: ['',[Validators.required]],
		salesEffectiveToDate: ['',[Validators.required]],
		marketingCarrier: ['', [Validators.minLength(2)]],
		fromAirport: ['', [Validators.minLength(3)]],
		toAirport: ['', [Validators.minLength(3)]],
		cabinPriority: ['',[Validators.maxLength(2)]],
		clientId: [''],
	};
	success: any = { isSuccess: false, successMessage: '' };
	page: any = this.PaginateService.getPageinateConfig();
	utilToMinDate:any;
	utilFromMaxDate:any;
	saleToMinDate:any;
	saleFromMaxDate:any;
	

	constructor(public lov: LovService, private messageBoxService: MessageBoxService, private PaginateService: PaginationService,
		private generalService: GeneralService, private BMService: BookingClassService, private formBuilder: FormBuilder,
		private hotkeysService: HotkeysService, private airportService: NewAirportMasterService, 
		private commonService: CommonService, private carrierService: CarrierMasterService) {
		this.hotkeysService.add(new Hotkey(MasterHotkeys.save, (event: KeyboardEvent): boolean => {
			if (this.formFlag == 'addBookingData') {
				this.onSubmit();
			} else if (this.formFlag == 'editBookingData') {
				this.onUpdate();
			}
			return false;
		}));

		this.hotkeysService.add(new Hotkey(MasterHotkeys.clear, (event: KeyboardEvent): boolean => {
			if (this.formFlag == 'addBookingData') {
				this.resetForm('add');
			} else if (this.formFlag == 'searchBookingData') {
				this.resetForm('search');
				this.getBookingDet();
			}
			return false;
		}));

		this.hotkeysService.add(new Hotkey(MasterHotkeys.cancel, (event: KeyboardEvent): boolean => {
			if (this.formFlag == 'addBookingData') {
				this.onCancelChange();
			} else if (this.formFlag == 'editBookingData') {
				this.onCancelChange();
			} else if (this.formFlag == 'searchBookingData') {
				document.getElementById("closeSearch").click();
			}
			return false;
		}));
	}

	getAllCarrier(): void {
		this.carrierService.getAllCarrierList().subscribe((res: any[]) => {
			this.operatingCarrierArray = res;
			this.marketingCarrierArray = res;
		});
	}

	getAllAirports(): void {
		this.airportService.getAirportList().subscribe((res: any[]) => {
			this.airportFromArray = JSON.parse(JSON.stringify(res));
			this.airportToArray = JSON.parse(JSON.stringify(res));
		});
	}

	editBookingMaster(id, type) {
		this.editBookingDet.get('cabin').disable();
		this.editBookingDet.get('fromAirport').disable();
		this.editBookingDet.get('toAirport').disable();
		if(type == 'update')this.resetForm('edit');else if(type=='add')this.resetForm('add');
		this.BMService.editCustomerDet(id).subscribe((res : any) => {
			if (type == 'update') {
				// this.resetForm('edit');
				let result = Object.assign({}, res);
				result.salesEffectiveFromDate = new Date(this.commonService.covertDate(result.salesEffectiveFromDate));
				result.salesEffectiveToDate = new Date(this.commonService.covertDate(result.salesEffectiveToDate));
				result.utilEffectiveFromDate = new Date(this.commonService.covertDate(result.utilEffectiveFromDate));
				result.utilEffectiveToDate = new Date(this.commonService.covertDate(result.utilEffectiveToDate));
				if(!(_.isEmpty(result.marketingCarrier))){
					result.marketingCarrier	= result.marketingCarrier.trim();
				}
				result.utilEffectiveFromDate > new Date() ? this.editBookingDet.get('utilEffectiveFromDate').enable() : this.editBookingDet.get('utilEffectiveFromDate').disable();
				result.salesEffectiveFromDate > new Date() ? this.editBookingDet.get('salesEffectiveFromDate').enable() : this.editBookingDet.get('salesEffectiveFromDate').disable();
				this.editBookingDet.patchValue(result);
			}
			else {
				// this.resetForm('add');
				let result = Object.assign({}, res);
				result.salesEffectiveFromDate = new Date(this.commonService.covertDate(result.salesEffectiveFromDate));
				result.salesEffectiveToDate = new Date(this.commonService.covertDate(result.salesEffectiveToDate));
				result.utilEffectiveFromDate = new Date(this.commonService.covertDate(result.utilEffectiveFromDate));
				result.utilEffectiveToDate = new Date(this.commonService.covertDate(result.utilEffectiveToDate));
				if(!(_.isEmpty(result.marketingCarrier))){
					result.marketingCarrier	= result.marketingCarrier.trim();
				}
				this.addBookingDet.patchValue(result);
			}
		})
	}
	getBookingDet() {
		this.BMService.getBookingDet().subscribe((res) => {
			this.bookingDet = res;
		});
	}


	resetForm(type) {
		if (type == 'add') {
			this.addsubmitted = false;
			this.addBookingDet.reset();
			this.resetDate = false;
			setTimeout(() => {
				this.resetDate = true;
			}, 10)

		}
		else if (type == 'edit') {
			this.editsubmitted = false;
			this.editBookingDet.reset();
			this.resetDate = false;
			setTimeout(() => {
				this.resetDate = true;
			}, 10)
		}
		else if (type == 'search') {
			this.searchsubmitted = false;
			this.searchForm.reset();
			this.resetSearchDate = false;
			setTimeout(() => {
				this.resetSearchDate = true;
			}, 10);
		}
	}
	ngOnInit() {
		this.lov.initLovDDS('booking_class');
		this.getAllAirports();
		this.getBookingDet();
		this.getAllCarrier();
		this.addBookingDet = this.formBuilder.group(this.formObj);
		let editForm = Object.assign({}, this.formObj);
		editForm['bookingClassId'] = "";
		this.editBookingDet = this.formBuilder.group(editForm);

		this.searchForm = this.formBuilder.group({
			operatingCarrier: ['', [Validators.minLength(2)]],
			utilizationEffectiveFromDate: [''],
			utilizationEffectiveToDate: [''],
			salesEffectiveFromDate: [''],
			salesEffectiveToDate: [''],
			rbd: [''],
			cabin: [''],
			marketingCarrier: ['', [Validators.minLength(2)]],
			fromAirport: ['', [Validators.minLength(3)]],
			toAirport: ['', [Validators.minLength(3)]],
		});

		this.getUtilEffectiveFromDate(this.addBookingDet, 'utilEffectiveFromDate');
		this.getUtilEffectiveToDate(this.addBookingDet, 'utilEffectiveToDate');
		this.getSaleEffectiveFromDate(this.addBookingDet, 'salesEffectiveFromDate');
		this.getSaleEffectiveToDate(this.addBookingDet, 'salesEffectiveToDate');
		this.getUtilEffectiveFromDate(this.editBookingDet, 'utilEffectiveFromDate');
		this.getUtilEffectiveToDate(this.editBookingDet, 'utilEffectiveToDate');
		this.getSaleEffectiveFromDate(this.editBookingDet, 'salesEffectiveFromDate');
		this.getSaleEffectiveToDate(this.editBookingDet, 'salesEffectiveToDate');
		this.getUtilEffectiveFromDate(this.searchForm, 'utilizationEffectiveFromDate');
		this.getUtilEffectiveToDate(this.searchForm, 'utilizationEffectiveToDate');
		this.getSaleEffectiveFromDate(this.searchForm, 'salesEffectiveFromDate');
		this.getSaleEffectiveToDate(this.searchForm, 'salesEffectiveToDate');
	}
	get am() { return this.addBookingDet.controls; }
	get em() { return this.editBookingDet.controls; }
	get sf() { return this.searchForm.controls; }

	getUtilEffectiveFromDate(formName: any, obj: string) {
		formName.controls[obj].valueChanges.subscribe((minDate) => {
			return this.utilToMinDate = minDate;
		});
	}
	getUtilEffectiveToDate(formName: any, obj: string) {
		formName.controls[obj].valueChanges.subscribe((maxDate) => {
			return this.utilFromMaxDate = maxDate;
		});
	}
	getSaleEffectiveFromDate(formName: any, obj: string) {
		formName.controls[obj].valueChanges.subscribe((minDate) => {
			return this.saleToMinDate = minDate;
		});
	}
	getSaleEffectiveToDate(formName: any, obj: string) {
		formName.controls[obj].valueChanges.subscribe((maxDate) => {
			return this.saleFromMaxDate = maxDate;
		});
	}

	onSearch() {
		this.searchsubmitted = true;
		console.log(this.searchForm)
		if (this.searchForm.invalid) return false;
		this.BMService.searchCustomerDet(this.searchForm.value).subscribe((res) => {
			this.bookingDet = res;
		});
	}
	onSubmit() {
		this.addsubmitted = true;
		if(!(_.isEmpty(this.addBookingDet.value.cabinPriority))){
			this.addBookingDet.value.cabinPriority = parseInt(this.addBookingDet.value.cabinPriority);
		}
		if (this.addBookingDet.invalid) return false;
		this.BMService.addBookingDet(this.addBookingDet.value).subscribe((res: any) => {
			if (res && res.bookingClassId) {
				this.updateDataTable(res, 'add');
				this.success = { isSuccess: true, successMessage: "Record has been successfully saved" };
				this.closeModalAdd.nativeElement.click();
				this.closeAlertValidation();
			}
		})
	}

	onUpdate() {
		this.editsubmitted = true;
		if (this.editBookingDet.invalid) return false;
		const bookingDetails = Object.assign({}, this.editBookingDet.getRawValue());
		this.BMService.updateBookingDet(bookingDetails).subscribe((res: any) => {
			if (res && res.bookingClassId) {
				this.updateDataTable(res, 'update');
				this.success = { isSuccess: true, successMessage: "Record has been successfully saved" };
				this.closeModalEdit.nativeElement.click();
				this.closeAlertValidation();
				this.onSearch();
			}
		});
	}

	closeAlertValidation() {
		let tempThis = this;
		window.setTimeout(() => {
			tempThis.success = {
				isSuccess: false,
				successMessage: ''
			};
		}, AlertMessageConstants.CLOSE_ALERT_TIME);
	}
	onCancelChange() {
		this.closeModalAdd.nativeElement.click();
		this.closeModalEdit.nativeElement.click();
	}
	updateDataTable(data, type) {
		if (type == 'add') this.bookingDet.unshift(data);
		else {
			const ind = this.bookingDet.findIndex((item) => { return data.bookingClassId == item.bookingClassId; });
			if (ind == -1) return false; if (type == 'update') this.bookingDet[ind] = data;
		}
		this.bookingDet = [...this.bookingDet];
	}
	validateEffectiveToDate(utilDate,saleDate) {
		return !(new Date(utilDate) > new Date() || new Date(saleDate) > new Date());
	}
	disableCalendarDatesOnUtilFromDateSelction(){
		let getUtilFromDate = this.editBookingDet.get("utilEffectiveFromDate").value;
		if(new Date(getUtilFromDate) < this.currentDate){
			return this.utilToMinDate = this.currentDate;
		}else{
			this.utilToMinDate = this.utilToMinDate;
		}
	}
	disableCalendarDatesOnSaleFromDateSelction(){
		let getSaleFromDate = this.editBookingDet.get("salesEffectiveFromDate").value;
		if( new Date(getSaleFromDate) < this.currentDate){
			return this.saleToMinDate = this.currentDate;
		}else{
			return this.saleToMinDate = this.saleToMinDate;
		}
	}
}
