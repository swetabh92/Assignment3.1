package com.sgl.smartpra.batch.mib.app.validator;

import com.sgl.smartpra.batch.mib.app.config.FeignConfiguration;
import com.sgl.smartpra.batch.mib.app.enums.ErrorCode;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingConstants;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingUtil;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.mib.entity.MiscBillInvTransTotalAmtEntity;
import com.sgl.smartpra.mib.entity.MiscBillingInvTransHeaderEntity;
import com.sgl.smartpra.mib.entity.MiscBillingTrnInvoiceEntity;

import org.apache.commons.collections4.map.HashedMap;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.BiPredicate;
import java.util.function.Predicate;
import java.util.stream.Collectors;

@Component
public class TransmissionHeaderValidator {

    @Autowired
    private FeignConfiguration.SmartpraMasterAppClient smartpraMasterAppClient;
    
	@Autowired
	private MiscBillingUtil miscBillingUtil;

    private BiPredicate<Integer, Integer> isIntEquals = (i,w) -> i.intValue() == w.intValue();

    private Predicate<List> isNotEmptyList = (w) -> w != null && !w.isEmpty();
    
    private String clientId;
    private Integer fileId;
    
    public void populate(MiscBillingInvTransHeaderEntity miscBillingInvTransHeaderEntity) {
    	this.setClientId(miscBillingInvTransHeaderEntity.getClientId());
		this.setFileId(miscBillingInvTransHeaderEntity.getFileId());
    }
    
	public List<ExceptionTransactionModel> validate(MiscBillingInvTransHeaderEntity miscBillingInvTransHeaderEntity){
		this.populate(miscBillingInvTransHeaderEntity);
        List<ExceptionTransactionModel> al = new ArrayList<>();
        Map<String,String> map = new HashedMap<>();
        
        if(!validateIssuingOrganisationId(miscBillingInvTransHeaderEntity)) {
            al.add(miscBillingUtil.prepareExceptionTransactionModel(ErrorCode.MISC1002.toString(), null, clientId, fileId));
        }
        if(!validateBillingCategory(miscBillingInvTransHeaderEntity)){
            al.add(miscBillingUtil.prepareExceptionTransactionModel(ErrorCode.MISC1003.toString(), null, clientId, fileId));
        }
        if(!validateInvoiceCount(miscBillingInvTransHeaderEntity)){
            map.put("Invoice Count", String.valueOf(miscBillingInvTransHeaderEntity.getInvoiceCount()));
            map.put("No. of Invoices in the file", String.valueOf(miscBillingInvTransHeaderEntity.getMiscBillingTrnInvoices().size()));
            al.add(miscBillingUtil.prepareExceptionTransactionModel(ErrorCode.MISC1004.toString(), map, clientId, fileId));
        }
        if(!validateTransactionSummaryTotalAmount(miscBillingInvTransHeaderEntity, map = new HashedMap<>())) {
            al.add(miscBillingUtil.prepareExceptionTransactionModel(ErrorCode.MISC1005.toString(), map, clientId, fileId));
        }
        if (!validateTransactionSummaryAddOnAmount(miscBillingInvTransHeaderEntity, map = new HashedMap<>())) {
             al.add(miscBillingUtil.prepareExceptionTransactionModel(ErrorCode.MISC1005.toString(), map, clientId, fileId));
        }
        if (!validateTransactionSummaryTaxAmount(miscBillingInvTransHeaderEntity, map = new HashedMap<>())) {
            al.add(miscBillingUtil.prepareExceptionTransactionModel(ErrorCode.MISC1005.toString(), map, clientId, fileId));
        }
        if (!validateTransactionSummaryVATAmount(miscBillingInvTransHeaderEntity, map = new HashedMap<>())) {
            al.add(miscBillingUtil.prepareExceptionTransactionModel(ErrorCode.MISC1005.toString(), map, clientId, fileId));
        }
        if (!validateAttachmentCount(miscBillingInvTransHeaderEntity, map = new HashedMap<>())) {
            al.add(miscBillingUtil.prepareExceptionTransactionModel(ErrorCode.MISC1005.toString(), map, clientId, fileId));
        }

        return al;
    }

    public Boolean validateBillingCategory(MiscBillingInvTransHeaderEntity miscBillingInvTransHeaderEntity){
        if(StringUtils.equals(miscBillingInvTransHeaderEntity.getBillingCategory(),"Miscellaneous")){
            return Boolean.TRUE;
        }
        return Boolean.FALSE;
    }

    public Boolean validateIssuingOrganisationId(MiscBillingInvTransHeaderEntity miscBillingInvTransHeaderEntity){
        String organisation = miscBillingInvTransHeaderEntity.getIssuingOrganizationId();
        String num = MiscBillingUtil.getHostCarrierCode(smartpraMasterAppClient, clientId);
        if(StringUtils.isNoneBlank( organisation,num)) {
            if(StringUtils.equals(organisation,num )) {
                return Boolean.TRUE;
            }

        } else {
            return Boolean.TRUE;
        }
        return Boolean.FALSE;
    }

    public Boolean validateInvoiceCount(MiscBillingInvTransHeaderEntity miscBillingInvTransHeaderEntity) {
        if (isNotEmptyList.test(miscBillingInvTransHeaderEntity.getMiscBillingTrnInvoices())) {
            if (miscBillingInvTransHeaderEntity.getMiscBillingTrnInvoices().size() == miscBillingInvTransHeaderEntity
                    .getInvoiceCount()) {
                return Boolean.TRUE;
            }
         }
        return Boolean.FALSE;
    }

    public Boolean validateTransactionSummaryTotalAmount(MiscBillingInvTransHeaderEntity miscBillingInvTransHeaderEntity,
                                                         Map<String,String> m) {
        List<MiscBillInvTransTotalAmtEntity> miscBillInvTransTotalAmtEntities = miscBillingInvTransHeaderEntity
                .getMiscBillInvTransTotalAmt();
        List<MiscBillingTrnInvoiceEntity> miscBillingTrnInvoiceEntities = miscBillingInvTransHeaderEntity
                .getMiscBillingTrnInvoices();

        if(isNotEmptyList.test(miscBillingTrnInvoiceEntities) && isNotEmptyList.test(miscBillInvTransTotalAmtEntities)){


            Map<String, Map<String, BigDecimal>> mTotalAmount = getMiscInvTrnTotalAmtEntities(miscBillInvTransTotalAmtEntities);

            Map<String,BigDecimal> mInvTotalAm = miscBillingTrnInvoiceEntities.stream()
                    .filter(Objects::nonNull)
                    .filter(w -> StringUtils.isNoneBlank(w.getCurrencyCode()))
                    .map(w -> {
                        if (w.getTotalAmount() == null) {
                            w.setTotalAmount(BigDecimal.ZERO);
                        }
                        return w;
                    })
                   .collect(Collectors.groupingBy(MiscBillingTrnInvoiceEntity::getCurrencyCode,
                           Collectors.reducing(BigDecimal.ZERO,MiscBillingTrnInvoiceEntity::getTotalAmount,
                                   BigDecimal::add)));


            Map<String,BigDecimal> mInvTAm = mTotalAmount.getOrDefault("AMT",Collections.emptyMap());
            if(mInvTAm != null && !mInvTAm.isEmpty()){
                if(mInvTAm.entrySet().stream().filter(e -> !mInvTotalAm.containsKey(e.getKey()) ).findFirst().isPresent()){
                    Map.Entry<String,BigDecimal> e =
                            mInvTAm.entrySet().stream().filter(w -> !mInvTotalAm.containsKey(w.getKey()) ).findFirst().get();
                    m.put(MiscBillingConstants.MISC1005_P1, String.valueOf(e.getValue()));
                    m.put(MiscBillingConstants.MISC1005_P2,e.getKey());
                    m.put(MiscBillingConstants.MISC1005_P3,String.valueOf(mInvTAm.get(e.getKey())));
                    return Boolean.FALSE;
                } else if(mInvTAm.entrySet().stream().filter(e ->
                    mInvTotalAm.getOrDefault(e.getKey(),BigDecimal.ZERO).compareTo(e.getValue()) != 0
                ).findFirst().isPresent()){
                    Map.Entry<String,BigDecimal> e =
                            mInvTAm.entrySet().stream().filter(w ->
                                    mInvTotalAm.getOrDefault(w.getKey(),BigDecimal.ZERO).compareTo(w.getValue()) != 0
                            ).findFirst().get();
                    m.put(MiscBillingConstants.MISC1005_P1, String.valueOf(e.getValue()));
                    m.put(MiscBillingConstants.MISC1005_P2,e.getKey());
                    m.put(MiscBillingConstants.MISC1005_P3,String.valueOf(mInvTAm.get(e.getKey())));
                   return Boolean.FALSE;
                } else {
                    return Boolean.TRUE;
                }
            }


        }
        return Boolean.FALSE;
    }

    private Map<String, Map<String, BigDecimal>> getMiscInvTrnTotalAmtEntities(List<MiscBillInvTransTotalAmtEntity> miscBillInvTransTotalAmtEntities) {
        return miscBillInvTransTotalAmtEntities
                .stream()
                .collect(Collectors
                        .groupingBy(MiscBillInvTransTotalAmtEntity::getAmountType, Collectors
                                .groupingBy(MiscBillInvTransTotalAmtEntity::getCurrencyCode,
                                        Collectors.reducing(BigDecimal.ZERO,
                                                MiscBillInvTransTotalAmtEntity::getTotalAmount,
                                                BigDecimal::add))));
    }

    public Boolean validateTransactionSummaryVATAmount(MiscBillingInvTransHeaderEntity miscBillingInvTransHeaderEntity
            ,Map<String,String> m) {
        List<MiscBillInvTransTotalAmtEntity> miscBillInvTransTotalAmtEntities = miscBillingInvTransHeaderEntity
                .getMiscBillInvTransTotalAmt();
        List<MiscBillingTrnInvoiceEntity> miscBillingTrnInvoiceEntities = miscBillingInvTransHeaderEntity
                .getMiscBillingTrnInvoices();

        if(isNotEmptyList.test(miscBillingTrnInvoiceEntities) && isNotEmptyList.test(miscBillInvTransTotalAmtEntities)){

            Map<String, Map<String, BigDecimal>> mTotalAmount = getMiscInvTrnTotalAmtEntities(miscBillInvTransTotalAmtEntities);

            Map<String,BigDecimal> mInvTotalAm = miscBillingTrnInvoiceEntities.stream()
                    .filter(Objects::nonNull)
                    .filter(w -> StringUtils.isNotEmpty(w.getCurrencyCode()))
                    .map(w -> {
                        if (w.getTotalVatAmount() == null) {
                            w.setTotalVatAmount(BigDecimal.ZERO);
                        }
                        return w;
                    })
                    .collect(Collectors.groupingBy(w -> w.getCurrencyCode(),
                            Collectors.reducing(BigDecimal.ZERO,MiscBillingTrnInvoiceEntity::getTotalVatAmount,
                                    BigDecimal::add)));


            Map<String,BigDecimal> mInvTAm = mTotalAmount.getOrDefault("VAT",Collections.emptyMap());
            if(mInvTAm != null && !mInvTAm.isEmpty()){
                if(mInvTAm.entrySet().stream().filter(e -> !mInvTotalAm.containsKey(e.getKey()) ).findFirst().isPresent()){
                    Map.Entry<String,BigDecimal> e =
                            mInvTAm.entrySet().stream().filter(w -> !mInvTotalAm.containsKey(w.getKey()) ).findFirst().get();
                    m.put(MiscBillingConstants.MISC1005_P1, String.valueOf(e.getValue()));
                    m.put(MiscBillingConstants.MISC1005_P2,e.getKey());
                    m.put(MiscBillingConstants.MISC1005_P3,String.valueOf(mInvTAm.get(e.getKey())));
                    return Boolean.FALSE;
                } else if(mInvTAm.entrySet().stream().filter(e ->
                        mInvTotalAm.getOrDefault(e.getKey(),BigDecimal.ZERO).compareTo(e.getValue()) != 0
                ).findFirst().isPresent()){
                    Map.Entry<String,BigDecimal> e =
                            mInvTAm.entrySet().stream().filter(w ->
                                    mInvTotalAm.getOrDefault(w.getKey(),BigDecimal.ZERO).compareTo(w.getValue()) != 0
                            ).findFirst().get();
                    m.put(MiscBillingConstants.MISC1005_P1, String.valueOf(e.getValue()));
                    m.put(MiscBillingConstants.MISC1005_P2,e.getKey());
                    m.put(MiscBillingConstants.MISC1005_P3,String.valueOf(mInvTAm.get(e.getKey())));
                    return Boolean.FALSE;
                } else {
                    return Boolean.TRUE;
                }
            }
        }
        return Boolean.FALSE;
    }

    public Boolean validateTransactionSummaryTaxAmount(MiscBillingInvTransHeaderEntity miscBillingInvTransHeaderEntity
                                                        ,Map<String,String> m) {
        List<MiscBillInvTransTotalAmtEntity> miscBillInvTransTotalAmtEntities = miscBillingInvTransHeaderEntity
                .getMiscBillInvTransTotalAmt();
        List<MiscBillingTrnInvoiceEntity> miscBillingTrnInvoiceEntities = miscBillingInvTransHeaderEntity
                .getMiscBillingTrnInvoices();

        if(isNotEmptyList.test(miscBillingTrnInvoiceEntities) && isNotEmptyList.test(miscBillInvTransTotalAmtEntities)){

            Map<String, Map<String, BigDecimal>> mTotalAmount = getMiscInvTrnTotalAmtEntities(miscBillInvTransTotalAmtEntities);

            Map<String,BigDecimal> mInvTotalAm = miscBillingTrnInvoiceEntities.stream()
                    .filter(Objects::nonNull)
                    .filter(w -> StringUtils.isNoneBlank(w.getCurrencyCode()))
                    .map(w -> {
                        if (w.getTotalTaxAmount() == null) {
                            w.setTotalTaxAmount(BigDecimal.ZERO);
                        }
                        return w;
                    })
                    .collect(Collectors.groupingBy(MiscBillingTrnInvoiceEntity::getCurrencyCode,
                            Collectors.reducing(BigDecimal.ZERO,MiscBillingTrnInvoiceEntity::getTotalTaxAmount,
                                    BigDecimal::add)));


            Map<String,BigDecimal> mInvTAm = mTotalAmount.getOrDefault("TAX",Collections.emptyMap());
            if(mInvTAm != null && !mInvTAm.isEmpty()){
                if(mInvTAm.entrySet().stream().filter(e -> !mInvTotalAm.containsKey(e.getKey()) ).findFirst().isPresent()){
                    Map.Entry<String,BigDecimal> e =
                            mInvTAm.entrySet().stream().filter(w -> !mInvTotalAm.containsKey(w.getKey()) ).findFirst().get();
                    m.put(MiscBillingConstants.MISC1005_P1, String.valueOf(e.getValue()));
                    m.put(MiscBillingConstants.MISC1005_P2,e.getKey());
                    m.put(MiscBillingConstants.MISC1005_P3,String.valueOf(mInvTAm.get(e.getKey())));
                    return Boolean.FALSE;
                } else if(mInvTAm.entrySet().stream().filter(e ->
                        mInvTotalAm.getOrDefault(e.getKey(),BigDecimal.ZERO).compareTo(e.getValue()) != 0
                ).findFirst().isPresent()){
                    Map.Entry<String,BigDecimal> e =
                            mInvTAm.entrySet().stream().filter(w ->
                                    mInvTotalAm.getOrDefault(w.getKey(),BigDecimal.ZERO).compareTo(w.getValue()) != 0
                            ).findFirst().get();
                    m.put(MiscBillingConstants.MISC1005_P1, String.valueOf(e.getValue()));
                    m.put(MiscBillingConstants.MISC1005_P2,e.getKey());
                    m.put(MiscBillingConstants.MISC1005_P3,String.valueOf(mInvTAm.get(e.getKey())));
                    return Boolean.FALSE;
                } else {
                    return Boolean.TRUE;
                }
            }
        }
        return Boolean.FALSE;
    }

    public Boolean validateTransactionSummaryAddOnAmount(MiscBillingInvTransHeaderEntity miscBillingInvTransHeaderEntity,
                                                         Map<String,String> m) {
        List<MiscBillInvTransTotalAmtEntity> miscBillInvTransTotalAmtEntities = miscBillingInvTransHeaderEntity
                .getMiscBillInvTransTotalAmt();
        List<MiscBillingTrnInvoiceEntity> miscBillingTrnInvoiceEntities = miscBillingInvTransHeaderEntity
                .getMiscBillingTrnInvoices();

        if(isNotEmptyList.test(miscBillingTrnInvoiceEntities) && isNotEmptyList.test(miscBillInvTransTotalAmtEntities)){

            Map<String, Map<String, BigDecimal>> mTotalAmount = getMiscInvTrnTotalAmtEntities(miscBillInvTransTotalAmtEntities);

            Map<String,BigDecimal> mInvTotalAm = miscBillingTrnInvoiceEntities.stream()
                    .filter(Objects::nonNull)
                    .filter(w -> StringUtils.isNoneBlank(w.getCurrencyCode()))
                    .map(w -> {
                        if (w.getTotalAddonChargeAmount() == null) {
                            w.setTotalAddonChargeAmount(BigDecimal.ZERO);
                        }
                        return w;
                    })
                    .collect(Collectors.groupingBy(MiscBillingTrnInvoiceEntity::getCurrencyCode,
                            Collectors.reducing(BigDecimal.ZERO,MiscBillingTrnInvoiceEntity::getTotalAddonChargeAmount,
                                    BigDecimal::add)));



            Map<String,BigDecimal> mInvTAm = mTotalAmount.getOrDefault("AOC",Collections.emptyMap());
            if(mInvTAm != null && !mInvTAm.isEmpty()){
                if(mInvTAm.entrySet().stream().filter(e -> !mInvTotalAm.containsKey(e.getKey()) ).findFirst().isPresent()){
                    Map.Entry<String,BigDecimal> e =
                            mInvTAm.entrySet().stream().filter(w -> !mInvTotalAm.containsKey(w.getKey()) ).findFirst().get();
                    m.put(MiscBillingConstants.MISC1005_P1, String.valueOf(e.getValue()));
                    m.put(MiscBillingConstants.MISC1005_P2,e.getKey());
                    m.put(MiscBillingConstants.MISC1005_P3,String.valueOf(mInvTAm.get(e.getKey())));
                    return Boolean.FALSE;
                } else if(mInvTAm.entrySet().stream().filter(e ->
                        mInvTotalAm.getOrDefault(e.getKey(),BigDecimal.ZERO).compareTo(e.getValue()) != 0
                ).findFirst().isPresent()){
                    Map.Entry<String,BigDecimal> e =
                            mInvTAm.entrySet().stream().filter(w ->
                                    mInvTotalAm.getOrDefault(w.getKey(),BigDecimal.ZERO).compareTo(w.getValue()) != 0
                            ).findFirst().get();
                    m.put(MiscBillingConstants.MISC1005_P1, String.valueOf(e.getValue()));
                    m.put(MiscBillingConstants.MISC1005_P2, e.getKey());
                    m.put(MiscBillingConstants.MISC1005_P3, String.valueOf(mInvTAm.get(e.getKey())));
                    return Boolean.FALSE;
                } else {
                    return Boolean.TRUE;
                }
            }


        }
        return Boolean.FALSE;
    }


    public Boolean validateAttachmentCount(MiscBillingInvTransHeaderEntity miscBillingInvTransHeaderEntity,
                                           Map<String,String> m) {
        List<MiscBillingTrnInvoiceEntity> miscBillingTrnInvoiceEntities = miscBillingInvTransHeaderEntity
                .getMiscBillingTrnInvoices();

        if(isNotEmptyList.test(miscBillingTrnInvoiceEntities)){

            int totalAttachmentCount = miscBillingTrnInvoiceEntities.stream()
                    .map(miscBillingTrnInvoiceEntity -> miscBillingTrnInvoiceEntity.getNoOfAttachments() != null
                            ? miscBillingTrnInvoiceEntity.getNoOfAttachments() : 0)
                    .reduce(0,Integer::sum);

            int count = miscBillingInvTransHeaderEntity.getAttachmentCount() == null ? 0  : miscBillingInvTransHeaderEntity.getAttachmentCount();
            m.put("Attachment Count",String.valueOf(miscBillingInvTransHeaderEntity.getAttachmentCount()));
            m.put("Attachment Counts",String.valueOf(totalAttachmentCount));
            if(totalAttachmentCount == count){
                return Boolean.TRUE;
            }

        }
        return Boolean.FALSE;
    }

    /**
 	 * @return the clientId
 	 */
 	public String getClientId() {
 		return clientId;
 	}

 	/**
 	 * @param clientId the clientId to set
 	 */
 	public void setClientId(String clientId) {
 		this.clientId = clientId;
 	}

 	/**
 	 * @return the fileId
 	 */
 	public Integer getFileId() {
 		return fileId;
 	}

 	/**
 	 * @param fileId the fileId to set
 	 */
 	public void setFileId(Integer fileId) {
 		this.fileId = fileId;
 	}


}
