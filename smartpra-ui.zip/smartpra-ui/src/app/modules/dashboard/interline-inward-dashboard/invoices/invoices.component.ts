import {Component, OnInit, Input, ElementRef, ViewChild, EventEmitter, Output} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {InwardDashboardService} from '../inward-dashboard.service';
import {PaginationService} from '../../../../commons/services/pagination/pagination.service';
import {CommonService} from '../../../masters/services/commons/common.service';
import { InterlineConstant } from '../constants/interline-constants';
import { InwardSearchModel } from '../models/inward-search-model';
import { MessageBoxService } from '../../../masters/services/commons/message-box.service';

@Component({
  selector: 'app-invoices',
  templateUrl: './invoices.component.html',
  styleUrls: ['../inward-dashboard.component.css']
})
export class InvoicesComponent implements OnInit {
  summarizedDownArrow:boolean = true;
  productionMode:boolean = false;
  invoiceEditSubmitted:boolean = false;
  showSummarizesdDT:boolean = true;
  singleSelectIcon:boolean;
  multiSelectIcon:boolean;
  invoiceRecords:any = [];
  selectedInvoiceList:any = [];
  selectedIDs: any[] = [];
  selectedCoupon:any;
  invoiceParams:any;
  page: any = this.paginateService.setCustomPaginationConfig({"pageSize": 5});
  count:number = 0;
  invoiceEditFormStag: FormGroup;
  clientID: string;
  @ViewChild('closeModalEdit') closeModalEdit: ElementRef;
  statusExpansion = InterlineConstant.STATUS_EXPANSION;
  @Output() batchSearchParams = new EventEmitter<any>();
  @Output() invoiceEmpty = new EventEmitter<any>();


  @Input('requestParams')
  set requestParams(requestParams: any) {
    if (requestParams) {
      this.invoiceParams = requestParams;
      this.page  = this.paginateService.setCustomPaginationConfig({"pageSize": 5});
      this.loadInvoices(requestParams);
    }
  }
  constructor(private paginateService: PaginationService, private commonService: CommonService,
    private formBuilder: FormBuilder,private inwardService: InwardDashboardService,private messageService: MessageBoxService) {

  }


  ngOnInit() {
    this.clientID = this.commonService.getClientId();
    this.invoiceEditFormStag = this.formBuilder.group({
      billedAirline:[''],
      billingAirline: [''],
      billingCode: [''],
      billingMonth: [''],
      billingPeriod: [''],
      chAgreementIndicator: [''],
      chDueDate: [''],
      clientId: [''],
      createdBy: [''],
      createdDate: [''],
      currencyOfBilling: [''],
      currencyOfListingEvaluation: [''],

      digitalSignatureFlag: [''],
      errorIndicator: [''],
      fileId: [''],
      fimInvoiceIndicator: [''],
      handlingFeeAbsorpAmount: [''],
      handlingFeeAbsorpAmtSign: [''],
      handlingFeeAbsorpPercenSign: [''],
      handlingFeeAbsorpPercent: [''],
      handlingFeeAmountSign: [''],
      idecFileDtlId: [''],
      idecInvoiceHdrId: [''],
      invoiceDate: [''],
      invoiceNumber: [''],
      invoiceSource: [''],
      invoiceType: [''],
      listingEvaluationToBillingRate: [''],
      netAmtAfterSamplingConst: [''],
      netBillingAmount: [''],
      netBillingAmountSign: [''],
      netTotal: [''],
      netTotalSign: [''],
      //noOfBillingRecords: [''],
      otherCommAbsorpPercent: [''],
      otherCommAbsorptionAmount: [''],
      otherCommAbsorptionAmtSign: [''],
      otherCommAbsorptionSign: [''],
      provAdjustmentRateSign: [''],
      provisionalBillingMonth: [''],
      settlementMethod:[''],
      status: [''],
      suspendedFlag: [''],
      systemExchangeRate: [''],
      totNetAmtWithoutVatSign: [''],
      totProviAdjustAmtSign: [''],
      totProviAdjustmentAmt: [''],
      totalGrossValue: [''],
      totalGrossValueSign: [''],
      totalHandlingFeeAmount: [''],
      totalInterlineServiceCharge: [''],
      totalIscSign: [''],
      totalNetAmountWithoutVat: [''],
      //totalNumberOfRecords: [''],
      totalOtherCommAmountSign: [''],
      totalOtherCommissionAmount: [''],
      totalTax: [''],
      totalTaxSign: [''],
      totalUatpAmount: [''],
      totalUatpAmountSign: [''],
      totalVatAmount: [''],
      totalVatAmountSign: [''],
      usdExchangeRate: [''],
      vatAbsorptionAmount: [''],
      vatAbsorptionAmountSign: [''],
      vatAbsorptionPercent: [''],
      vatAbsorptionPercentSign: ['']
    });
  }

  get ies() { return this.invoiceEditFormStag.controls; }

  getserverSideData(pageInfo) {
		this.page = this.paginateService.mergePageObj(pageInfo, this.page);
		this.loadInvoices(this.invoiceParams);
  }

  emptyInvoices(){
    this.selectedInvoiceList = [];
    this.invoiceRecords = [];
    this.selectedCoupon = null;
    this.invoiceRecords = [...this.invoiceRecords];
  }

  loadInvoices(data: InwardSearchModel) {
    if (data.area && data.area == InterlineConstant.PRODUCTION) {
      this.productionMode = true;
    } else {
      this.productionMode = false;
    }
    this.selectedInvoiceList = [];
    let paginates = this.paginateService.getQueryObj(this.page);
    this.inwardService.getInvoicesData(data,paginates).subscribe((response:any)=> {
      if(!this.productionMode) {
				this.page.count = response.totalCount;
        this.invoiceRecords = response.invoiceDetailsStg;
        if (this.invoiceRecords && this.invoiceRecords.length > 0 && this.invoiceRecords[0]) {
          this.selectedInvoiceList = [this.invoiceRecords[0]];
          this.selectedCoupon = this.invoiceRecords[0];
          this.createBatchParams(data.area, this.invoiceRecords[0].idecInvoiceHdrId);
          this.singleSelectIcon = false;
          this.multiSelectIcon = false;
        } else {
          this.invoiceEmpty.emit();
        }
      } else {
        //this.invoiceRecords = response.invoiceDetailsProd;
      }
    });
  }

  createBatchParams(area:string, idecInvoiceHdrId: number) {
    let params = {
      area: area,
      invoiceHeaderId: idecInvoiceHdrId
    };
    this.batchSearchParams.emit(params);
  }

  onSelectRow(event, type?:string, inputevent?:any){
    if(type == InterlineConstant.ALL && event.selected) {
      if (event.selected.length > 0) {
        this.selectedInvoiceList = event.selected;
      } else {
        this.selectedInvoiceList = [];
      }
    } else {
      if(inputevent && inputevent.target.checked) {
          this.selectedInvoiceList.push(event);
          this.selectedCoupon = event;
          if(!this.productionMode)
            this.createBatchParams(InterlineConstant.STAGING,event.idecInvoiceHdrId);
      } else {
        if (this.selectedInvoiceList.length > 0) {
          let ind:number, index:number;
          if(!this.productionMode) {
            ind = this.selectedInvoiceList.findIndex(item => item['idecInvoiceHdrId'] == event['idecInvoiceHdrId']);
          } else {
            //ind = this.selectedInvoiceList.findIndex(item => item['idecInvoiceHdrId'] == event['idecInvoiceHdrId']);
          }
          this.selectedInvoiceList.splice(ind,1);
        }
      }
    }
    if (this.selectedInvoiceList.length == 1) {
      this.singleSelectIcon = false;
    } else {
      this.singleSelectIcon = true;
    }
    if (this.selectedInvoiceList.length > 0)
      this.multiSelectIcon = false;
    else
      this.multiSelectIcon = true;
  }

  onCancelChange(){
    this.closeModalEdit.nativeElement.click();
  }

  updateInvoice(){
    this.invoiceEditSubmitted = true;
    if(!this.productionMode) {
      if (this.invoiceEditFormStag.valid) {
        let id = this.selectedCoupon.invoiceNumber;
        this.inwardService.updateInvoiceStagData(id, this.invoiceEditFormStag.value).subscribe((response:any)=> {
          if (response.error === null) {
            this.loadInvoices(this.invoiceParams);
            this.messageService.getSuccessMessage(InterlineConstant.SUCCESS,InterlineConstant.RECORDUPDATESUCCESS);
            this.closeModalEdit.nativeElement.click();
          }
        });
      }
    }
  }

  updateDataTable(data, type) {
		if (type == InterlineConstant.ADD) this.invoiceRecords.unshift(data);
		else {
			const ind = this.invoiceRecords.findIndex((item) => { return data.interlineForm3CsvId == item.interlineForm3CsvId; });
			if (ind == -1) return false; if (type == InterlineConstant.UPDATE) this.invoiceRecords[ind] = data;
		}
		this.invoiceRecords = [...this.invoiceRecords];
  }

  editInvRecords(){
    if(!this.productionMode) {
      let id = this.selectedCoupon.idecInvoiceHdrId;
      this.inwardService.getInvoiceById(id).subscribe((response:any)=> {
        this.invoiceEditFormStag.patchValue(response);
      });
    } else {
      //this.invoiceEditFormProd.patchValue(this.selectedCoupon);
    }

  }

  deleteInvRecords(){
    if(!this.productionMode) {
      this.selectedIDs = this.selectedInvoiceList.map(res => res.idecInvoiceHdrId);
    } else {
      //this.selectedIDs = this.selectedInvoiceList.map(res => res.idecInvoiceHdrId);
    }
    let ids = this.selectedIDs.toString();
    this.messageService.deleteRecordMessage(this.selectedIDs.length).then((result) => {
			if (result.value) {
        if(!this.productionMode) {
          this.inwardService.deleteInvoiceStgData(ids).subscribe((response:any)=> {
            this.loadInvoices(this.invoiceParams);
            this.singleSelectIcon = true;
            this.multiSelectIcon = true;
            this.selectedInvoiceList = [];
            this.messageService.getSuccessMessage(InterlineConstant.SUCCESS,InterlineConstant.DELETEMESSAGE);
          });
        } else {
          /*this.inwardService.deleteInvoiceStgData(ids).subscribe((response:any)=> {
            this.loadInvoices(this.invoiceParams);
            this.singleSelectIcon = true;
            this.multiSelectIcon = true;
            this.selectedInvoiceList = [];
            this.messageService.getSuccessMessage(InterlineConstant.SUCCESS,InterlineConstant.DELETEMESSAGE);
          });*/
        }
      }
    });

  }

  removeCommaFromAmount(data : any){
    Object.keys(data).forEach((key) => {
      if (data[key] && data[key] !== null && data[key] !== undefined &&(key == 'paxAmount' || key == 'cargoAmount' || key == 'uatpAmount' || key == 'miscAmount' || key == 'miscellaneousAmount' || key == 'totalDebitAmount' || key == 'totalCreditAmount' || key == 'debitAmount' || key == 'creditAmount' || key == 'totalBalance' || key == 'balanceAmount')) {
        if(data[key].indexOf(",") != -1)
          data[key] = data[key].replace(/\,/g,"");
      }
    });
    return data;
  }

  validateInvRecords(){}

  onResetSearch(){}

  cancelSearch(event){}

  showSearchBox(): void {
  }
}

