package com.sgl.smartpra.allocation.master.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.allocation.master.app.service.FileTypeMappingService;
import com.sgl.smartpra.allocation.master.model.FileType;
import com.sgl.smartpra.allocation.master.model.FileTypeMapping;

@RestController
public class FileMappingController {

	@Autowired
	FileTypeMappingService fileTypeMappingService;

	@GetMapping("/file-type-mapping/{fileTypeMappingId}")
	@ResponseStatus(value = HttpStatus.OK)
	public FileTypeMapping findByFileTypeMappingId(@PathVariable("fileTypeMappingId") Integer fileTypeMappingId) {
		return fileTypeMappingService.findByFileTypeMappingId(fileTypeMappingId);
	}

	@GetMapping("/file-type-mapping")
	@ResponseStatus(value = HttpStatus.OK)
	public List<FileTypeMapping> getAllFileTypeMappings() {
		return fileTypeMappingService.findAll();
	}
	
	@GetMapping("/file-type-mapping/{moduleLovId}/{fileTypeId}")
	@ResponseStatus(value = HttpStatus.OK)
	public FileTypeMapping getFileTypeMappingByFileTypeId(@PathVariable("moduleLovId") Integer moduleLovId,
			@PathVariable("fileTypeId") Integer fileTypeId) {
		return fileTypeMappingService.findFileTypeMappingByFileTypeId(fileTypeId, moduleLovId);
	}

	@GetMapping("/file-type-mapping/filetype/{lovModuleId}")
	@ResponseStatus(value = HttpStatus.OK)
	public List<FileType> getAllFileType(@PathVariable("lovModuleId") Integer lovModuleId,
			@RequestParam(value = "clientId", required = false) String clientId) {
		return fileTypeMappingService.getFileTypeByModuleId(lovModuleId,clientId);
	}
	
	@GetMapping("/file-type-mapping/filetype")
	@ResponseStatus(value = HttpStatus.OK)
	public List<FileType> getAllFileType() {
		return fileTypeMappingService.findAllFileType();
	}
}
