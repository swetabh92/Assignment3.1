import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-role-funtion-action',
  templateUrl: './role-funtion-action.component.html',
  styleUrls: ['./role-funtion-action.component.css']
})
export class RoleFuntionActionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
