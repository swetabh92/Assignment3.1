package com.sgl.smartpra.batch.amadeus.app.domain;

import java.io.Serializable;

public  class AmadeusETLCouponDetails implements Serializable{

	private String cabin;

	private String clientId;

	private int couponNumber;

	private String destination;

	private String documentNumber;

	private int fileId;

	private String issueAirline;

	private String marketingCarrierDesignator;

	private String marketingCarrierNumCode;

	private Object marketingFlightDate;

	private String marketingFlightNumber;

	private String operatingCarrierDesignator;

	private String operatingCarrierNumCode;

	private Object operatingFlightDate;

	private String operatingFlightNumber;

	private String origin;

	private String rbd;

	public String getCabin() {
		return cabin;
	}

	public void setCabin(String cabin) {
		this.cabin = cabin;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public int getCouponNumber() {
		return couponNumber;
	}

	public void setCouponNumber(int couponNumber) {
		this.couponNumber = couponNumber;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getDocumentNumber() {
		return documentNumber;
	}

	public void setDocumentNumber(String documentNumber) {
		this.documentNumber = documentNumber;
	}

	public int getFileId() {
		return fileId;
	}

	public void setFileId(int fileId) {
		this.fileId = fileId;
	}

	public String getIssueAirline() {
		return issueAirline;
	}

	public void setIssueAirline(String issueAirline) {
		this.issueAirline = issueAirline;
	}

	public String getMarketingCarrierDesignator() {
		return marketingCarrierDesignator;
	}

	public void setMarketingCarrierDesignator(String marketingCarrierDesignator) {
		this.marketingCarrierDesignator = marketingCarrierDesignator;
	}

	public String getMarketingCarrierNumCode() {
		return marketingCarrierNumCode;
	}

	public void setMarketingCarrierNumCode(String marketingCarrierNumCode) {
		this.marketingCarrierNumCode = marketingCarrierNumCode;
	}

	public Object getMarketingFlightDate() {
		return marketingFlightDate;
	}

	public void setMarketingFlightDate(Object marketingFlightDate) {
		this.marketingFlightDate = marketingFlightDate;
	}

	public String getMarketingFlightNumber() {
		return marketingFlightNumber;
	}

	public void setMarketingFlightNumber(String marketingFlightNumber) {
		this.marketingFlightNumber = marketingFlightNumber;
	}

	public String getOperatingCarrierDesignator() {
		return operatingCarrierDesignator;
	}

	public void setOperatingCarrierDesignator(String operatingCarrierDesignator) {
		this.operatingCarrierDesignator = operatingCarrierDesignator;
	}

	public String getOperatingCarrierNumCode() {
		return operatingCarrierNumCode;
	}

	public void setOperatingCarrierNumCode(String operatingCarrierNumCode) {
		this.operatingCarrierNumCode = operatingCarrierNumCode;
	}

	public Object getOperatingFlightDate() {
		return operatingFlightDate;
	}

	public void setOperatingFlightDate(Object operatingFlightDate) {
		this.operatingFlightDate = operatingFlightDate;
	}

	public String getOperatingFlightNumber() {
		return operatingFlightNumber;
	}

	public void setOperatingFlightNumber(String operatingFlightNumber) {
		this.operatingFlightNumber = operatingFlightNumber;
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public String getRbd() {
		return rbd;
	}

	public void setRbd(String rbd) {
		this.rbd = rbd;
	}
}
