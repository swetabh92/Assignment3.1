package com.sgl.smartpra.batch.sales.validator.app.domain;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the file_total_curr_type_stg database table.
 * 
 */
@Entity
@Table(name="file_total_curr_type_stg")
public class FileTotalCurrTypeStg extends BSPRecord implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="file_total_curr_type_id")
	private int fileTotalCurrTypeId;

	@Column(name="bsp_identifier")
	private String bspIdentifier;

	@Column(name="created_by")
	private String createdBy;

	@Column(name="created_date")
	private Timestamp createdDate;

	@Column(name="currency_type")
	private String currencyType;

	@Column(name="gross_value_amt")
	private String grossValueAmt;

	@Column(name="last_updated_by")
	private String lastUpdatedBy;

	@Column(name="last_updated_date")
	private Timestamp lastUpdatedDate;

	@Column(name="office_count")
	private String officeCount;

	@Column(name="reserved_space")
	private String reservedSpace;

	@Column(name="seq_number")
	private String seqNumber;

	@Column(name="std_message_identifier")
	private String stdMessageIdentifier;

	@Column(name="std_numeric_qualifier")
	private String stdNumericQualifier;

	@Column(name="total_commission_value_amt")
	private String totalCommissionValueAmt;

	@Column(name="total_remittance_amt")
	private String totalRemittanceAmt;

	@Column(name="total_tax_misc_fee_amt")
	private String totalTaxMiscFeeAmt;

	@Column(name="total_tax_on_commission_amt")
	private String totalTaxOnCommissionAmt;

	//bi-directional many-to-one association to SalesFileHeaderStg
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.MERGE)
	@JoinColumn(name="file_hdr_id")
	private SalesFileHeaderStg salesFileHeaderStg;

	public FileTotalCurrTypeStg() {
	}

	public int getFileTotalCurrTypeId() {
		return this.fileTotalCurrTypeId;
	}

	public void setFileTotalCurrTypeId(int fileTotalCurrTypeId) {
		this.fileTotalCurrTypeId = fileTotalCurrTypeId;
	}

	public String getBspIdentifier() {
		return this.bspIdentifier;
	}

	public void setBspIdentifier(String bspIdentifier) {
		this.bspIdentifier = bspIdentifier;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCurrencyType() {
		return this.currencyType;
	}

	public void setCurrencyType(String currencyType) {
		this.currencyType = currencyType;
	}

	public String getGrossValueAmt() {
		return this.grossValueAmt;
	}

	public void setGrossValueAmt(String grossValueAmt) {
		this.grossValueAmt = grossValueAmt;
	}

	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getLastUpdatedDate() {
		return this.lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getOfficeCount() {
		return this.officeCount;
	}

	public void setOfficeCount(String officeCount) {
		this.officeCount = officeCount;
	}

	public String getReservedSpace() {
		return this.reservedSpace;
	}

	public void setReservedSpace(String reservedSpace) {
		this.reservedSpace = reservedSpace;
	}

	public String getSeqNumber() {
		return this.seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdMessageIdentifier() {
		return this.stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getStdNumericQualifier() {
		return this.stdNumericQualifier;
	}

	public void setStdNumericQualifier(String stdNumericQualifier) {
		this.stdNumericQualifier = stdNumericQualifier;
	}

	public String getTotalCommissionValueAmt() {
		return this.totalCommissionValueAmt;
	}

	public void setTotalCommissionValueAmt(String totalCommissionValueAmt) {
		this.totalCommissionValueAmt = totalCommissionValueAmt;
	}

	public String getTotalRemittanceAmt() {
		return this.totalRemittanceAmt;
	}

	public void setTotalRemittanceAmt(String totalRemittanceAmt) {
		this.totalRemittanceAmt = totalRemittanceAmt;
	}

	public String getTotalTaxMiscFeeAmt() {
		return this.totalTaxMiscFeeAmt;
	}

	public void setTotalTaxMiscFeeAmt(String totalTaxMiscFeeAmt) {
		this.totalTaxMiscFeeAmt = totalTaxMiscFeeAmt;
	}

	public String getTotalTaxOnCommissionAmt() {
		return this.totalTaxOnCommissionAmt;
	}

	public void setTotalTaxOnCommissionAmt(String totalTaxOnCommissionAmt) {
		this.totalTaxOnCommissionAmt = totalTaxOnCommissionAmt;
	}

	public SalesFileHeaderStg getSalesFileHeaderStg() {
		return this.salesFileHeaderStg;
	}

	public void setSalesFileHeaderStg(SalesFileHeaderStg salesFileHeaderStg) {
		this.salesFileHeaderStg = salesFileHeaderStg;
	}
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
/*	@Override
	public LineTokenizer lineTokenizer() {

		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		FileTotalsCurrencyTypeStgLayout fileTotalsCurrencyTypeStgLayout = new FileTotalsCurrencyTypeStgLayout();
		tokenizer.setColumns(fileTotalsCurrencyTypeStgLayout.getColumns());
		tokenizer.setNames(fileTotalsCurrencyTypeStgLayout.getNames());
		return tokenizer;

	}

	@Override
	public FieldSetMapper<BSPRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<BSPRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<BSPRecord>();
		fieldSetMapper.setTargetType(FileTotalCurrTypeStg.class);
		return fieldSetMapper;
	}

	@Override
	public ItemProcessor<? extends BSPRecord, ? extends BSPRecord> processor() {
		return new FileTotalsCurrencyTypeStgProcessor();
	}

	@Override
	public ItemWriter<? super BSPRecord> writer() {
		return new FileTotalsCurrencyTypeStgWriter();
	}
*/

}