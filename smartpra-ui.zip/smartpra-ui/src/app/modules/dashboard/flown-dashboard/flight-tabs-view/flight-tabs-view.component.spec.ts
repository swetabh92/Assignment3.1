import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FlightTabsViewComponent } from './flight-tabs-view.component';

describe('FlightTabsViewComponent', () => {
  let component: FlightTabsViewComponent;
  let fixture: ComponentFixture<FlightTabsViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FlightTabsViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FlightTabsViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
