import { Component, OnInit } from '@angular/core';
import { PaginationService } from 'src/app/commons/services/pagination/pagination.service';
import { LovService } from '../../../services/LOV/lov.service';
import { GeneralService } from 'src/app/commons/services/general.service';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { MessageBoxService } from '../../../services/commons/message-box.service';
import { HotkeysService } from 'angular2-hotkeys';
import { CommonService } from '../../../services/commons/common.service';
import { ChargeCategoryService } from '../../../services/interline/charge-category/charge-category.service';
import { ChargeCategory } from '../../../models/interline/charge-category';

@Component({
  selector: 'app-charge-category-master',
  templateUrl: './charge-category-master.component.html',
  styleUrls: ['./charge-category-master.component.css']
})
export class ChargeCategoryMasterComponent implements OnInit {
  categorySearch: boolean = false;
  categoryList: ChargeCategory[] = [];
  fin_Type: any = [];
  editing = {};
  searchForm: FormGroup;
  page: any = this.paginateService.getPageinateConfig();
  searchsubmitted: boolean = false;
  success: any = { isSuccess: false, successMessage: '' };
  loc: any = [{ name: 'True', id: 'true' }, { name: 'False', id: 'false' }];


  constructor(public lov: LovService, private paginateService: PaginationService, private generalService: GeneralService,
    private chargeCategoryList: ChargeCategoryService, private formBuilder: FormBuilder,
    private messageBox: MessageBoxService, private hotkeysService: HotkeysService, private commonService: CommonService) { }

  ngOnInit() {
    this.lov.initLovDDS('fin_type');
    this.fin_Type = this.lov.getData('financial_trn_type', 'fin_type');
    this.getChargeCategoryList();
    this.searchFormInitialize();
  }



  getChargeCategoryList() {
    this.chargeCategoryList.getChargeCategory().subscribe((res:ChargeCategory[]) => {
      this.categoryList = res;
    })
  }



  getChargeCodeList(chargeCategoryCode) {
    if (chargeCategoryCode) {
      this.chargeCategoryList.onClickCategory.emit(chargeCategoryCode);
    }
  }

  searchFormInitialize() {
    this.searchForm = this.formBuilder.group({
      chargeCategoryCode: ['', [Validators.maxLength(3)]]
    })
  }

  onSearch() {
    this.searchsubmitted = true;
    if (this.searchForm.invalid) return false;
    this.chargeCategoryList.searchChargeCategory(this.searchForm.value).subscribe((res) => {
      this.categoryList = res;
    })
    this.resetForm();
  }

  resetForm() {
    this.searchForm.reset();
    this.searchsubmitted = false;
  }

  onSubmit() {
    this.chargeCategoryList.updateChargeCategory(this.categoryList).subscribe((res: any) => {
      if (res.message!=''||res.message == null) {
      } else {
        this.success = { isSuccess: true, successMessage: "Record has been successfully updated" }
      }
    })
  }

  onDeactivate(row) {   
    if (row.activate == "false") {
      this.chargeCategoryList.onDeactiveChargeCategoryObject(row).subscribe((res: any) => {
        if (res.message!=''||res.message == null) {
          this.getChargeCategoryList();
        } else {
          this.success = { isSuccess: true, successMessage: "Record has been successfully Deactivated" }
          this.chargeCategoryList.onDeactivateCategory.emit();
          this.getChargeCategoryList();
        }
      })
    }
  }

  get s() { return this.searchForm.controls }

  updateValue(event, cell, rowIndex) {
    this.editing[rowIndex + '-' + cell] = false;
    this.categoryList[rowIndex][cell] = event.target.value;
    this.onDeactivate(this.categoryList[rowIndex]);
    this.categoryList = [...this.categoryList];
  }


}
