/**
 * 
 */
package com.sgl.smartpra.batch.mib.app.validator;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.apache.commons.collections4.map.HashedMap;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.collect.Multimap;
import com.sgl.smartpra.batch.mib.app.config.FeignConfiguration;
import com.sgl.smartpra.batch.mib.app.config.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.batch.mib.app.enums.ErrorCode;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingConstants;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingUtil;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.global.master.model.Carrier;
import com.sgl.smartpra.global.master.model.ChargeCategory;
import com.sgl.smartpra.global.master.model.ChargeCode;
import com.sgl.smartpra.global.master.model.Country;
import com.sgl.smartpra.global.master.model.Dictionary;
import com.sgl.smartpra.global.master.model.DictionaryValue;
import com.sgl.smartpra.master.model.SystemParameter;
import com.sgl.smartpra.mib.entity.MiscBillingTrnInvoiceEntity;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

/**
 * @author kanprasa
 *
 */
@Data
@Service
@Slf4j
public class CommonValidator {
	
	private String clientId;
    private Integer fileId;
    private String batchNo;
    private String invoiceNo;
    private String chargeCategory;
    private String chargeCode;
    private Carrier carrier;
    private Carrier hostCarrier;
    private ChargeCategory chargeCategoryObj;
    private ChargeCode chargeCodeObj;
    private String billingMonth;
    private Integer billingPeriod;
    private String billingPeriodEndDate;
    private String outwardFileName;
    private int outwardInvoiceCount;
    private int outwardChargeCodeCount;
    private int transHeaderId;
    private Map<String, List<String>> dictionaryMap = new HashMap<>();
    private Map<String, String> chargeCategoryMap = new HashMap<>();
	private Map<String, List<ChargeCode>> chargeCodeMap = new HashMap<>();
	private Map<String, String> sysParamMap = new HashMap<>();
	private Map<String, String> countryMap = new HashMap<>(); 
	private boolean isMasterSet = false;
    
	@Autowired
	private SmartpraMasterAppClient smartpraMasterAppClient;
	
	@Autowired
	private MiscBillingUtil miscBillingUtil;

    @Autowired
    private FeignConfiguration.SmartpraGlobalMasterAppClient smartpraGlobalMasterAppClient;
    
    public void populateCommonFields(String inwardOutwardFlag, MiscBillingTrnInvoiceEntity invoiceEntity) {
   		this.setClientId(invoiceEntity.getClientId());
   		if(invoiceEntity.getMiscBillingInvTransHeader() != null && invoiceEntity.getMiscBillingInvTransHeader().getFileId() != null) {
   			this.setFileId(invoiceEntity.getMiscBillingInvTransHeader().getFileId());
   		}
    	this.setBatchNo(invoiceEntity.getInvoiceUrn());
		this.setInvoiceNo(invoiceEntity.getInvoiceNumber());
    	this.setChargeCategory(invoiceEntity.getChargeCategoryCode());
    	if(MiscBillingConstants.INWARD.equalsIgnoreCase(inwardOutwardFlag)) {
    		this.populateCarrier(invoiceEntity.getSellerOrganizationId());
    	} else {
    		this.populateCarrier(invoiceEntity.getBuyerOrganizationId());
    	}
    	this.populateChargeCategoryObj(this.chargeCategory);
    	if(dictionaryMap.size() == 0) {
    		this.populateDictionaryMap();
    	}
    	if(chargeCategoryMap.size() < 1) {
	    	List<ChargeCategory> chargeCategoryList = smartpraGlobalMasterAppClient.getAllChargeCategory(null, null, null);
			for (ChargeCategory chargeCategory : chargeCategoryList) {
				List<ChargeCode> chargeCodeList = smartpraGlobalMasterAppClient.getAllChargeCodesFromChargeCategory(chargeCategory.getChargeCategoryCode().get());
				chargeCodeMap.put(chargeCategory.getChargeCategoryCode().get(), chargeCodeList);
				if(MiscBillingConstants.INWARD.equalsIgnoreCase(inwardOutwardFlag)) {
					chargeCategoryMap.put(chargeCategory.getChargeCategoryName().get(), chargeCategory.getChargeCategoryCode().get());
				} else {
					chargeCategoryMap.put(chargeCategory.getChargeCategoryCode().get(), chargeCategory.getChargeCategoryName().get());
				}
			}
    	}
    	if(MiscBillingConstants.OUTWARD.equalsIgnoreCase(inwardOutwardFlag)) {
    		if(sysParamMap.size() == 0) {
    			this.populateSystemParameters();
    		}
	    	if(countryMap.size() == 0) {
	    		try {
					List<Country> countryList = smartpraGlobalMasterAppClient.getListOfCountries(null, null);
					countryMap = countryList.stream().collect(Collectors.toMap(c -> c.getCountryCode(), c -> c.getCountryName().get()));
				} catch (Exception e) {
					log.error("CountryController throws exception while retriving listofCountries from master.");
					e.printStackTrace();
				}
	    	}
    	}
    	this.isMasterSet = true;
    }
    
    public void populateSystemParameters() {
    	if(sysParamMap.size() == 0) {
    		List<String> params = Arrays.asList("DEFAULT_CURRENCY_CODE", "STARTING_FINANCIAL_MONTH", "Default_Processing_Manager", "DEFAULT_CARRIER_NUMERIC_CODE", "DEFAULT_CARRIER_ALPHA_CODE");
    		try {
    			List<SystemParameter> systemParameterList = smartpraMasterAppClient.getSystemParameterByparameterNameAndClientId(clientId, params);
    			sysParamMap = systemParameterList.stream().collect(Collectors.toMap(s -> s.getParameterName().get().trim(), s -> s.getParameterRangeFrom().get()));
			} catch (Exception e) {
				log.error("SystemParameterController throws exception while retriving data from master.");
				e.printStackTrace();
			}
    	}
    }
    
    public void requiredValidation(String elementName, Object elementValue, 
 		Multimap<String,ExceptionTransactionModel> mErrorCode, Predicate<Object> predicate) {
     	Map<String,String> map = new HashedMap<>();
     	if (predicate.test(elementValue)){
             map.put(MiscBillingConstants.ELEMENT_NAME, elementName); 
             map.put(MiscBillingConstants.INVOICE_NO, invoiceNo);
             mErrorCode.put(batchNo, miscBillingUtil.prepareExceptionTransactionModel(ErrorCode.MISC1129.toString(), map, clientId, fileId));
        }
    }
    
    public void requiredValidationForLineItemDetail(String elementName, Object elementValue, 
 		   Multimap<String,ExceptionTransactionModel> mErrorCode, Integer lineItemNumber, Integer lineItemDetailNumber, 
 		   Predicate<Object> predicate) {
     	Map<String, String> map = new HashedMap<>();
     	if (predicate.test(elementValue)){
     		map.put(MiscBillingConstants.ELEMENT_NAME, elementName); 
     		map.put(MiscBillingConstants.INVOICE_NO, invoiceNo);
     		map.put(MiscBillingConstants.LINE_ITEM_NO, lineItemNumber.toString());
     		map.put(MiscBillingConstants.LINE_ITEM_DTL_NO, lineItemDetailNumber.toString());
     		mErrorCode.put(batchNo, miscBillingUtil.prepareExceptionTransactionModel(ErrorCode.MISC1113.toString(), map, clientId, fileId));
     	}
    }
    
    public void requiredValidationForSupportingDetail(String elementName, 
  		   Multimap<String,ExceptionTransactionModel> mErrorCode, Integer lineItemNumber, Integer lineItemDetailNumber) {
     	Map<String, String> map = new HashedMap<>();
     	map.put(MiscBillingConstants.ELEMENT_NAME, elementName); 
      	map.put(MiscBillingConstants.INVOICE_NO, invoiceNo);
      	map.put(MiscBillingConstants.LINE_ITEM_NO, lineItemNumber.toString());
      	map.put(MiscBillingConstants.LINE_ITEM_DTL_NO, lineItemDetailNumber.toString());
      	mErrorCode.put(batchNo, miscBillingUtil.prepareExceptionTransactionModel(ErrorCode.MISC1113.toString(), map, clientId, fileId));
     }
    
    public void setErrorCode(Multimap<String, ExceptionTransactionModel> mErrorCode, Map<String, String> map, ErrorCode errorCode) {
		mErrorCode.put(batchNo, miscBillingUtil.prepareExceptionTransactionModel(errorCode.toString(), map, clientId, fileId));
	}
    
    public void setErrorCode(Multimap<String, ExceptionTransactionModel> mErrorCode, ErrorCode errorCode, String key, String value) {
    	Map<String, String> map = new HashedMap<>();
        map.put(key, value);
		mErrorCode.put(batchNo, miscBillingUtil.prepareExceptionTransactionModel(errorCode.toString(), map, clientId, fileId));
	}

	public void populateDictionaryMap() {
		List<Dictionary> dictionaryList = smartpraGlobalMasterAppClient.getDictionaryByElementdefine(MiscBillingConstants.EMPTY_STRING, "D");
		for (Dictionary dictionary : dictionaryList) {
			String elementName = dictionary.getElementName().get();
			List<DictionaryValue> dictionaryValueList = dictionary.getDictionaryValue();
			List<String> dictList = new ArrayList<>();
			for (DictionaryValue dictionaryValue : dictionaryValueList) {
				dictList.add(dictionaryValue.getDictionaryValue().get());
			}
			dictionaryMap.put(elementName, dictList);
		}
	}	
	
	public boolean doesValueExistsInDictionary(String elementName, String value) {
		List<String> dictList = dictionaryMap.get(elementName);
		if(dictList != null && dictList.size() > 0) {
			return dictList.stream().anyMatch(d -> StringUtils.equalsIgnoreCase(value, d));
		}
		return false;
	}
	
	// Inward - Seller
	// Outward - Buyer
    public void populateCarrier(String orgId){    	
        Carrier carrier = null;
        try {
            carrier = smartpraGlobalMasterAppClient.getCarrierByCarrierCode(orgId);
            if(carrier != null){
                this.setCarrier(carrier);
            }
        } catch (Exception e) {
            log.error("Carrier is null for sellerOrganizationId : ", orgId, e.getMessage());
        }
    }
    
    public void populateHostCarrier(String orgId){    	
        Carrier hostCarrier = null;
        try {
        	hostCarrier = smartpraGlobalMasterAppClient.getCarrierByCarrierCode(orgId);
            if(hostCarrier != null){
                this.setHostCarrier(hostCarrier);
            }
        } catch (Exception e) {
            log.error("Carrier is null for sellerOrganizationId : ", orgId, e.getMessage());
        }
    }
    
    public void populateChargeCategoryObj(String chargeCategory) {
        ChargeCategory chargeCategoryObj = null;
        try {
        	chargeCategoryObj = smartpraGlobalMasterAppClient.getChargeCategoryByChargeCategoryCode(chargeCategory);
        	if(chargeCategoryObj != null) {
        		this.setChargeCategoryObj(chargeCategoryObj);
        	}
        } catch(Exception e){
            log.error("ChargeCategory is null for : ", chargeCategory, e.getMessage());
       }
    }
    
    public void populateChargeCodeObj(String chargeCategory, String chargeCode){
    	ChargeCode chargeCodeObj = null;
    	try {
    		chargeCodeObj = smartpraGlobalMasterAppClient.getChargeCodeByChargeCode(chargeCategory, chargeCode);
        	if(chargeCodeObj != null) {
        		this.setChargeCodeObj(chargeCodeObj);
        		this.setChargeCode(chargeCode);
        	}
        } catch(Exception e){
            log.error("ChargeCode is null for chargeCategory : ", chargeCategory, e.getMessage());
        }
    }
    
    public Boolean validateTaxAmount(BigDecimal taxAmt, BigDecimal percent, BigDecimal taxableAmount){
    	taxAmt = taxAmt == null ? BigDecimal.ZERO : taxAmt;
        percent = percent == null ? BigDecimal.ZERO : percent;
        taxableAmount = taxableAmount == null ? BigDecimal.ZERO : taxableAmount;
        if (percent.compareTo(BigDecimal.ZERO) == 0) {
            return Boolean.TRUE;
        }
        BigDecimal calTotal = taxableAmount.multiply(percent.divide(new BigDecimal(100)));
        return (taxAmt.compareTo(calTotal) == 0);
    }
    
    public boolean isRequired(Object object, Predicate<Object> predicate) {
    	return predicate.test(object);
    }
    public boolean isValueEmpty(Object object, Predicate<Object> predicate) {
    	return predicate.test(object);
    }
    public void reset() {
    	this.setBatchNo(MiscBillingConstants.EMPTY_STRING);
		this.setInvoiceNo(MiscBillingConstants.EMPTY_STRING);
    	this.setChargeCategory(MiscBillingConstants.EMPTY_STRING);
    	this.setChargeCode(MiscBillingConstants.EMPTY_STRING);
    	this.setChargeCategoryObj(null);
    	this.setChargeCodeObj(null);
    	this.setCarrier(null);
    }
    public void resetMasters() {
    	this.setClientId(MiscBillingConstants.EMPTY_STRING);
    	this.setFileId(null);
    	this.setHostCarrier(null);
        this.setBillingMonth(MiscBillingConstants.EMPTY_STRING);
        this.setBillingPeriod(null);
        this.setDictionaryMap(new HashMap<>());
        this.setChargeCodeMap(new HashMap<>());
        this.setChargeCategoryMap(new HashMap<>());
    	this.setSysParamMap(new HashMap<>());
    	this.setCountryMap(new HashMap<>()); 
    	this.setMasterSet(false);
        this.setOutwardFileName(MiscBillingConstants.EMPTY_STRING);
        this.setOutwardInvoiceCount(0);
        this.setOutwardChargeCodeCount(0);
        this.setTransHeaderId(0);
        this.setBillingPeriodEndDate(null);
    }
}
