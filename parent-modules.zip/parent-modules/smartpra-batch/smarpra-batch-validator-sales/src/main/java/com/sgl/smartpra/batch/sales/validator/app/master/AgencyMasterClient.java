package com.sgl.smartpra.batch.sales.validator.app.master;

import java.util.List;

import com.sgl.smartpra.master.model.AgencyMaster;

public interface AgencyMasterClient {
	
	public List<AgencyMaster> getAllAgency(String agencyCode, String reportingAgency,String agencyType,String areaOfOperation, String reportingAgencyType);
	

}