package com.sgl.smartpra.allocation.master.app.util;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.allocation.master.app.config.FeignConfiguration;

@Service
public class AllocationMasterUtil {

	@Autowired
	FeignConfiguration.SmartpraMasterAppClient smartpraMasterAppClient;

	public List<String> getListOfValuesList(String clientId, String tableName, String columnName) {
		List<String> list = new ArrayList<>();
		smartpraMasterAppClient.getListOfValuesList(clientId, tableName, columnName)
				.forEach(listOfValue -> list.add(listOfValue.getFieldShortDescription()));

		return list;
	}
}
