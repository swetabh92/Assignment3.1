package com.sgl.smartpra.batch.mib.app.processor;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import com.sgl.smartpra.batch.mib.app.config.FeignConfiguration;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingConstants;
import com.sgl.smartpra.batch.mib.app.validator.CommonValidator;
import com.sgl.smartpra.batch.mib.app.validator.InvoiceValidator;
import com.sgl.smartpra.batch.mib.app.validator.TransmissionHeaderValidator;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.mib.entity.MiscBillingInvTransHeaderEntity;
import com.sgl.smartpra.mib.entity.MiscBillingTrnInvoiceEntity;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class MiscBillingValidatorProcessor {

	@Autowired
    private TransmissionHeaderValidator transmissionHeaderValidator;

    @Autowired
    private InvoiceValidator invoiceValidator;

    @Autowired
    private CommonValidator commonValidator;
    
    @Autowired
	private FeignConfiguration.SmartpraExceptionTransIntgAppClient smartpraExceptionTransIntgAppClient;
    
	public void validate(MiscBillingInvTransHeaderEntity miscBillingInvTransHeaderEntity) {
		
		List<ExceptionTransactionModel> alExceptionTransactionModels = transmissionHeaderValidator.validate(miscBillingInvTransHeaderEntity);
		Multimap<String,ExceptionTransactionModel> mErr = ArrayListMultimap.create();
		
		List<MiscBillingTrnInvoiceEntity> invoiceEntityList = miscBillingInvTransHeaderEntity.getMiscBillingTrnInvoices();
		for (MiscBillingTrnInvoiceEntity invoiceEntity : invoiceEntityList) {
			commonValidator.populateCommonFields(MiscBillingConstants.INWARD, invoiceEntity);
			invoiceValidator.validateInvoiceTxn(invoiceEntity, mErr);
			commonValidator.reset();
		}
		
		if (alExceptionTransactionModels != null && !alExceptionTransactionModels.isEmpty()){
			try {
				alExceptionTransactionModels.forEach(e -> smartpraExceptionTransIntgAppClient.initExceptionTrasaction(e));
			} catch (Exception e) {
				log.error(e.getMessage());
				e.printStackTrace();
			}
			for (MiscBillingTrnInvoiceEntity miscBillingTrnInvoiceEntity: miscBillingInvTransHeaderEntity.getMiscBillingTrnInvoices()) {
				miscBillingTrnInvoiceEntity.setInvoiceStatus("ER");
			}
		}

		if(mErr != null && !mErr.isEmpty()) {
			mErr.asMap().forEach((k,v) -> v.forEach(w -> {
				try {
					System.out.println("key: " + k + ", value: " + w.getExceptionCode());
					smartpraExceptionTransIntgAppClient.initExceptionTrasaction(w);
				} catch (Exception e) {
					log.error(e.getMessage());
				}
			}));

			if (alExceptionTransactionModels == null || alExceptionTransactionModels.isEmpty()) {
				for (MiscBillingTrnInvoiceEntity miscBillingTrnInvoiceEntity: miscBillingInvTransHeaderEntity.getMiscBillingTrnInvoices()) {
					if (mErr.containsKey(miscBillingTrnInvoiceEntity.getInvoiceUrn())){
						miscBillingTrnInvoiceEntity.setInvoiceStatus("ER");
					}
				}
			}
		}
	}
}
