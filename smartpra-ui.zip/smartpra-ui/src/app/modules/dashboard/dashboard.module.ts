import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import {DashboardRoutingModule} from './dashboard-routing.module';
import {ExceptionTransactionTableComponent} from './excpetion-management/exception-transaction-table/exception-transaction-table.component';
import {SharedModule} from "../../shared/shared.module";
import { PendingApprovalComponent } from './excpetion-management/pending-approval/pending-approval.component';
import { CoreDataModule } from 'src/app/core-data/core-data.module';

@NgModule({
  imports: [
    CommonModule,
    DashboardRoutingModule,
    SharedModule,
    CoreDataModule
  ],
  exports: [
    ExceptionTransactionTableComponent,
    PendingApprovalComponent
  ],
  declarations: [ExceptionTransactionTableComponent, PendingApprovalComponent]
})

export class DashboardModule {
}
