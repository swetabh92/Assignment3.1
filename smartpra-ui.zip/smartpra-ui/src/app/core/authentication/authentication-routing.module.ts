import { NgModule } from '@angular/core';
import { Routes, RouterModule, CanActivate } from '@angular/router';
import { AppfirsttimepasswordComponent } from './appfirsttimepassword/appfirsttimepassword.component';
import { AppforgetuseridComponent } from './appforgetuserid/appforgetuserid.component';
import { AppregisterComponent } from './appregister/appregister.component';
import { AppresetpasswordfinalComponent } from './appresetpasswordfinal/appresetpasswordfinal.component';
import { AppresetpasswordinitComponent } from './appresetpasswordinit/appresetpassword.component';
import { AuthGuard } from './auth-gaurd-service/_guards/auth.guard';

const routes: Routes = [
  { path: 'first-time-password', component: AppfirsttimepasswordComponent},
  { path: 'first-time-password/:key', component: AppfirsttimepasswordComponent},
  { path: 'forget-userid', component: AppforgetuseridComponent},
  { path: 'register', component: AppregisterComponent, canActivate:[AuthGuard]},
  { path: 'password-rest-final', component: AppresetpasswordfinalComponent},
  { path: 'password-rest-final/:key', component: AppresetpasswordfinalComponent},
  { path: 'reset-password-init', component: AppresetpasswordinitComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AuthenticationRoutingModule { }
