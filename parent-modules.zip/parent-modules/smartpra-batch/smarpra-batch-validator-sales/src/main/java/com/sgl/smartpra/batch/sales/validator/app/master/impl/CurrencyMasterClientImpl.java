package com.sgl.smartpra.batch.sales.validator.app.master.impl;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.batch.sales.validator.app.config.FeignConfiguration.SmartpraGlobalMasterAppClient;
import com.sgl.smartpra.batch.sales.validator.app.master.CurrencyMasterClient;
import com.sgl.smartpra.global.master.model.Currency;

@Service
public class CurrencyMasterClientImpl implements CurrencyMasterClient {

	@Autowired
	private SmartpraGlobalMasterAppClient smartpraGlobalMasterAppClient;

	@Override
	public List<Currency> getAllcurrencies(String currencyCode, String currencyName) {
		return smartpraGlobalMasterAppClient.getAllcurrencies(currencyCode, currencyName);

	}

}