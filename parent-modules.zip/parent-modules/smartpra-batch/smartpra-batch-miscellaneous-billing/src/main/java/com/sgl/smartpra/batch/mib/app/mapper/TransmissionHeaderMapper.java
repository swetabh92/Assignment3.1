package com.sgl.smartpra.batch.mib.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.mib.entity.MiscBillingInvTransHeaderEntity;
import com.sgl.smartpra.mib.jaxb.standard.TransmissionHeader;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface TransmissionHeaderMapper {
	
	@Mapping(source = "transmissionDateTime", target = "transmissionDateTime")
	@Mapping(source = "version", target = "transVersion")
	@Mapping(source = "transmissionID", target = "transmissionId")
	@Mapping(source = "issuingOrganizationID", target = "issuingOrganizationId")
	@Mapping(source = "receivingOrganizationID", target = "receivingOrganizationId")
	@Mapping(source = "billingCategory", target = "billingCategory")
	public void mapTransmissionHeaderToEntity(TransmissionHeader TransmissionHeader, @MappingTarget MiscBillingInvTransHeaderEntity miscBillingInvTransHeaderEntity);

}
