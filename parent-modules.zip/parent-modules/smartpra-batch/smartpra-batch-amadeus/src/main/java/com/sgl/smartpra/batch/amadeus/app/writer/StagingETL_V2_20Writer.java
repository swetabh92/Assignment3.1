package com.sgl.smartpra.batch.amadeus.app.writer;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.amadeus.app.common.AmadeusRecCounts;
import com.sgl.smartpra.batch.amadeus.app.common.AppConstants;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusBatchRecord;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusNewTaxStaging;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusRecordDetailStaging;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusRecordStaging;
import com.sgl.smartpra.batch.amadeus.app.domain.StgCouponModel;
import com.sgl.smartpra.batch.amadeus.app.processor.StgETLCouponProcessor;
import com.sgl.smartpra.batch.amadeus.app.processor.StgETLTicketProcessor;
import com.sgl.smartpra.batch.amadeus.app.repository.AmadeusRecordStagingRepository;
import com.sgl.smartpra.flown.repository.FlownCouponRepository;
import com.sgl.smartpra.flown.repository.FlownEsacRepository;
import com.sgl.smartpra.sales.domain.TicketMain;

@Component
@Scope(value="step")
public class StagingETL_V2_20Writer<T extends AmadeusBatchRecord> implements ItemWriter<AmadeusRecordStaging> {

	private static final Logger LOGGER = LoggerFactory.getLogger(StagingETL_V2_20Writer.class);

	@Autowired
	private AmadeusRecordStagingRepository amadeusRecordStagingRepository;

	@Autowired
	private FlownCouponRepository amadeusETlFlownCouponRepository;

	@Autowired
	private FlownEsacRepository amadeusETlEsacCouponRepository;

	@Autowired 
	StgTicketDataWriter stgTicketDataWriter;

	@Autowired
	StgETLTicketProcessor stgETLTicketProcessor;

	@Autowired
	StgETLCouponProcessor stgETLCouponProcessor;

	@SuppressWarnings("unchecked")
	@Override
	public void write(List<? extends AmadeusRecordStaging> amadeusRecordStagingList) throws Exception {

		amadeusRecordStagingRepository.saveAll(amadeusRecordStagingList);
		//amadeusRecordStagingRepository.flush();
		
		List<TicketMain> ticketMainList;
		StgCouponModel stgCouponModel;
		for(AmadeusRecordStaging amadeusRecordStaging :amadeusRecordStagingList) {
			ticketMainList = stgETLTicketProcessor.process(amadeusRecordStaging);
			if(ticketMainList != null && ticketMainList.size() > 0) {
				try {
					LOGGER.info("#################################################### STG  - TICKET SAVE");
					stgTicketDataWriter.write(ticketMainList);
					AmadeusRecCounts.addTransferCount(ticketMainList.size());
				} catch(DataIntegrityViolationException dve) {
					AmadeusRecCounts.addErrorCount(ticketMainList.size());
					System.out.println(dve.getMessage());
				}
				LOGGER.info("#################################################### STG  - TICKET SAVE END");
				stgCouponModel = stgETLCouponProcessor.process(amadeusRecordStaging);
				LOGGER.info("#################################################### STG  - stgCouponModel : " + String.valueOf(stgCouponModel==null));
				if(stgCouponModel != null && (stgCouponModel.getFlownCoupon() != null || stgCouponModel.getFlownEsac() != null)) {
					try {
						LOGGER.info("#################################################### STG  - stgCouponModel is not null");
						if(stgCouponModel.getFlownCoupon() != null) {
							amadeusETlFlownCouponRepository.save(stgCouponModel.getFlownCoupon());
						}
						amadeusETlEsacCouponRepository.save(stgCouponModel.getFlownEsac());
					} catch(DataIntegrityViolationException dve) {
						LOGGER.info(dve.getMessage());
						System.out.println(dve.getMessage());
					}
				}
				LOGGER.info("#################################################### STG  - coupon SAVE END");
			}
		}


	}

}
