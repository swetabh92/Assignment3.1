package com.sgl.smartpra.batch.fdr.app.config;

import java.math.BigInteger;
import java.util.List;

import javax.validation.Valid;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.sgl.smartpra.batch.global.model.FileLogging;
import com.sgl.smartpra.master.model.SystemParameter;

@Configuration
public class FeignConfiguration {

	@FeignClient(value = "smartpra-batch-global-app")
	public interface BatchGlobalFeignClient {

		@PostMapping("/filelog")
		public FileLogging createFileLog(@Valid @RequestBody FileLogging fileLog);

		@GetMapping("/filelogs/filename/{fileName}")
		public List<FileLogging> getFileLogByFileName(@PathVariable(value = "fileName") String fileName);

		@GetMapping("/filelog/{fileId}")
		public FileLogging getFileLogByFileId(@PathVariable(value = "fileId") BigInteger fileId);

		@PutMapping("/filelog/{fileId}")
		public FileLogging updateFileLog(@PathVariable(value = "fileId") BigInteger fileId,
				@Valid @RequestBody FileLogging fileLog);

	}

	@FeignClient(value = "smartpra-master-app")
	public interface SmartpraMasterAppClient {

		@GetMapping("/system-parameters-with-date/{parameterName}")
		public List<SystemParameter> getSystemParameterByparameterName(
				@PathVariable(value = "parameterName") String parameterName);

	}

}
