import {Injectable} from '@angular/core';
import {StorageConstants} from "../../constants/storage-constants";
import {
  GlobalTaskModel,
  ResolutionTimerModel
} from "../../../modules/common/resolution-timer/model/resolution-timer.model";
import {ResolutionTimerContractService} from "../../../modules/common/resolution-timer/contract/resolution-timer-contract.service";


@Injectable({
  providedIn: 'root'
})
export class StorageService {

  constructor(private resolutionTimerContractService: ResolutionTimerContractService) {
  }

  setResolutionTimerInstance(resolutionTimerModel: ResolutionTimerModel): void {
    localStorage.setItem(StorageConstants.RESOLUTION_MODEL, JSON.stringify(resolutionTimerModel));
    localStorage.setItem(StorageConstants.CURRENT_TASK_ID, String(resolutionTimerModel.taskId));
    this.emitResolutionTimerContract()
  }


  static getResolutionTimerInstance(): ResolutionTimerModel {
    let resolutionModel;
    return !resolutionModel ? new ResolutionTimerModel() : JSON.parse(localStorage.getItem(StorageConstants.RESOLUTION_MODEL));
  }

  emitResolutionTimerContract(): void {
    this.resolutionTimerContractService.changeMessage(StorageService.getResolutionTimerInstance());
  }

  static getCurrentTaskId(): number {
    let resolutionModel = localStorage.getItem(StorageConstants.RESOLUTION_MODEL);
    return JSON.parse(resolutionModel).taskId;
  }

}
