import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import swal from 'sweetalert2';

import { environment } from '../../../../environments/environment';
import { Roleprofile } from '../models/roleprofile';
import { MessageBoxService } from '../../masters/services/commons/message-box.service';
const httpOptions = {
  // headers: new HttpHeaders({ 'Content-Type': 'multipart/form-data' })
 };
 const httpOptions1 = {
   headers: new HttpHeaders({ 'Content-Type': 'multipart/form-data' })
  };
@Injectable({
  providedIn: 'root'
})
export class RoleprofileService {
  globalUrl = environment.apiUrlGlobal;
  masterUrl = environment.apiUrlMaster;
  authUrl = environment.apiUrlauth;
  constructor(private http: HttpClient, private messageBoxService: MessageBoxService) { }
  getRoleprofileAll(): Observable<Roleprofile[]> {
    return this.http.get<Roleprofile[]>(this.authUrl + 'mas-roles')
      .pipe(
        tap(_ => this.log('fetched Roleprofile details')),
        catchError(this.handleError('getAllRoleprofile', []))
      );
  }
  getManagerAll() {
    return this.http.get(this.authUrl + 'mas-roles')
      .pipe(
        tap(_ => this.log('fetched Roleprofile details')),
        catchError(this.handleError('getAllRoleprofile', []))
      );
  }
  RoleprofileByRoleprofileId(roleId: string): Observable<Roleprofile> {
    return this.http.get<Roleprofile>(this.authUrl + 'mas-roles/' + roleId).pipe(
      tap(_ => this.log(`fetched Roleprofile roleId=${roleId}`)),
      catchError(this.handleError<Roleprofile>(`RoleprofileByRoleprofileId roleId=${roleId}`))
    );
  }
  searchRoleprofile(parms: string): Observable<Roleprofile> {
    return this.http.get<Roleprofile>(this.authUrl + parms).pipe(
      tap(_ => this.log(`search Roleprofile roleId by ${parms}`)),
      catchError(this.handleError<Roleprofile>(`search Roleprofile roleId by ${parms}`))
    );
  }
  /** POST: add a new Roleprofile to the server */
  addRoleprofile(roleprofile: Roleprofile): Observable<Roleprofile> {
    return this.http.post<Roleprofile>(this.authUrl + 'mas-roles/', roleprofile, httpOptions).pipe(
      tap(_ => this.log(`added Roleprofile roleId=${roleprofile.roleId}`)),
      catchError(this.handleError<Roleprofile>('addRoleprofile'))
    );
  }
  updateRoleprofile(roleprofile: Roleprofile): Observable<any> {
   // console.log(Roleprofile.roleId);
    // console.log(Roleprofile);
    return this.http.put<Roleprofile>(this.authUrl + 'mas-roles/', roleprofile, httpOptions).pipe(
      tap(_ => this.log(`updated Roleprofile roleId=${roleprofile.roleId}`)),
      catchError(this.handleError<Roleprofile>('addRoleprofile'))
    );
  }
  deleteRoleprofile(roleId: string): Observable<Roleprofile> {
    return this.http.delete<Roleprofile>(this.authUrl + 'mas-roles/' + roleId , httpOptions).pipe(
      tap(_ => this.log(`activate Roleprofile roleId=${roleId}`)),
      catchError(this.handleError<Roleprofile>('activateRoleprofile'))
    );
  }
  activateRoleprofile(roleId: string): Observable<Roleprofile> {
    return this.http.put<Roleprofile>(this.authUrl + 'mas-roles/' + roleId + '/activate?lastUpdatedBy=admin', httpOptions).pipe(
      tap(_ => this.log(`activate Roleprofile roleId=${roleId}`)),
      catchError(this.handleError<Roleprofile>('activateRoleprofile'))
    );
  }
  deactivateRoleprofile(roleId: string): Observable<Roleprofile> {
    return this.http.put<Roleprofile>(this.authUrl + 'mas-roles/' + roleId + '/deactivate?lastUpdatedBy=admin', httpOptions).pipe(
      tap(_ => this.log(`deactivate Roleprofile roleId=${roleId}`)),
      catchError(this.handleError<Roleprofile>('deactvateRoleprofile'))
    );
  }

  private handleError<T>(operation = 'operation', result?: T) {
    return (e: any): Observable<T> => {
      console.log(e);
      const error = e.error.message || e.error.error || e.error.error_description || 'Could not connect server';
      console.log(error);
      this.messageBoxService.getErrorMessage('ERROR', error);
      return of(result as T);
    };
  }
  private log(error: any) {
    console.log(error);
    if (error.message) {
      this.messageBoxService.getErrorMessage('ERROR', error.message);
    }
  }
}

