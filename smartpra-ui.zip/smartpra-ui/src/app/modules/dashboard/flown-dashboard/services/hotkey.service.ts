import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { HotkeysService, Hotkey } from 'angular2-hotkeys';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
export class Command {
  name: string;
  combo: string;
  ev: KeyboardEvent;
  module:string;
}
@Injectable({
  providedIn: 'root'
})
export class HotkeyService {
  hotKeyModule = 'FlownDashboardComponent';
  private subject: Subject<Command>;
  commands: Observable<Command>;
   hotkeys = {
    "alt+s": ["FlownDashboardComponent.search","FlightCouponTableComponent.save"],
    "alt+c": [ "FlownDashboardComponent.clear","FlightCouponTableComponent.clear"],
    "alt+n": [ "FlightCouponTableComponent.cancel"],
    'alt+shift+s': ["FlownDashboardComponent.advanceSearch"],
    'alt+shift+c': ["FlownDashboardComponent.advanceClear"],
  }

  constructor(private hotkeysService: HotkeysService) { 
    this.subject = new Subject<Command>();
    this.commands = this.subject.asObservable();
    for (const key in this.hotkeys) {
      const commands = this.hotkeys[key];
      hotkeysService.add(new Hotkey(key, (ev, combo) => this.hotkey(ev, combo, commands),['INPUT', 'SELECT', 'TEXTAREA']));
    }
  }
  hotkey(ev: KeyboardEvent, combo: string, commands: string[]): boolean {
    commands.forEach(c => {
      const command = {
        name: c,
        ev: ev,
        combo: combo,
        module: this.hotKeyModule
      } as Command;
      this.subject.next(command);
    });
    return true;
  }
  resetHotKeyModule(){
    this.hotKeyModule = 'FlownDashboardComponent';
  }
}
