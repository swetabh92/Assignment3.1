package com.sgl.smartpra.batch.global.app.repository;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.batch.global.app.dao.result.ExpectedFrequencyResult;
import com.sgl.smartpra.batch.global.app.dao.result.FileStatusResult;
import com.sgl.smartpra.batch.global.app.dao.result.MultiRecordExceptionsResult;
import com.sgl.smartpra.batch.global.app.entity.FileLoggingEntity;

@Repository
public interface FileLogRepository
		extends JpaRepository<FileLoggingEntity, BigInteger>, JpaSpecificationExecutor<FileLoggingEntity> {

	@Query("select fileLoggingEntity from FileLoggingEntity fileLoggingEntity  where fileLoggingEntity.fileName = :fileName "
			+ " and (fileLoggingEntity.fileStatus='TR' or fileLoggingEntity.fileStatus='tr') ")
	public List<FileLoggingEntity> getFileLogByFileName(@Param("fileName") String fileName);

	@Query(name = "getFileStatus", nativeQuery = true)
	public List<FileStatusResult> getFileLogStatus(LocalDate fromDate, LocalDate toDate);

	@Query("from FileLoggingEntity where moduleId = :lovModuleId and fileStatus = :fileStatus and createdDate between :fromDate and :toDate")
	public List<FileLoggingEntity> getFileDetails(@Param("fromDate") Timestamp fromDate,
			@Param("toDate") Timestamp toDate, @Param("lovModuleId") Integer lovModuleId,
			@Param("fileStatus") String fileStatus);

	@Query(name = "getExpectedFrequencyAndModuleName", nativeQuery = true)
	public ExpectedFrequencyResult getExpectedFrequencyAndModuleNameResult(String fileType, Integer lovModuleId);

	@Query(name = "getMultiRecordExceptions", nativeQuery = true)
	public List<MultiRecordExceptionsResult> getMultiRecordExceptions(@Param("fileLogId") Integer fileLogId);

}
