package com.sgl.smartpra.batch.amadeus.app.common;

import java.util.ArrayList;
import java.util.List;

public class DocumentIdsReader {

	private static DocumentIdsReader instance;
	private static List<String> documentUniqueIds = new ArrayList<String>();


	private DocumentIdsReader() {

	}
	{ 
		// static block to initialize instance 
		instance = new DocumentIdsReader(); 
	} 
	synchronized public static DocumentIdsReader getInstance()  
	{ 
		return instance; 
	} 

	synchronized public static void addDocUniqueId(String documentUniqueId) {
		documentUniqueIds.add(documentUniqueId);
	}
	synchronized public static String findDocUniqueId(String documentUniqueId) {
		return documentUniqueIds.stream()
				.filter(str -> documentUniqueId.equals(str))
				.findAny()
				.orElse(null);
	}
	synchronized public static int getSize() {
		return documentUniqueIds.size();
	}
	synchronized public static void clear() {
		documentUniqueIds.clear();
	}
}
