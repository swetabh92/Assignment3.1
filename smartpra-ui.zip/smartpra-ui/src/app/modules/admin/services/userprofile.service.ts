import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import swal from 'sweetalert2';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/filter';
import 'rxjs/add/operator/delay';

import { environment } from '../../../../environments/environment';
import { Userprofile } from '../models/userprofile';
import { MessageBoxService } from '../../masters/services/commons/message-box.service';
const httpOptions = {
 // headers: new HttpHeaders({ 'Content-Type': 'multipart/form-data' })
};
const httpOptions1 = {
  headers: new HttpHeaders({ 'Content-Type': 'multipart/form-data' })
 };


@Injectable({
  providedIn: 'root'
})

export class UserprofileService {
  globalUrl = environment.apiUrlGlobal;
  masterUrl = environment.apiUrlMaster;
  authUrl = environment.apiUrlauth;
  constructor(private http: HttpClient, private messageBoxService: MessageBoxService) { }
  getUserprofileAll(): Observable<Userprofile[]> {
    return this.http.get<Userprofile[]>(this.authUrl + 'users')
      .pipe(
        tap(_ => this.log('fetched Userprofile details')),
        catchError(this.handleError('getAllUserprofile', []))
      );
  }
  UserprofileByUserRoleName(name): Observable<Userprofile[]> {
    return this.http.get<Userprofile[]>(this.authUrl + 'users/role/' + name)
      .pipe(
        tap(_ => this.log('fetched Userprofile details')),
        catchError(this.handleError('getAllUserprofile', []))
      );
  }
  UserprofileByUserprofileId(userId: string): Observable<Userprofile> {
    return this.http.get<Userprofile>(this.authUrl + 'users/userId/' + userId).pipe(
      tap(_ => this.log(`fetched Userprofile userId=${userId}`)),
      catchError(this.handleError<Userprofile>(`UserprofileByUserprofileId userId=${userId}`))
    );
  }
  searchUserprofile(formdata): Observable<Userprofile> {
    // console.log(formdata); return;
    return this.http.post<Userprofile>(this.authUrl + 'users/search' , formdata).pipe(
      tap(_ => this.log(`search Userprofile`)),
      catchError(this.handleError<Userprofile>(`search Userprofile`))
    );
  }
  /** POST: add a new Userprofile to the server */
  addUserprofile(formdata): Observable<Userprofile> {
    // console.log(formdata); return;
    return this.http.post<Userprofile>(this.authUrl + 'users/', formdata, httpOptions).pipe(
      tap(_ => this.log(`added Userprofile userId=`)),
      catchError(this.handleError<Userprofile>('addUserprofile'))
    );
  }
  UserPasswordUpdate(formdata): Observable<Userprofile> {
    // console.log(formdata); return;
    return this.http.post<Userprofile>(this.authUrl + 'profile/change-password/', formdata, httpOptions).pipe(
      tap(_ => this.log(`updated Password`)),
      catchError(this.handleError<Userprofile>('updated Password'))
    );
  }
  checkEmailNotTaken2(email: string) {
    return this.http.get('assets/dummy_datas/users.json').delay(1000)
    .map(res => res as Userprofile[] || [])
    .map(users => users.filter(user => user.email === email))
    .map(users => !users.length);
  }
  checkEmailNotTaken3(email: string) {
    return this.http.get(this.authUrl + 'users').delay(1000)
    .map(res => res as Userprofile[] || [])
    .map(users => users.filter(user => user.email === email))
    .map(users => !users.length);
  }
  checkEmailNotTaken(email: string) {
    return this.http.post('http://10.92.92.223:1212/smartpra/user-management/api/' + 'users/email', {'email': email}, httpOptions1)
    // .delay(1000)
    .map(res => res as Userprofile[] || [])
    .map(users => users.filter(user => user.email === email))
    .map(users => !users.length);
  }
  userImport(formdata): Observable<Userprofile> {
    // console.log(formdata); return;
    return this.http.post<Userprofile>(this.authUrl + 'profile/user-import/', formdata, httpOptions).pipe(
      tap(_ => this.log(`Import Users`)),
      catchError(this.handleError<Userprofile>('Import Users'))
    );
  }
  updateUserprofile(formdata): Observable<any> {
   // console.log(Userprofile.userId); 
    // console.log(Userprofile);
    return this.http.put<Userprofile>(this.authUrl + 'users/', formdata).pipe(
      tap(_ => this.log(`updated Userprofile userId=${formdata.userId}`)),
      catchError(this.handleError<Userprofile>('addUserprofile'))
    );
  }
  activateUserprofile(userId: string): Observable<Userprofile> {
    return this.http.put<Userprofile>(this.authUrl + 'users/activateordeactivate/' + userId , httpOptions).pipe(
      tap(_ => this.log(`activate Userprofile userId=${userId}`)),
      catchError(this.handleError<Userprofile>('activateUserprofile'))
    );
  }
  deactivateUserprofile(userId: string): Observable<Userprofile> {
    return this.http.put<Userprofile>(this.authUrl + 'users/activateordeactivate/' + userId , httpOptions).pipe(
      tap(_ => this.log(`deactivate Userprofile userId=${userId}`)),
      catchError(this.handleError<Userprofile>('deactvateUserprofile'))
    );
  }
  private handleError<T>(operation = 'operation', result?: T) {
    return (e: any): Observable<T> => {
      // console.log(e);
      const error = e.error.message || e.error.error || e.error.error_description || 'Could not connect server';
      this.messageBoxService.getErrorMessage('ERROR', error);
      return of(result as T);
    };
  }
  private log(error: any) {
    console.log(error);
    if (error.message) {
      this.messageBoxService.getErrorMessage('ERROR', error.message);
    }
  }
}

