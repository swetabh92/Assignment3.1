import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AllocationMasterRoutingModule } from './allocation-master-routing.module';
import { AllocationMasterComponent } from './allocation-master.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { CoreDataModule } from 'src/app/core-data/core-data.module';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    CoreDataModule,
    AllocationMasterRoutingModule
  ],
  declarations: [
    AllocationMasterComponent
  ]
})
export class AllocationMasterModule { }
