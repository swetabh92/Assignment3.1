package com.sgl.smartpra.batch.bsp.app.util;

public class BSPConstants {

	public static final String PAR_DEFAULT_CARRIER_ALPHA_CODE = "DEFAULT_CARRIER_ALPHA_CODE";
	public static final String PAR_DECIMAL_PRECISION = "DECIMAL_PRECISION";
	public static final String PAR_DECIMAL_REFERENCE = "DECIMAL_REFERENCE";
	public static final String PAR_AUTO_CREATE_AGENT = "AUTO_CREATE_AGENT";

	public static final String LINE_NUMBER = "Line No";
	public static final String FIELD = "Field";
	public static final String MESSAGE = "Message";
	
	public static final String REPORTING_AGENCY="9999999";
	public static final String REPORTING_AGENCY_TYPE="P";
	public static final String FILE_SOURCE="BSP";
	
	public static final String TRANSACTION_TYPE_TKT="TKTT";
	
	public static final String TRANSACTION_TYPE_ACM="ACM";
	public static final String TRANSACTION_TYPE_SPC="SPCR";
	public static final String TRANSACTION_TYPE_SSAC="SSAC";

	public static final String TRANSACTION_TYPE_ADM="ADM";
	public static final String TRANSACTION_TYPE_RCS="RCSM";
	public static final String TRANSACTION_TYPE_SSAD="SSAD";
	public static final String TRANSACTION_TYPE_SPD="SPDR";
	public static final String TRANSACTION_TYPE_TAA="TAAD";

	public static final String TRANSACTION_TYPE_REFUND="RFND";
	
	public static final String TICKET_TYPE_CNJ="CNJ";
	public static final String TICKET_TYPE_PRIME="P";
	public static final String TICKET_TYPE_REISSUE="R";
	public static final String ELECTRONIC_TICKET_INDICATOR="E";
	
	public static final String TICKET_STATUS_READY_FOR_VALIDATION="RV";
	public static final String TICKET_STATUS_ERROR_IN_VALIDATION="EV";
	
	
	public static final String FOP_TYPE_EXCHANGE="EX";
	public static final String FOP_TYPE_TP="TP";
	public static final String FOP_TYPE_CA="CA";
	public static final String FOP_TYPE_P="P";
	public static final String FOP_TYPE_N="N";
	
	
	public static final String INDICATOR_YES="Y";
	public static final String INDICATOR_NO="N";
	public static final String INDICATOR_I="I";
	public static final String INDICATOR_B="B";
	public static final String BT_INDICATOR_B="BT";
	public static final String BT_INDICATOR_I="IT";
	
	public static final String EMD_STANDALONE="EMDS";
	public static final String EMD_INDICATOR_STANDALONE="S";
	
	public static final String EMD_ASSOCIATE="EMDA";
	public static final String EMD_INDICATOR_ASSOCIATE="A";
	
	public static final String TRAVEL_TYPE_INTERNATIONAL="I";
	public static final String TRAVEL_TYPE_DOMESTIC="D";
	
	public static final String TRAVEL_TYPE_INTERNATIONALDESC="International";
	public static final String TRAVEL_TYPE_DOMESTIC_DESC="Domestic";
	
	
	
	
	
	

	// file logging constants
//	public static final String FILELOGGING_FILECATEGORY = "Text";
//	public static final String FILELOGGING_MODULE = "Sales";
//	public static final Integer FILELOGGING_MODULE_ID = 3;
//	public static final String CREATEDBY = "Admin";
//	public static final String UPDATEDBY = "Admin";
//	
//	public static final String BSP = "BSP";
//	
//	public static final String FILELOGGING_INTERFACE_INPUT = "I";
//	public static final String FILELOGGING_FILETYPE_BSP_IN = "BSP-IN";

}
