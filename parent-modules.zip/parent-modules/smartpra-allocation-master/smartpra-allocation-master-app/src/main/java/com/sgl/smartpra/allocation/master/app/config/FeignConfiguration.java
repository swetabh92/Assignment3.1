package com.sgl.smartpra.allocation.master.app.config;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import com.sgl.smartpra.global.master.model.Airport;
import com.sgl.smartpra.global.master.model.CommonIdName;
import com.sgl.smartpra.master.model.ListOfValues;
import com.sgl.smartpra.master.model.POS;
import com.sgl.smartpra.master.model.Region;
import com.sgl.smartpra.master.model.RouteCode;
import com.sgl.smartpra.master.model.SourceCode;
import com.sgl.smartpra.master.model.SystemParameter;
import com.sgl.smartpra.service.model.MasGroup;

@Configuration
public class FeignConfiguration {

	@FeignClient(value = "smartpra-global-master-app")
	public interface GlobalMasterFeignClient {
		@GetMapping("/airports/{airportCode}")
		public Airport getAirportByAirportCode(@PathVariable(value = "airportCode") String airportCode);

		@GetMapping("/airports")
		public List<Airport> getAllAirport(@RequestParam(name = "airportCode", required = false) String airportCode,
				@RequestParam(name = "airportName", required = false) String airportName,
				@RequestParam(name = "cityCode", required = false) String cityCode,
				@RequestParam(name = "cityName", required = false) String cityName,
				@RequestParam(name = "countryCode", required = false) String countryCode);

		@GetMapping("/currencies/currency-list")
		public List<CommonIdName> getCurrencyList();
		
		@GetMapping("/carriers/carrier-list")
		public List<CommonIdName> getCarrierList();
	}

	@FeignClient(value = "smartpra-master-app")
	public interface SmartpraMasterAppClient {

		@GetMapping("/system-parameters-with-date/{parameterName}")
		public List<SystemParameter> getSystemParameterByparameterName(
				@PathVariable(value = "parameterName") String parameterName);

		@GetMapping("/listofvalues/{clientId}/{tableName}/{columnName}/{fieldValue}")
		public ListOfValues getListOfValues(@PathVariable(value = "clientId", required = true) String clientId,
				@PathVariable(value = "tableName", required = true) String tableName,
				@PathVariable(value = "columnName", required = true) String columnName,
				@PathVariable(value = "fieldValue", required = true) String fieldValue);

		@GetMapping("/listofvalueslist/{clientId}/{tableName}/{columnName}")
		public List<ListOfValues> getListOfValuesList(@PathVariable(value = "clientId") String clientId,
				@PathVariable(value = "tableName") String tableName,
				@PathVariable(value = "columnName") String columnName);

		@GetMapping("/listofvalues/{listofvaluesId}")
		public ListOfValues getListOfValue(@PathVariable(value = "listofvaluesId") Integer listofvaluesId);

		@GetMapping("/regions/{regionCode}")
		public Region getRegionByRegionCode(@PathVariable(value = "regionCode") String regionCode);

		@GetMapping("/regions")
		public List<Region> getAllRegion(@RequestParam(value = "regionCode", required = false) String regionCode,
				@RequestParam(value = "regionName", required = false) String regionName,
				@RequestParam(value = "continentName", required = false) String continentName,
				@RequestParam(value = "isActive", required = false) Boolean isActive);

		@GetMapping("/pos/{posCode}")
		public POS getPosByPosCode(@PathVariable(value = "posCode") String posCode);

		@GetMapping("/route-codes")
		public List<RouteCode> getAllRouteCode();
		
		@GetMapping("/source-codes/source-codes/{clientId}")
		public List<SourceCode> getAllSourceCode(@PathVariable(value = "clientId") String clientId);
				

	}

	@FeignClient(value = "smartpra-user-service")
	public interface SmartpraUserManagementClient {
		@GetMapping("/mas-groups/{id}")
		public ResponseEntity<MasGroup> getMasGroup(@PathVariable(value = "id") Long id);

		@GetMapping("/mas-groups/groups")
		public ResponseEntity<MasGroup> getMasGroupById(@RequestParam(name = "teamId", required = false) Long teamId,
				@RequestParam(name = "groupId", required = false) Long groupId,
				@RequestParam(name = "userId", required = false) Long userId);
	}

}
