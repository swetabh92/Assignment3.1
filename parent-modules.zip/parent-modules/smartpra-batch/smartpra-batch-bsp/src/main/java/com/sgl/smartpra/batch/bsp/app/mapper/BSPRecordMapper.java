package com.sgl.smartpra.batch.bsp.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.sgl.smartpra.batch.bsp.app.domain.staging.AdditionalCardInfoStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.AdditionalItineraryDataStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.AddlInfoFormOfPaymentStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.AddlInfoPassengerStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.AddlTaxesInfoStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.BillingCycleHeaderStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.BillingCycleTotalsStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.CardAuthInfoStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.CommissionStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.CouponTaxInformationStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.DocumentAmountsStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.EMDCouponDetailStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.EMDRemarksStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.FareCalculationStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.FileHeaderStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.FileTotalsStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.FormOfPaymentStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.ItineraryDataSegmentStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.NettingValuesStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.OfficeHeaderStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.OfficeSubtotalsStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.OfficeTotalsStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.QualIssueInfoStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.RelatedTicketDocumentInfoStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.StdDocumentAmountsStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TDSCardAuthInfoStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TaxOnCommissionStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TicketDocumentIdentificationStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TransactionHeaderStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.UnticketedPointInfoStg;
import com.sgl.smartpra.batch.bsp.app.record.AdditionalCardInfo;
import com.sgl.smartpra.batch.bsp.app.record.AdditionalItineraryData;
import com.sgl.smartpra.batch.bsp.app.record.AddlInfoFormOfPayment;
import com.sgl.smartpra.batch.bsp.app.record.AddlInfoPassenger;
import com.sgl.smartpra.batch.bsp.app.record.AddlTaxesInfo;
import com.sgl.smartpra.batch.bsp.app.record.BillingCycleHeader;
import com.sgl.smartpra.batch.bsp.app.record.BillingCycleTotals;
import com.sgl.smartpra.batch.bsp.app.record.CardAuthInfo;
import com.sgl.smartpra.batch.bsp.app.record.Commission;
import com.sgl.smartpra.batch.bsp.app.record.CouponTaxInformation;
import com.sgl.smartpra.batch.bsp.app.record.DocumentAmounts;
import com.sgl.smartpra.batch.bsp.app.record.EMDCouponDetail;
import com.sgl.smartpra.batch.bsp.app.record.EMDRemarks;
import com.sgl.smartpra.batch.bsp.app.record.FareCalculation;
import com.sgl.smartpra.batch.bsp.app.record.FileHeader;
import com.sgl.smartpra.batch.bsp.app.record.FileTotals;
import com.sgl.smartpra.batch.bsp.app.record.FormOfPayment;
import com.sgl.smartpra.batch.bsp.app.record.ItineraryDataSegment;
import com.sgl.smartpra.batch.bsp.app.record.NettingValues;
import com.sgl.smartpra.batch.bsp.app.record.OfficeHeader;
import com.sgl.smartpra.batch.bsp.app.record.OfficeSubtotals;
import com.sgl.smartpra.batch.bsp.app.record.OfficeTotals;
import com.sgl.smartpra.batch.bsp.app.record.QualIssueInfo;
import com.sgl.smartpra.batch.bsp.app.record.RelatedTicketDocumentInfo;
import com.sgl.smartpra.batch.bsp.app.record.StdDocumentAmounts;
import com.sgl.smartpra.batch.bsp.app.record.TDSCardAuthInfo;
import com.sgl.smartpra.batch.bsp.app.record.TaxOnCommission;
import com.sgl.smartpra.batch.bsp.app.record.TicketDocumentIdentification;
import com.sgl.smartpra.batch.bsp.app.record.TransactionHeader;
import com.sgl.smartpra.batch.bsp.app.record.UnticketedPointInfo;

@Mapper(componentModel = "Spring")
public interface BSPRecordMapper {

	BSPRecordMapper INSTANCE = Mappers.getMapper(BSPRecordMapper.class);

	FileHeaderStg mapFileHeaderRecord(FileHeader fileHeader);

	BillingCycleHeaderStg mapBillingCycleHeaderRecord(BillingCycleHeader billingCycleHeader);

	OfficeHeaderStg mapOfficeHeaderRecord(OfficeHeader officeHeader);

	OfficeSubtotalsStg mapOfficeSubtotalsRecord(OfficeSubtotals officeSubtotals);

	OfficeTotalsStg mapOfficeTotalsRecord(OfficeTotals officeTotals);

	BillingCycleTotalsStg mapBillingCycleTotalsRecord(BillingCycleTotals billingCycleTotals);

	FileTotalsStg mapFileTotalsRecord(FileTotals fileTotals);

	TransactionHeaderStg mapTransactionHeaderRecord(TransactionHeader transactionHeader);

	TicketDocumentIdentificationStg mapTicketDocumentIdentificationRecord(
			TicketDocumentIdentification ticketDocumentIdentification);

	StdDocumentAmountsStg mapStdDocumentAmountsRecord(StdDocumentAmounts stdDocumentAmounts);

	CouponTaxInformationStg mapCouponTaxInformationRecord(CouponTaxInformation couponTaxInformation);

	CommissionStg mapCommissionRecord(Commission commission);

	TaxOnCommissionStg mapTaxOnCommissionRecord(TaxOnCommission taxOnCommission);

	RelatedTicketDocumentInfoStg mapRelatedTicketDocumentInfoRecord(
			RelatedTicketDocumentInfo relatedTicketDocumentInfo);

	QualIssueInfoStg mapQualIssueInfoRecord(QualIssueInfo qualIssueInfo);

	NettingValuesStg mapNettingValuesRecord(NettingValues nettingValues);

	UnticketedPointInfoStg mapUnticketedPointInfoRecord(UnticketedPointInfo unticketedPointInfo);

	AdditionalItineraryDataStg mapAdditionalItineraryDataRecord(AdditionalItineraryData additionalItineraryData);

	ItineraryDataSegmentStg mapItineraryDataSegmentRecord(ItineraryDataSegment itineraryDataSegment);

	DocumentAmountsStg mapDocumentAmountsRecord(DocumentAmounts documentAmounts);

	AddlInfoPassengerStg mapAddlInfoPassengerRecord(AddlInfoPassenger addlInfoPassenger);

	AddlInfoFormOfPaymentStg mapAddlInfoFormOfPaymentRecord(AddlInfoFormOfPayment addlInfoFormOfPayment);

	AddlTaxesInfoStg mapAddlTaxesInfoRecord(AddlTaxesInfo addlTaxesInfo);

	EMDCouponDetailStg mapEMDCouponDetailRecord(EMDCouponDetail emdCouponDetail);

	EMDRemarksStg mapEMDRemarksRecord(EMDRemarks emdRemarks);

	FareCalculationStg mapFareCalculationRecord(FareCalculation fareCalculation);

	AdditionalCardInfoStg mapAdditionalCardInfoRecord(AdditionalCardInfo additionalCardInfo);

	CardAuthInfoStg mapCardAuthInfoRecord(CardAuthInfo cardAuthInfo);

	TDSCardAuthInfoStg mapTDSCardAuthInfoRecord(TDSCardAuthInfo tdsCardAuthInfo);

	FormOfPaymentStg mapFormOfPaymentRecord(FormOfPayment formOfPayment);

}
