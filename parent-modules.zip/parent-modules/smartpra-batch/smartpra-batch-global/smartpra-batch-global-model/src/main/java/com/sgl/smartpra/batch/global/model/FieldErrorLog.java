package com.sgl.smartpra.batch.global.model;

import java.io.Serializable;
import java.math.BigInteger;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.sgl.smartpra.common.model.BaseMaster;

@JsonInclude(Include.NON_NULL)
public class FieldErrorLog extends BaseMaster implements Serializable {
	
	private static final long serialVersionUID = -5588140957992107025L;

	private BigInteger fieldErrorId;
	
	private BigInteger fileId;
	
	private Integer recordNumber;
	
	private String fieldName;
	
	private String fieldValue;
	
	private String errorDescription;
	
	private String errorDetail;
	
	private String status;

	public BigInteger getFieldErrorId() {
		return fieldErrorId;
	}

	public void setFieldErrorId(BigInteger fieldErrorId) {
		this.fieldErrorId = fieldErrorId;
	}

	public BigInteger getFileId() {
		return fileId;
	}

	public void setFileId(BigInteger fileId) {
		this.fileId = fileId;
	}

	public Integer getRecordNumber() {
		return recordNumber;
	}

	public void setRecordNumber(Integer recordNumber) {
		this.recordNumber = recordNumber;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getFieldValue() {
		return fieldValue;
	}

	public void setFieldValue(String fieldValue) {
		this.fieldValue = fieldValue;
	}

	public String getErrorDescription() {
		return errorDescription;
	}

	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}

	public String getErrorDetail() {
		return errorDetail;
	}

	public void setErrorDetail(String errorDetail) {
		this.errorDetail = errorDetail;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	
}
