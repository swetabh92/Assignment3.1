import { Component, OnInit, ViewChild, Input, Output, ElementRef, OnDestroy } from '@angular/core';
import { GeneralService } from '../../../../../commons/services/general.service';
import { FlightControlMasterService } from '../../../services/flown/flight-control-master/flight-control-master.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FlightControl } from '../../../models/flown/flight-control.model';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { DatepickerOptions } from 'ng2-datepicker';
import { DatePipe } from '@angular/common';
import swal from 'sweetalert2';
import { MessageBoxService } from '../../../services/commons/message-box.service';
import { CommonService } from '../../../services/commons/common.service';
import { PaginationService } from '../../../../../commons/services/pagination/pagination.service';
import { HotkeysService } from 'angular2-hotkeys/src/hotkeys.service';
import { Hotkey } from 'angular2-hotkeys/src/hotkey.model';
import { MasterHotkeys } from '../../../../../commons/properties/master/master-hotkeys.enum'
import { LovService } from '../../../services/LOV/lov.service';

@Component({
  selector: 'app-flight-control-master',
  templateUrl: './flight-control-master.component.html',
  styleUrls: ['./flight-control-master.component.css']
})
export class FlightControlMasterComponent implements OnInit {
  @ViewChild('closeModalAdd') closeModalAdd: ElementRef;
  @ViewChild('closeModalEdit') closeModalEdit: ElementRef;
  dtOptions: any = {};
  public renderDT = false;
  // We use this trigger because fetching the list of persons can be quite long,
  // thus we ensure the data is fetched before rendering
  clientID: String = "";
  formObj = {
    flightControlId: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(6)]],
    controlDescription: ['', [Validators.required, Validators.minLength(1), Validators.maxLength(50)]],
    selfOalIndicator: ['', [Validators.required]],
    controlType: ['', [Validators.required]],
    controlFormula: [''],
    controlIndicator1: [''],
    controlValue1: [''],
    controlIndicator2: [''],
    controlValue2: [''],
    controlIndicator3: [''],
    controlValue3: [''],
    controlIndicator4: [''],
    controlValue4: [''],
    controlIndicator5: [''],
    controlValue5: [''],
    matchControl: [''],
    controlIdentification: [''],
  };
  searchstring: any;
  flightControlListArray: any = [];
  flightObj: FlightControl;
  marked = false;
  collapse_search_form = true;
  box_search_status = false;
  addNewFlightControlForm: FormGroup;
  addNewsubmitted = false;
  editsubmittedForm: FormGroup;
  editsubmitted = false;
  searchForm: FormGroup;
  searchsubmitted = false;
  flightControlAutoId: Number;
  mandatoryFlag: string = "";
  controlTypeCValidation = false;
  controlTypeVValidation = false;
  formFlag: string = "";
  error: any = { isError: false, errorMessage: '' };
  page: any = this.PaginateService.getPageinateConfig();
  controlValue1Array: any = [];
  controlValue2Array: any = [];
  controlValue3Array: any = [];
  controlValue4Array: any = [];
  controlValue5Array: any = [];

  constructor(public lov: LovService, private PaginateService: PaginationService, private generalService: GeneralService, private flightControlService: FlightControlMasterService, private commonService: CommonService,
    private formBuilder: FormBuilder, private router: Router, private messageBoxService: MessageBoxService, private hotkeysService: HotkeysService) {

    this.hotkeysService.add(new Hotkey(MasterHotkeys.save, (event: KeyboardEvent): boolean => {
      if (this.formFlag == 'addFlightControl') {
        this.onSubmit();
      } else if (this.formFlag == 'editFlightControl') {
        this.onUpdate();
      }
      return false;
    }));

    this.hotkeysService.add(new Hotkey(MasterHotkeys.clear, (event: KeyboardEvent): boolean => {
      if (this.formFlag == 'addFlightControl') {
        this.onResetAdd();
      } else if (this.formFlag == 'editFlightControl') {
        this.onResetEdit();
      } else if (this.formFlag == 'searchFlightControl') {
        this.onResetSearch();
      }
      return false;
    }));

    this.hotkeysService.add(new Hotkey(MasterHotkeys.cancel, (event: KeyboardEvent): boolean => {
      if (this.formFlag == 'addFlightControl') {
        this.onCancelChange();
      } else if (this.formFlag == 'editFlightControl') {
        this.onCancelChange();
      }
      else if (this.formFlag == 'searchFlightControl') {
        this.showSearchBox(event);
      }
      return false;
    }));
  }

  ngOnInit() {
    this.lov.initLovDDS('flight_control');
    this.getAllFlightControlList();
    this.clientID = this.commonService.getClientId();

    let addForm = Object.assign({}, this.formObj);
    addForm['createdBy'] = this.commonService.getUser();
    addForm['clientId'] = this.clientID,
    this.addNewFlightControlForm = this.formBuilder.group(addForm);
    let editForm = Object.assign({}, this.formObj);
    editForm['clientId'] = this.clientID,
    editForm['flightControlAutoId'] = "";
    editForm['activate'] = true;
    editForm['lastUpdatedBy'] = this.commonService.getUser();
    this.editsubmittedForm = this.formBuilder.group(editForm);

    this.searchForm = this.formBuilder.group({
      controlId: ['', Validators.maxLength(6)],
      activate: [''],
    });
  }

  closeAlertValidation() {
    var tempThis = this;
    window.setTimeout(function () {
      tempThis.error = { isError: false, errorMessage: '' };
    }, 6000);
  }

  getAllFlightControlList(): void {
    this.renderDT = false;
    this.flightControlService.getAllFlightControl().subscribe((res: any[]) => {
      this.flightControlListArray = res;
      setTimeout(() => {
        this.renderDT = true;
      }, 100);
    });
  }

  get f() {
    return this.addNewFlightControlForm.controls;
  }

  get sf() {
    return this.searchForm.controls;
  }
  onResetAdd(): void {
    this.addNewFlightControlForm.reset();
    this.addNewFlightControlForm.markAsPristine();
    this.addNewFlightControlForm.markAsUntouched();
    this.addNewFlightControlForm.updateValueAndValidity();
    this.resetAllControlValue();
    this.addNewsubmitted = false;
    this.controlTypeCValidation = false;
    this.controlTypeVValidation = false;
    this.addNewFlightControlForm.patchValue({
      createdBy: this.commonService.getUser(),
      clientId: this.clientID,
    });
  }

  onSubmit(): void {
    this.addNewsubmitted = true;
    this.addNewFlightControlForm.value.controlType == "C" ? this.controlTypeCValidation = true : this.controlTypeCValidation = false;
    this.addNewFlightControlForm.value.controlType == "V" ? this.controlTypeVValidation = true : this.controlTypeVValidation = false;
    if (this.addNewFlightControlForm.invalid) {
      return;
    } else {
      let data = Object.assign({}, this.addNewFlightControlForm.value);
      if (!data['controlFormula']) {
        data['controlFormula'] = "";
      }
      this.flightControlService.addFlightControl(data).subscribe(
        flightControlService => {
          if (flightControlService && flightControlService.flightControlAutoId) {
            this.updateDataTable(flightControlService, 'add');
            this.closeModalAdd.nativeElement.click();
            this.error = { isError: true, errorMessage: "Record has been successfully saved" };
            this.closeAlertValidation();
            this.onResetAdd();
          }
        });
    }
  }

  onResetEdit() {
    this.editsubmittedForm.reset();
    this.editsubmittedForm.markAsPristine();
    this.editsubmittedForm.markAsUntouched();
    this.editsubmittedForm.updateValueAndValidity();
    this.resetAllControlValue();
    this.editsubmitted = false;
    this.controlTypeCValidation = false;
    this.controlTypeVValidation = false;
    this.editsubmittedForm.patchValue({
      lastUpdatedBy: this.commonService.getUser(),
      flightControlAutoId: this.flightControlAutoId,
      clientId: this.clientID,
      activate: true
    });
  }

  get u() {
    return this.editsubmittedForm.controls;
  }

  showEditvalues(getId) {
    this.flightControlService.getFlightControlByFlightControlId(getId).subscribe(
      flightControlService => {
        if (!!flightControlService && flightControlService.flightControlAutoId) {
          for(var i=1; i<=5 ; i++){
          this.callControlValueLOV(flightControlService['controlIndicator'+i], i, "edit");
          }

          this.editsubmittedForm.patchValue({
            flightControlAutoId: flightControlService['flightControlAutoId'],
            flightControlId: flightControlService['flightControlId'],
            controlDescription: flightControlService['controlDescription'],
            selfOalIndicator: flightControlService['selfOalIndicator'],
            controlType: flightControlService['controlType'],
            controlFormula: flightControlService['controlFormula'],
            controlIndicator1: flightControlService['controlIndicator1'],
            controlIndicator2: flightControlService['controlIndicator2'],
            controlIndicator3: flightControlService['controlIndicator3'],
            controlIndicator4: flightControlService['controlIndicator4'],
            controlIndicator5: flightControlService['controlIndicator5'],
            matchControl: flightControlService['matchControl'] != null ? flightControlService['matchControl'].trim() : flightControlService['matchControl'],
            controlIdentification: flightControlService['controlIdentification'],
            controlValue1: flightControlService['controlValue1'],
            controlValue2: flightControlService['controlValue2'],
            controlValue3: flightControlService['controlValue3'],
            controlValue4: flightControlService['controlValue4'],
            controlValue5: flightControlService['controlValue5'],
            clientId: this.clientID
          });
          this.flightControlAutoId = flightControlService['flightControlAutoId'];
          this.onControlTypeChange(flightControlService['controlType'], 'edit');
          this.box_search_status = false;

        } else {
          this.messageBoxService.showFetchErrorMessage();
        }
      });
  }

  showCopyValues(getId): void {
    this.flightControlService.getFlightControlByFlightControlId(getId).subscribe(
      flightControlService => {
        if (!!flightControlService && flightControlService.flightControlId) {
          for(var i=1; i<=5 ; i++){
            this.callControlValueLOV(flightControlService['controlIndicator'+i], i, "edit");
            }

          this.addNewFlightControlForm.patchValue({
            flightControlId: flightControlService['flightControlId'],
            controlDescription: flightControlService['controlDescription'],
            selfOalIndicator: flightControlService['selfOalIndicator'],
            controlType: flightControlService['controlType'],
            controlFormula: flightControlService['controlFormula'],
            controlIndicator1: flightControlService['controlIndicator1'],
            controlIndicator2: flightControlService['controlIndicator2'],
            controlIndicator3: flightControlService['controlIndicator3'],
            controlIndicator4: flightControlService['controlIndicator4'],
            controlIndicator5: flightControlService['controlIndicator5'],
            matchControl: flightControlService['matchControl'] != null ? flightControlService['matchControl'].trim() : flightControlService['matchControl'],
            controlIdentification: flightControlService['controlIdentification'],
            controlValue1: flightControlService['controlValue1'],
            controlValue2: flightControlService['controlValue2'],
            controlValue3: flightControlService['controlValue3'],
            controlValue4: flightControlService['controlValue4'],
            controlValue5: flightControlService['controlValue5'],
            clientId: this.clientID
          });
          this.onControlTypeChange(flightControlService['controlType'], 'add');
          this.box_search_status = false;

        } else {
          this.messageBoxService.showFetchErrorMessage();
        }
      });
  }

  onUpdate() {
    this.editsubmitted = true;
    this.editsubmittedForm.value.controlType == "C" ? this.controlTypeCValidation = true : this.controlTypeCValidation = false;
    this.editsubmittedForm.value.controlType == "V" ? this.controlTypeVValidation = true : this.controlTypeVValidation = false;
    if (this.editsubmittedForm.invalid) {
      return;
    } else {
      const flightControl = Object.assign({}, this.editsubmittedForm.value);
      delete (flightControl.flightControlAutoId);
      delete (flightControl.activate);
      let data = this.commonService.convertApiObj(flightControl);
      if (!data['controlFormula']) {
        data['controlFormula'] = "";
      }
      this.flightControlService.updateFlightControl(this.editsubmittedForm.value, flightControl).subscribe(
        flightControlService => {
          if (flightControlService && flightControlService.flightControlAutoId) {
            this.updateDataTable(flightControlService, 'update');
            this.closeModalEdit.nativeElement.click();
            this.error = { isError: true, errorMessage: "Record has been successfully saved" };
            this.closeAlertValidation();
            this.onResetEdit();
          }
        });
    }
  }


  showSearchBox(e) {
    this.box_search_status = !this.box_search_status;
    this.collapse_search_form = true;
  }

  onResetSearch() {
    this.searchForm.reset();
    this.renderDT = false;
    this.getAllFlightControlList();
  }

  onSearch() {
    this.searchsubmitted = true;
    this.searchstring = 'flight-control?';
    if (this.searchForm.value.controlId) {
      this.searchstring += 'flightControlId=' + this.searchForm.value.controlId + '&&';
    }
    if (this.searchForm.value.activate) {
      this.searchstring += 'activate=' + this.searchForm.value.activate + '&&';
    }
    this.renderDT = false;
    this.flightControlService.searchFlightControl(this.searchstring).subscribe(
      flightControlService => {
        this.flightControlListArray = flightControlService;
        setTimeout(() => {
          this.renderDT = true;
        }, 100);
      });
  }

  toggleVisibility(e) {
    this.marked = e.target.checked;
  }
  removeafterDeactivate(flightControl: FlightControl): void {
    this.flightControlListArray = this.flightControlListArray.filter(h => h !== flightControl);
  }

  changeStatusFlightControl(masterDet, e) {
    if (e.target.checked) {
      this.messageBoxService.showActivationMessage('Flight Control').then((result) => {
        if (result.value) {
          this.flightControlService.activateFlightControl(masterDet.flightControlAutoId).subscribe(
            data => {
              console.log('data->' + data);
              this.onSearch();
            }, error => {
              console.log('error->' + error);
            });
          this.messageBoxService.showActivationSuccess('Flight Control');

        } else if (
          // Read more about handling dismissals
          result.dismiss === swal.DismissReason.cancel
        ) {
          e.target.checked = false;
          this.messageBoxService.showStatusUnchangedMessage('Flight Control');
        }
      });
      this.onSearch();
    } else {
      this.messageBoxService.showDeactivationMessage('Flight Control').then((result) => {
        if (result.value) {
          this.flightControlService.deactivateFlightControl(masterDet.flightControlAutoId).subscribe(
            data => {
              console.log('data->' + data);
              this.onSearch();
            }, error => {
              console.log('error->' + error);
            });
          this.messageBoxService.showDeactivationSuccess('Flight Control');

        } else if (
          // Read more about handling dismissals
          result.dismiss === swal.DismissReason.cancel
        ) {
          e.target.checked = true;
          this.messageBoxService.showStatusUnchangedMessage('Flight Control');
        }
      });
    }
  }



  onControlTypeChange(value, form) {
    if (form == 'add') {
      if (value == 'C') {
        this.resetAllControlValue();
        this.mandatoryFlag = "calculative";
        this.addNewFlightControlForm.controls['controlFormula'].setValidators([Validators.required]);
        this.addNewFlightControlForm.controls['controlFormula'].updateValueAndValidity();

        this.addNewFlightControlForm.controls['controlIndicator1'].setValue(null);
        this.addNewFlightControlForm.controls['controlIndicator1'].clearValidators();
        this.addNewFlightControlForm.controls['controlIndicator1'].updateValueAndValidity();
        this.addNewFlightControlForm.controls['controlValue1'].setValue(null);
        this.addNewFlightControlForm.controls['controlValue1'].clearValidators();
        this.addNewFlightControlForm.controls['controlValue1'].updateValueAndValidity();

        this.addNewFlightControlForm.controls['controlIndicator2'].setValue(null);
        this.addNewFlightControlForm.controls['controlValue2'].setValue(null);
        this.addNewFlightControlForm.controls['controlIndicator3'].setValue(null);
        this.addNewFlightControlForm.controls['controlValue3'].setValue(null);
        this.addNewFlightControlForm.controls['controlIndicator4'].setValue(null);
        this.addNewFlightControlForm.controls['controlValue4'].setValue(null);
        this.addNewFlightControlForm.controls['controlIndicator5'].setValue(null);
        this.addNewFlightControlForm.controls['controlValue5'].setValue(null);
      } else {
        this.mandatoryFlag = "value";
        this.addNewFlightControlForm.controls['controlIndicator1'].setValidators([Validators.required]);
        this.addNewFlightControlForm.controls['controlIndicator1'].updateValueAndValidity();
        this.addNewFlightControlForm.controls['controlValue1'].setValidators([Validators.required]);
        this.addNewFlightControlForm.controls['controlValue1'].updateValueAndValidity();

        this.addNewFlightControlForm.controls['controlFormula'].setValue(null);
        this.addNewFlightControlForm.controls['controlFormula'].clearValidators();
        this.addNewFlightControlForm.controls['controlFormula'].updateValueAndValidity();
      }
    } else {
      if (value == 'C') {
        this.resetAllControlValue();
        this.mandatoryFlag = "calculative";
        this.editsubmittedForm.controls['controlFormula'].setValidators([Validators.required]);
        this.editsubmittedForm.controls['controlFormula'].updateValueAndValidity();

        this.editsubmittedForm.controls['controlIndicator1'].setValue(null);
        this.editsubmittedForm.controls['controlIndicator1'].clearValidators();
        this.editsubmittedForm.controls['controlIndicator1'].updateValueAndValidity();
        this.editsubmittedForm.controls['controlValue1'].setValue(null);
        this.editsubmittedForm.controls['controlValue1'].clearValidators();
        this.editsubmittedForm.controls['controlValue1'].updateValueAndValidity();

        this.editsubmittedForm.controls['controlIndicator2'].setValue(null);
        this.editsubmittedForm.controls['controlValue2'].setValue(null);
        this.editsubmittedForm.controls['controlIndicator3'].setValue(null);
        this.editsubmittedForm.controls['controlValue3'].setValue(null);
        this.editsubmittedForm.controls['controlIndicator4'].setValue(null);
        this.editsubmittedForm.controls['controlValue4'].setValue(null);
        this.editsubmittedForm.controls['controlIndicator5'].setValue(null);
        this.editsubmittedForm.controls['controlValue5'].setValue(null);
      } else {
        this.mandatoryFlag = "value";
        this.editsubmittedForm.controls['controlIndicator1'].setValidators([Validators.required]);
        this.editsubmittedForm.controls['controlIndicator1'].updateValueAndValidity();
        this.editsubmittedForm.controls['controlValue1'].setValidators([Validators.required]);
        this.editsubmittedForm.controls['controlValue1'].updateValueAndValidity();

        this.editsubmittedForm.controls['controlFormula'].setValue(null);
        this.editsubmittedForm.controls['controlFormula'].clearValidators();
        this.editsubmittedForm.controls['controlFormula'].updateValueAndValidity();
      }
    }
  }

  onCancelChange() {
    this.addNewsubmitted = false;
    this.editsubmitted = false;
    this.mandatoryFlag = "";
    this.onResetAdd();
    this.onResetEdit();
    this.closeModalAdd.nativeElement.click();
    this.closeModalEdit.nativeElement.click();
    this.resetAllControlValue();
  }
  updateDataTable(data, type) {
    if (type == 'add') this.flightControlListArray.unshift(data);
    else {
      const ind = this.flightControlListArray.findIndex((item) => { return data.flightControlAutoId == item.flightControlAutoId; });
      if (ind == -1) return false; if (type == 'update') this.flightControlListArray[ind] = data; else if (type == 'remove') this.flightControlListArray.splice(ind, 1);
    }
    this.flightControlListArray = [...this.flightControlListArray];
  }

  callControlValueLOV(data, controlIndicator, form) {
    const json = { "fieldValue": data };
    if (data != null && data != "" && data != undefined) {
      this.getControlValByControlInd(json, controlIndicator, form);
    }
  }

  getControlValByControlInd(data, controlIndicator, form) {
    for(var i=1; i<=5 ; i++){
      if (controlIndicator == i) {
        form === 'add' ? this.addNewFlightControlForm.controls['controlValue'+i].setValue(null) : this.editsubmittedForm.controls['controlValue'+i].setValue(null);
        this['controlValue'+i+'Array'] = [];
        this['controlValue'+i+'Array'] = this.lov.getData(data['fieldValue'].split(' ').join('_'), 'flight_control');
       } 
      }
  }

  resetAllControlValue() {
    this.controlValue1Array = [];
    this.controlValue2Array = [];
    this.controlValue3Array = [];
    this.controlValue4Array = [];
    this.controlValue5Array = [];
  }
}

