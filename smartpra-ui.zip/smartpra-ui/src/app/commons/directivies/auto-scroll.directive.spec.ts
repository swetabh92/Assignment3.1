import { AutoScrollDirective } from './auto-scroll.directive';

describe('AutoScrollDirective', () => {
  it('should create an instance', () => {
    const directive = new AutoScrollDirective();
    expect(directive).toBeTruthy();
  });
});
