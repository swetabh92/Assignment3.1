package com.sgl.smartpra.batch.sales.validator.app.processor;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.sales.validator.app.config.FeignConfiguration.SmartpraGlobalMasterAppClient;
import com.sgl.smartpra.batch.sales.validator.app.master.AgencyMasterClient;
import com.sgl.smartpra.batch.sales.validator.app.master.AirportMasterClient;
import com.sgl.smartpra.batch.sales.validator.app.master.CurrencyMasterClient;
import com.sgl.smartpra.global.master.model.Airport;
import com.sgl.smartpra.global.master.model.Currency;
import com.sgl.smartpra.master.model.AgencyMaster;

/**
 * 
 * @author mansound1
 *
 */
@Component
public class SalesRulesImpl implements SalesRules {

	@Autowired
	SmartpraGlobalMasterAppClient smartpraGlobalMasterAppClient;

	@Autowired
	AirportMasterClient airportMaster;
	
	@Autowired
	AgencyMasterClient agencyMasterClient;
	
	@Autowired
	CurrencyMasterClient currencyMasterClient;

	@Override
	public boolean checkCarrierCode(String carrierCode) {
		try {
			smartpraGlobalMasterAppClient.getCarrierByCarrierCode(carrierCode);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;
	}

	@Override
	public boolean validateAirportCode(String airportCode) {
		Airport airport = airportMaster.getAirportByAirportCode(airportCode);
		if (airport != null) {
			return true;
		} else {
			return false;
		}

	}

	@Override
	public boolean validateCityCode(String cityCode) {
		List<Airport> airports = airportMaster.getAllAirport(null, null, cityCode, null, null);
		if (airports == null || airports.isEmpty()) {
			return false;
		} else {
			return false;
		}

	}

	@Override
	public boolean validateDocumentNo(String documentNo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean validateAgentCode(String agentCode) {
		 List<AgencyMaster> agencyMasters =agencyMasterClient.getAllAgency(agentCode, null,null,null, null);
		 if (agencyMasters == null || agencyMasters.isEmpty()) {
				return false;
			} else {
				return false;
			}

	}
	
	public boolean validateCurrencyCode(String currencyCode) {
		List<Currency> currencies= 	currencyMasterClient.getAllcurrencies(currencyCode,null);
		 if (currencies == null || currencies.isEmpty()) {
				return false;
			} else {
				return false;
			}

	}

}