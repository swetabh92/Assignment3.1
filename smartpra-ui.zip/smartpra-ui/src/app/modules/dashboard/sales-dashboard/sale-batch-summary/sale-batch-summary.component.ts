import {Component, Input, OnInit} from '@angular/core';
import {BatchListModel} from '../model/sale-model';
import {SalesdashboardserviceService} from '../salesdashboardservice.service';

@Component({
  selector: 'app-sale-batch-summary',
  templateUrl: './sale-batch-summary.component.html',
  styleUrls: ['./sale-batch-summary.component.css']
})
export class SaleBatchSummaryComponent implements OnInit {
  batchSummaryClose: boolean;
  batchSummaryListResults: BatchListModel[] = [];

  @Input('value')
  set values(val: any) {
    if (val) {
      this.getBatchSummary(val);
      this.batchSummaryClose = true;
    }
  }

  constructor(private salesService: SalesdashboardserviceService) {
  }

  getBatchSummary(selectedSale) {
    this.salesService.getBatchSummaryDetails(selectedSale.agencyCode, selectedSale.reportingAgency).subscribe((res: any[]) => {
      this.batchSummaryListResults = res[0];
      console.log(res[0]);
    });
  }

  ngOnInit() {
  }

  /*temp */
  convertDecimal(val) {
    if (val == null) {
      val = 0;
    }
    val = Number(val);
    return val.toFixed(this.salesService.currencyDecimalPression);
  }

  closeBatchSummary(type) {
    if (type == 'close') {
      this.batchSummaryClose = false;
    }
  }

  convertValueToZero(val: any) {
    if (val == null) {
      val = 0;
      return val;
    } else {
      return val;
    }
  }

  /* convertToSingleValue(val: any) {
     if(val && val!= null){
        let len = val.length;
        return val[len - 1]
     }else{
       return val;
     }

   }*/
}
