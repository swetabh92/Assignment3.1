import { Directive,HostListener} from '@angular/core';
import { NgControl } from "@angular/forms";

@Directive({
  selector: '[appUpperCase]'
})
export class UpperCaseDirective {

 constructor(private control : NgControl){}
 @HostListener('input', ['$event']) onKeyup(event: KeyboardEvent) {
	 let val = (<HTMLInputElement>event.target).value;
	if(val) this.control.control.setValue(val.toUpperCase());
 }
}
