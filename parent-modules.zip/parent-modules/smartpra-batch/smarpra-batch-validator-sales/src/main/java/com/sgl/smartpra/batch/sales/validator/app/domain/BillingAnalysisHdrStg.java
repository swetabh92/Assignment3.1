package com.sgl.smartpra.batch.sales.validator.app.domain;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the billing_analysis_hdr_stg database table.
 * 
 */
@Entity
@Table(name="billing_analysis_hdr_stg")
public class BillingAnalysisHdrStg extends BSPRecord implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="billing_cycle_auto_id")
	private int billingCycleAutoId;

	@Column(name="billing_analysis_ending_date")
	private String billingAnalysisEndingDate;

	@Column(name="created_by")
	private String createdBy;

	@Column(name="created_date")
	private Timestamp createdDate;

	@Column(name="dynamic_run_identifier")
	private String dynamicRunIdentifier;

	private String filler2;

	@Column(name="hot_reporting_end_date")
	private String hotReportingEndDate;

	@Column(name="last_updated_by")
	private String lastUpdatedBy;

	@Column(name="last_updated_date")
	private Timestamp lastUpdatedDate;

	@Column(name="processing_cycle_identifier")
	private String processingCycleIdentifier;

	@Column(name="processing_date_identifier")
	private String processingDateIdentifier;

	@Column(name="seq_number")
	private String seqNumber;

	@Column(name="std_message_identifier")
	private String stdMessageIdentifier;

	@Column(name="std_numeric_quaifier")
	private String stdNumericQuaifier;

	//bi-directional many-to-one association to SalesFileHeaderStg
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.MERGE)
    @JoinColumn(name="file_hdr_id")
	private SalesFileHeaderStg salesFileHeaderStg;

	public BillingAnalysisHdrStg() {
	}

	public int getBillingCycleAutoId() {
		return this.billingCycleAutoId;
	}

	public void setBillingCycleAutoId(int billingCycleAutoId) {
		this.billingCycleAutoId = billingCycleAutoId;
	}

	public String getBillingAnalysisEndingDate() {
		return this.billingAnalysisEndingDate;
	}

	public void setBillingAnalysisEndingDate(String billingAnalysisEndingDate) {
		this.billingAnalysisEndingDate = billingAnalysisEndingDate;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDynamicRunIdentifier() {
		return this.dynamicRunIdentifier;
	}

	public void setDynamicRunIdentifier(String dynamicRunIdentifier) {
		this.dynamicRunIdentifier = dynamicRunIdentifier;
	}

	public String getFiller2() {
		return this.filler2;
	}

	public void setFiller2(String filler2) {
		this.filler2 = filler2;
	}

	public String getHotReportingEndDate() {
		return this.hotReportingEndDate;
	}

	public void setHotReportingEndDate(String hotReportingEndDate) {
		this.hotReportingEndDate = hotReportingEndDate;
	}

	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getLastUpdatedDate() {
		return this.lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getProcessingCycleIdentifier() {
		return this.processingCycleIdentifier;
	}

	public void setProcessingCycleIdentifier(String processingCycleIdentifier) {
		this.processingCycleIdentifier = processingCycleIdentifier;
	}

	public String getProcessingDateIdentifier() {
		return this.processingDateIdentifier;
	}

	public void setProcessingDateIdentifier(String processingDateIdentifier) {
		this.processingDateIdentifier = processingDateIdentifier;
	}

	public String getSeqNumber() {
		return this.seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdMessageIdentifier() {
		return this.stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getStdNumericQuaifier() {
		return this.stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public SalesFileHeaderStg getSalesFileHeaderStg() {
		return this.salesFileHeaderStg;
	}

	public void setSalesFileHeaderStg(SalesFileHeaderStg salesFileHeaderStg) {
		this.salesFileHeaderStg = salesFileHeaderStg;
	}
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	/*@Override
	public LineTokenizer lineTokenizer() {

		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		BillingAnalysisHeaderStgLayout billingAnalysisHeaderStgLayout = new BillingAnalysisHeaderStgLayout();
		tokenizer.setColumns(billingAnalysisHeaderStgLayout.getColumns());
		tokenizer.setNames(billingAnalysisHeaderStgLayout.getNames());
		return tokenizer;

	}

	@Override
	public FieldSetMapper<BSPRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<BSPRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<BSPRecord>();
		fieldSetMapper.setTargetType(BillingAnalysisHdrStg.class);
		return fieldSetMapper;
	}

	@Override
	public ItemProcessor<? extends BSPRecord, ? extends BSPRecord> processor() {
		return new BillingAnalysisHeaderStgProcessor();
	}

	@Override
	public ItemWriter<? super BSPRecord> writer() {
		return new BillingAnalysisHeaderStgWriter();
	}
*/
}