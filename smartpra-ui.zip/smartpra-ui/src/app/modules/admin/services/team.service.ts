import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import swal from 'sweetalert2';

import { environment } from '../../../../environments/environment';
import { Team } from '../models/team';
import { MessageBoxService } from '../../masters/services/commons/message-box.service';
const httpOptions = {
  // headers: new HttpHeaders({ 'Content-Type': 'multipart/form-data' })
};
const httpOptions1 = {
  headers: new HttpHeaders({ 'Content-Type': 'multipart/form-data' })
};
@Injectable({
  providedIn: 'root'
})
export class TeamService {
  globalUrl = environment.apiUrlGlobal;
  masterUrl = environment.apiUrlMaster;
  authUrl = environment.apiUrlauth;
  constructor(private http: HttpClient, private messageBoxService: MessageBoxService) { }
  getTeamAll(): Observable<Team[]> {
    return this.http.get<Team[]>(this.authUrl + 'mas-teams')
      .pipe(
        tap(_ => this.log('fetched Team details')),
        catchError(this.handleError('getAllTeam', []))
      );
  }
  TeamByTeamId(teamId: string): Observable<Team> {
    return this.http.get<Team>(this.authUrl + 'mas-teams/' + teamId).pipe(
      tap(_ => this.log(`fetched Team teamId=${teamId}`)),
      catchError(this.handleError<Team>(`TeamByTeamId teamId=${teamId}`))
    );
  }
  searchTeam(parms: string): Observable<Team> {
    return this.http.get<Team>(this.authUrl + parms).pipe(
      tap(_ => this.log(`search Team teamId by ${parms}`)),
      catchError(this.handleError<Team>(`search Team teamId by ${parms}`))
    );
  }
  /** POST: add a new Team to the server */
  addTeam(formdata): Observable<Team> {
    // console.log(formdata); return;
    return this.http.post<Team>(this.authUrl + 'mas-teams/', formdata, httpOptions).pipe(
      tap(_ => this.log(`added Team teamId=`)),
      catchError(this.handleError<Team>('addTeam'))
    );
  }
  updateTeam(team: Team): Observable<any> {
    // console.log(Team.teamId);
    console.log(team);
    return this.http.put<Team>(this.authUrl + 'mas-teams/', team, httpOptions).pipe(
      tap(_ => this.log(`updated Team teamId=${team.teamId}`)),
      catchError(this.handleError<Team>('addTeam'))
    );
  }
  activateTeam(teamId: string): Observable<Team> {
    return this.http.put<Team>(this.authUrl + 'mas-teams/activateordeactivate/' + teamId, httpOptions).pipe(
      tap(_ => this.log(`activate Team teamId=${teamId}`)),
      catchError(this.handleError<Team>('activateTeam'))
    );
  }
  deactivateTeam(teamId: string): Observable<Team> {
    return this.http.put<Team>(this.authUrl + 'mas-teams/activateordeactivate/' + teamId, httpOptions).pipe(
      tap(_ => this.log(`deactivate Team teamId=${teamId}`)),
      catchError(this.handleError<Team>('deactvateTeam'))
    );
  }

  getTeamByGroupId(groupId: string): Observable<Team> {
    return this.http.get<Team>(this.authUrl + 'mas-teams/byGroup/' + groupId).pipe(
      tap(_ => this.log(`fetched Team teamId=${groupId}`)),
      catchError(this.handleError<Team>(`TeamByTeamId teamId=${groupId}`))
    );
  }
  private handleError<T>(operation = 'operation', result?: T) {
    return (e: any): Observable<T> => {
      console.log(e);
      const error = e.error.message || e.error.error || e.error.error_description || 'Could not connect server';
      console.log(error);
      this.messageBoxService.getErrorMessage('ERROR', error);
      return of(result as T);
    };
  }
  private log(error: any) {
    console.log(error);
    if (error.message) {
      this.messageBoxService.getErrorMessage('ERROR', error.message);
    }
  }
}
