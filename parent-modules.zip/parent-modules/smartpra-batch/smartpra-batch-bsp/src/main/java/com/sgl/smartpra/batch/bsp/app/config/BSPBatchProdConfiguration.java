package com.sgl.smartpra.batch.bsp.app.config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import javax.validation.ConstraintViolationException;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.data.RepositoryItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.transaction.PlatformTransactionManager;

import com.sgl.smartpra.batch.bsp.app.domain.staging.AgentRegisterStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TicketModel;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TransactionHeaderStg;
import com.sgl.smartpra.batch.bsp.app.listener.BSPProdLoadJobExecutionListener;
import com.sgl.smartpra.batch.bsp.app.processor.AgencyMasterProcessor;
import com.sgl.smartpra.batch.bsp.app.processor.AgentRegisterProcessor;
import com.sgl.smartpra.batch.bsp.app.processor.TransactionProcessor;
import com.sgl.smartpra.batch.bsp.app.reader.AgencyMasterReader;
import com.sgl.smartpra.batch.bsp.app.repository.staging.AgentRegisterStgRepository;
import com.sgl.smartpra.batch.bsp.app.repository.staging.FileHeaderStgRepository;
import com.sgl.smartpra.batch.bsp.app.repository.staging.TransactionHeaderStgRepository;
import com.sgl.smartpra.batch.bsp.app.service.FileLoggingDetailTasklet;
import com.sgl.smartpra.batch.bsp.app.writer.AgencyMasterWriter;
import com.sgl.smartpra.batch.bsp.app.writer.AgentRegisterWriter;
import com.sgl.smartpra.batch.bsp.app.writer.TicketModelWriter;
import com.sgl.smartpra.master.model.AgencyMaster;
import com.sgl.smartpra.sales.domain.AgentRegister;

@Configuration
@EnableBatchProcessing
public class BSPBatchProdConfiguration {

	@Autowired
	private FileLoggingDetailTasklet fileLoggingDetailTasklet;

	@Autowired
	private JobBuilderFactory jobBuilderFactory;

	@Autowired
	private StepBuilderFactory stepBuilderFactory;

	@Autowired
	private BSPProdLoadJobExecutionListener jobExecutionListener;

	@Autowired
	private PlatformTransactionManager transactionManager;

	@Autowired
	private AgentRegisterStgRepository agentRegisterStgRepository;

	@Autowired
	private TransactionHeaderStgRepository transactionHeaderStgRepository;

	@Autowired
	private FileHeaderStgRepository fileHeaderStgRepository;

	@Bean
	public Job loadBSPFromStagingToProdJob(BSPProdLoadJobExecutionListener jobExecutionListener, Step getfileLoggingDetail, Step loadAgentRegister, Step createAgentMaster, Step loadTransaction) {
		// @formatter:off
		return jobBuilderFactory
				.get("loadBSPFromStagingToProdJob")
				.incrementer(new RunIdIncrementer())
				.start(getfileLoggingDetail)
				.next(loadAgentRegister)
//				.next(createAgentMaster)
				.next(loadTransaction)
				.listener(jobExecutionListener)
				.build();
		// @formatter:on
	}

	@Bean
	public Step getfileLoggingDetail() {

		// @formatter:off
		return stepBuilderFactory
				.get("fileLoggingDetailTasklet")
				.tasklet(fileLoggingDetailTasklet)
				.build();
		// @formatter:on
	}

	@Bean
	public Step loadAgentRegister() {
		// @formatter:off
		return stepBuilderFactory
				.get("loadAgentRegister")
				.<AgentRegisterStg, AgentRegister>chunk(100)
				.reader(agentRegisterItemReader(null, null))
				.processor((ItemProcessor<AgentRegisterStg, AgentRegister>) agentRegisterProcessor())
				.writer(agentRegisterWriter())
				.transactionManager(transactionManager)
				.taskExecutor(new SimpleAsyncTaskExecutor())
				.throttleLimit(1)
				.build();
		// @formatter:on
	}

	@Bean
	public Step createAgentMaster() {
		// @formatter:off
		return stepBuilderFactory
				.get("createAgentMaster")
				.<AgencyMaster, AgencyMaster>chunk(1)
				.reader(agencyMasterReader())
				.processor((ItemProcessor<AgencyMaster, AgencyMaster>) agencyMasterProcessor())
				.writer(agencyMasterWriter())
				.transactionManager(transactionManager)
				.taskExecutor(new SimpleAsyncTaskExecutor())
				.throttleLimit(1)
				.build();
				// @formatter:on
	}
	
	@Bean
	@StepScope
	public RepositoryItemReader<AgentRegisterStg> agentRegisterItemReader(@Value("#{jobParameters[fileId]}") Integer fileId, @Value("#{stepExecution}") StepExecution stepExecution) {

		RepositoryItemReader<AgentRegisterStg> reader = new RepositoryItemReader<AgentRegisterStg>();
		ArrayList<Integer> arguments = new ArrayList<Integer>();
		arguments.add(fileId);
		reader.setRepository(agentRegisterStgRepository);
		reader.setMethodName("findByFileId");
		reader.setArguments(arguments);
		reader.setSaveState(false);
		Map<String, Direction> map = new HashMap<String, Direction>();
		map.put("fileHdrId", Direction.ASC);
		reader.setSort(map);

		// Initialize the Agent Register Map; this will be used to get the SalesKey
		Map<String, AgentRegister> agentRegisterMap = new Hashtable<String, AgentRegister>();
		stepExecution.getJobExecution().getExecutionContext().put("salesKey", agentRegisterMap);
		
		// Initialize the Agent Code Map; this will be used to create agent master
		Map<String, String> agentCodeMap = new Hashtable<String, String>();
		stepExecution.getJobExecution().getExecutionContext().put("agentCode", agentCodeMap);

		return reader;

	}
	
	
	
	@Bean
	public Step loadTransaction() {
		// @formatter:off
		return stepBuilderFactory
				.get("loadTransaction")
				.<TransactionHeaderStg, List<TicketModel>>chunk(50)
				.reader(transactionItemReader(null))
				.processor((ItemProcessor<TransactionHeaderStg, List<TicketModel>>) transactionProcessor())
				.writer((ItemWriter<List<TicketModel>>) ticketMainWriter())
				.faultTolerant()
				.skip(ConstraintViolationException.class)
				.faultTolerant()
			    .skip(DataIntegrityViolationException.class)
			    .noRetry(DataIntegrityViolationException.class)
			    .noRollback(DataIntegrityViolationException.class) 
				.transactionManager(transactionManager)
				.taskExecutor(new SimpleAsyncTaskExecutor())
				.throttleLimit(25)
				.build();
		// @formatter:on
	}

	@Bean
	@StepScope
	public RepositoryItemReader<TransactionHeaderStg> transactionItemReader(@Value("#{jobParameters[fileId]}") Integer fileId) {
		RepositoryItemReader<TransactionHeaderStg> reader = new RepositoryItemReader<TransactionHeaderStg>();
		ArrayList<Integer> arguments = new ArrayList<Integer>();
		arguments.add(fileId);
		reader.setRepository(transactionHeaderStgRepository);
		reader.setMethodName("findByFileId");
		reader.setArguments(arguments);
		Map<String, Direction> map = new HashMap<String, Direction>();
		map.put("transactionHdrId", Direction.ASC);
		reader.setSort(map);
		return reader;
	}

	@Bean
	@StepScope
	public AgentRegisterProcessor agentRegisterProcessor() {
		return new AgentRegisterProcessor();
	}

	@Bean
	@StepScope
	public AgentRegisterWriter agentRegisterWriter() {
		return new AgentRegisterWriter();
	}

	@Bean
	@StepScope
	public TransactionProcessor transactionProcessor() {
		return new TransactionProcessor();
	}

	@Bean
	@StepScope
	public TicketModelWriter ticketMainWriter() {
		return new TicketModelWriter();
	}

	@Bean
	@StepScope
	public AgencyMasterProcessor agencyMasterProcessor() {
		return new AgencyMasterProcessor();
	}
	
	@Bean
	@StepScope
	public AgencyMasterWriter agencyMasterWriter() {
		return new AgencyMasterWriter();
	}
	
	@Bean
	@StepScope
	public ItemReader<AgencyMaster> agencyMasterReader() {
		return new AgencyMasterReader();
	}
}
