export const AppConstants = {
 DEFAULT_LANG_CODE : "en",
 LANG_FILES_PATH : "assets/i18n/",
 JSON_TYPE : ".json"
};
