import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {path:'inputoutput',loadChildren:'./input-output/input-output.module#InputOutputModule'},
  {path:'salesDashboard',loadChildren:'./sales-dashboard/sales-dashboard.module#SalesDashboardModule'},
  {path:'flownDashboard',loadChildren:'./flown-dashboard/flown-dashboard.module#FlownDashboardModule'},
  {path:'standalone-proration', loadChildren:'./standalone-proration/standalone-proration.module#StandaloneProrationModule'},
  {path:'interlineInwardDashboard',loadChildren:'./interline-inward-dashboard/inward-dashboard.module#InwardDashboardModule'},
  {path:'outwardBillingProcess',loadChildren:'./outward-billing-process/outward-billing-process.module#OutwardBillingProcessModule'},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule { }
