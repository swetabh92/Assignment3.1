package com.sgl.smartpra.batch.fdr.app.writer;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.fdr.app.config.FeignConfiguration.BatchGlobalFeignClient;
import com.sgl.smartpra.batch.fdr.app.domain.CurrencyRate;
import com.sgl.smartpra.batch.fdr.app.domain.CurrencyRecord;
import com.sgl.smartpra.batch.fdr.app.repository.FDRRepository;

@Component
@Scope(value = "step")
public class FDRWriter<T extends CurrencyRecord> implements ItemWriter<CurrencyRate> {

	@Autowired
	private FDRRepository roeRepository;

	private int count = 0;

	private Date date;

	@Value("#{stepExecution}")
	private StepExecution stepExecution;

	public StepExecution getStepExecution() {
		return stepExecution;
	}

	public void setStepExecution(StepExecution stepExecution) {
		this.stepExecution = stepExecution;
	}

	public void write(List<? extends CurrencyRate> fdrList) throws Exception {
		Date nextMonthFirstDay = null;
		Date nextMonthLastDay = null;
		String effectiveDate = (String) stepExecution.getExecutionContext().get("effectiveDate");
		try {
			String year = effectiveDate.substring(2, 4);
			String month = effectiveDate.substring(4, 6);
			String day = effectiveDate.substring(6, 8);
			String formatedYres = "20" + year;
			String date1 = day + "/" + month + "/" + formatedYres;
			DateFormat format = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);
			Date dt = null;
			try {
				dt = format.parse(date1);
			} catch (Exception e) {
				e.printStackTrace();
			}
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(dt);
			calendar.add(Calendar.MONTH, 1);
			calendar.set(Calendar.DATE, calendar.getActualMinimum(Calendar.DAY_OF_MONTH));
			nextMonthFirstDay = calendar.getTime();
			fdrList.get(0).setEffectiveFromDate(nextMonthFirstDay);
			calendar.set(Calendar.DATE, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
			nextMonthLastDay = calendar.getTime();
			fdrList.get(0).setEffectiveToDate(nextMonthLastDay);
		} catch (Exception ex) {
		}

		for (CurrencyRate currencyRate : fdrList) {
			CurrencyRate eurCurrencyrate = new CurrencyRate();
			eurCurrencyrate.setCurrencyFromCode(currencyRate.getCurrencyFromCode());
			eurCurrencyrate.setCurrencyToCode("EUR");
			eurCurrencyrate.setEffectiveFromDate(nextMonthFirstDay);
			eurCurrencyrate.setEffectiveToDate(nextMonthLastDay);
			eurCurrencyrate.setInboundFileId(currencyRate.getInboundFileId());

			String eurExRate = currencyRate.getEurExchangeRate().substring(0, 12);
			Double exchangerate = Double.valueOf(eurExRate.substring(0, 7) + "." + eurExRate.substring(7, 12));
			eurCurrencyrate.setExchangeRate(exchangerate);

			try {
				roeRepository.save(eurCurrencyrate);
			} catch (DataIntegrityViolationException e) {
				count++;

			} catch (Exception ex) {

			}
			CurrencyRate gbpCurrencyrate = new CurrencyRate();
			gbpCurrencyrate.setCurrencyFromCode(currencyRate.getCurrencyFromCode());
			gbpCurrencyrate.setCurrencyToCode("GBP");
			gbpCurrencyrate.setEffectiveFromDate(nextMonthFirstDay);
			gbpCurrencyrate.setEffectiveToDate(nextMonthLastDay);
			gbpCurrencyrate.setInboundFileId(currencyRate.getInboundFileId());
			String gbpExRate = currencyRate.getGbpExchangeRate().substring(0, 12);
			gbpCurrencyrate
					.setExchangeRate(Double.valueOf(gbpExRate.substring(0, 7) + "." + gbpExRate.substring(7, 12)));

			try {
				roeRepository.save(gbpCurrencyrate);
			} catch (DataIntegrityViolationException e) {
				count++;

			}

			CurrencyRate usdCurrencyrate = new CurrencyRate();
			usdCurrencyrate.setCurrencyFromCode(currencyRate.getCurrencyFromCode());
			usdCurrencyrate.setCurrencyToCode("USD");
			usdCurrencyrate.setEffectiveFromDate(nextMonthFirstDay);
			usdCurrencyrate.setEffectiveToDate(nextMonthLastDay);
			usdCurrencyrate.setInboundFileId(currencyRate.getInboundFileId());
			String usdExRate = currencyRate.getUsdExchangeRate().substring(0, 12);
			usdCurrencyrate
					.setExchangeRate(Double.valueOf(usdExRate.substring(0, 7) + "." + usdExRate.substring(7, 12)));

			try {
				roeRepository.save(usdCurrencyrate);
			} catch (DataIntegrityViolationException e) {
				count++;

			}

			JobExecution jobExecution = this.stepExecution.getJobExecution();
			ExecutionContext jobExecutionContext = jobExecution.getExecutionContext();

			jobExecutionContext.put("duplicateRecord", count);
		}

	}
}
