import { Directive,HostListener} from '@angular/core';
import { NgControl } from "@angular/forms";

@Directive({
  selector: '[appPercentage]'
})
export class PercentageDirective {

  constructor(private control : NgControl){}
 @HostListener('input', ['$event']) onKeyup(event: KeyboardEvent) {
	 let val:any = (<HTMLInputElement>event.target).value.replace(/[^0-9.]/g, '');
	 if(val.slice(-1) ==".") return;
	 else if(val !="") val = Number(val);
	 this.control.control.setValue(val);
 }
 
}
