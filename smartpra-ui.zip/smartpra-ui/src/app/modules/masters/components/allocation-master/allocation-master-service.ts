import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Observable, of} from 'rxjs';
import {catchError, tap} from 'rxjs/operators';
import {environment} from "../../../../../environments/environment";
import {MessageBoxService} from "../../../dashboard/sales-dashboard/MessageBoxService";
import {ExceptionMasterModel} from "../others/exception-master/exception-master-model";

const httpOptions = {
  headers: new HttpHeaders({'Content-Type': 'application/json'})
};

@Injectable({
  providedIn: 'root'
})
export class AllocationMasterService {

  apiUrl = environment.apiUrl + "exception-master/";
  masterUrl = environment.apiUrlMasterDev;
  allocationUrl = " http://10.100.27.36:8060/smartpra/exception-allocation/allocation-master";
  assignAllocationUrl = " http://10.100.27.36:8060/smartpra/exception-allocation/allocation-master/preload/";
  assignAllocationSaveUrl = "http://10.100.27.36:8060/smartpra/exception-allocation/allocation-master/";
  AllocationEditUrl ="http://10.100.27.36:8060/allocation-master/{allocationMasterId} "

  constructor(private http: HttpClient, private messageBoxService: MessageBoxService) {
  }

  /** GET Exception list from the server */
  getAllException(params: any): Observable<ExceptionMasterModel[]> {

    return this.http.get<ExceptionMasterModel[]>(this.apiUrl + 'exception').pipe(
      tap(_ => this.log('fetched Exception Details')),
      catchError(this.handleError('getAllException', []))
    );
  }

  getAllReferenceData(params: any): Observable<ExceptionMasterModel[]> {
    let queryString = Object.keys(params).map(key => key + '=' + params[key]).join('&');
    return this.http.get<ExceptionMasterModel[]>(this.allocationUrl + '/getLoadingData?' + queryString).pipe(
      tap(_ => this.log('fetched Exception Details')),
      catchError(this.handleError('getAllException', []))
    );
  }


  getAllModules() {
    return this.http.get<ExceptionMasterModel[]>(this.masterUrl + 'listofvalueslist/QR/General/Module').pipe(
      tap(_ => this.log('fetched Exception Details')),
      catchError(this.handleError('getAllException', []))
    );
  }

  getAllModulesChange(moduleName) {
    return this.http.get<ExceptionMasterModel[]>(this.assignAllocationUrl + moduleName).pipe(
      tap(_ => this.log('fetched Exception Details')),
      catchError(this.handleError('getAllException', []))
    );
  }


  getAllExceptionAllocation(moduleId) {
    return this.http.get<ExceptionMasterModel[]>(this.assignAllocationSaveUrl+ moduleId).pipe(
      tap(_ => this.log('fetched Exception Details')),
      catchError(this.handleError('getAllException', []))
    );
  }

  private handleError<T>(operation = 'operation', result?: T) {
    return (e: any): Observable<T> => {
      this.messageBoxService.getErrorMessage('ERROR', e['error']['message']);
      return of(e as T);
    };
  }

  private log(error: any) {
    if (error.message) {
      this.messageBoxService.getErrorMessage('ERROR', error.message);
    }
  }


  assignAllocation(data: any): Observable<ExceptionMasterModel> {
    return this.http.post<ExceptionMasterModel>(this.allocationUrl, data, httpOptions).pipe(
      tap(() => this.log(`added task`)),
      catchError(this.handleError<ExceptionMasterModel>('add pos'))
    );
  }

  assignAllocationSave(data: any, moduleName: any) : Observable<ExceptionMasterModel> {
    data.createdBy = 'admin';
    data.moduleName = moduleName;
    data.clientId = 'QR';
    if (data && data.hasOwnProperty('teamId'))
      data.teamId = parseInt(data.teamId);
    if (data && data.hasOwnProperty('groupId'))
      data.groupId = parseInt(data.groupId);
    return this.http.post<ExceptionMasterModel>(this.assignAllocationSaveUrl, data, httpOptions).pipe(
      tap(() => this.log(`added task`)),
      catchError(this.handleError<ExceptionMasterModel>('add pos'))
    );
  }
  
 updateAllocation(data:any): Observable <any > {
    return this.http.put <any >(this.apiUrl + '/allocation-master/', data, httpOptions).pipe(
      tap(_ => this.log(`updated Allocation data  anyID=${data}`)),
      catchError(this.handleError <any >('update Allocation data'))
    );
 }
}
