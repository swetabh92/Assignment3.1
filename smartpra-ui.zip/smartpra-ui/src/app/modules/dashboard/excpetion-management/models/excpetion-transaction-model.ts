export interface ExceptionTransactionModel {
  exceptionsViewModelList: ExceptionsViewPaginationModel[];
  totalCount: number
}

export interface ExceptionsViewPaginationModel {
  exceptionTransId: number
  moduleId: number
  moduleName: string
  issueAirline: string
  airlineType: string
  countryCode: string
  exceptionCode: string
  exceptionType: string
  exceptionMasterId: number
  exceptionDetails: string
  aging: number
  exceptionDate: Date
  exceptionSeverity: string
  mainDocument: string
  originalDocument: string
  conjunctionDocument: string
  couponNumber: string
  documentUniqueId: string
  fileId: number
  environment: string
  agencyCode: string;
  batchType: string;
  batchNumber: string;
  reportingCurrency: string;
  fromReportingPeriod: Date;
  toReporingPeriod: Date;
  flightNumber: string
  fromAirport: string
  toAirport: string
  upliftStation: string
  departureDate: Date
  flightCreationDate: Date
  groupId: number
  teamId: number
  userId: number
  assignedDate: Date
  assignedBy: string
  aggregationId: string
}
