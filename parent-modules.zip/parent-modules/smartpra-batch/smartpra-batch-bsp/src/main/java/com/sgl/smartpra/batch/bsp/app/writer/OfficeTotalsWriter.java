package com.sgl.smartpra.batch.bsp.app.writer;

import java.util.List;

import org.springframework.batch.core.StepExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.sgl.smartpra.batch.bsp.app.domain.staging.BSPStagingDomainObject;
import com.sgl.smartpra.batch.bsp.app.domain.staging.OfficeTotalsStg;
import com.sgl.smartpra.batch.bsp.app.repository.staging.OfficeTotalsStgRepository;

public class OfficeTotalsWriter extends BSPBaseItemWriter {

	@Value("#{stepExecution}")
	private StepExecution stepExecution;

	@Autowired
	private OfficeTotalsStgRepository officeTotalsStgRepository;

	@SuppressWarnings("unchecked")
	@Override
	public void write(List<? extends BSPStagingDomainObject> items) throws Exception {

		items.forEach(item -> {
			((OfficeTotalsStg) item).setOfficeHdrId(stepExecution.getExecutionContext().getInt("officeHeaderId"));
			((OfficeTotalsStg) item)
					.setFileHdrId(stepExecution.getJobExecution().getExecutionContext().getInt("fileHeaderId"));
			((OfficeTotalsStg) item).setFileId(stepExecution.getJobExecution().getExecutionContext().getInt("fileId"));
			super.setCreateAuditValues(item);
		});

		officeTotalsStgRepository.saveAll((Iterable<OfficeTotalsStg>) items);
	}
}
