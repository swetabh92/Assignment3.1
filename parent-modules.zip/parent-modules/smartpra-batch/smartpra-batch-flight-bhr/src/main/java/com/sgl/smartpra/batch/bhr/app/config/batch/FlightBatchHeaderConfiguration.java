package com.sgl.smartpra.batch.bhr.app.config.batch;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManagerFactory;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.mapping.PatternMatchingCompositeLineMapper;
import org.springframework.batch.item.file.transform.LineTokenizer;
import org.springframework.batch.item.support.ClassifierCompositeItemProcessor;
import org.springframework.batch.item.support.ClassifierCompositeItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.classify.Classifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;
import org.springframework.transaction.PlatformTransactionManager;

import com.sgl.smartpra.batch.bhr.app.domain.BatchRecord;
import com.sgl.smartpra.batch.bhr.app.domain.FlightBatchHeaderStg;
import com.sgl.smartpra.batch.bhr.app.listener.JobCompletionNotificationListener;


@Configuration
@EnableBatchProcessing
public class FlightBatchHeaderConfiguration {

	@Autowired
	public JobBuilderFactory jobBuilderFactory;

	@Autowired
	public StepBuilderFactory stepBuilderFactory;

	@Autowired
	EntityManagerFactory emf;

	@Value("${max-threads}")
	private int maxThreads;

	@Value("${batch.directory.bhr.input}")
	private String batchInputDir;

	@Autowired
	private PlatformTransactionManager transactionManager;

	@Bean
	public TaskExecutor taskExecutor() {
		SimpleAsyncTaskExecutor taskExecutor = new SimpleAsyncTaskExecutor();
		taskExecutor.setConcurrencyLimit(maxThreads);
		return taskExecutor;
	}

	@Bean
	public Job importBhrFileJob(JobCompletionNotificationListener listener, Step importBatchHeaderFileData) {

		// @formatter:off
		return jobBuilderFactory
				.get("importBatchHeaderFileJob")
				.incrementer(new RunIdIncrementer())
				.listener(listener)
				.flow(importBatchHeaderFileData)
				.end()
				.build();
		// @formatter:on
	}

	@SuppressWarnings("unchecked")
	@Bean
	public Step importBatchHeaderFileData() {
		// @formatter:off
		return stepBuilderFactory.get("importBatchHeaderFileData").<BatchRecord, BatchRecord>chunk(100)
				.reader(batchHeaderFileItemReader(null))
				.processor((ItemProcessor<? super BatchRecord, ? extends BatchRecord>) batchHeaderFileProcessor(
						batchHeaderFileDetailProcessor()))
				.writer((ItemWriter<? super BatchRecord>) batchHeaderFileWriter(batchHeaderFileStgWriter()))
				.transactionManager(transactionManager)
				.taskExecutor(taskExecutor())
				.throttleLimit(maxThreads)
				.build();
		// @formatter:on
	}

	@Bean
	@StepScope
	public FlatFileItemReader<BatchRecord> batchHeaderFileItemReader(
			@Value("#{jobParameters[fileName]}") String fileName) {
		FlatFileItemReader<BatchRecord> reader = new FlatFileItemReader<BatchRecord>();
		reader.setResource(new FileSystemResource(batchInputDir +File.separator+ fileName));
		reader.setLineMapper(batchHeaderLineMapper());
		return reader;
	}

	@Bean
	public LineMapper<BatchRecord> batchHeaderLineMapper() {
		PatternMatchingCompositeLineMapper<BatchRecord> mapper = new PatternMatchingCompositeLineMapper<>();
		Map<String, LineTokenizer> tokenizers = new HashMap<String, LineTokenizer>(10);
		tokenizers.put("*", (new FlightBatchHeaderStg()).lineTokenizer());
		mapper.setTokenizers(tokenizers);

		Map<String, FieldSetMapper<BatchRecord>> mappers = new HashMap<String, FieldSetMapper<BatchRecord>>();
		mappers.put("*", (new FlightBatchHeaderStg()).fieldSetMapper());
		BeanWrapperFieldSetMapper<BatchRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<>();
		fieldSetMapper.setTargetType(BatchRecord.class);
		mapper.setFieldSetMappers(mappers);
		return mapper;
	}

	@Bean
	public ItemWriter<? super BatchRecord> batchHeaderFileStgWriter() {
		return new FlightBatchHeaderStg().writer();
	}


	@SuppressWarnings("serial")
	@Bean
	public ClassifierCompositeItemWriter<? extends BatchRecord> batchHeaderFileWriter(
			ItemWriter<? super BatchRecord> batchHeaderFileStgWriter) {
		ClassifierCompositeItemWriter<BatchRecord> classifierCompositeItemWriter = new ClassifierCompositeItemWriter<>();
		classifierCompositeItemWriter.setClassifier(new Classifier<BatchRecord, ItemWriter<? super BatchRecord>>() {
			@Override
			public ItemWriter<? super BatchRecord> classify(BatchRecord classifiable) {
				if (classifiable instanceof FlightBatchHeaderStg) {
					 return batchHeaderFileStgWriter;
				} 
				return null;
			}

		});
		return classifierCompositeItemWriter;
	}

	@Bean
	@StepScope
	public ItemProcessor<? extends BatchRecord, ? extends BatchRecord> batchHeaderFileDetailProcessor() {
		return new FlightBatchHeaderStg().processor();
	}
	

	@Bean
	@StepScope
	public ClassifierCompositeItemProcessor<? extends BatchRecord, ? extends BatchRecord> batchHeaderFileProcessor(
			ItemProcessor<? extends BatchRecord, ? extends BatchRecord> batchHeaderFileDetailProcessor) {

		ClassifierCompositeItemProcessor<BatchRecord, BatchRecord> classifierCompositeItemProcessor = new ClassifierCompositeItemProcessor<>();
		classifierCompositeItemProcessor
				.setClassifier(new Classifier<BatchRecord, ItemProcessor<?, ? extends BatchRecord>>() {
					private static final long serialVersionUID = 1586908304088511090L;

					@Override
					public ItemProcessor<?, ? extends BatchRecord> classify(BatchRecord classifiable) {
						if (classifiable instanceof FlightBatchHeaderStg) {
							return batchHeaderFileDetailProcessor;
						} 
						return null;

					}

				});
		return classifierCompositeItemProcessor;

	}
}
