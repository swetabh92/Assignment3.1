package com.sgl.smartpra.batch.bsp.app.record;

import java.util.ArrayList;

import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;
import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;

public class BillingCycleHeader extends BSPBaseRecord {

	@Override
	public String getRecordType() {
		return BSPRecordType.BILLING_CYCLE_HEADER;
	}

	// Layout of BSP Billing Cycle Header Record
	class BillingCycleHeaderLayout extends FixedLengthRecordLayout {
		public BillingCycleHeaderLayout() {
			fixedLengthFieldLayoutList = new ArrayList<FixedLengthFieldLayout>();

			// entire line
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("line", 1, 136));

			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdMessageIdentifier", 1, 3));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("seqNumber", 4, 11));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdNumericQuaifier", 12, 13));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("processingDateIdentifier", 14, 16));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("processingCycleIdentifier", 17, 17));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("billingAnalysisEndingDate", 18, 23));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("dynamicRunIdentifier", 24, 24));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("hotReportingEndDate", 25, 30));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("filler2", 31, 136));
		}
	}

	@Override
	public LineTokenizer lineTokenizer(String handbookRevisionNumber) {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		BillingCycleHeaderLayout billingCycleHeaderLayout = new BillingCycleHeaderLayout();
		tokenizer.setColumns(billingCycleHeaderLayout.getColumns());
		tokenizer.setNames(billingCycleHeaderLayout.getNames());
		return tokenizer;
	}

	@Override
	public FieldSetMapper<BSPBaseRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<BSPBaseRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<BSPBaseRecord>();
		fieldSetMapper.setTargetType(this.getClass());
		return fieldSetMapper;
	}

	// variables to hold the record values
	private String stdMessageIdentifier;
	private String seqNumber;
	private String stdNumericQuaifier;
	private String processingDateIdentifier;
	private String processingCycleIdentifier;
	private String billingAnalysisEndingDate;
	private String dynamicRunIdentifier;
	private String hotReportingEndDate;
	private String filler2;

	public String getStdMessageIdentifier() {
		return stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getSeqNumber() {
		return seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdNumericQuaifier() {
		return stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getProcessingDateIdentifier() {
		return processingDateIdentifier;
	}

	public void setProcessingDateIdentifier(String processingDateIdentifier) {
		this.processingDateIdentifier = processingDateIdentifier;
	}

	public String getProcessingCycleIdentifier() {
		return processingCycleIdentifier;
	}

	public void setProcessingCycleIdentifier(String processingCycleIdentifier) {
		this.processingCycleIdentifier = processingCycleIdentifier;
	}

	public String getBillingAnalysisEndingDate() {
		return billingAnalysisEndingDate;
	}

	public void setBillingAnalysisEndingDate(String billingAnalysisEndingDate) {
		this.billingAnalysisEndingDate = billingAnalysisEndingDate;
	}

	public String getDynamicRunIdentifier() {
		return dynamicRunIdentifier;
	}

	public void setDynamicRunIdentifier(String dynamicRunIdentifier) {
		this.dynamicRunIdentifier = dynamicRunIdentifier;
	}

	public String getHotReportingEndDate() {
		return hotReportingEndDate;
	}

	public void setHotReportingEndDate(String hotReportingEndDate) {
		this.hotReportingEndDate = hotReportingEndDate;
	}

	public String getFiller2() {
		return filler2;
	}

	public void setFiller2(String filler2) {
		this.filler2 = filler2;
	}
}
