import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BookingClassMasterComponent } from './booking-class-master.component';

describe('BookingClassMasterComponent', () => {
  let component: BookingClassMasterComponent;
  let fixture: ComponentFixture<BookingClassMasterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BookingClassMasterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BookingClassMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
