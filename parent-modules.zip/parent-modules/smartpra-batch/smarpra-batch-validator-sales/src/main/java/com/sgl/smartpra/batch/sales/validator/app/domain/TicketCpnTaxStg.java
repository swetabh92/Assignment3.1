package com.sgl.smartpra.batch.sales.validator.app.domain;

import java.io.Serializable;
import javax.persistence.*;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.fasterxml.jackson.annotation.JsonIgnore;
/*import com.sgl.smartpra.batch.bsp.app.processor.TicketCouponStgProcessor;*/
/*import com.sgl.smartpra.batch.bsp.app.writer.TicketCouponStgWriter;
import com.sgl.smartpra.batch.bsp.app.writer.TicketCouponTaxStgWriter;*/

import java.sql.Timestamp;


/**
 * The persistent class for the ticket_cpn_tax_stg database table.
 * 
 */
@Entity
@Table(name="ticket_cpn_tax_stg")
public class TicketCpnTaxStg  implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="tkt_cpn_tax_dtl_id")
	private int tktCpnTaxDtlId;

	@Column(name="coupon_number")
	private String couponNumber;

	@Column(name="coupon_tax_airport_code")
	private String couponTaxAirportCode;

	@Column(name="coupon_tax_applicable_amount")
	private String couponTaxApplicableAmount;

	@Column(name="coupon_tax_code")
	private String couponTaxCode;

	@Column(name="coupon_tax_currency_type")
	private String couponTaxCurrencyType;

	@Column(name="coupon_tax_reported_amount")
	private String couponTaxReportedAmount;

	@Column(name="coupon_tax_type")
	private String couponTaxType;

	@Column(name="created_by")
	private String createdBy;

	@Column(name="created_date")
	private Timestamp createdDate;

	@Column(name="document_number")
	private String documentNumber;

	@Column(name="issue_airline")
	private String issueAirline;

	@Column(name="last_updated_by")
	private String lastUpdatedBy;

	@Column(name="last_updated_date")
	private Timestamp lastUpdatedDate;

	@Column(name="main_document")
	private String mainDocument;

	@Column(name="segment_tax_airport_code")
	private String segmentTaxAirportCode;

	//bi-directional many-to-one association to TicketMainStg
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="trn_tkt_id")
	private TicketMainStg ticketMainStg;

	public TicketCpnTaxStg() {
	}

	public int getTktCpnTaxDtlId() {
		return this.tktCpnTaxDtlId;
	}

	public void setTktCpnTaxDtlId(int tktCpnTaxDtlId) {
		this.tktCpnTaxDtlId = tktCpnTaxDtlId;
	}

	public String getCouponNumber() {
		return this.couponNumber;
	}

	public void setCouponNumber(String couponNumber) {
		this.couponNumber = couponNumber;
	}

	public String getCouponTaxAirportCode() {
		return this.couponTaxAirportCode;
	}

	public void setCouponTaxAirportCode(String couponTaxAirportCode) {
		this.couponTaxAirportCode = couponTaxAirportCode;
	}

	public String getCouponTaxApplicableAmount() {
		return this.couponTaxApplicableAmount;
	}

	public void setCouponTaxApplicableAmount(String couponTaxApplicableAmount) {
		this.couponTaxApplicableAmount = couponTaxApplicableAmount;
	}

	public String getCouponTaxCode() {
		return this.couponTaxCode;
	}

	public void setCouponTaxCode(String couponTaxCode) {
		this.couponTaxCode = couponTaxCode;
	}

	public String getCouponTaxCurrencyType() {
		return this.couponTaxCurrencyType;
	}

	public void setCouponTaxCurrencyType(String couponTaxCurrencyType) {
		this.couponTaxCurrencyType = couponTaxCurrencyType;
	}

	public String getCouponTaxReportedAmount() {
		return this.couponTaxReportedAmount;
	}

	public void setCouponTaxReportedAmount(String couponTaxReportedAmount) {
		this.couponTaxReportedAmount = couponTaxReportedAmount;
	}

	public String getCouponTaxType() {
		return this.couponTaxType;
	}

	public void setCouponTaxType(String couponTaxType) {
		this.couponTaxType = couponTaxType;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDocumentNumber() {
		return this.documentNumber;
	}

	public void setDocumentNumber(String documentNumber) {
		this.documentNumber = documentNumber;
	}

	public String getIssueAirline() {
		return this.issueAirline;
	}

	public void setIssueAirline(String issueAirline) {
		this.issueAirline = issueAirline;
	}

	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getLastUpdatedDate() {
		return this.lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getMainDocument() {
		return this.mainDocument;
	}

	public void setMainDocument(String mainDocument) {
		this.mainDocument = mainDocument;
	}

	public String getSegmentTaxAirportCode() {
		return this.segmentTaxAirportCode;
	}

	public void setSegmentTaxAirportCode(String segmentTaxAirportCode) {
		this.segmentTaxAirportCode = segmentTaxAirportCode;
	}

	public TicketMainStg getTicketMainStg() {
		return this.ticketMainStg;
	}

	public void setTicketMainStg(TicketMainStg ticketMainStg) {
		this.ticketMainStg = ticketMainStg;
	}

}