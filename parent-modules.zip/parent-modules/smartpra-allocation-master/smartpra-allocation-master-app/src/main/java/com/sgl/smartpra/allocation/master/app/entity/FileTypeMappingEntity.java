package com.sgl.smartpra.allocation.master.app.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@EqualsAndHashCode(callSuper = false)
@Data
@DynamicInsert
@DynamicUpdate
@Table(schema = "SmartPRAMaster", name = "filetype_mapping")

public class FileTypeMappingEntity extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "filetype_mapping")
	private Integer fileTypeMappingId;

	@NotNull
	@Column(name = "file_type_id")
	private Integer fileTypeId;

	@NotNull
	@Column(name = "module_lov_id")
	private Integer moduleLovId;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(insertable=false, updatable=false , name = "file_type_id")
    FileTypeEntity fileType;
		
	//@ManyToOne
	//@JoinColumn(insertable=false, updatable=false , name = "filetype_mapping_id",nullable=false)
    //private AllocationMasterEntity allocationMaster;

}
