package com.sgl.smartpra.batch.bsp.app.record;

import java.util.ArrayList;

import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;
import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;

public class RelatedTicketDocumentInfo extends BSPBaseRecord {

	@Override
	public String getRecordType() {
		return BSPRecordType.RELATED_TICKET_DOCUMENT_INFO;
	}

	// Layout of Related Ticket Document Info record
	class RelatedTicketDocumentInfoLayout extends FixedLengthRecordLayout {
		public RelatedTicketDocumentInfoLayout() {
			fixedLengthFieldLayoutList = new ArrayList<FixedLengthFieldLayout>();

			// entire line
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("line", 1, 136));

			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdMessageIdentifier", 1, 3));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("seqNumber", 4, 11));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdNumericQuaifier", 12, 13));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("dateOfIssue", 14, 19));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("transactionNumber", 20, 25));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("tktDocNumber", 26, 39));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("checkDigit", 40, 40));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("waiverCode", 41, 54));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("reasonForMemoIssuanceCode", 55, 59));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("relatedTktDocCpnIdentifier", 60, 63));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("dateOfIssueRelatedDocument", 64, 69));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("filler", 70, 136));
		}
	}

	@Override
	public LineTokenizer lineTokenizer(String handbookRevisionNumber) {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		RelatedTicketDocumentInfoLayout relatedTicketDocumentInfoLayout = new RelatedTicketDocumentInfoLayout();
		tokenizer.setColumns(relatedTicketDocumentInfoLayout.getColumns());
		tokenizer.setNames(relatedTicketDocumentInfoLayout.getNames());
		return tokenizer;
	}

	@Override
	public FieldSetMapper<BSPBaseRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<BSPBaseRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<BSPBaseRecord>();
		fieldSetMapper.setTargetType(this.getClass());
		return fieldSetMapper;
	}

	// Variables to hold record values
	private String stdMessageIdentifier;
	private String seqNumber;
	private String stdNumericQuaifier;
	private String dateOfIssue;
	private String transactionNumber;
	private String tktDocNumber;
	private String checkDigit;
	private String waiverCode;
	private String reasonForMemoIssuanceCode;
	private String relatedTktDocCpnIdentifier;
	private String dateOfIssueRelatedDocument;
	private String filler;

	public String getStdMessageIdentifier() {
		return stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getSeqNumber() {
		return seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdNumericQuaifier() {
		return stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getDateOfIssue() {
		return dateOfIssue;
	}

	public void setDateOfIssue(String dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}

	public String getTransactionNumber() {
		return transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

	public String getTktDocNumber() {
		return tktDocNumber;
	}

	public void setTktDocNumber(String tktDocNumber) {
		this.tktDocNumber = tktDocNumber;
	}

	public String getCheckDigit() {
		return checkDigit;
	}

	public void setCheckDigit(String checkDigit) {
		this.checkDigit = checkDigit;
	}

	public String getWaiverCode() {
		return waiverCode;
	}

	public void setWaiverCode(String waiverCode) {
		this.waiverCode = waiverCode;
	}

	public String getReasonForMemoIssuanceCode() {
		return reasonForMemoIssuanceCode;
	}

	public void setReasonForMemoIssuanceCode(String reasonForMemoIssuanceCode) {
		this.reasonForMemoIssuanceCode = reasonForMemoIssuanceCode;
	}

	public String getRelatedTktDocCpnIdentifier() {
		return relatedTktDocCpnIdentifier;
	}

	public void setRelatedTktDocCpnIdentifier(String relatedTktDocCpnIdentifier) {
		this.relatedTktDocCpnIdentifier = relatedTktDocCpnIdentifier;
	}

	public String getDateOfIssueRelatedDocument() {
		return dateOfIssueRelatedDocument;
	}

	public void setDateOfIssueRelatedDocument(String dateOfIssueRelatedDocument) {
		this.dateOfIssueRelatedDocument = dateOfIssueRelatedDocument;
	}

	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}
}