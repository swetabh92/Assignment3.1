package com.sgl.smartpra.batch.bsp.app.service;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BSPJobLauncher {

	@Autowired
	JobLauncher jobLauncher;

	@Autowired
	Job loadBSPFileDataToStagingJob;

	@Autowired
	Job loadBSPFromStagingToProdJob;

	public JobExecution launchBSPStagingLoadJob(String fileName, String user, String clientId)
			throws JobExecutionAlreadyRunningException, JobRestartException, JobInstanceAlreadyCompleteException,
			JobParametersInvalidException {

		// @formatter:off
		
		JobParameters jobParameters = new JobParametersBuilder()
				.addLong("time", System.currentTimeMillis())
				.addString("fileName", fileName)
				.addString("user", user)
				.addString("clientId", clientId)
				.toJobParameters();
		
		// @formatter:on

		return jobLauncher.run(loadBSPFileDataToStagingJob, jobParameters);
	}

	public void launchBSPProdLoadJob(Long fileId, String user) throws JobExecutionAlreadyRunningException,
			JobRestartException, JobInstanceAlreadyCompleteException, JobParametersInvalidException {

		// @formatter:off
		
		JobParameters jobParameters = new JobParametersBuilder()
				.addLong("time", System.currentTimeMillis())
				.addLong("fileId", fileId)
				.addString("user", user)
				.toJobParameters();
		
		// @formatter:on

		jobLauncher.run(loadBSPFromStagingToProdJob, jobParameters);
	}

}