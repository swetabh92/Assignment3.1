package com.sgl.smartpra.batch.global.app.mapper;

import java.util.List;

import org.mapstruct.Mapper;

import com.sgl.smartpra.batch.global.app.entity.InboundFileLogEntity;
import com.sgl.smartpra.batch.global.model.InboundFileLog;


@Mapper
public interface InboundFileLogMapper {

	InboundFileLog mapToInboundFileLogModel(InboundFileLogEntity inboundFileLogEntity);

	List<InboundFileLog> mapToInboundFileLogModelList(List<InboundFileLogEntity> inboundFileLogEntityList);

	InboundFileLogEntity mapToInboundFileLogEntity(InboundFileLog inboundFileLog);

	List<InboundFileLogEntity> mapToPOSEntityList(List<InboundFileLog> inboundFileLogList);
}
