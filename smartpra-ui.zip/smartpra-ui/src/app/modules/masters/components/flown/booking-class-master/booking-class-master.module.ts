import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BookingClassMasterRoutingModule } from './booking-class-master-routing.module';
import { BookingClassMasterComponent } from './booking-class-master.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { CoreDataModule } from 'src/app/core-data/core-data.module';

@NgModule({
  imports: [
    CommonModule,
    CoreDataModule,
    SharedModule,
    BookingClassMasterRoutingModule
  ],
  declarations: [
    BookingClassMasterComponent
  ]
})
export class BookingClassMasterModule { }
