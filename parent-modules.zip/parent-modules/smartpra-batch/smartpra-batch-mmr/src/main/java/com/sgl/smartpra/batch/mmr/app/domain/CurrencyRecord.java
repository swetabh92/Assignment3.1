package com.sgl.smartpra.batch.mmr.app.domain;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.LineTokenizer;


public abstract class CurrencyRecord {
	
	public abstract LineTokenizer lineTokenizer();

	public abstract FieldSetMapper<CurrencyRecord> fieldSetMapper();

	public abstract ItemProcessor<? extends CurrencyRecord, ? extends CurrencyRecord> processor();

	public abstract ItemWriter<? super CurrencyRecord> writer();

}
