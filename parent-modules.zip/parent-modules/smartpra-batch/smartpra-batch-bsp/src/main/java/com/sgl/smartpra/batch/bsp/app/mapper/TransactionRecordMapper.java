package com.sgl.smartpra.batch.bsp.app.mapper;

import java.util.ArrayList;

import com.sgl.smartpra.batch.bsp.app.domain.staging.AdditionalCardInfoStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.AdditionalItineraryDataStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.AddlInfoFormOfPaymentStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.AddlInfoPassengerStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.AddlTaxesInfoStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.CardAuthInfoStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.CommissionStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.CouponTaxInformationStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.DocumentAmountsStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.EMDCouponDetailStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.EMDRemarksStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.FareCalculationStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.FormOfPaymentStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.ItineraryDataSegmentStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.NettingValuesStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.QualIssueInfoStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.RelatedTicketDocumentInfoStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.StdDocumentAmountsStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TDSCardAuthInfoStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TaxOnCommissionStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TicketDocumentIdentificationStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TransactionHeaderStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TransactionRecordStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.UnticketedPointInfoStg;
import com.sgl.smartpra.batch.bsp.app.record.TransactionRecord;

public class TransactionRecordMapper {

	public static TransactionRecordStg mapTransactionRecord(TransactionRecord transactionRecord) {

		if (transactionRecord == null) {
			return null;
		}

		TransactionRecordStg transactionRecordStg = new TransactionRecordStg();

		mapTransactionHeader(transactionRecordStg, transactionRecord);
		mapDocumentIdentification(transactionRecordStg, transactionRecord);
		mapStdDocumentAmounts(transactionRecordStg, transactionRecord);
		mapCouponTaxInformation(transactionRecordStg, transactionRecord);
		mapCommission(transactionRecordStg, transactionRecord);
		mapTaxOnCommission(transactionRecordStg, transactionRecord);
		mapRelatedTicketDocumentInfo(transactionRecordStg, transactionRecord);
		mapQualIssueInfo(transactionRecordStg, transactionRecord);
		mapNettingValues(transactionRecordStg, transactionRecord);
		mapUnticketedPointInfo(transactionRecordStg, transactionRecord);
		mapAdditionalItineraryData(transactionRecordStg, transactionRecord);
		mapItineraryDataSegment(transactionRecordStg, transactionRecord);
		mapDocumentAmounts(transactionRecordStg, transactionRecord);
		mapAddlInfoPassenger(transactionRecordStg, transactionRecord);
		mapAddlInfoFormOfPayment(transactionRecordStg, transactionRecord);
		mapAddlTaxesInfo(transactionRecordStg, transactionRecord);
		mapEMDCouponDetail(transactionRecordStg, transactionRecord);
		mapEMDRemarks(transactionRecordStg, transactionRecord);
		mapFareCalculation(transactionRecordStg, transactionRecord);
		mapAdditionalCardInfo(transactionRecordStg, transactionRecord);
		mapCardAuthInfo(transactionRecordStg, transactionRecord);
		mapTDSCardAuthInfo(transactionRecordStg, transactionRecord);
		mapFormOfPayment(transactionRecordStg, transactionRecord);

		return transactionRecordStg;
	}

	private static void mapTransactionHeader(TransactionRecordStg transactionRecordStg,
			TransactionRecord transactionRecord) {

		// Transaction Header
		if (transactionRecord.getTransactionHeader() == null) {
			return;
		}

		TransactionHeaderStg transactionHeaderStg = BSPRecordMapper.INSTANCE
				.mapTransactionHeaderRecord(transactionRecord.getTransactionHeader());
		transactionRecordStg.setTransactionHeaderStg(transactionHeaderStg);

	}

	private static void mapDocumentIdentification(TransactionRecordStg transactionRecordStg,
			TransactionRecord transactionRecord) {
		// Ticket / Document Identification
		if (transactionRecord.getTicketDocumentIdentificationList() == null) {
			return;
		}

		ArrayList<TicketDocumentIdentificationStg> ticketDocumentIdentificationStgList = new ArrayList<TicketDocumentIdentificationStg>();
		transactionRecord.getTicketDocumentIdentificationList().forEach(item -> {
			TicketDocumentIdentificationStg ticketDocumentIdentificationStg = BSPRecordMapper.INSTANCE
					.mapTicketDocumentIdentificationRecord(item);
			ticketDocumentIdentificationStgList.add(ticketDocumentIdentificationStg);
		});

		if (ticketDocumentIdentificationStgList.size() > 0) {
			transactionRecordStg.setTicketDocumentIdentificationStgList(ticketDocumentIdentificationStgList);
		}
	}

	private static void mapStdDocumentAmounts(TransactionRecordStg transactionRecordStg,
			TransactionRecord transactionRecord) {
		// Standard Document Amounts
		if (transactionRecord.getStdDocumentAmountsList() == null) {
			return;
		}

		ArrayList<StdDocumentAmountsStg> stdDocumentAmountsStgList = new ArrayList<StdDocumentAmountsStg>();
		transactionRecord.getStdDocumentAmountsList().forEach(item -> {
			StdDocumentAmountsStg stdDocumentAmountsStg = BSPRecordMapper.INSTANCE.mapStdDocumentAmountsRecord(item);
			stdDocumentAmountsStgList.add(stdDocumentAmountsStg);
		});

		if (stdDocumentAmountsStgList.size() > 0) {
			transactionRecordStg.setStdDocumentAmountsStgList(stdDocumentAmountsStgList);
		}
	}

	private static void mapCouponTaxInformation(TransactionRecordStg transactionRecordStg,
			TransactionRecord transactionRecord) {
		// Coupon Tax Information
		if (transactionRecord.getCouponTaxInformationList() == null) {
			return;
		}

		ArrayList<CouponTaxInformationStg> couponTaxInformationStgList = new ArrayList<CouponTaxInformationStg>();

		if (transactionRecord.getCouponTaxInformationList() == null) {
			return;
		}

		transactionRecord.getCouponTaxInformationList().forEach(item -> {
			CouponTaxInformationStg couponTaxInformationStg = BSPRecordMapper.INSTANCE
					.mapCouponTaxInformationRecord(item);
			couponTaxInformationStgList.add(couponTaxInformationStg);
		});

		if (couponTaxInformationStgList.size() > 0) {
			transactionRecordStg.setCouponTaxInformationStgList(couponTaxInformationStgList);
		}
	}

	private static void mapCommission(TransactionRecordStg transactionRecordStg, TransactionRecord transactionRecord) {
		// Commission
		if (transactionRecord.getCommissionList() == null) {
			return;
		}

		ArrayList<CommissionStg> commissionStgList = new ArrayList<CommissionStg>();
		transactionRecord.getCommissionList().forEach(item -> {
			CommissionStg commissionStg = BSPRecordMapper.INSTANCE.mapCommissionRecord(item);
			commissionStgList.add(commissionStg);
		});

		if (commissionStgList.size() > 0) {
			transactionRecordStg.setCommissionStgList(commissionStgList);
		}
	}

	private static void mapTaxOnCommission(TransactionRecordStg transactionRecordStg,
			TransactionRecord transactionRecord) {
		// Tax On Commission
		if (transactionRecord.getTaxOnCommissionList() == null) {
			return;
		}

		ArrayList<TaxOnCommissionStg> taxOnCommissionStgList = new ArrayList<TaxOnCommissionStg>();
		transactionRecord.getTaxOnCommissionList().forEach(item -> {
			TaxOnCommissionStg taxOnCommissionStg = BSPRecordMapper.INSTANCE.mapTaxOnCommissionRecord(item);
			taxOnCommissionStgList.add(taxOnCommissionStg);
		});

		if (taxOnCommissionStgList.size() > 0) {
			transactionRecordStg.setTaxOnCommissionStgList(taxOnCommissionStgList);
		}
	}

	private static void mapRelatedTicketDocumentInfo(TransactionRecordStg transactionRecordStg,
			TransactionRecord transactionRecord) {

		// Related Ticket Document Info
		if (transactionRecord.getRelatedTicketDocumentInfoList() == null) {
			return;
		}

		ArrayList<RelatedTicketDocumentInfoStg> relatedTicketDocumentInfoStgList = new ArrayList<RelatedTicketDocumentInfoStg>();
		transactionRecord.getRelatedTicketDocumentInfoList().forEach(item -> {
			RelatedTicketDocumentInfoStg relatedTicketDocumentInfoStg = BSPRecordMapper.INSTANCE
					.mapRelatedTicketDocumentInfoRecord(item);
			relatedTicketDocumentInfoStgList.add(relatedTicketDocumentInfoStg);
		});

		if (relatedTicketDocumentInfoStgList.size() > 0) {
			transactionRecordStg.setRelatedTicketDocumentInfoStgList(relatedTicketDocumentInfoStgList);
		}
	}

	private static void mapQualIssueInfo(TransactionRecordStg transactionRecordStg,
			TransactionRecord transactionRecord) {
		// Qual Issue Info
		if (transactionRecord.getQualIssueInfoList() == null) {
			return;
		}

		ArrayList<QualIssueInfoStg> qualIssueInfoStgList = new ArrayList<QualIssueInfoStg>();
		transactionRecord.getQualIssueInfoList().forEach(item -> {
			QualIssueInfoStg qualIssueInfoStg = BSPRecordMapper.INSTANCE.mapQualIssueInfoRecord(item);
			qualIssueInfoStgList.add(qualIssueInfoStg);
		});

		if (qualIssueInfoStgList.size() > 0) {
			transactionRecordStg.setQualIssueInfoStgList(qualIssueInfoStgList);
		}
	}

	private static void mapNettingValues(TransactionRecordStg transactionRecordStg,
			TransactionRecord transactionRecord) {

		// Netting Values
		if (transactionRecord.getNettingValuesList() == null) {
			return;
		}

		ArrayList<NettingValuesStg> nettingValuesStgList = new ArrayList<NettingValuesStg>();
		transactionRecord.getNettingValuesList().forEach(item -> {
			NettingValuesStg nettingValuesStg = BSPRecordMapper.INSTANCE.mapNettingValuesRecord(item);
			nettingValuesStgList.add(nettingValuesStg);
		});

		if (nettingValuesStgList.size() > 0) {
			transactionRecordStg.setNettingValuesStgList(nettingValuesStgList);
		}

	}

	private static void mapUnticketedPointInfo(TransactionRecordStg transactionRecordStg,
			TransactionRecord transactionRecord) {

		// Un-ticketed Point Info
		if (transactionRecord.getUnticketedPointInfo() == null) {
			return;
		}

		ArrayList<UnticketedPointInfoStg> unticketedPointInfoStgList = new ArrayList<UnticketedPointInfoStg>();
		transactionRecord.getUnticketedPointInfo().forEach(item -> {
			UnticketedPointInfoStg unticketedPointInfoStg = BSPRecordMapper.INSTANCE.mapUnticketedPointInfoRecord(item);
			unticketedPointInfoStgList.add(unticketedPointInfoStg);
		});

		if (unticketedPointInfoStgList.size() > 0) {
			transactionRecordStg.setUnticketedPointStgInfo(unticketedPointInfoStgList);
		}
	}

	private static void mapAdditionalItineraryData(TransactionRecordStg transactionRecordStg,
			TransactionRecord transactionRecord) {
		// Additional Itinerary Data
		if (transactionRecord.getAdditionalItineraryDataList() == null) {
			return;
		}

		ArrayList<AdditionalItineraryDataStg> additionalItineraryDataStgList = new ArrayList<AdditionalItineraryDataStg>();
		transactionRecord.getAdditionalItineraryDataList().forEach(item -> {
			AdditionalItineraryDataStg additionalItineraryDataStg = BSPRecordMapper.INSTANCE
					.mapAdditionalItineraryDataRecord(item);
			additionalItineraryDataStgList.add(additionalItineraryDataStg);
		});

		if (additionalItineraryDataStgList.size() > 0) {
			transactionRecordStg.setAdditionalItineraryDataStgList(additionalItineraryDataStgList);
		}

	}

	private static void mapItineraryDataSegment(TransactionRecordStg transactionRecordStg,
			TransactionRecord transactionRecord) {
		// Itinerary Data Segment
		if (transactionRecord.getItineraryDataSegmentList() == null) {
			return;
		}

		ArrayList<ItineraryDataSegmentStg> itineraryDataSegmentStgList = new ArrayList<ItineraryDataSegmentStg>();
		transactionRecord.getItineraryDataSegmentList().forEach(item -> {
			ItineraryDataSegmentStg itineraryDataSegmentStg = BSPRecordMapper.INSTANCE
					.mapItineraryDataSegmentRecord(item);
			itineraryDataSegmentStgList.add(itineraryDataSegmentStg);
		});

		if (itineraryDataSegmentStgList.size() > 0) {
			transactionRecordStg.setItineraryDataSegmentStgList(itineraryDataSegmentStgList);
		}

	}

	private static void mapDocumentAmounts(TransactionRecordStg transactionRecordStg,
			TransactionRecord transactionRecord) {
		// Document Amounts
		if (transactionRecord.getDocumentAmounts() == null) {
			return;
		}

		DocumentAmountsStg documentAmountsStg = BSPRecordMapper.INSTANCE
				.mapDocumentAmountsRecord(transactionRecord.getDocumentAmounts());
		transactionRecordStg.setDocumentAmountsStg(documentAmountsStg);
	}

	private static void mapAddlInfoPassenger(TransactionRecordStg transactionRecordStg,
			TransactionRecord transactionRecord) {
		// Additional Info Passenger
		if (transactionRecord.getAddlInfoPassenger() == null) {
			return;
		}

		AddlInfoPassengerStg addlInfoPassengerStg = BSPRecordMapper.INSTANCE
				.mapAddlInfoPassengerRecord(transactionRecord.getAddlInfoPassenger());
		transactionRecordStg.setAddlInfoPassengerStg(addlInfoPassengerStg);
	}

	private static void mapAddlInfoFormOfPayment(TransactionRecordStg transactionRecordStg,
			TransactionRecord transactionRecord) {
		// Additional Info Form Of Payment
		if (transactionRecord.getAddlInfoFormOfPaymentList() == null) {
			return;
		}

		ArrayList<AddlInfoFormOfPaymentStg> addlInfoFormOfPaymentStgList = new ArrayList<AddlInfoFormOfPaymentStg>();
		transactionRecord.getAddlInfoFormOfPaymentList().forEach(item -> {
			AddlInfoFormOfPaymentStg addlInfoFormOfPaymentStg = BSPRecordMapper.INSTANCE
					.mapAddlInfoFormOfPaymentRecord(item);
			addlInfoFormOfPaymentStgList.add(addlInfoFormOfPaymentStg);
		});

		if (addlInfoFormOfPaymentStgList.size() > 0) {
			transactionRecordStg.setAddlInfoFormOfPaymentStgList(addlInfoFormOfPaymentStgList);
		}
	}

	private static void mapAddlTaxesInfo(TransactionRecordStg transactionRecordStg,
			TransactionRecord transactionRecord) {
		// Additional Taxes Info
		if (transactionRecord.getAddlTaxesInfoList() == null) {
			return;
		}

		ArrayList<AddlTaxesInfoStg> addlTaxesInfoStgList = new ArrayList<AddlTaxesInfoStg>();
		transactionRecord.getAddlTaxesInfoList().forEach(item -> {
			AddlTaxesInfoStg addlTaxesInfoStg = BSPRecordMapper.INSTANCE.mapAddlTaxesInfoRecord(item);
			addlTaxesInfoStgList.add(addlTaxesInfoStg);
		});

		if (addlTaxesInfoStgList.size() > 0) {
			transactionRecordStg.setAddlTaxesInfoStgList(addlTaxesInfoStgList);
		}
	}

	private static void mapEMDCouponDetail(TransactionRecordStg transactionRecordStg,
			TransactionRecord transactionRecord) {
		// EMD Coupon Detail
		if (transactionRecord.getEmdCouponDetailList() == null) {
			return;
		}

		ArrayList<EMDCouponDetailStg> emdCouponDetailStgList = new ArrayList<EMDCouponDetailStg>();
		transactionRecord.getEmdCouponDetailList().forEach(item -> {
			EMDCouponDetailStg emdCouponDetailStg = BSPRecordMapper.INSTANCE.mapEMDCouponDetailRecord(item);
			emdCouponDetailStgList.add(emdCouponDetailStg);
		});

		if (emdCouponDetailStgList.size() > 0) {
			transactionRecordStg.setEmdCouponDetailStgList(emdCouponDetailStgList);
		}
	}

	private static void mapEMDRemarks(TransactionRecordStg transactionRecordStg, TransactionRecord transactionRecord) {
		// EMD Remarks
		if (transactionRecord.getEmdRemarksList() == null) {
			return;
		}

		ArrayList<EMDRemarksStg> emdRemarksStgList = new ArrayList<EMDRemarksStg>();
		transactionRecord.getEmdRemarksList().forEach(item -> {
			EMDRemarksStg emdRemarksStg = BSPRecordMapper.INSTANCE.mapEMDRemarksRecord(item);
			emdRemarksStgList.add(emdRemarksStg);
		});

		if (emdRemarksStgList.size() > 0) {
			transactionRecordStg.setEmdRemarksStgList(emdRemarksStgList);
		}
	}

	private static void mapFareCalculation(TransactionRecordStg transactionRecordStg,
			TransactionRecord transactionRecord) {
		// Fare Calculation
		if (transactionRecord.getFareCalculationList() == null) {
			return;
		}

		ArrayList<FareCalculationStg> fareCalculationStgList = new ArrayList<FareCalculationStg>();
		transactionRecord.getFareCalculationList().forEach(item -> {
			FareCalculationStg fareCalculationStg = BSPRecordMapper.INSTANCE.mapFareCalculationRecord(item);
			fareCalculationStgList.add(fareCalculationStg);
		});

		if (fareCalculationStgList.size() > 0) {
			transactionRecordStg.setFareCalculationStgList(fareCalculationStgList);
		}
	}

	private static void mapAdditionalCardInfo(TransactionRecordStg transactionRecordStg,
			TransactionRecord transactionRecord) {
		// Additional Card Info
		if (transactionRecord.getAdditionalCardInfoList() == null) {
			return;
		}

		ArrayList<AdditionalCardInfoStg> additionalCardInfoStgList = new ArrayList<AdditionalCardInfoStg>();
		transactionRecord.getAdditionalCardInfoList().forEach(item -> {
			AdditionalCardInfoStg additionalCardInfoStg = BSPRecordMapper.INSTANCE.mapAdditionalCardInfoRecord(item);
			additionalCardInfoStgList.add(additionalCardInfoStg);
		});

		if (additionalCardInfoStgList.size() > 0) {
			transactionRecordStg.setAdditionalCardInfoStgList(additionalCardInfoStgList);
		}
	}

	private static void mapCardAuthInfo(TransactionRecordStg transactionRecordStg,
			TransactionRecord transactionRecord) {
		// Card Auth Info
		if (transactionRecord.getCardAuthInfoList() == null) {
			return;
		}

		ArrayList<CardAuthInfoStg> cardAuthInfoStgList = new ArrayList<CardAuthInfoStg>();
		transactionRecord.getCardAuthInfoList().forEach(item -> {
			CardAuthInfoStg cardAuthInfoStg = BSPRecordMapper.INSTANCE.mapCardAuthInfoRecord(item);
			cardAuthInfoStgList.add(cardAuthInfoStg);
		});

		if (cardAuthInfoStgList.size() > 0) {
			transactionRecordStg.setCardAuthInfoStgList(cardAuthInfoStgList);
		}
	}

	private static void mapTDSCardAuthInfo(TransactionRecordStg transactionRecordStg,
			TransactionRecord transactionRecord) {
		// TDS Card Auth Info
		if (transactionRecord.getTdsCardAuthInfoList() == null) {
			return;
		}

		ArrayList<TDSCardAuthInfoStg> tdsCardAuthInfoStgList = new ArrayList<TDSCardAuthInfoStg>();
		transactionRecord.getTdsCardAuthInfoList().forEach(item -> {
			TDSCardAuthInfoStg tdsCardAuthInfoStg = BSPRecordMapper.INSTANCE.mapTDSCardAuthInfoRecord(item);
			tdsCardAuthInfoStgList.add(tdsCardAuthInfoStg);
		});

		if (tdsCardAuthInfoStgList.size() > 0) {
			transactionRecordStg.setTdsCardAuthInfoStgList(tdsCardAuthInfoStgList);
		}
	}

	private static void mapFormOfPayment(TransactionRecordStg transactionRecordStg,
			TransactionRecord transactionRecord) {
		// Form Of Payment
		if (transactionRecord.getFormOfPaymentList() == null) {
			return;
		}

		ArrayList<FormOfPaymentStg> formOfPaymentStgList = new ArrayList<FormOfPaymentStg>();
		transactionRecord.getFormOfPaymentList().forEach(item -> {
			FormOfPaymentStg formOfPaymentStg = BSPRecordMapper.INSTANCE.mapFormOfPaymentRecord(item);
			formOfPaymentStgList.add(formOfPaymentStg);
		});

		if (formOfPaymentStgList.size() > 0) {
			transactionRecordStg.setFormOfPaymentStgList(formOfPaymentStgList);
		}
	}
}
