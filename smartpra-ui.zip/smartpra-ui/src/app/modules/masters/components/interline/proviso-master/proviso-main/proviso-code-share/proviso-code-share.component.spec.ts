import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProvisoCodeShareComponent } from './proviso-code-share.component';

describe('ProvisoCodeShareComponent', () => {
  let component: ProvisoCodeShareComponent;
  let fixture: ComponentFixture<ProvisoCodeShareComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProvisoCodeShareComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProvisoCodeShareComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
