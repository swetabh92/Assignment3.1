export const ExceptionConstant = {
  "TRANSFERRED": "TRANSFERRED",
  "ASSIGNED": "ASSIGNED",
  "WORK_IN_PROGRESS": "WORK_IN_PROGRESS",
  "RESOLVED": "RESOLVED",
  "CLOSED": "CLOSED",
  "MANUAL": "MANUAL",
  "SUCCESSCODE": 200,
  "SUCCESSCODENOCONTENT": 204,
  "PENDING_APPROVAL": "PENDING_APPROVAL",
  "RESOLUTION_DATE_TIME_FORMAT": "YYYY-MM-DDTHH:mm:ss",
  "SALE_PARAMS": ["moduleId", "moduleName", "exceptionSeverity", "fromDate", "toDate", "sortOrder", "exceptionStatus", "exceptionCode", "environment", "aging", "airlineType", "exceptionCategory", "exceptionType", "agencyCode", "batchType", "batchNumber", "reportingCurrency", "fromReportingPeriod", "toReporingPeriod","documentUniqueId"],
  "FLOWN_PARAMS": ["moduleId", "moduleName", "exceptionSeverity", "fromDate", "toDate", "sortOrder", "exceptionStatus", "exceptionCode", "environment", "aging", "airlineType", "exceptionCategory", "exceptionType", "flightNumber", "fromAirport", "toAirport", "upliftStation", "departureDate", "flightCreationDate"],
  "SALE": "SALE",
  "FLOWN": "FLOWN",
  "SIMPLE_DATE_FORMAT": "yyyy-MM-dd"
};


export const ExceptionScreenConstant = {
  "TICKET_CAPTURE_SCREEN": "ticketedit",

};


enum ExceptionStatusConstant {
}
