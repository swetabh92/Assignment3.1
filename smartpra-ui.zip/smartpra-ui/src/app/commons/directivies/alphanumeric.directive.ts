import { Directive,HostListener } from '@angular/core';
import { NgControl } from "@angular/forms";

@Directive({
  selector: '[appAlphanumeric]'
})
export class AlphanumericDirective {

  constructor(private control : NgControl) { }
    @HostListener('input', ['$event']) onKeyup(event: KeyboardEvent) {
      this.control.control.setValue((<HTMLInputElement>event.target).value.replace(/[^ a-zA-Z0-9]/g, ''));
    }
}
