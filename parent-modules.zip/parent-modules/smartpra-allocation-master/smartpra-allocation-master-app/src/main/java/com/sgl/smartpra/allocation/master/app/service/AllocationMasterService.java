package com.sgl.smartpra.allocation.master.app.service;

import java.util.List;

import com.sgl.smartpra.allocation.master.enums.ModuleNameEnum;
import com.sgl.smartpra.allocation.master.model.AllocationMaster;
import com.sgl.smartpra.allocation.master.model.AllocationMasterSearchModel;

public interface AllocationMasterService {

	<T extends AllocationMaster> AllocationMaster getPreloadByModule(ModuleNameEnum moduleName);

	void assignAllocation(AllocationMasterSearchModel allocationMasterSearchModel);

	void updateAllocationMaster(Integer allocationMasterId, AllocationMasterSearchModel allocationMasterSearchModel);

	List<AllocationMaster> getAllAllocationsByModule(ModuleNameEnum moduleName, Integer moduleLovId);

}
