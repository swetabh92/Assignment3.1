package com.sgl.smartpra.batch.interline.common;

import java.lang.reflect.Method;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import javax.validation.ConstraintViolation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.interline.configuration.FeignConfiguration.ExceptionTransIntgAppClient;
import com.sgl.smartpra.batch.interline.configuration.FeignConfiguration.SmartpraExceptionMasterApp;
import com.sgl.smartpra.batch.interline.configuration.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.exception.master.model.ExceptionMasterModel;
import com.sgl.smartpra.exception.master.model.ExceptionParametersDefinitionModel;
import com.sgl.smartpra.exception.txn.model.ExceptionParametersValueModel;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.interline.domain.entity.prod.form3.InterlineForm3Details;
import com.sgl.smartpra.interline.domain.entity.stg.form3.InterlineForm3CsvStg;
import com.sgl.smartpra.interline.domain.util.InterlineCommonConstants;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ExceptionServiceIntegration {

	private static final String GET = "get";

	private static final String ELEMENT_VALUE = "Element Value";

	private static final String REFERENCE = "reference";

	private static final String ELEMENT_NAME = "Element Name";

	@Autowired
	private SmartpraMasterAppClient smartpraMasterAppClient;
	
	@Autowired
	private ExceptionTransIntgAppClient exceptionTransIntgAppClient;

	@Autowired
	private SmartpraExceptionMasterApp smartpraExceptionMasterApp;

	public boolean postException(InterlineForm3Details interlineForm3Details,
			String exceptionCode) {
		List<ExceptionParametersValueModel> parametersValueList = getException(
				interlineForm3Details, null, exceptionCode);

		ExceptionTransactionModel exceptionTransactionModel = prepareExceptionTransactionModel(
				interlineForm3Details);
		exceptionTransactionModel.setParametersValueList(parametersValueList);
		exceptionTransactionModel.setExceptionCode(exceptionCode);
		log.info(exceptionTransactionModel.toString());
		exceptionTransIntgAppClient
				.initExceptionTrasaction(exceptionTransactionModel);
		return false;
	}
	public List<ExceptionParametersValueModel> getException(
			InterlineForm3Details interlineForm3Details,
			ConstraintViolation<InterlineForm3CsvStg> constraintViolation,
			String exceptionCode) {
		List<ExceptionParametersValueModel> parametersValueList = new ArrayList<>();
		ExceptionMasterModel exceptionMasterModel = smartpraExceptionMasterApp
				.findByExceptionCode(exceptionCode);
		List<ExceptionParametersDefinitionModel> definitionList = exceptionMasterModel
				.getParametersDefinitionList();
		definitionList.forEach(param -> {
			try {
				String paramName = param.getParameterName().get();
				Object paramValue = null;

				if (paramName.equals(ELEMENT_NAME)
						&& Objects.nonNull(constraintViolation)) {
					paramValue = constraintViolation.getPropertyPath();
					String paramValueStr = String.valueOf(paramValue);
					// Level 2 Validations
					if (Objects.nonNull(paramValue)
							&& paramValueStr.startsWith(REFERENCE)) {
						paramValue = paramValueStr.replace(REFERENCE, "");
					}
				} else if (paramName.equals(ELEMENT_VALUE)
						&& Objects.nonNull(constraintViolation)) {
					String paramValueStr = String
							.valueOf(constraintViolation.getPropertyPath());
					// Level 2 Validations
					if (Objects.nonNull(paramValueStr)
							&& paramValueStr.startsWith(REFERENCE)) {
						paramValueStr = paramValueStr.replace(REFERENCE, "");
					}
					paramValue = getFieldValue(interlineForm3Details,
							GET + paramValueStr, null);
				} else {
					paramValue = getFieldValue(interlineForm3Details,
							GET + paramName.replace(" ", ""), null);
				}
				parametersValueList.add(getExceptionParametersValue(paramName,
						String.valueOf(paramValue)));
			} catch (Exception e) {
				log.error(e.getMessage());
			}
		});
		return parametersValueList;
	}

	private ExceptionTransactionModel prepareExceptionTransactionModel(
			InterlineForm3Details interlineForm3Details) {
		String clientId = interlineForm3Details.getClientId();
		Long stagingReferenceId = Long
				.valueOf(interlineForm3Details.getInterlineForm3CsvId());
		long fileId = interlineForm3Details.getFileId().longValue();
		LocalDateTime outwardBillingPeriodsEndDate = null;
		try {
			Integer billingPeriod = interlineForm3Details.getBillingPeriod();
			Objects.requireNonNull(billingPeriod);
			Date date = smartpraMasterAppClient.getOutwardBillingPeriodsEndDate(
					interlineForm3Details.getBillingMonth(),
					billingPeriod);
			outwardBillingPeriodsEndDate = date.toInstant()
					.atZone(ZoneId.systemDefault()).toLocalDateTime();
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		String billingAirlineNumCode = interlineForm3Details.getBillingAirlineNumCode();
		String billedAirlineNumCode = interlineForm3Details.getBilledAirlineNumCode();
		ExceptionTransactionModel exceptionTransactionModel = getExceptionTransaction(
				clientId, stagingReferenceId, fileId,
				billingAirlineNumCode,
				billedAirlineNumCode, null, null,
				null,
				outwardBillingPeriodsEndDate);
		return exceptionTransactionModel;
	}

	public ExceptionTransactionModel getExceptionTransaction(String clientId,
			Long stagingReferenceId, long fileId, String billingCarrier,
			String billedCarrier, String sourceCode, String invoiceNo,
			LocalDateTime invoiceDate, LocalDateTime billingDate) {
		ExceptionTransactionModel exceptionTransactionModel = new ExceptionTransactionModel();
		exceptionTransactionModel.setClientId(clientId);
		exceptionTransactionModel.setEnvironment(InterlineCommonConstants.STAGING_ENVIRONMENT);
		exceptionTransactionModel.setExceptionDate(LocalDateTime.now());
		exceptionTransactionModel.setCreatedBy(InterlineCommonConstants.CREATED_BY);
		exceptionTransactionModel.setBatchKey1(billingCarrier);
		exceptionTransactionModel.setBatchKey2(billedCarrier);
		exceptionTransactionModel.setBatchKey3(sourceCode);
		exceptionTransactionModel.setBatchKey4(invoiceNo);
		exceptionTransactionModel.setBatchKey5(invoiceDate);
		exceptionTransactionModel.setBatchKey6(billingDate);
		exceptionTransactionModel.setFileId(fileId);
		exceptionTransactionModel.setStagingReferenceId(stagingReferenceId);
		return exceptionTransactionModel;
	}

	private ExceptionParametersValueModel getExceptionParametersValue(
			String parameterName, String parameterValue) {
		ExceptionParametersValueModel parametersValueModel = new ExceptionParametersValueModel();
		parametersValueModel.setParameterName(parameterName);
		parametersValueModel.setParameterValue(parameterValue);
		return parametersValueModel;
	}

	private static Object getFieldValue(Object object, String methodName,
			String[] params) throws Exception {
		Class<?> clazz = object.getClass();
		Method method = clazz.getDeclaredMethod(methodName);
		method.setAccessible(true);
		return method.invoke(object);
	}
}