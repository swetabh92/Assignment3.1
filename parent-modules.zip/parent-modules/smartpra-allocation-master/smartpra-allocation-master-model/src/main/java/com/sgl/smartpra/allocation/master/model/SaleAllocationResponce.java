package com.sgl.smartpra.allocation.master.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class SaleAllocationResponce extends AllocationMaster {

	private static final long serialVersionUID = 1L;

	private String stationName;

	private String fileType;

	private String exceptionCreatedFrom;

	private String exceptionCreatedTo;

	private String salesFromDate;

	private String salesToDate;

	private String utilizationFromDate;

	private String utilizationToDate;
}
