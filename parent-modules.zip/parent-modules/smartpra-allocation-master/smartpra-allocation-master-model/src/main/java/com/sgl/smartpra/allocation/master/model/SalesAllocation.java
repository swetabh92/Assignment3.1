package com.sgl.smartpra.allocation.master.model;

import java.time.LocalDate;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@JsonInclude(Include.NON_NULL)
public class SalesAllocation extends AllocationMaster {

	private static final long serialVersionUID = 7678044835909152120L;

	
	private String stationName;

	private List<String> fileType;

	private LocalDate exceptionCreatedFrom;

	private LocalDate exceptionCreatedTo;

	private LocalDate salesFromDate;

	private LocalDate salesToDate;

	private LocalDate utilizationFromDate;

	private LocalDate utilizationToDate;

}
