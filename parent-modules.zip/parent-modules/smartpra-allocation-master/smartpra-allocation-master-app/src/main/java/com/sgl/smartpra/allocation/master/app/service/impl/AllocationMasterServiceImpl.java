package com.sgl.smartpra.allocation.master.app.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.allocation.master.app.config.FeignConfiguration;
import com.sgl.smartpra.allocation.master.app.dao.AllocationMasterDao;
import com.sgl.smartpra.allocation.master.app.entity.AllocationMasterEntity;
import com.sgl.smartpra.allocation.master.app.mapper.AllocationMasterMapper;
import com.sgl.smartpra.allocation.master.app.mapper.FlownAllocationMapper;
import com.sgl.smartpra.allocation.master.app.mapper.InwardAllocationMapper;
import com.sgl.smartpra.allocation.master.app.mapper.OutwardAllocationMapper;
import com.sgl.smartpra.allocation.master.app.mapper.SalesAllocationMapper;
import com.sgl.smartpra.allocation.master.app.service.AllocationMasterService;
import com.sgl.smartpra.allocation.master.app.service.FileTypeMappingService;
import com.sgl.smartpra.allocation.master.app.util.AllocationMasterUtil;
import com.sgl.smartpra.allocation.master.enums.ModuleNameEnum;
import com.sgl.smartpra.allocation.master.model.AllocationMaster;
import com.sgl.smartpra.allocation.master.model.AllocationMasterSearchModel;
import com.sgl.smartpra.allocation.master.model.FileType;
import com.sgl.smartpra.allocation.master.model.FlownAllocation;
import com.sgl.smartpra.allocation.master.model.InwardAllocation;
import com.sgl.smartpra.allocation.master.model.SaleAllocationResponce;
import com.sgl.smartpra.allocation.master.model.SalesAllocation;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.global.master.model.CommonIdName;
import com.sgl.smartpra.master.model.ListOfValues;
import com.sgl.smartpra.master.model.RouteCode;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AllocationMasterServiceImpl implements AllocationMasterService {

	@Autowired
	private FeignConfiguration.SmartpraMasterAppClient smartpraMasterAppClient;

	@Autowired
	private FeignConfiguration.GlobalMasterFeignClient globalMasterFeignClient;

	@Autowired
	private FileTypeMappingService fileTypeMappingService;

	@Autowired
	private SalesAllocationMapper salesAllocationMapper;

	@Autowired
	private FlownAllocationMapper flownAllocationMapper;

	@Autowired
	private InwardAllocationMapper inwardAllocationMapper;

	@Autowired
	private OutwardAllocationMapper outwardAllocationMapper;

	@Autowired
	private AllocationMasterDao allocationMasterDao;

	@Autowired
	private AllocationMasterUtil allocationMasterUtil;

	@Autowired
	private AllocationMasterMapper allocationMasterMapper;

	private static final String CLIENTID = "QR";

	private static final String TABLE_NAME = "flight_data_details";

	private static final String TABLE_NAME_GENERAL = "general";

	private static final String COLUMN_NAME_FLIGHT_STATUS = "flight_status";

	private static final String COLUMN_NAME_FLIGHT_CATEGORY = "service_type";

	private static final String COLUMN_NAME_GENERAL = "module";

	private static final String COLUMN_NAME_ZONE = "zone";

	public <T extends AllocationMaster> AllocationMaster getPreloadByModule(ModuleNameEnum moduleName) {

		switch (moduleName) {

			case FLOWN:
				FlownAllocation flownAllocation = new FlownAllocation();

				flownAllocation.setFlightStatus(
						allocationMasterUtil.getListOfValuesList(CLIENTID, TABLE_NAME, COLUMN_NAME_FLIGHT_STATUS));

				flownAllocation.setFlightCategory(
						allocationMasterUtil.getListOfValuesList(CLIENTID, TABLE_NAME, COLUMN_NAME_FLIGHT_CATEGORY));

				flownAllocation.setRouteCode(smartpraMasterAppClient.getAllRouteCode().stream().map(RouteCode::getRouteCode)
						.collect(Collectors.toList()));

				return flownAllocation;

			case SALE:
				SalesAllocation salesAllocation = new SalesAllocation();

				salesAllocation.setFileType(fileTypeMappingService.findAllFileType().stream().map(FileType::getFileTypeName)
						.collect(Collectors.toList()));

				return salesAllocation;

			case INWARD:
				InwardAllocation inwardAllocation = new InwardAllocation();

				List<String> sourceCodeList = new ArrayList<>();

				List<String> currencyList = globalMasterFeignClient.getCurrencyList().stream().map(CommonIdName::getName)
						.collect(Collectors.toList());

				List<String> carrierList = globalMasterFeignClient.getCarrierList().stream().map(CommonIdName::getName)
						.collect(Collectors.toList());

				smartpraMasterAppClient.getAllSourceCode(CLIENTID)
						.forEach(sourceCode -> sourceCodeList.add(OptionalUtil.getValue(sourceCode.getSourceCode())));

				inwardAllocation.setZones(allocationMasterUtil.getListOfValuesList(CLIENTID, TABLE_NAME, COLUMN_NAME_ZONE));
				inwardAllocation.setBillingCurrency(currencyList);
				inwardAllocation.setListingCurrency(currencyList);
				inwardAllocation.setBillingCarrier(carrierList);
				inwardAllocation.setAllianceName(carrierList);
				inwardAllocation.setSourceCode(sourceCodeList);

				return inwardAllocation;

			default:
				break;
		}

		return null;
	}

	public void assignAllocation(AllocationMasterSearchModel allocationMasterSearchModel) {

		switch (allocationMasterSearchModel.getModuleName()) {
			case SALE:

				allocationMasterDao.save(salesAllocationMapper.mapToEntity(allocationMasterSearchModel));

				break;
			case FLOWN:

				allocationMasterDao.save(flownAllocationMapper.mapToEntity(allocationMasterSearchModel));

				break;
			case INWARD:

				allocationMasterDao.save(inwardAllocationMapper.mapToEntity(allocationMasterSearchModel));

				break;
			case OUTWARD:

				allocationMasterDao.save(outwardAllocationMapper.mapToEntity(allocationMasterSearchModel));

				break;

			default:
				break;
		}
	}

	@Override
	public void updateAllocationMaster(Integer allocationMasterId,
									   AllocationMasterSearchModel allocationMasterSearchModel) {

		AllocationMasterEntity allocationMasterEntity = allocationMasterDao.findById(allocationMasterId);

		switch (allocationMasterSearchModel.getModuleName()) {
			case SALE:

				allocationMasterDao
						.save(salesAllocationMapper.mapToEntity(allocationMasterSearchModel, allocationMasterEntity));

				break;
			case FLOWN:

				allocationMasterDao
						.save(flownAllocationMapper.mapToEntity(allocationMasterSearchModel, allocationMasterEntity));

				break;
			case INWARD:

				allocationMasterDao
						.save(inwardAllocationMapper.mapToEntity(allocationMasterSearchModel, allocationMasterEntity));

				break;
			case OUTWARD:

				allocationMasterDao
						.save(outwardAllocationMapper.mapToEntity(allocationMasterSearchModel, allocationMasterEntity));

				break;

			default:
				break;
		}

	}

	@Override
	public List<AllocationMaster> getAllAllocationsByModule(ModuleNameEnum moduleName,Integer moduleLovId) {

		List<AllocationMasterEntity> allocationMasterEntityList = allocationMasterDao.findByModuleLovId(moduleLovId);

		switch (moduleName) {
			case SALE:
				SaleAllocationResponce saleAllocationResponce = new SaleAllocationResponce();

				List<AllocationMaster> saleResponce = new ArrayList<>();

				for (AllocationMasterEntity allocationMasterEntity : allocationMasterEntityList) {

					saleResponce.add(allocationMasterMapper.mapToSaleModel(allocationMasterEntity, saleAllocationResponce));
				}

				return saleResponce;

			default:
				break;
		}

		return allocationMasterMapper.mapToModel(allocationMasterDao.findByModuleLovId(moduleLovId));
	}

}