package com.sgl.smartpra.allocation.master.model;

import java.time.LocalDate;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.sgl.smartpra.allocation.master.enums.ModuleNameEnum;
import com.sgl.smartpra.common.model.BaseModel;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class AllocationMasterSearchModel extends BaseModel {

	private static final long serialVersionUID = 1L;

	private Integer allocationMasterId;

	@NotNull
	@Valid
	private ModuleNameEnum moduleName;

	@NotNull
	private Long groupId;

	@NotNull
	private Long teamId;

	@NotNull
	private String clientId;

	@NotNull
	private Long moduleLovId;

	// ------------------------FLOWN-----------------------------

	private String flightStatus;

	private String flightCategory;

	private String oal;

	private String routeCode;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate flightFromDate;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate flightToDate;

	// ------------------------SALES------------------------------

	private String stationName;

	private String fileType;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate exceptionCreatedFrom;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate exceptionCreatedTo;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate salesFromDate;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate salesToDate;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate utilizationFromDate;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate utilizationToDate;

	// ------------------------INWARD------------------------------

	private String billingMonth;

	private String billingCurrency;

	private String sourceCode;

	private String listingCurrency;

	private String zones;

	private String billedCarrier;

	private String allianceName;

}
