import {Component, Input, OnInit, ViewChild} from '@angular/core';
import {DatatableComponent} from '@swimlane/ngx-datatable';
import {GeneralService} from '../../../../commons/services/general.service';

@Component({
  selector: 'app-sale-erroneous',
  templateUrl: './sale-erroneous.component.html',
  styleUrls: ['./sale-erroneous.component.css']
})
export class SaleErroneousComponent implements OnInit {

  currentSort1:any = [{ prop: "", dir: 'asc'}];
  @ViewChild('sortTable') sortTable: DatatableComponent;

  constructor(private gService:GeneralService) { }


  saleStagingData =[{"name":"SALE","key":"sale"},{"name":"REFUND","key":"refund"},{"name":"EXCHANGE","key":"exchange"},{"name":"ADM","key":"adm"},{"name":"ACM","key":"acm"}];
  ngOnInit() {
  }



  @Input() fileSaleErroneousDetails;
  @Input() page;


  onCustomSort(sortCol: string) {
    let sortDir = 'asc';
    if(this.currentSort1[0].prop === sortCol) sortDir = this.currentSort1[0].dir === 'asc'?'desc':'asc';
    this.currentSort1 = [{ prop: sortCol, dir: sortDir }];
    this.sortTable.onColumnSort({ sorts: this.currentSort1});
  }

}
