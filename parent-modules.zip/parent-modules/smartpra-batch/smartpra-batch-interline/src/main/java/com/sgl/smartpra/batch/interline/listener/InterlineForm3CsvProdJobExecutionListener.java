package com.sgl.smartpra.batch.interline.listener;

import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;

import lombok.extern.slf4j.Slf4j;
@Slf4j
public class InterlineForm3CsvProdJobExecutionListener implements JobExecutionListener{

	@Override
	public void beforeJob(JobExecution jobExecution) {
		log.info("beforeJob");		
	}

	@Override
	public void afterJob(JobExecution jobExecution) {
		log.info("afterJob");		
	}

}
