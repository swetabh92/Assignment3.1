export class Team {
  clientId: number;
  isActive: true;
  groupId: number;
  teamId: number;
  teamManagerId: number;
  teamName: string;
      constructor() { }
    }
