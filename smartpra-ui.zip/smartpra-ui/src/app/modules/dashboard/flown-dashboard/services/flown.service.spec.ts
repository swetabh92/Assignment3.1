import { TestBed } from '@angular/core/testing';

import { FlownService } from './flown.service';

describe('FlownSearchService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: FlownService = TestBed.get(FlownService);
    expect(service).toBeTruthy();
  });
});
