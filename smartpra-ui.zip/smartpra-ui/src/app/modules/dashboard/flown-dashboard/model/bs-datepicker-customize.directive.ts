import { Directive,ElementRef,AfterViewInit,HostListener} from '@angular/core';
import { DateFormatService} from "../../../../commons/services/date-format/date-format.service"
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';

@Directive({
  selector: '[bsDatepicker]'
})
export class BsDatepickerCustomizeDirective implements AfterViewInit{
  dateFormat = this.dateFormatService.getDateFormat();
 constructor(private _BsDatepickerConfig:BsDatepickerConfig,private dateFormatService:DateFormatService,private el: ElementRef) {
  this._BsDatepickerConfig.dateInputFormat = this.dateFormat;
  }
  ngAfterViewInit() {
        if(!this.el.nativeElement.hasAttribute("placeholder")) this.el.nativeElement.setAttribute("placeholder",this.dateFormat);
  }

}
