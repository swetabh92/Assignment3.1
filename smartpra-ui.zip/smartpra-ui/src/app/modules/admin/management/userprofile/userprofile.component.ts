import { Component, OnInit, Input, Output, EventEmitter, OnDestroy, ElementRef, ViewChild, Renderer2 } from '@angular/core';
import { FormBuilder, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { GeneralService } from '../../../../commons/services/general.service';
import { AuthenticationService } from '../../../../core/authentication/auth-gaurd-service/_services/authentication.service';
import { UserprofileService } from '../../services/userprofile.service';
import { CountryMasterService } from '../../../masters/services/others/country-master/country-master.service';
import { CarrierMasterService } from '../../../masters/services/others/carrier-master/carrier-master.service';
import { Userprofile } from '../../models/userprofile';
import { RoleprofileService } from '../../services/roleprofile.service';
import { TeamService } from '../../services/team.service';
import { GroupService } from '../../services/group.service';
import { MediaService } from '../../services/media.service';
import { Subject } from 'rxjs';
import swal from 'sweetalert2';
import { DatepickerOptions } from 'ng2-datepicker';
import { DatePipe } from '@angular/common';
import { MessageBoxService } from '../../../masters/services/commons/message-box.service';
import * as _ from 'underscore';
import { AmazingTimePickerService } from 'amazing-time-picker';
import {CommonService} from "../../../masters/services/commons/common.service";
declare var moment: any;


@Component({
  selector: 'app-userprofile',
  templateUrl: './userprofile.component.html',
  styleUrls: ['./userprofile.component.css']
})
export class UserprofileComponent implements OnInit, OnDestroy {
  @ViewChild('closeModalAdd') closeModalAdd: ElementRef;
  @ViewChild('closeModalEdit') closeModalEdit: ElementRef;
  @ViewChild('closeModalRole') closeModalRole: ElementRef;
  @ViewChild('closeModalTeam') closeModalTeam: ElementRef;
  dtOptions: any = {};
  @ViewChild('closeModalGroup') closeModalGroup: ElementRef;
  // We use this trigger because fetching the list of persons can be quite long,
  // thus we ensure the data is fetched before rendering
  dtTrigger: Subject<any> = new Subject<any>();
  public renderDT = false;
  createdBy = 'admin';
  lastUpdatedBy = 'admin';
  resetPasswordValue: any;
  collapse_search_form = true;
  box_search_status = true;
  addNewForm: FormGroup;
  addNewsubmitted = false;
  editNewForm: FormGroup;
  editsubmitted = false;
  searchForm: FormGroup;
  searchsubmitted = false;
  searchresult = false;
  searchstring = '';
  usersImportForm: FormGroup;
  usersImportsubmitted = false;
  checkdata: any;
  usersList$: any;
  userdetail: any;
  previewUrl = '';
  selectedFiles: any;
  selectedvoiceFiles: FileList;
  countryArray: any = [];
  countryOptions: any = [];
  stateArray: any = [];
  stateOptions: any = [];
  cityArray: any = [];
  cityOptions: any = [];
  langKeyArray: any = [];
  langKeyOptions: any = [];
  preferredLanguageArray: any = [];
  preferredLanguageOptions: any = [];
  isactiveArray: any = [];
  isactiveOptions: any = [];
  airLineCodeArray: any = [];
  airLineCodeOptions: any = [];
  groupArray: any = [];
  groupOptions: any = [];
  managerArray: any = [];
  managerOptions: any = [];
  moduleArray: any = [];
  moduleOptions: any = [];
  teamArray: any = [];
  teamOptions: any = [];
  roleArray: any = [];
  roleOptions: any = [];
  availableUserRoles = [];
  assignedUserRoles: any;
  tempAvailableRoles = [];
  tempAssignedRoles = [];
  currentUser: any;
  availableTeams = [];
  allTeams = [];
  assignedTeams: any;
  tempAvailableTeams = [];
  tempAssignedTeams = [];
  currentTeam: any;
  // Group variables
  availableGroups = [];
  allGroups = [];
  assignedGroups: any;
  tempAvailableGroups = [];
  tempAssignedGroups = [];
  currentGroup: any;

  dayPickerConfig : DatepickerOptions = {
    displayFormat: 'hh:mm',
    // @ts-ignore
    format: 'hh:mm',
    useEmptyBarTitle: false,
    // addClass: 'date-picker',
    // fieldId: 'picker-id',
    addStyle: {'width': '100%'},
    maxDate: new Date(Date.now()),
  };
  dateOptions: DatepickerOptions = {
    displayFormat: 'MM/DD/YYYY',
    useEmptyBarTitle: false,
    maxDate: new Date(Date.now()),
    // addClass: 'date-picker',
    // fieldId: 'picker-id',
    addStyle: {'width': '100%'},
  };
  constructor(private activatedRoute: ActivatedRoute,
    private mediaService: MediaService,
    private formBuilder: FormBuilder,
    private generalService: GeneralService,
    private authenticationService: AuthenticationService,
    private userservice: UserprofileService,
    private roleprofileservice: RoleprofileService,
    private render: Renderer2,
    private teamservice: TeamService,
    private groupservice: GroupService,
    private countryservice: CountryMasterService,
    private carrierservice: CarrierMasterService,
    private messageBoxService: MessageBoxService,
    private atp: AmazingTimePickerService,
    private commonService : CommonService
  ) { }

  ngOnInit() {
    this.GetAllCountries();
    this.getAllStateList();
    this.GetAllCities();
    this.GetAllRoles();
    this.GetAllTeam();
    this.GetAllGroup();
    this.GetAllManager();
    this.GetAllairLineCode();
    this.langKeyArray = [{ id: 'en', name: 'English' }];
    this.preferredLanguageArray = [{ id: 'en', name: 'English' }];
    this.isactiveArray = [{ id: '1', name: 'active' }, { id: '0', name: 'inactive' }];
    this.dtOptions = {
      searching: false, // to hide the search field in the data table top
      pagingType: 'full_numbers',
      lengthMenu: [[5, 10, 25, 50, -1], [5, 10, 25, 50, 'All']], // used to display records size( no of rows)
      language: {
        lengthMenu: 'Page size _MENU_',
        paginate: {
          next: '<i style="color:#0079c1" class="fa fa-angle-right fa-lg"></i>',
          previous: '<i style="color:#0079c1" class="fa fa-angle-left fa-lg"></i>',
          first: '<i style="color:#0079c1" class="fa fa-step-backward"></i>',
          last: '<i style="color:#0079c1" class="fa fa-step-forward"></i>'
        }
      },
      dom: 'tflrp<"datatableclass"i>',
      columnDefs: [
        {
          'searchable': false,
          'orderable': false,
          'targets': [-1, -2]
        }
      ],
      // end of disable search and order
    };
    this.GetAllUsers();
    this.usersImportForm = this.formBuilder.group({
      file: ['', Validators.required],
    });
    this.addNewForm = this.formBuilder.group({
      email: [
        '',
        [Validators.required, Validators.email],
        this.validateEmailNotTaken.bind(this)
      ],
      categoryLevel: ['', Validators.required],
      airLineCode: ['', Validators.required],
      departmentName:  ['', Validators.required],
      organizationName:  ['', Validators.required],
      createdBy:  ['admin'],
      displayName:  ['', Validators.required],
      firstName:  ['', Validators.required],
      instantOfJoining: [''], // ['', Validators.required],
      // isActive: [''], // ['', Validators.required],
      langKey:  ['', Validators.required],
      lastName: [''], // ['', Validators.required],
      masUsersId: [''], // ['', Validators.required],
      middleName: [''], // ['', Validators.required],
      preferredLanguage: ['', Validators.required],
      processName: [''], // ['', Validators.required],
      shiftEndTime: [''], // ['', Validators.required],
      shiftStartTime: [''], // ['', Validators.required],
      userAddress1:  ['', Validators.required],
      userAddress2: [''], // ['', Validators.required],
      userAddress3: [''], // ['', Validators.required],
      userEmail: [''], // ['', Validators.required],
      userFullName: [''], // ['', Validators.required],
      userGroupId: [''], // ['', Validators.required],
      userManagerId: [''], // ['', Validators.required],
      // userModuleId: [''], // ['', Validators.required],
      userName: [''], // ['', Validators.required],
      userPhoto: [''], // ['', Validators.required],
      userRemarks: [''], // ['', Validators.required],
      userRoleId: [''], // ['', Validators.required],
      userTeamId: [''], // ['', Validators.required],
      userTelephone: ['', [Validators.maxLength(10), Validators.minLength(10)]], // ['', Validators.required],
      passwordHash: [''], // ['', Validators.required],
      // voiceProfile: [''], // ['', Validators.required],
    });
    this.editNewForm = this.formBuilder.group({
      categoryLevel: [''], // ['', Validators.required],
      airLineCode: [''], // ['', Validators.required],
      departmentName: [''], // ['', Validators.required],
      organizationName: [''], // ['', Validators.required],
      displayName: [''], // ['', Validators.required],
      email: [''], // ['', Validators.required],
      firstName: [''], // ['', Validators.required],
      instantOfJoining: [''], // ['', Validators.required],
      // isActive: [''], // ['', Validators.required],
      langKey: [''], // ['', Validators.required],
      lastName: [''], // ['', Validators.required],
      masUsersId: [''], // ['', Validators.required],
      middleName: [''], // ['', Validators.required],
      preferredLanguage: [''], // ['', Validators.required],
      processName: [''], // ['', Validators.required],
      shiftEndTime: [''], // ['', Validators.required],
      shiftStartTime: [''], // ['', Validators.required],
      userAddress1: [''], // ['', Validators.required],
      userAddress2: [''], // ['', Validators.required],
      userAddress3: [''], // ['', Validators.required],
      userEmail: [''], // ['', Validators.required],
      userFullName: [''], // ['', Validators.required],
      userGroupId: [''], // ['', Validators.required],
      userManagerId: [''], // ['', Validators.required],
      // userModuleId: [''], // ['', Validators.required],
      userName: [''], // ['', Validators.required],
      userPhoto: [''], // ['', Validators.required],
      userRemarks: [''], // ['', Validators.required],
      userRoleId: [''], // ['', Validators.required],
      roleId: [''], // ['', Validators.required],
      userTeamId: [''], // ['', Validators.required],
      userTelephone: [''], // ['', Validators.required],
      // voiceProfile: [''], // ['', Validators.required],
      lastUpdatedBy: [''], // ['', Validators.required],
      passwordHash: [''], // ['', Validators.required],
    });
    this.searchForm = this.formBuilder.group({
      email: ['', ],
      firstName: ['', ],
      lastName: ['', ],
      userName: ['', ],
    });
  }
  splitDate(date: any) {
    if (date instanceof Date) {
      const datePipe = new DatePipe('en-US');
      return datePipe.transform(date, 'yyyy-MM-dd');
    } else {
      return date.split('T')[0];
    }
  }
  validateEmailNotTaken(control: AbstractControl) {
    console.log(control.value);
    return this.userservice.checkEmailNotTaken3(control.value).map(res => {
      return res ? null : { emailTaken: true };
    });
  }
  open() {
    const amazingTimePicker = this.atp.open();
    amazingTimePicker.afterClose().subscribe(time => {
      console.log(time);
    });
  }
  GetAllRoles(): void {
    this.roleprofileservice.getRoleprofileAll().subscribe((res: any[]) => {
      this.roleArray = res;
      this.availableUserRoles = res;
    });
  }
  GetAllairLineCode(): void {
    this.carrierservice.getAllCarrierList().subscribe((res: any[]) => {
      this.airLineCodeArray = res;
    });
  }
  onSelectUserRole(userRoles) {
    this.currentUser = userRoles;
    this.findAssignedRoles(userRoles.masUserRoles, this.availableUserRoles);
  }

  findAssignedRoles(assignedUserRole, availableUserRoles) {
    const assignedRoles = [];
    _.each(assignedUserRole, function (data: any) { assignedRoles.push(_.findWhere(availableUserRoles, { 'roleId': data.masRoleId })); });
    this.assignedUserRoles = assignedRoles;
    this.availableUserRoles = this.availableUserRoles.filter(item => !this.assignedUserRoles.includes(item));
  }

  onSelectAvailableRoles(event, data) {
    // AV -> Available Roles

    const className = event.currentTarget.className;

    if (className.includes('active')) {
      event.currentTarget.classList.remove('active');
      this.filterRolesByRoleType(data, 'AV');
    } else {
      this.render.addClass(event.target, 'active');
      this.tempAvailableRoles.push(data);
    }
  }
  onSelectAssignedRoles(event, data) {

    const className = event.currentTarget.className;

    // AS -> Assigned Roles
    if (className.includes('active')) {
      event.currentTarget.classList.remove('active');
      this.filterRolesByRoleType(data, 'AS');
    } else {
      this.render.addClass(event.target, 'active');
      this.tempAssignedRoles.push(data);
    }
  }
  filterRolesByRoleType(data, arrayType) {
    if (arrayType === 'AS') {
      const index = this.tempAssignedRoles.indexOf(data);
      if (index > -1) {
        this.tempAssignedRoles.splice(index, 1);
      }
    } else {
      const index = this.tempAvailableRoles.indexOf(data);
      if (index > -1) {
        this.tempAvailableRoles.splice(index, 1);
      }
    }
  }

  updateAssignedRoles() {
    for (let i = 0; i < this.tempAssignedRoles.length; i++) {
      this.availableUserRoles.push(this.tempAssignedRoles[i]);
    }
    this.assignedUserRoles = this.assignedUserRoles.filter(val => !this.tempAssignedRoles.includes(val));
    this.tempAssignedRoles = [];
    this.updateUserRoleRequest();
  }

  updateAvailableRoles() {
    for (let i = 0; i < this.tempAvailableRoles.length; i++) {
      this.assignedUserRoles.push(this.tempAvailableRoles[i]);
    }
    this.availableUserRoles = this.availableUserRoles.filter(val => !this.tempAvailableRoles.includes(val));
    this.tempAvailableRoles = [];
    this.updateUserRoleRequest();

  }

  updateUserRoleRequest() {
    this.assignedUserRoles = _.each(this.assignedUserRoles, function (data: any) { data.masRoleId = data.roleId; });
    this.currentUser.masUserRoles = this.assignedUserRoles;
    this.userservice.updateUserprofile(this.currentUser).subscribe(
      userservice => {
        if (!!userservice) {
          this.GetAllUsers();
          this.closeModalEdit.nativeElement.click();
          swal(
            'Updated!',
            'User role has been Updated.',
            'success'
          );
        }
      });
  }

  onRoleCloseModal() {
    this.availableUserRoles = [];
    this.assignedUserRoles = [];
    this.availableUserRoles = this.roleArray;
  }


  GetAllManager(): void {
    this.userservice.UserprofileByUserRoleName('Manager').subscribe((res: any[]) => {
      this.managerArray = res;
    });
  }
  GetAllTeam(): void {
    this.teamservice.getTeamAll().subscribe((res: any[]) => {
      this.teamArray = res;
      this.availableTeams = res;
      this.allTeams = res;
    });
  }
  GetAllGroup(): void {
    this.groupservice.getGroupAll().subscribe((res: any[]) => {
      this.groupArray = res;
      this.availableGroups = res;
      this.allGroups = res;
    });
  }
  GetAllCountries(): void {
    this.countryservice.getAllCountryCodeName().subscribe((res: any[]) => {
      this.countryArray = res;
    });
  }
  getAllStateList(): void {
    this.countryservice.getAllStateCodeName().subscribe((res: any[]) => {
      this.stateArray = res;
    });
  }
  GetAllCities(): void {
    this.countryservice.getAllCityCodeName().subscribe((res: any[]) => {
      this.cityArray = res;
    });
  }
  onSelectFile(event) {
    if (event.target.files && event.target.files[0]) {
      this.mediaService.getBase64(event.target.files[0]).then(
        (base64: any) => {
          this.previewUrl = base64;
          this.selectedFiles = base64;
        }
      );
    }
  }
  onSelectVoiceFile(event) {
    if (event.target.files && event.target.files[0]) {
      const reader = new FileReader();
      this.selectedvoiceFiles = event.target.files;
      reader.readAsDataURL(event.target.files[0]); // read file as data url
    }
  }
  showSearchBox(e) {
    this.box_search_status = !this.box_search_status;
    this.collapse_search_form = true;
  }
  collapseSearchform(event) {
    const targetclass = event.target.className;
    // console.log(targetclass);
    // this.collapse_search_form = !this.collapse_search_form;
    if (targetclass === 'btn btn-box-tool fa fa-angle-up') {
      this.collapse_search_form = !this.collapse_search_form;
      event.target.className = 'btn btn-box-tool fa fa-angle-down';
    } else if (targetclass === 'btn btn-box-tool fa fa-angle-down') {
      this.collapse_search_form = !this.collapse_search_form;
      event.target.className = 'btn btn-box-tool fa fa-angle-up';
    }
  }

  onResetSearch() {
    this.searchForm.reset();
    this.renderDT = false;
    this.GetAllUsers();
  }
  onSearch() {
    this.searchsubmitted = true;
    // stop here if form is invalid
    if (this.searchForm.invalid) {
      return;
    } else {
      this.searchsubmitted = true;
      // console.log( this.searchstring); return;
      this.renderDT = false;
      this.userservice.searchUserprofile(this.searchForm.value).subscribe(
        userservice => {
          this.usersList$ = userservice;
          setTimeout(() => {
            this.renderDT = true;
          }, 100);
        });
    }
  }
  GetAllUsers() {
    this.renderDT = false;
    this.userservice.getUserprofileAll().subscribe((res: any[]) => {
      this.usersList$ = res;
      setTimeout(() => {
        this.renderDT = true;
      }, 100);
    });
  }

  onSelectGroup(group) {
    this.currentGroup = group;
    this.findAssignedGroups(group.masUserGroups, this.availableGroups);
  }

  findAssignedGroups(assignedGroup, availableGroup) {
    const assignedUserGroup = [];
    _.each(assignedGroup, function (data: any) { assignedUserGroup.push(_.findWhere(availableGroup, { 'groupId': data.masGroupId })); });
    this.assignedGroups = assignedGroup;
    if (this.assignedGroups && this.assignedGroups.length > 0) {
      this.availableGroups = this.availableGroups.filter(item => !this.availableGroups.includes(item));
    }

  }

  onSelectAvailableGroups(event, data) {
    // AV -> Available Roles
    const className = event.currentTarget.className;

    if (className.includes('active')) {
      event.currentTarget.classList.remove('active');
      this.filterGroupByType(data, 'AV');
    } else {
      this.render.addClass(event.target, 'active');
      this.tempAvailableGroups.push(data);
    }
  }

  onSelectAssignedGroups(event, data) {
    const className = event.currentTarget.className;

    // AS -> Assigned Roles
    if (className.includes('active')) {
      event.currentTarget.classList.remove('active');
      this.filterGroupByType(data, 'AS');
    } else {
      this.render.addClass(event.target, 'active');
      this.tempAssignedGroups.push(data);
    }
  }

  filterGroupByType(data, arrayType) {
    if (arrayType === 'AS') {
      const index = this.tempAssignedGroups.indexOf(data);
      if (index > -1) {
        this.tempAssignedGroups.splice(index, 1);
      }
    } else {
      const index = this.tempAvailableGroups.indexOf(data);
      if (index > -1) {
        this.tempAvailableGroups.splice(index, 1);
      }
    }
  }

  updateAssignedGroup() {
    for (let i = 0; i < this.tempAssignedGroups.length; i++) {
      this.availableGroups.push(this.tempAssignedGroups[i]);
    }

    this.assignedGroups = this.assignedGroups.filter(val => !this.tempAssignedGroups.includes(val));
    this.tempAssignedGroups = [];
    this.updateUserGroupRequest();
  }

  updateAvailableGroups() {
    for (let i = 0; i < this.tempAvailableGroups.length; i++) {
      this.assignedGroups.push(this.tempAvailableGroups[i]);
    }
    this.availableGroups = this.availableGroups.filter(val => !this.tempAvailableGroups.includes(val));
    this.tempAvailableGroups = [];
    this.updateUserGroupRequest();
  }

  updateUserGroupRequest() {
    const userId = this.currentGroup.masUsersId;
    this.assignedGroups = _.each(this.assignedGroups, function (data: any) { data.masGroupId = data.groupId, data.masUserGroupId = data.groupId; data.masUsersId = userId; });
    this.currentGroup.masUserGroups = this.assignedGroups;
    this.userservice.updateUserprofile(this.currentGroup).subscribe(
      userservice => {
        if (!!userservice) {
          this.closeModalGroup.nativeElement.click();
          this.onCloseGroupModal();
          swal(
            'Updated!',
            'User Group has been updated.',
            'success'
          );
        }
      });
  }

  onCloseGroupModal() {
    this.availableGroups = [];
    this.assignedGroups = [];
    this.availableGroups = this.allGroups;
  }

  // Group service Ends Here

  // Team Service Starts Here

  onSelectTeam(team) {
    this.currentTeam = team;
    this.findAssignedTeams(team.masUserTeams, this.availableTeams);
  }

  findAssignedTeams(assignedTeam, availableTeam) {
    const assignedUserTeam = [];
    _.each(assignedTeam, function (data: any) { assignedUserTeam.push(_.findWhere(availableTeam, { 'teamId': data.masTeamId })); });
    this.assignedTeams = assignedTeam;
    this.availableTeams = this.availableTeams.filter(item => !this.assignedTeams.includes(item));
  }

  onSelectAvailableTeams(event, data) {
    // AV -> Available Roles
    const className = event.currentTarget.className;

    if (className.includes('active')) {
      event.currentTarget.classList.remove('active');
      this.filterTeasmByType(data, 'AV');
    } else {
      this.render.addClass(event.target, 'active');
      this.tempAvailableTeams.push(data);
    }
  }
  onSelectAssignedTeams(event, data) {
    const className = event.currentTarget.className;

    // AS -> Assigned Roles
    if (className.includes('active')) {
      event.currentTarget.classList.remove('active');
      this.filterTeasmByType(data, 'AS');
    } else {
      this.render.addClass(event.target, 'active');
      this.tempAssignedTeams.push(data);
    }
  }
  filterTeasmByType(data, arrayType) {
    if (arrayType === 'AS') {
      const index = this.tempAssignedTeams.indexOf(data);
      if (index > -1) {
        this.tempAssignedTeams.splice(index, 1);
      }
    } else {
      const index = this.tempAvailableTeams.indexOf(data);
      if (index > -1) {
        this.tempAvailableTeams.splice(index, 1);
      }
    }
  }

  updateAssignedTeam() {
    for (let i = 0; i < this.tempAssignedTeams.length; i++) {
      this.availableTeams.push(this.tempAssignedTeams[i]);
    }
    this.assignedTeams = this.assignedTeams.filter(val => !this.tempAssignedTeams.includes(val));
    this.tempAssignedTeams = [];
    this.updateUserTeamRequest();

  }

  updateAvailableTeams() {
    for (let i = 0; i < this.tempAvailableTeams.length; i++) {
      this.assignedTeams.push(this.tempAvailableTeams[i]);
    }

    this.availableTeams = this.availableTeams.filter(val => !this.tempAvailableTeams.includes(val));
    this.tempAvailableTeams = [];
    this.updateUserTeamRequest();
  }

  updateUserTeamRequest() {
    const userId = this.currentTeam.masUsersId;
    this.assignedTeams = _.each(this.assignedTeams, function (data: any) { data.masTeamId = data.teamId, data.masUserTeamId = data.teamId; data.masUsersId = userId; });
    this.currentTeam.masUserTeams = this.assignedTeams;
    this.userservice.updateUserprofile(this.currentTeam).subscribe(
      userservice => {
        if (!!userservice) {
          this.closeModalTeam.nativeElement.click();
          this.onCloseTeamModal();
          swal(
            'Updated!',
            'User Team has been updated.',
            'success'
          );
        }
      });
  }

  onCloseTeamModal() {
    this.availableTeams = [];
    this.assignedTeams = [];
    this.availableTeams = this.allTeams;
  }


  get f() { return this.addNewForm.controls; }
  onResetAdd() {
    this.addNewForm.reset();
    this.addNewsubmitted = false
  }
  addNewUser(): void {
    // console.log(this.addNewForm.value);
    this.addNewsubmitted = true;
    // stop here if form is invalid
    if (this.addNewForm.invalid) {
      return;
    } else {
      // Add your formdata values in here
      const formdata = new FormData();
      formdata.append('categoryLevel', this.addNewForm.value.categoryLevel);
      formdata.append('departmentName', this.addNewForm.value.departmentName);
      formdata.append('organizationName', this.addNewForm.value.organizationName);
      formdata.append('airLineCode', this.addNewForm.value.airLineCode);
      formdata.append('createdBy', this.addNewForm.value.createdBy);
      formdata.append('displayName', this.addNewForm.value.displayName);
      formdata.append('email', this.addNewForm.value.email);
      formdata.append('firstName', this.addNewForm.value.firstName);
      formdata.append('instantOfJoining', this.addNewForm.value.instantOfJoining);
      formdata.append('isActive', this.addNewForm.value.isActive);
      formdata.append('langKey', this.addNewForm.value.langKey);
      formdata.append('lastName', this.addNewForm.value.lastName);
      formdata.append('masUsersId', this.addNewForm.value.masUsersId);
      formdata.append('middleName', this.addNewForm.value.middleName);
      formdata.append('preferredLanguage', this.addNewForm.value.preferredLanguage);
      formdata.append('processName', this.addNewForm.value.processName);
      formdata.append('shiftEndTime', this.addNewForm.value.shiftEndTime);
      formdata.append('shiftStartTime', this.addNewForm.value.shiftStartTime);
      formdata.append('userAddress1', this.addNewForm.value.userAddress1);
      formdata.append('userAddress2', this.addNewForm.value.userAddress2);
      formdata.append('userAddress3', this.addNewForm.value.userAddress3);
      formdata.append('userEmail', this.addNewForm.value.userEmail);
      formdata.append('userFullName', this.addNewForm.value.userFullName);
      formdata.append('userGroupId', this.addNewForm.value.userGroupId);
      formdata.append('userManagerId', this.addNewForm.value.userManagerId);
      formdata.append('userModuleId', this.addNewForm.value.userModuleId);
      formdata.append('userName', this.addNewForm.value.userName);
      formdata.append('userRemarks', this.addNewForm.value.userRemarks);
      formdata.append('userRoleId', this.addNewForm.value.userRoleId);
      formdata.append('userTeamId', this.addNewForm.value.userTeamId);
      formdata.append('userTelephone', this.addNewForm.value.userTelephone);
      formdata.append('passwordHash', this.addNewForm.value.passwordHash);
      if (this.selectedFiles) {
        formdata.append('userPhoto', this.selectedFiles);
        this.addNewForm.value.userProfilePhoto = this.selectedFiles;
        this.addNewForm.value.userPhoto = null;
      } else {
        formdata.append('userPhoto', '');
        this.addNewForm.value.userProfilePhoto = '';
        this.addNewForm.value.userPhoto = null;
      }
      if (this.selectedvoiceFiles) {
        // formdata.append('voiceProfile', this.selectedvoiceFiles.item(0));
        this.addNewForm.value.voiceProfile = this.selectedvoiceFiles;
      } else {
        formdata.append('voiceProfile', '');
        this.addNewForm.value.voiceProfile = '';
      }
      if(this.addNewForm.value.shiftEndTime){
        this.addNewForm.value.shiftEndTime = this.commonService.convertTime(this.addNewForm.value.shiftEndTime);
      }
      if(this.addNewForm.value.shiftStartTime){
        this.addNewForm.value.shiftStartTime = this.commonService.convertTime(this.addNewForm.value.shiftStartTime);
      }
      this.userservice.addUserprofile(this.addNewForm.value).subscribe(
        userservice => {
          // console.log(userservice);
          if (!!userservice && userservice.userId) {
            this.GetAllUsers();
            this.closeModalAdd.nativeElement.click();
            swal(
              'Success',
              'New Records Addeded',
              'success'
            );
            this.onResetAdd();
          }
        });
    }
  }
  get u() { return this.editNewForm.controls; }
  showEditvalues(getId) {
    // alert(getId);
    this.userservice.UserprofileByUserprofileId(getId).subscribe(
      userservice => {
        if (!!userservice && userservice.masUsersId) {
          this.userdetail = userservice;
          this.previewUrl = "";
        } else {
          swal(
            'Error',
            'Error fetching record',
            'error'
          );
        }
      });
  }
  onResetEdit() {
  }
  editNewUser() {
    this.editsubmitted = true;
    // console.log(this.editNewForm);
    // stop here if form is invalid
    if (this.editNewForm.invalid) {
      swal(
        'Error',
        'sorry error in the form',
        'error'
      );
      return;
    } else {
      // console.log(this.editNewForm.value); return;
      const formdata = new FormData();
      formdata.append('categoryLevel', this.editNewForm.value.categoryLevel);
      formdata.append('departmentName', this.editNewForm.value.departmentName);
      formdata.append('organizationName', this.editNewForm.value.organizationName);
      formdata.append('airLineCode', this.editNewForm.value.airLineCode);
      formdata.append('createdBy', this.editNewForm.value.createdBy);
      formdata.append('displayName', this.editNewForm.value.displayName);
      formdata.append('email', this.editNewForm.value.email);
      formdata.append('firstName', this.editNewForm.value.firstName);
      formdata.append('instantOfJoining', this.editNewForm.value.instantOfJoining);
      formdata.append('isActive', this.editNewForm.value.isActive);
      formdata.append('langKey', this.editNewForm.value.langKey);
      formdata.append('lastName', this.editNewForm.value.lastName);
      formdata.append('masUsersId', this.editNewForm.value.masUsersId);
      formdata.append('middleName', this.editNewForm.value.middleName);
      formdata.append('preferredLanguage', this.editNewForm.value.preferredLanguage);
      formdata.append('processName', this.editNewForm.value.processName);
      formdata.append('shiftEndTime', this.editNewForm.value.shiftEndTime);
      formdata.append('shiftStartTime', this.editNewForm.value.shiftStartTime);
      formdata.append('userAddress1', this.editNewForm.value.userAddress1);
      formdata.append('userAddress2', this.editNewForm.value.userAddress2);
      formdata.append('userAddress3', this.editNewForm.value.userAddress3);
      formdata.append('userEmail', this.editNewForm.value.userEmail);
      formdata.append('userFullName', this.editNewForm.value.userFullName);
      // formdata.append('userGroupId', this.editNewForm.value.userGroupId);
      // formdata.append('userManagerId', this.editNewForm.value.userManagerId);
      // formdata.append('userModuleId', this.editNewForm.value.userModuleId);
      formdata.append('userName', this.editNewForm.value.userName);
      formdata.append('userRemarks', this.editNewForm.value.userRemarks);
      // formdata.append('userRoleId', this.editNewForm.value.userRoleId);
      // formdata.append('userTeamId', this.editNewForm.value.userTeamId);
      formdata.append('userTelephone', this.editNewForm.value.userTelephone);
      // formdata.append('passwordHash', this.editNewForm.value.passwordHash);
      if (this.selectedFiles) {
        // formdata.append('userPhoto', this.selectedFiles.item(0));
        formdata.append('userPhoto', this.selectedFiles);
        this.editNewForm.value.userProfilePhoto = this.selectedFiles;
        this.editNewForm.value.userPhoto = null;
      } else {
        formdata.append('userPhoto', '');
        this.editNewForm.value.userProfilePhoto = '';
        this.editNewForm.value.userPhoto = null;
      }
      if (this.selectedvoiceFiles) {
        // formdata.append('voiceProfile', this.selectedvoiceFiles.item(0));
        this.editNewForm.value.voiceProfile = this.selectedvoiceFiles;
      } else {
        formdata.append('voiceProfile', '');
        this.editNewForm.value.voiceProfile = '';
      }
      this.userservice.updateUserprofile(this.editNewForm.value).subscribe(
        userservice => {
          if (!!userservice) {
            this.GetAllUsers();
            this.closeModalEdit.nativeElement.click();
            swal(
              'Updated!',
              'Userprofile has been Updated.',
              'success'
            );
          }
        });
    }
  }
  removeafterDeactivate(user: Userprofile): void {
    this.usersList$ = this.usersList$.filter(h => h !== user);
  }
  changeStatusUser(userprofile, e, Id) {
    if (e.target.checked) {
      swal({
        type: 'warning',
        title: 'Are you sure to activate this user?',
        text: 'You will not be able to recover the data of Users',
        showCancelButton: true,
        confirmButtonColor: '#049F0C',
        cancelButtonColor: '#ff0000',
        confirmButtonText: 'Yes, activate it!',
        cancelButtonText: 'No, keep it deactivated',
        closeOnClickOutside: false,
        closeOnEsc: false,
        allowOutsideClick: false,
      } as any).then((result) => {
        if (result.value) {
          this.userservice.activateUserprofile(Id).subscribe(
            userservice => {
              // console.log(userservice);
              if (userservice === null) {
                this.GetAllUsers();
                swal(
                  'Activated!',
                  'User has been activated.',
                  'success'
                );
              }
            });
        } else if (
          // Read more about handling dismissals
          result.dismiss === swal.DismissReason.cancel
        ) {
          e.target.checked = false;
          swal(
            'Cancelled',
            'Usersprofile is status unchanged',
            'error'
          );
        }
      });
    } else {
      swal({
        type: 'warning',
        title: 'Are you sure to deactivate this user?',
        text: 'You will not be able to recover the data of Users',
        showCancelButton: true,
        confirmButtonColor: '#049F0C',
        cancelButtonColor: '#ff0000',
        confirmButtonText: 'Yes, deactivate it!',
        cancelButtonText: 'No, keep it as active',
        closeOnClickOutside: false,
        closeOnEsc: false,
        allowOutsideClick: false,
      } as any).then((result) => {
        if (result.value) {
          this.userservice.deactivateUserprofile(Id).subscribe(
            userservice => {
              if (userservice === null) {
                this.GetAllUsers();
                swal(
                  'De-Activated!',
                  'User has been deactivated.',
                  'success'
                );
              }
            });
        } else if (
          // Read more about handling dismissals
          result.dismiss === swal.DismissReason.cancel
        ) {
          e.target.checked = true;
          swal(
            'Cancelled',
            'Usersprofile is status unchanged',
            'error'
          );
        }
      });
    }
  }
  resetPasswordByAdmin(registeredemail) {
    this.resetPasswordValue = { email: registeredemail };
    swal({
      type: 'warning',
      title: 'Are you sure to reset password to this user?',
      text: 'Password reset key will be sent to the following email' + ' ' + registeredemail,
      showCancelButton: true,
      confirmButtonColor: '#049F0C',
      cancelButtonColor: '#ff0000',
      confirmButtonText: 'Yes, reset it!',
      cancelButtonText: 'No',
      closeOnClickOutside: false,
      closeOnEsc: false,
      allowOutsideClick: false,
    } as any).then((result) => {
      if (result.value) {
        this.authenticationService.resetPasswordInit(this.resetPasswordValue).subscribe(
          userservice => {
            this.GetAllUsers();
            swal(
              'Success!',
              'Reset passwod link has been sent to registered Email',
              'success'
            );
          });
      } else if (
        // Read more about handling dismissals
        result.dismiss === swal.DismissReason.cancel
      ) {
        swal(
          'Cancelled',
          'Users status unchanged',
          'info'
        );
      }
    });
  }
  OnItemDeSelectGroup(e) {
    console.log(e);
  }
  OnItemSelectGroup(e) {
    console.log(e);
  }
  // onImportUsers(event) {
  //   if (event.target.files && event.target.files[0]) {
  //     const reader = new FileReader();
  //     this.usersImportForm.value.file = event.target.files;
  //     reader.readAsDataURL(event.target.files[0]); // read file as data url
  //     this.onImportUsersSubmit();
  //   }
  // }
  onImportUsersSubmit(event) {
    this.usersImportsubmitted = true;
    if (event.target.files && event.target.files[0]) {
      const reader = new FileReader();
      this.usersImportForm.value.file = event.target.files;
      reader.readAsDataURL(event.target.files[0]); // read file as data url
      //  this.onImportUsersSubmit();
    }
    // stop here if form is invalid
    if (this.usersImportForm.invalid) {
      return;
    } else {
      console.log(this.usersImportForm.value);
      const formData = new FormData();
      formData.append('file', this.usersImportForm.value.file[0]);

      this.userservice.userImport(formData).subscribe(
        userservice => {
          swal(
            'Success',
            'Users status unchanged',
            'success'
          );
        });
    }
  }
  onExportUsers(): void {
    let userList: any;
    userList = this.usersList$;

    const userListJSON = [];

    _.each(userList, function (data: any) {
      const excelData = {
        'User Full Name': data.userFullName,
        'Display Name': data.displayName,
        'First Name': data.firstName,
        'Middle Name': data.middleName,
        'Last Name': data.lastName,
        'Category Level': data.categoryLevel,
        'Process Name': data.processName,
        'Email': data.email,
        'Shift Start Time': data.shiftStartTime,
        'Shift End Time': data.shiftEndTime,
        'Instant Of Joining': data.instantOfJoining,
        'Preferred Language': data.preferredLanguage,
        'User Address1': data.userAddress1,
        'User Address2': data.userAddress2,
        'User Address3': data.userAddress3,
        'User Email': data.userEmail,
        'User Remarks': data.userRemarks,
        'isActive': data.isActive,
        'Airline Code': data.airLineCode,
        'Department Name': data.departmentName,
        'Organization Name': data.organizationName,
        'User Telephone': data.userTelephone,
        'LangKey': data.langKey
      };
      userListJSON.push(excelData);
    });
    this.mediaService.exportAsExcelFile(userListJSON, 'User_List');
  }
  onExportUsersSearch(): void {
    let userList: any;
    this.userservice.searchUserprofile(this.searchForm.value).subscribe(
      res => {
        userList = res;
        const userListJSON = [];
        _.each(userList, function (data: any) {
          const searchexcelData = {
            'User Full Name': data.userFullName,
            'Display Name': data.displayName,
            'First Name': data.firstName,
            'Middle Name': data.middleName,
            'Last Name': data.lastName,
            'Category Level': data.categoryLevel,
            'Process Name': data.processName,
            'Email': data.email,
            'Shift Start Time': data.shiftStartTime,
            'Shift End Time': data.shiftEndTime,
            'Instant Of Joining': data.instantOfJoining,
            'Preferred Language': data.preferredLanguage,
            'User Address1': data.userAddress1,
            'User Address2': data.userAddress2,
            'User Address3': data.userAddress3,
            'User Email': data.userEmail,
            'User Remarks': data.userRemarks,
            'isActive': data.isActive,
            'Airline Code': data.airLineCode,
            'Department Name': data.departmentName,
            'Organization Name': data.organizationName,
            'User Telephone': data.userTelephone,
            'LangKey': data.langKey
          };
          userListJSON.push(searchexcelData);
        });
        this.mediaService.exportAsExcelFile(userListJSON, 'SearchUserList');
      });
    // console.log(userList);

  }

  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }

}
