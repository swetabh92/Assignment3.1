export interface BatchListModel {
  documentNumber:string;
  agencyCode:string;
  reportingAgency:string;
  reportedDate:Date;
  reportingStartDate:Date;
  reportingEndDate:Date;
  batchCurrency:string;
  source:string;
  grossFare:number;
  grossFareDocType:number;
  tax:number;
  commission:number;
  cashSale:number;
  creditSale:number;
  agentName:string;
  batchType:string;
}
