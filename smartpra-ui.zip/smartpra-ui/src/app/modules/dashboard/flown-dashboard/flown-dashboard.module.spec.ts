import { FlownDashboardModule } from './flown-dashboard.module';

describe('FlownDashboardModule', () => {
  let flownDashboardModule: FlownDashboardModule;

  beforeEach(() => {
    flownDashboardModule = new FlownDashboardModule();
  });

  it('should create an instance', () => {
    expect(flownDashboardModule).toBeTruthy();
  });
});
