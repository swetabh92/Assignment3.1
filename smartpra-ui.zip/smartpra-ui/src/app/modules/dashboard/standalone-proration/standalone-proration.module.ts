import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { StandaloneProrationRoutingModule } from './standalone-proration-routing.module';
import { StandaloneProrationComponent } from './standalone-proration/standalone-proration.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { ReactiveFormsModule } from '@angular/forms';
import { CoreDataModule } from 'src/app/core-data/core-data.module';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    CoreDataModule,
    StandaloneProrationRoutingModule
  ],
  declarations: [StandaloneProrationComponent]
})
export class StandaloneProrationModule { }
