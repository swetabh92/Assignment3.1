package com.sgl.smartpra.allocation.master.app.service;

import java.util.List;

import com.sgl.smartpra.allocation.master.model.FileType;
import com.sgl.smartpra.allocation.master.model.FileTypeMapping;

public interface FileTypeMappingService {
	
	List<FileTypeMapping> findAll();
	
	List<FileType> findAllFileType();

	FileTypeMapping findByFileTypeMappingId(Integer fileTypeMappingId);
	
	FileTypeMapping findFileTypeMappingByFileTypeId(Integer fileTypeId, Integer moduleLovId);

	List<FileType> getFileTypeByModuleId(Integer moduleLovId, String clientId);
}
