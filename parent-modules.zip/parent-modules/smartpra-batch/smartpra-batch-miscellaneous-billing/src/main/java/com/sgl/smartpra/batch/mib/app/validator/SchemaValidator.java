package com.sgl.smartpra.batch.mib.app.validator;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.XMLConstants;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import com.sgl.smartpra.batch.mib.app.config.FeignConfiguration;
import com.sgl.smartpra.batch.mib.app.enums.ErrorCode;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingConstants;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingUtil;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class SchemaValidator {
	
    @Value("${batch.directory.misc-billing.input}")
	private String batchInputDir;
    
	@Autowired
	private MiscBillingUtil miscBillingUtil;
    
    @Autowired
	private FeignConfiguration.SmartpraExceptionTransIntgAppClient smartpraExceptionTransIntgAppClient;
    
    private static int count = 1;
	
	public boolean validateXMLSchema(String fileName, String clientId, Integer fileId) {
		boolean isError = false;
		Map<String, String> map = new HashMap<>();
		
		try {
       		log.debug("batchInputDir: " + batchInputDir);
        	
            SchemaFactory factory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = factory.newSchema(new File(MiscBillingConstants.IATA_XSD_PATH));
            Validator validator = schema.newValidator();
            
            final List<String> exceptionList = new ArrayList<>();
            validator.setErrorHandler(new ErrorHandler() {
	            @Override
	            public void warning(SAXParseException exception) throws SAXException {
	            	exceptionList.add(handleMessage("warning", exception));
	            	String key = ErrorCode.MISC1133.toString() + "_" + count++;
	            	map.put(key, exception.getMessage());
	            }

	            @Override
	            public void fatalError(SAXParseException exception) throws SAXException {
	            	exceptionList.add(handleMessage("fatalError", exception));
	            	String key = ErrorCode.MISC1133.toString() + "_" + count++;
	            	map.put(key, exception.getMessage());
	            }

	            @Override
	            public void error(SAXParseException exception) throws SAXException {
	            	exceptionList.add(handleMessage("Error", exception));
	            	String key = ErrorCode.MISC1133.toString() + "_" + count++;
	            	map.put(key, exception.getMessage());
	            }
              
	            private String handleMessage(String level, SAXParseException exception) throws SAXException {
	            	return "[" + level + "], line no: " + exception.getLineNumber() + ", message: " + exception.getMessage();
	            }
            });
            validator.validate(new StreamSource(new File(batchInputDir + File.separator + fileName)));
            ExceptionTransactionModel errorModel = miscBillingUtil.prepareExceptionTransactionModel(ErrorCode.MISC1133.toString(), map, clientId, fileId);
           	//smartpraExceptionTransIntgAppClient.initExceptionTrasaction(errorModel);
        } catch (IOException | SAXException e) {
        	log.debug("Exception: " +e.getMessage());
            isError = true;
        }
		return isError;
	}
}
