import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChargeCategoryMasterComponent } from './charge-category-master.component';

describe('SectionMasterComponent', () => {
  let component: ChargeCategoryMasterComponent;
  let fixture: ComponentFixture<ChargeCategoryMasterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChargeCategoryMasterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChargeCategoryMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
