import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from 'src/app/shared/shared.module';
import { CoreDataModule } from 'src/app/core-data/core-data.module';

import { RouteCodeMasterRoutingModule } from './route-code-master-routing.module';
import { RouteCodeMasterComponent } from './route-code-master.component';

@NgModule({
  imports: [
    CommonModule, 
    SharedModule,
    CoreDataModule,
    RouteCodeMasterRoutingModule
  ],
  declarations: [RouteCodeMasterComponent]
})
export class RouteCodeMasterModule { }
