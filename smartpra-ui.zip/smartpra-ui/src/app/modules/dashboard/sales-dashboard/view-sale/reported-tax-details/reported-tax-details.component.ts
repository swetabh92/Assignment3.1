import { Component, OnInit,Input } from '@angular/core';
import {PaginationService} from '../../../../../commons/services/pagination/pagination.service';
import {SalesdashboardserviceService} from '../../salesdashboardservice.service';
import { DateFormatService } from '../../../../../commons/services/date-format/date-format.service';

@Component({
  selector: 'app-reported-tax-details',
  templateUrl: './reported-tax-details.component.html',
  styleUrls: ['./reported-tax-details.component.css']
})
export class ReportedTaxDetailsComponent implements OnInit {
  page: any = this.paginateService.setCustomPaginationConfig({'pageSize': 5});
  constructor(private dateFormatService:DateFormatService,private salesService:SalesdashboardserviceService,private paginateService: PaginationService) { }
  reportedTaxDetails:any = [];
  error:any;
  @Input('value')
  set value(val:any){
      if(val) {
          this.getReportdTaxDertails(val.uniqueDocumentId) 

      }
  }
  ngOnInit() {
  }
  getReportdTaxDertails(documentId): void {

    this.salesService.getReportedTaxDetials(documentId).subscribe(
      data => {
        this.reportedTaxDetails = data,
        error => this.error = error;
      }
    );
  }

}
