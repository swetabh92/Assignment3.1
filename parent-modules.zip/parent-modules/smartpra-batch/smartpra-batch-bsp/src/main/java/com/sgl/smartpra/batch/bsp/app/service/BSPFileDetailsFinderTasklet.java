package com.sgl.smartpra.batch.bsp.app.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.file.FlatFileParseException;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class BSPFileDetailsFinderTasklet implements Tasklet {

	@Value("${batch.directory.bsp.input}")
	private String batchInputDir;

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		BufferedReader bufferedReader = null;
		String fileName = "";
		String firstLine = null;

		try {
			fileName = chunkContext.getStepContext().getStepExecution().getJobParameters().getString("fileName");
			bufferedReader = new BufferedReader(new FileReader(batchInputDir + File.separator + fileName));
			firstLine = bufferedReader.readLine();
		} catch (FileNotFoundException e) {
			throw new FileNotFoundException("Unable to find file " + fileName + " in directory " + batchInputDir
					+ " for processing the batch job.");
		} finally {
			if (bufferedReader != null) {
				bufferedReader.close();
			}
		}

		if (firstLine == null) {
			throw new FlatFileParseException("Header record could not be found in first line of BSP HOT file", "", 1);
		}

		if (firstLine.startsWith("BFH")) {
			// continue
		} else {
			throw new FlatFileParseException("Header record could not be found in first line of BSP HOT file",
					firstLine, 1);
		}

		if (firstLine.length() < 22) {
			throw new FlatFileParseException(
					"BSP HOT File version from the header record. Record is not of required size.`	", firstLine, 1);
		}

		// extract position 20 to 22 for version
		String handbookRevisionNumber = firstLine != null ? firstLine.substring(19, 22) : null;
		chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext()
				.putString("handbookRevisionNumber", handbookRevisionNumber);

		// extract position 14 to 16 for station
		String bspIdentifier = firstLine != null ? firstLine.substring(13, 16) : null;
		chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext()
				.putString("bspIdentifier", bspIdentifier);

		// extract position 14 to 16 for effectiveDate
		String processingDate = firstLine != null ? firstLine.substring(26, 32) : null;
		chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext()
		.putString("processingDate", processingDate);
		return RepeatStatus.FINISHED;
	}

}
