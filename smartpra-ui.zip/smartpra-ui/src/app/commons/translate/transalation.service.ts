import {Injectable} from "@angular/core";
import {HttpClient} from "@angular/common/http";
import {AppConstants} from "../constants/app-constants";

/*
* Global Service To translate the language text the entire application
* All language files are stored in assets/i18n folder
* In case of selected language code , default language code is retrived from app constants
* */
@Injectable()
export class TranslateService {
  data: any = {};

  constructor(private http: HttpClient) {}

  use(lang: string): Promise<{}> {
    return new Promise<{}>((resolve) => {
      const langPath = AppConstants.LANG_FILES_PATH + `${lang || AppConstants.DEFAULT_LANG_CODE}` + AppConstants.JSON_TYPE;
      this.http.get<{}>(langPath).subscribe(
        translation => {
          this.data = Object.assign({}, translation || {});
          resolve(this.data);
        }
      );
    });
  }
}
