package com.sgl.smartpra.batch.bsp.app.record;

import java.util.ArrayList;

import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;
import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;

public class OfficeHeader extends BSPBaseRecord {

	@Override
	public String getRecordType() {
		return BSPRecordType.OFFICE_HEADER;
	}

	// Layout of BSP Office Header Record
	class OfficeHeaderLayout extends FixedLengthRecordLayout {
		public OfficeHeaderLayout() {
			fixedLengthFieldLayoutList = new ArrayList<FixedLengthFieldLayout>();

			// entire line
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("line", 1, 136));

			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdMessageIdentifier", 1, 3));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("seqNumber", 4, 11));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdNumericQuaifier", 12, 13));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("agentNumericCode", 14, 21));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("remittancePeriodEndDate", 22, 27));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("currencyType", 28, 31));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("multiLocationIdentifier", 32, 34));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("filler", 35, 136));
		}
	}

	@Override
	public LineTokenizer lineTokenizer(String handbookRevisionNumber) {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		OfficeHeaderLayout officeHeaderLayout = new OfficeHeaderLayout();
		tokenizer.setColumns(officeHeaderLayout.getColumns());
		tokenizer.setNames(officeHeaderLayout.getNames());
		return tokenizer;
	}

	@Override
	public FieldSetMapper<BSPBaseRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<BSPBaseRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<BSPBaseRecord>();
		fieldSetMapper.setTargetType(this.getClass());
		return fieldSetMapper;
	}

	// Variables to hold record values
	private String stdMessageIdentifier;
	private String seqNumber;
	private String stdNumericQuaifier;
	private String agentNumericCode;
	private String remittancePeriodEndDate;
	private String currencyType;
	private String multiLocationIdentifier;
	private String filler;

	// let us plug all the transaction of Office Header inside it
	private ArrayList<TransactionRecord> transactionRecordList;

	// let us plug all the Office Subtotals of Office Header inside it
	private ArrayList<OfficeSubtotals> officeSubtotalsList;

	public String getStdMessageIdentifier() {
		return stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getSeqNumber() {
		return seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdNumericQuaifier() {
		return stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getAgentNumericCode() {
		return agentNumericCode;
	}

	public void setAgentNumericCode(String agentNumericCode) {
		this.agentNumericCode = agentNumericCode;
	}

	public String getRemittancePeriodEndDate() {
		return remittancePeriodEndDate;
	}

	public void setRemittancePeriodEndDate(String remittancePeriodEndDate) {
		this.remittancePeriodEndDate = remittancePeriodEndDate;
	}

	public String getCurrencyType() {
		return currencyType;
	}

	public void setCurrencyType(String currencyType) {
		this.currencyType = currencyType;
	}

	public String getMultiLocationIdentifier() {
		return multiLocationIdentifier;
	}

	public void setMultiLocationIdentifier(String multiLocationIdentifier) {
		this.multiLocationIdentifier = multiLocationIdentifier;
	}

	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}

	public ArrayList<TransactionRecord> getTransactionRecordList() {
		return transactionRecordList;
	}

	public void setTransactionRecordList(ArrayList<TransactionRecord> transactionRecordList) {
		this.transactionRecordList = transactionRecordList;
	}

	public void addTransactionRecord(TransactionRecord transactionRecord) {
		if (this.transactionRecordList == null) {
			this.transactionRecordList = new ArrayList<TransactionRecord>();
		}

		this.transactionRecordList.add(transactionRecord);
	}

	public ArrayList<OfficeSubtotals> getOfficeSubtotalsList() {
		return officeSubtotalsList;
	}

	public void setOfficeSubtotalsList(ArrayList<OfficeSubtotals> officeSubtotalsList) {
		this.officeSubtotalsList = officeSubtotalsList;
	}

	public void addOfficeSubtotals(OfficeSubtotals officeSubtotals) {
		if (this.officeSubtotalsList == null) {
			this.officeSubtotalsList = new ArrayList<OfficeSubtotals>();
		}

		this.officeSubtotalsList.add(officeSubtotals);
	}
}
