import {Component, OnInit, Input} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {GeneralService} from '../../../../commons/services/general.service';
import {InwardDashboardService} from '../inward-dashboard.service';
import {DatePipe} from '@angular/common';
import {PaginationService} from '../../../../commons/services/pagination/pagination.service';
import {CommonService} from '../../../masters/services/commons/common.service';
import { InterlineConstant } from '../constants/interline-constants';
import { MessageBoxService } from '../../../masters/services/commons/message-box.service';



@Component({
  selector: 'app-transactions',
  templateUrl: './transactions.component.html',
  styleUrls: ['../inward-dashboard.component.css']
})
export class TransactionsComponent implements OnInit {
  summarizedDownArrow:boolean = true;
  showSummarizesdDT:boolean = true;
  selectedTransactionList:any = [];
  selectedInvoiceList:any = [];
  taxRecords:any = [];
  vatRecords:any = [];
  selectedIDs: any[] = [];
  selectedCoupon:any;
  transactionRecords:any = [];
  singleSelectIcon:boolean;
  multiSelectIcon:boolean;
  statusExpansion = InterlineConstant.STATUS_EXPANSION;
  transactionID:number;
  productionMode:boolean = false;
  page: any = this.paginateService.setCustomPaginationConfig({"pageSize": 5});
  couponParam:any;
  taxEditFormStg:FormGroup;
  vatEditFormStg:FormGroup;
  totalTaxAmount:number;
  totalVatBaseAmount:number;
  totalVatPercent:number;
  totalVatAmount:number;
  showTaxEditForm:boolean = false;
  showVatEditForm:boolean = false;
  taxEditSubmitted:boolean = false;
  vatEditSubmitted:boolean = false;

  @Input('couponParams')
  set couponParams(couponParams: any) {
    if (couponParams) {
      this.couponParam = couponParams;
      this.page  = this.paginateService.setCustomPaginationConfig({"pageSize": 5});
      this.loadTransactions(couponParams);
    }
  }

  constructor(private paginateService: PaginationService,private generalService: GeneralService, private commonService: CommonService,
    private formBuilder: FormBuilder,private inwardService: InwardDashboardService,private messageService: MessageBoxService) {

  }


  ngOnInit() {
    this.taxEditFormStg = this.formBuilder.group({
      "idecTaxBreakupId": ['', Validators.required],
      "transactionSeqNo": ['', Validators.required],
      "clientId": [''],
      "billingAirline": ['', Validators.required],
      "billedAirline": [''],
      "billingCode": [''],
      "invoiceNumber": [''],
      "ticketIssuingAirline": [''],
      "couponNumber": ['', Validators.required],
      "ticketDocumentNumber": ['', Validators.required],
      "recordSequenceNo": [''],
      "taxCode": ['', Validators.required],
      "taxAmountBilled": ['', [Validators.required,Validators.pattern('[0-9]+(\.[0-9][0-9]?)?')]],
      "createdBy": [''],
      "createdDate": [''],
      "fileId": [''],
      "status": [''],
    });
    this.vatEditFormStg = this.formBuilder.group({
      "idecVatBreakupId": ['', Validators.required],
      "transactionSeqNo": ['', Validators.required],
      "createdBy": [''],
      "createdDate": [''],
      "fileId": [''],
      "clientId": [''],
      "billingAirline": ['', Validators.required],
      "billedAirline": [''],
      "billingCode": [''],
      "invoiceNumber": [''],
      "ticketIssuingAirline": [''],
      "couponNumber": ['', Validators.required],
      "ticketDocumentNumber": ['', Validators.required],
      "recordSequenceNo": [''],
      "vatText": ['', Validators.required],
      "vatBaseAmount": ['', Validators.required],
      "vatIdentifier": ['', Validators.required],
      "vatLabel": ['', Validators.required],
      "vatPercentage": ['', Validators.required],
      "vatCalculatedAmount": ['', [Validators.required,Validators.pattern('[0-9]+(\.[0-9][0-9]?)?')]],
      "status": ['']
    });
  }

  getserverSideData(pageInfo) {
		this.page = this.paginateService.mergePageObj(pageInfo, this.page);
		this.loadTransactions(this.couponParam);
  }

  emptyCoupons(){
    this.selectedTransactionList = [];
    this.transactionRecords = [];
    this.selectedCoupon = null;
    this.transactionRecords = [...this.transactionRecords];
  }

  loadTransactions(data: any) {
    let paginates = this.paginateService.getQueryObj(this.page);
    this.selectedTransactionList = [];
    this.inwardService.getCouponData(data, paginates).subscribe((response:any)=> {
      if(!this.productionMode) {
				this.page.count = response.totalCount;
        this.transactionRecords = response.primeCouponDetailsStg;
        if (this.transactionRecords && this.transactionRecords.length > 0) {
          this.singleSelectIcon = false;
          this.multiSelectIcon = false;
        }
      } else {
        //this.transactionRecords = response.invoiceDetailsProd;
      }
    });
  }

  onSelectRow(event, type?:string, inputevent?:any){
    if(type == InterlineConstant.ALL && event.selected) {
      if (event.selected.length > 0) {
        this.selectedTransactionList = event.selected;
      } else {
        this.selectedTransactionList = [];
      }
    } else {
      if(inputevent && inputevent.target.checked) {
          this.selectedTransactionList.push(event);
          this.selectedCoupon = event;
          //this.createInvoiceParams('03','044');
      } else {
        if (this.selectedTransactionList.length > 0) {
          let ind:number, index:number;
          if(!this.productionMode) {
            ind = this.selectedTransactionList.findIndex(item => item['transactionSeqNo'] == event['transactionSeqNo']);
          } else {
            //ind = this.selectedTransactionList.findIndex(item => item['interlineForm3Id'] == event['interlineForm3Id']);
          }
          this.selectedTransactionList.splice(ind,1);
        }
      }
    }
    if (this.selectedTransactionList.length == 1) {
      this.singleSelectIcon = false;
    } else {
      this.singleSelectIcon = true;
    }
    if (this.selectedTransactionList.length > 0)
      this.multiSelectIcon = false;
    else
      this.multiSelectIcon = true;
  }

  deleteCouponRecords(){
    if(!this.productionMode) {
      this.selectedIDs = this.selectedTransactionList.map(res => res.transactionSeqNo);
    } else {
      //this.selectedIDs = this.selectedTransactionList.map(res => res.transactionSeqNo);
    }
    let ids = this.selectedIDs.toString();
    this.messageService.deleteRecordMessage(this.selectedIDs.length).then((result) => {
			if (result.value) {
        if(!this.productionMode) {
          this.inwardService.deleteCouponStgData(ids).subscribe((response:any)=> {
            this.loadTransactions(this.couponParam);
            this.singleSelectIcon = true;
            this.multiSelectIcon = true;
            this.selectedTransactionList = [];
            this.messageService.getSuccessMessage(InterlineConstant.SUCCESS,InterlineConstant.DELETEMESSAGE);
          });
        } else {
          /*this.inwardService.deleteInvoiceStgData(ids).subscribe((response:any)=> {
            this.loadTransactions(this.invoiceParams);
            this.singleSelectIcon = true;
            this.multiSelectIcon = true;
            this.selectedTransactionList = [];
            this.messageService.getSuccessMessage(InterlineConstant.SUCCESS,InterlineConstant.DELETEMESSAGE);
          });*/
        }
      }
    });

  }

  loadTaxDetails(transactionSeqNo: number){
    let data = {
        "area": "Staging",
        "transactionSeqNo": transactionSeqNo
    };
    this.inwardService.getTaxData(data).subscribe((response:any)=> {
      if(response){
        this.taxRecords = response.idecTaxBreakupStg;
        if (this.taxRecords.length > 1)
          this.totalTaxAmount =  this.sumOfAmountValues(this.taxRecords, 'taxAmountBilled');
      }
    });
  }


  get tes() { return this.taxEditFormStg.controls; }
  get ves() { return this.vatEditFormStg.controls; }

  showTaxEdit(id:number){
    this.showTaxEditForm = true;
    this.inwardService.getTaxById(id).subscribe((res:any)=> {
      this.taxEditFormStg.patchValue(res);
    });
  }

  sumOfAmountValues(list:any, key:string) {
    return list.reduce(function myFunction(total, value) {
      return +total + (+value[key]);
    });
  }

  updateTax(){
    this.taxEditSubmitted = true;
    if(!this.productionMode) {
      if (this.taxEditFormStg.valid) {
        this.inwardService.updateTaxStagById(this.taxEditFormStg.value).subscribe((response:any)=> {
          if (response === null) {
            this.showTaxEditForm = false;
            this.loadTaxDetails(this.taxEditFormStg.value.transactionSeqNo);
            this.messageService.getSuccessMessage(InterlineConstant.SUCCESS, InterlineConstant.RECORDUPDATESUCCESS);
          }
        });
      }
    }
  }

  deleteTax(id:number, transactionSeqNo : number){
    this.inwardService.deleteTaxById(id).subscribe((res:any)=> {
      this.loadTaxDetails(transactionSeqNo);
      this.messageService.getSuccessMessage(InterlineConstant.SUCCESS,InterlineConstant.DELETEMESSAGE);
    });
  }

  onCancelTaxEdit(){
    this.showTaxEditForm = false;
  }

  loadVatDetails(transactionSeqNo: number){
    let data = {
      "area": "Staging",
      "transactionSeqNo": transactionSeqNo
    };
    this.inwardService.getVatData(data).subscribe((response:any)=> {
      if(response){
        this.vatRecords = response.idecVatBreakupStg;
        if (this.vatRecords.length > 1) {
          this.totalVatBaseAmount =  this.sumOfAmountValues(this.vatRecords, 'vatBaseAmount');
          this.totalVatPercent =  this.sumOfAmountValues(this.vatRecords, 'vatPercentage');
          this.totalVatAmount =  this.sumOfAmountValues(this.vatRecords, 'vatCalculatedAmount');
        }
      }
    });
  }

  showVatEdit(id:number){
    this.showVatEditForm = true;
    this.inwardService.getVatById(id).subscribe((res:any)=> {
      this.vatEditFormStg.patchValue(res);
    });
  }

  updateVat(){
    this.vatEditSubmitted = true;
    if(!this.productionMode) {
      if (this.vatEditFormStg.valid) {
        this.inwardService.updateVatStagById(this.vatEditFormStg.value).subscribe((response:any)=> {
          if (response === null) {
            this.showTaxEditForm = false;
            this.loadTaxDetails(this.vatEditFormStg.value.transactionSeqNo);
            this.messageService.getSuccessMessage(InterlineConstant.SUCCESS, InterlineConstant.RECORDUPDATESUCCESS);
          }
        });
      }
    }
  }

  deleteVat(id:number, transactionSeqNo : number){
    this.inwardService.deleteVatById(id).subscribe((res:any)=> {
      this.loadVatDetails(transactionSeqNo);
      this.messageService.getSuccessMessage(InterlineConstant.SUCCESS,InterlineConstant.DELETEMESSAGE);
    });
  }

  onCancelVatEdit(){
    this.showVatEditForm = false;
  }

  onResetSearch(){}

  cancelSearch(event){}

  showSearchBox(): void {
  }
}

