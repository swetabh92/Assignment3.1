package com.sgl.smartpra.batch.interline.common;

public interface FileErrorConstants {
	
	/**
	 * CSV Form 3 file name format
	 */
	String FORM3_FORMAT = "ICH_STD_YYMMPP_CCNNN_F3_FINAL_A.CSV";
	
	/**
	 * IDEC file name format
	 */
	String IDEC_FORMAT = "PIDECT-BBBCCCCCCCC.DAT";

	/**
	 * ANSI Form 3 file name format
	 */
	String ANSI_FORMAT = "MONYYPPForm3Report.f3";

	/**
	 * File name
	 */
	String FILE_NAME = "File Name";
	
}
