package com.sgl.smartpra.batch.mib.app.utils;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.mapstruct.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.sgl.smartpra.mib.jaxb.dictionary.InvoiceType;
import com.sgl.smartpra.mib.jaxb.dictionary.TaxCategory;
import com.sgl.smartpra.mib.jaxb.dictionary.TaxType;
import com.sgl.smartpra.mib.jaxb.standard.ChargeAmount;
import com.sgl.smartpra.mib.jaxb.standard.InvoiceSummary;
import com.sgl.smartpra.mib.jaxb.standard.LineItem;
import com.sgl.smartpra.mib.jaxb.standard.TaxAmount;


@Component
public class QualifiedByUtil {
	
	@Qualifier
	@Target(ElementType.METHOD)
	@Retention(RetentionPolicy.SOURCE)
	public @interface StringToDate {}
	
	@Qualifier
	@Target(ElementType.METHOD)
	@Retention(RetentionPolicy.SOURCE)
	public @interface BillingMonth {}
	
	@Qualifier
	@Target(ElementType.METHOD)
	@Retention(RetentionPolicy.SOURCE)
	public @interface BillingPeriod {}
	
	@Qualifier
	@Target(ElementType.METHOD)
	@Retention(RetentionPolicy.SOURCE)
	public @interface BigIntegerToString {}
	
	@Qualifier
	@Target(ElementType.METHOD)
	@Retention(RetentionPolicy.SOURCE)
	public @interface BigIntegerToInteger {}
	
	@Qualifier
	@Target(ElementType.METHOD)
	@Retention(RetentionPolicy.SOURCE)
	public @interface IntegerToBigInteger {}
	
	@Qualifier
	@Target(ElementType.METHOD)
	@Retention(RetentionPolicy.SOURCE)
	public @interface ReturnSumFromList {}
	
	@Qualifier
	@Target(ElementType.METHOD)
	@Retention(RetentionPolicy.SOURCE)
	public @interface ListToBigDecimal {}
	
	@Qualifier
	@Target(ElementType.METHOD)
	@Retention(RetentionPolicy.SOURCE)
	public @interface ObjectToBigDecimal {}
	
	@Qualifier
	@Target(ElementType.METHOD)
	@Retention(RetentionPolicy.SOURCE)
	public @interface ObjectToString {}
	
	@Qualifier
	@Target(ElementType.METHOD)
	@Retention(RetentionPolicy.SOURCE)
	public @interface BigDecimalToObject {}
	
	@Qualifier
	@Target(ElementType.METHOD)
	@Retention(RetentionPolicy.SOURCE)
	public @interface StringToEnum {}
	
	@Qualifier
	@Target(ElementType.METHOD)
	@Retention(RetentionPolicy.SOURCE)
	public @interface StringToBigInteger {}

	@StringToDate
    public Date stringToDate(String source) {
		try {
			return new SimpleDateFormat("yyyy-MM-dd").parse(source);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return null;
    }
	
	@StringToBigInteger
    public BigInteger StringToBigInteger(String source) {
		BigInteger bi = new BigInteger("0");
		if(!StringUtils.isEmpty(source)){
			return new BigInteger(source.trim());
		}
		return bi;
    }
	
	@ObjectToString
    public String objectToString(Object object) {
		String str = MiscBillingConstants.EMPTY_STRING;
		if(StringUtils.isEmpty(object)){	
			return MiscBillingConstants.EMPTY_STRING;
		} else {
			if(object instanceof TaxType) {
				TaxType taxtype = (TaxType) object;
				str = taxtype.value();
			} else if(object instanceof TaxCategory) {
				TaxCategory taxCategory = (TaxCategory) object;
				str = taxCategory.value();
			} else if(object instanceof InvoiceType) {
				InvoiceType invoiceType = (InvoiceType) object;
				if(MiscBillingConstants.INVOICE.equals(invoiceType.value())) {
					str = MiscBillingConstants.I;
				} else if(MiscBillingConstants.CREDIT_NOTE.equals(invoiceType.value())) {
					str = MiscBillingConstants.C;
				}
			} else if(object instanceof Date) {	
				try {
					Date date = (Date) object;
					DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");  
					str = dateFormat.format(date);
				} catch (Exception e) {
					e.printStackTrace();
				}  
			} else {
				str = object.toString();
			}
		}
		return str;
    }
	
	@BillingMonth
    public static String getBillingMonth(String settlementMonthPeriod) {
		
		if(StringUtils.isEmpty(settlementMonthPeriod)){
			return MiscBillingConstants.EMPTY_STRING;
		} 
		// Gets YYMM format value
		// settlementMonthPeriod = 190402
		String YYMM = settlementMonthPeriod.substring(0, 4);
		String YY = YYMM.substring(0, 2);
		String MM = YYMM.substring(2);
		String MON = MiscBillingUtil.getMonth(MM);
		return MON + "-" + YY;
    }
	
	@BillingPeriod
    public static Integer getBillingPeriod(String settlementMonthPeriod) {
		
		// settlementMonthPeriod = 190402
		Integer period = 0;
		try {
			period = Integer.parseInt(settlementMonthPeriod.substring(4));
		} catch(Exception e) {
			period = 0;
		}
		return period;
    }
	
	@BigIntegerToString
    public static String getBigIntegerToString(BigInteger value) {
		
		String str = MiscBillingConstants.EMPTY_STRING;
		if(value != null) {
			str = value.toString();
		}
		return str;
    }
	
	@BigIntegerToInteger
    public static Integer getBigIntegerToInteger(BigInteger value) {
		
		if(value != null) {
			return Integer.valueOf(value.intValue());
		}
		return Integer.valueOf(0);
    }
	
	@IntegerToBigInteger
    public static BigInteger getIntegerToBigInteger(Integer value) {
		
		if(value != null) {
			return BigInteger.valueOf(value.intValue());
		} 
		return BigInteger.valueOf(0);
    }
	
	@ReturnSumFromList
    public static BigDecimal getReturnSumFromList(List<?> list) {
		
		BigDecimal sum = new BigDecimal(0);
		for (Object object : list) {
			if(object instanceof InvoiceSummary.AddOnCharges) {
				InvoiceSummary.AddOnCharges addOnCharge = (InvoiceSummary.AddOnCharges) object;
				if(!StringUtils.isEmpty(addOnCharge.getAddOnChargeAmount())){
					sum = sum.add(addOnCharge.getAddOnChargeAmount());
				}
			} else if(object instanceof com.sgl.smartpra.mib.jaxb.standard.AddOnCharges) {
				com.sgl.smartpra.mib.jaxb.standard.AddOnCharges addOnCharge = 
						(com.sgl.smartpra.mib.jaxb.standard.AddOnCharges) object;
				if(!StringUtils.isEmpty(addOnCharge.getAddOnChargeAmount())){
					sum = sum.add(addOnCharge.getAddOnChargeAmount());
				}
			}
		}
		return sum;
    }
	
	@ListToBigDecimal
    public static BigDecimal getListToBigDecimal(List<?> list) {
		
		BigDecimal value = new BigDecimal(0);
		if(list != null && list.size() > 0) {
			for (Object object : list) {
				if(object instanceof LineItem.ChargeAmount) {
					LineItem.ChargeAmount chargeAmt = (LineItem.ChargeAmount) object;
					value = chargeAmt.getValue();	
				} else if(object instanceof ChargeAmount) {
					ChargeAmount chargeAmt = (ChargeAmount) object;
					value = chargeAmt.getValue();
				} else if(object instanceof TaxAmount) {
					TaxAmount taxAmt = (TaxAmount) object;
					if(list.size() == 1) {
						value = taxAmt.getValue();
					} else {
						if(taxAmt.getName() != null && !StringUtils.isEmpty(taxAmt.getName().name())){
							if(MiscBillingConstants.DIFFERENCE.equalsIgnoreCase(taxAmt.getName().name())) {
								value = taxAmt.getValue();
							}
						}	
					}
				}
			}
		}
		return value;
    }
	
	@SuppressWarnings("restriction")
	@ObjectToBigDecimal
    public static BigDecimal convertObjectToBigDecimal(Object object) {
		
		BigDecimal value = new BigDecimal(0);
		if(object != null) {
			if(object instanceof com.sun.org.apache.xerces.internal.dom.ElementNSImpl) {
				com.sun.org.apache.xerces.internal.dom.ElementNSImpl element = (com.sun.org.apache.xerces.internal.dom.ElementNSImpl) object;
				value = new BigDecimal(element.getFirstChild().getNodeValue());	
			} 
		}
		return value;
    }
	
	@BigDecimalToObject
    public static Object convertBigDecimalToObject(BigDecimal value) {
		Object obj = new Object();
		if(value != null) {
			obj = value.toString();	
		}
		return obj;
    }
}
