package com.sgl.smartpra.batch.amadeus.app.processor;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import org.springframework.batch.core.StepExecution;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusBatchRecord;


@Component
@Scope(value="step")
public class AmadeusProcessor implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static final  String CREATED_BY="Amadeus";

	public static final  String FILE_SOURCE="ETL";

	public static final  String STATUS="N";

	@Value("#{stepExecution}")
	private StepExecution stepExecution; 

	@Value("#{jobParameters['inboundFileId']}")
	public Integer inboundFileId;

	public Integer getInboundFileId() {
		return inboundFileId;
	}

	public void setInboundFileId(Integer inboundFileId) {
		this.inboundFileId = inboundFileId;
	}

	public void process(AmadeusBatchRecord amadeusBatchRecord) {



		amadeusBatchRecord.setCreatedBy(CREATED_BY);
		amadeusBatchRecord.setCreatedDate(new Timestamp(new Date().getTime()));


	}
}
