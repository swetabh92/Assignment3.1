import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FlownRoutingModule } from './flown-routing.module';

@NgModule({
  imports: [
    CommonModule,
    FlownRoutingModule
  ],
  declarations: []
})
export class FlownModule { }
