import { Component, ViewChild, ElementRef,OnInit, OnDestroy } from '@angular/core';
import { GeneralService } from '../../../../../commons/services/general.service';
import { NewAirportMasterService } from '../../../services/flown/new-airport-master/new-airport-master.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subject } from 'rxjs';
import { Airport } from '../../../models/flown/airport.model';
import { CountryMasterService } from '../../../services/others/country-master/country-master.service';
import swal from 'sweetalert2';
import { MessageBoxService } from '../../../services/commons/message-box.service';
import { PaginationService } from '../../../../../commons/services/pagination/pagination.service';
import { HotkeysService } from 'angular2-hotkeys/src/hotkeys.service';
import { Hotkey } from 'angular2-hotkeys/src/hotkey.model';
import { MasterHotkeys } from '../../../../../commons/properties/master/master-hotkeys.enum'

@Component({
  selector: 'app-new-airport-master',
  templateUrl: './new-airport-master.component.html',
  styleUrls: ['./new-airport-master.component.css']
})
export class NewAirportMasterComponent implements OnInit{
	@ViewChild('closeModalAdd') closeModalAdd: ElementRef;
	@ViewChild('closeModalEdit') closeModalEdit: ElementRef;
	@ViewChild('closeModalSearch') closeModalSearch: ElementRef;
	createdBy = 'admin';
	lastUpdatedBy = 'admin';
	addMasterDet: FormGroup;
	editMasterDet: FormGroup;
	searchForm: FormGroup;
	editsubmitted = false;
	addsubmitted = false;
	searchsubmitted = false;
	searchParams = false;
	countryArray: any = [];
	setAirportObj : any={};
	formFlag: string = "";
	error: any = {
		isError: false,
		errorMessage: ''
	};
	/*pagination*/
	page: any = this.PaginateService.getPageinateConfig();
	/*ngx configuration*/
	masterDet = [];
	// public renderDT = false;
	constructor(private PaginateService: PaginationService, private Gservice: GeneralService, private airportservice: NewAirportMasterService, private formBuilder: FormBuilder, private countryService: CountryMasterService, private messageBoxService: MessageBoxService,private hotkeysService: HotkeysService,) {
		this.hotkeysService.add(new Hotkey(MasterHotkeys.save, (event: KeyboardEvent): boolean => {
			if (this.formFlag == 'addMaster') {
				this.onSubmit();
			} else if (this.formFlag == 'editMaster') {
				this.onUpdate();
			}
			return false;
		}));

		this.hotkeysService.add(new Hotkey(MasterHotkeys.clear, (event: KeyboardEvent): boolean => {
			if (this.formFlag == 'addMaster') {
				this.resetForm('add');
			} else if (this.formFlag == 'editMaster') {
				this.resetForm('edit');
			} else if (this.formFlag == 'searchMaster') {
				this.resetForm('search');
				this.getAirportData();
				// this.getFormCodes();
			}
			return false;
		}));

		this.hotkeysService.add(new Hotkey(MasterHotkeys.cancel, (event: KeyboardEvent): boolean => {
			if (this.formFlag == 'addMaster') {
				this.onCancelChange();
			} else if (this.formFlag == 'editMaster') {
				this.onCancelChange();
			} else if (this.formFlag == 'searchMaster') {
				document.getElementById("closeSearch").click();
			}
			return false;
		}));

	

	}
	ngOnInit() {
		this.getserverSideData({
			offset: '0'
		});
		this.GetAllCountries();
		this.addMasterDet = this.formBuilder.group({
			createdBy: ['admin'],
			airportCode: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(3)]],
			airportName: ['', [Validators.required, Validators.maxLength(30)]],
			cityCode: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(3)]],
			cityName: ['', [Validators.required, Validators.maxLength(30)]],
			countryCode: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(2)]],
			euVatExempted: ['',],
			lattitude: ['', [Validators.required, Validators.maxLength(10)]],
			longitude: ['', [Validators.required, Validators.maxLength(10)]],
			stateCode: ['',],
		});
		this.editMasterDet = this.formBuilder.group({
			lastUpdatedBy: ['admin'],
			airportCode: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(3)]],
			airportName: ['', [Validators.required, Validators.maxLength(30)]],
			cityCode: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(3)]],
			cityName: ['', [Validators.required, Validators.maxLength(30)]],
			countryCode: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(2)]],
			euVatExempted: ['',],
			lattitude: ['', [Validators.required, Validators.maxLength(10)]],
			longitude: ['', [Validators.required, Validators.maxLength(10)]],
			stateCode: ['',],
		});
		this.searchForm = this.formBuilder.group({
			airportCode: ['', [Validators.maxLength(3)]],
			airportName: ['', [Validators.maxLength(30)]],
			cityCode: ['', [Validators.maxLength(3)]],
			cityName: ['', [Validators.maxLength(30)]],
			countryCode: ['', ],
			isActive: ['', ],
		});
	}

	get f() {
		return this.addMasterDet.controls;
	}
	get u() {
		return this.editMasterDet.controls;
	}
	get s() {
		return this.searchForm.controls;
	}
	getserverSideData(pageInfo) {
		this.page = this.PaginateService.mergePageObj(pageInfo, this.page);
		this.getAirportData();
	}
	getAirportData() {
		// this.renderDT = false;
		let offset = this.page.offset;
		let data = this.PaginateService.getQueryObj(this.page);
		if (this.searchParams) data = Object.assign({}, data, this.searchForm.value);
		this.airportservice.getAirportAll(data).subscribe((res: any) => {
			if (res.data) {
				this.page.count = res.totalCount;
				this.masterDet = res.data;
				// setTimeout(() => {
				// 	this.renderDT = true;
				// 	}, 50);
			}
		});
	}
	onSearch() {
		// this.renderDT = false;
		this.searchsubmitted = true;
		if (this.searchForm.invalid) {
			return false;
		} else {
			this.searchParams = true;
			this.getAirportData();
			// setTimeout(() => {
			// 	this.renderDT = true;
			// }, 50);
		}
	}
	editMaster(id, type) {
		this.airportservice.getAirportByAirportCode(id).subscribe((res) => {
			if (res && res.airportCode) {
				if (type == 'update') {
					this.resetForm('edit');
					this.editMasterDet.patchValue(res);
					this['setAirportObj']['airportCode'] = res['airportCode'];
				} else {
					this.resetForm('add');
					this.addMasterDet.patchValue(res);
				}
			} else this.messageBoxService.showFetchErrorMessage();
		})
	}
	resetForm(type) {
		if (type == 'add') {
			this.addsubmitted = false;
			this.addMasterDet.reset();
			this.addMasterDet.patchValue({
				createdBy : "admin"
			});
		} else if (type == 'edit') {
			this.editsubmitted = false;
			this.editMasterDet.reset();
			this.editMasterDet.patchValue({
				airportCode: this['setAirportObj']['airportCode'],
				lastUpdatedBy : "admin"
			});
		} else if (type == 'search') {
			this.searchParams = false;
			this.searchsubmitted = false;
			this.searchForm.reset();
		}
	}

	onSubmit() {
		this.addsubmitted = true;
		if (this.addMasterDet.invalid) return false;
		this.addMasterDet.controls['createdBy'].setValue('admin');
		this.airportservice.addAirport(this.addMasterDet.value).subscribe(
			(res: any) => {
				if (res && res.airportCode) {
					this.updateDataTable(res,'add');
					this.closeModalAdd.nativeElement.click();
					this.error = {
						isError: true,
						errorMessage: "Record has been successfully saved"
					};
					this.closeAlertValidation();
					// this.getAirportData();
				}
			});
	}
	onUpdate() {
		this.editsubmitted = true;
		if (this.editMasterDet.invalid) {
			return false;
		} else {
			this.editMasterDet.controls['lastUpdatedBy'].setValue('admin');
			this.airportservice.updateAirport(this.editMasterDet.value).subscribe(
				(res: any) => {
					if (res && res.airportCode) {
						this.updateDataTable(res,'update');
						this.closeModalEdit.nativeElement.click();
						this.error = {
							isError: true,
							errorMessage: "Record has been successfully saved"
						};
						this.closeAlertValidation();
						// this.getAirportData();
					}
				});
		}
	}

	changeStatus(masterDet, e) {
		if (e.target.checked) {
		  this.messageBoxService.showActivationMessage('Airport').then((result) => {
			if (result.value) {
			  this.airportservice.activateAirport(masterDet.airportCode).subscribe(
				data => {
				this.getAirportData();
				this.messageBoxService.showActivationSuccess('Airport');
				e.target.checked = false;
				
				});
			  
			} else{
			  e.target.checked = false;
			  this.messageBoxService.showStatusUnchangedMessage('Airport');
			}
		  });
		  this.onSearch();
		} else {
		  this.messageBoxService.showDeactivationMessage('Airport').then((result) => {
			if (result.value) {
			  this.airportservice.deactivateAirport(masterDet.airportCode).subscribe(
				data => {
				 	this.getAirportData();
					 this.messageBoxService.showDeactivationSuccess('Airport');
					e.target.checked = true;
				});
			} else{
			  e.target.checked = true;
			  this.messageBoxService.showStatusUnchangedMessage('Airport');
			}
		  });
		} 
	  }

	closeAlertValidation() {
		var tempThis = this;
		window.setTimeout(function () {
			tempThis.error = {
				isError: false,
				errorMessage: ''
			};
		}, 6000);
	}
	GetAllCountries(): void {
		this.countryService.getAllCountries().subscribe((res: any[]) => {
			this.countryArray = res;
		});
	}

	onCancelChange() {
		this.addsubmitted = false;
		this.editsubmitted = false;
		this.resetForm('add')
		this.resetForm('edit');
		this.closeModalAdd.nativeElement.click();
		this.closeModalEdit.nativeElement.click();
		}
		updateDataTable(data,type){
			if(type == 'add') this.masterDet.unshift(data);	
			else{
				const ind = this.masterDet.findIndex((item) => { return data.airportCode == item.airportCode;});
				if(ind == -1) return false;if(type =='update')  this.masterDet[ind] = data;else if(type == 'remove') this.masterDet.splice(ind, 1);
			}
			this.masterDet = [...this.masterDet];
		}

}
