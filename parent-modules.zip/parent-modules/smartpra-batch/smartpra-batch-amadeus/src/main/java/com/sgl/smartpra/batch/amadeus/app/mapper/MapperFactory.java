package com.sgl.smartpra.batch.amadeus.app.mapper;

import org.mapstruct.factory.Mappers;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MapperFactory {

	@Bean
	EmdQueuemapper getEMDQueueMapper() {
		return Mappers.getMapper(EmdQueuemapper.class);

	}
}
