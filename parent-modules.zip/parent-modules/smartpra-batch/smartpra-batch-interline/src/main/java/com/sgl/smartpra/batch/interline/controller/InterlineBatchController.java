package com.sgl.smartpra.batch.interline.controller;

import java.math.BigInteger;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.batch.interline.common.InterlineBatchConstants;
import com.sgl.smartpra.batch.interline.common.JobDetails;
import com.sgl.smartpra.batch.interline.configuration.BatchJobFactory;

@RestController
public class InterlineBatchController {

	@Autowired
	BatchJobFactory batchJobFactory;

	@RequestMapping(value = "/invokejob/{jobName}/{fileName}", method = RequestMethod.GET)
	public String invokeJob(@PathVariable String jobName, @PathVariable String fileName) throws JobExecutionAlreadyRunningException, JobRestartException, JobInstanceAlreadyCompleteException, JobParametersInvalidException {
		JobParameters jobParameters = new JobParametersBuilder()
				.addLong(InterlineBatchConstants.TIME, System.currentTimeMillis())
				.addString(InterlineBatchConstants.FILE_NAME, fileName)
				.addString(InterlineBatchConstants.JOB_NAME, jobName)
				.toJobParameters();
		return batchJobFactory.invokeJob(jobName, jobParameters);
	}

	@PostMapping("/invokeBatchjob")
	public String invokeBatchJob(@RequestBody JobDetails jobDetails) throws JobExecutionAlreadyRunningException, JobRestartException, JobInstanceAlreadyCompleteException, JobParametersInvalidException {
		JobParametersBuilder jobParametersBuilder = new JobParametersBuilder();
		jobParametersBuilder.addLong(InterlineBatchConstants.TIME, System.currentTimeMillis());
		Map<String, String> jobParams = jobDetails.getJobParams();
		if(Objects.nonNull(jobParams)) {
			jobParams.forEach((k, v) -> {
				jobParametersBuilder.addString(k, v);
			});
		}
		return batchJobFactory.invokeJob(jobDetails.getJobName(), jobParametersBuilder.toJobParameters());
	}
	
	@RequestMapping(value = "/invokeStg2ProdDataTransferJob", method = RequestMethod.GET)
	public String invokeStg2ProdDataTransferJob(@RequestParam(required = false) String fileId) throws Exception  {
		
		JobParameters jobParameters = new JobParametersBuilder()
				.addLong(InterlineBatchConstants.TIME, System.currentTimeMillis())
				.addString(InterlineBatchConstants.FILE_ID, fileId).toJobParameters();
		
		return batchJobFactory.invokeJob(InterlineBatchConstants.STG2PROD_DATA_TRANSFER_JOB, jobParameters);
	}
}
