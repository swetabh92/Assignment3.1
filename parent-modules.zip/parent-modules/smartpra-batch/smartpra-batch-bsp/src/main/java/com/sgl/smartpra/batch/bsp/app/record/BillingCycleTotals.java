package com.sgl.smartpra.batch.bsp.app.record;

import java.util.ArrayList;

import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;
import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;

public class BillingCycleTotals extends BSPBaseRecord {

	@Override
	public String getRecordType() {
		return BSPRecordType.BILLING_CYCLE_TOTALS_PER_CURRTYPE;
	}

	// Layout of Billing Cycle Totals Record
	public class BillingCycleTotalsLayout extends FixedLengthRecordLayout {
		public BillingCycleTotalsLayout() {
			fixedLengthFieldLayoutList = new ArrayList<FixedLengthFieldLayout>();

			// entire line
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("line", 1, 136));

			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdMessageIdentifier", 1, 3));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("seqNumber", 4, 11));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdNumericQuaifier", 12, 13));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("processingDateIdentifier", 14, 16));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("processingCycleIdentifier", 17, 17));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("officeCount", 18, 22));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("grossValueAmt", 23, 37));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("totalRemittanceAmt", 38, 52));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("totalCommissionValue", 53, 67));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("totalTaxMiscFeeAmt", 68, 82));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("totalTaxOnCommissionAmt", 83, 97));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("filler", 98, 132));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("currencyType", 133, 136));
		}
	}

	@Override
	public LineTokenizer lineTokenizer(String handbookRevisionNumber) {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		BillingCycleTotalsLayout billingCycleTotalsLayout = new BillingCycleTotalsLayout();
		tokenizer.setColumns(billingCycleTotalsLayout.getColumns());
		tokenizer.setNames(billingCycleTotalsLayout.getNames());
		return tokenizer;
	}

	@Override
	public FieldSetMapper<BSPBaseRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<BSPBaseRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<BSPBaseRecord>();
		fieldSetMapper.setTargetType(this.getClass());
		return fieldSetMapper;
	}

	// Variables to hold record values
	private String stdMessageIdentifier;
	private String seqNumber;
	private String stdNumericQuaifier;
	private String processingDateIdentifier;
	private String processingCycleIdentifier;
	private String officeCount;
	private String grossValueAmt;
	private String totalRemittanceAmt;
	private String totalCommissionValue;
	private String totalTaxMiscFeeAmt;
	private String totalTaxOnCommissionAmt;
	private String filler;
	private String currencyType;

	public String getStdMessageIdentifier() {
		return stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getSeqNumber() {
		return seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdNumericQuaifier() {
		return stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getProcessingDateIdentifier() {
		return processingDateIdentifier;
	}

	public void setProcessingDateIdentifier(String processingDateIdentifier) {
		this.processingDateIdentifier = processingDateIdentifier;
	}

	public String getProcessingCycleIdentifier() {
		return processingCycleIdentifier;
	}

	public void setProcessingCycleIdentifier(String processingCycleIdentifier) {
		this.processingCycleIdentifier = processingCycleIdentifier;
	}

	public String getOfficeCount() {
		return officeCount;
	}

	public void setOfficeCount(String officeCount) {
		this.officeCount = officeCount;
	}

	public String getGrossValueAmt() {
		return grossValueAmt;
	}

	public void setGrossValueAmt(String grossValueAmt) {
		this.grossValueAmt = grossValueAmt;
	}

	public String getTotalRemittanceAmt() {
		return totalRemittanceAmt;
	}

	public void setTotalRemittanceAmt(String totalRemittanceAmt) {
		this.totalRemittanceAmt = totalRemittanceAmt;
	}

	public String getTotalCommissionValue() {
		return totalCommissionValue;
	}

	public void setTotalCommissionValue(String totalCommissionValue) {
		this.totalCommissionValue = totalCommissionValue;
	}

	public String getTotalTaxMiscFeeAmt() {
		return totalTaxMiscFeeAmt;
	}

	public void setTotalTaxMiscFeeAmt(String totalTaxMiscFeeAmt) {
		this.totalTaxMiscFeeAmt = totalTaxMiscFeeAmt;
	}

	public String getTotalTaxOnCommissionAmt() {
		return totalTaxOnCommissionAmt;
	}

	public void setTotalTaxOnCommissionAmt(String totalTaxOnCommissionAmt) {
		this.totalTaxOnCommissionAmt = totalTaxOnCommissionAmt;
	}

	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}

	public String getCurrencyType() {
		return currencyType;
	}

	public void setCurrencyType(String currencyType) {
		this.currencyType = currencyType;
	}
}
