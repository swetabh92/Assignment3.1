import {AfterViewInit, Component, OnInit} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';

import { GeneralService } from '../../../commons/services/general.service';
import { AuthenticationService } from '../auth-gaurd-service/_services/authentication.service';
import swal from 'sweetalert2';

@Component({
  selector: 'app-appforgetuserid',
  templateUrl: './appforgetuserid.component.html',
  styleUrls: ['./appforgetuserid.component.css']
})
export class AppforgetuseridComponent implements OnInit,AfterViewInit{
  forgetUserid: FormGroup;
  submitted = false;
  returnUrl: string;
  error = '';
  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private authenticationService: AuthenticationService,
    private Gservice: GeneralService
  ) { }

  ngAfterViewInit() {
    this.Gservice.LoadFormSettingJs();
  }
  ngOnInit() {
    this.forgetUserid = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]]
    });

  }
  get f() { return this.forgetUserid.controls; }
  onSubmit() {
    this.submitted = true;
    // stop here if form is invalid
     console.log(this.forgetUserid.value);
    if (this.forgetUserid.invalid) {
      return;
    }
    this.authenticationService.forgetUserid(this.forgetUserid.value)
    .pipe(first())
    .subscribe(
      result => {
        // Handle result
        swal(
          'success',
          'Reset password link has been sent to your Email ',
          'success'
        );
        this.router.navigate(['login']);
      },
      error => {
        swal(
          'error',
          'Email address not registered',
          'error'
        );
      },
      () => {
        // 'onCompleted' callback.
        // No errors, route to new page here
      });
  }
}
