package com.sgl.smartpra.batch.sales.validator.app.enums;

public enum ErrorCode {
	SALE1001, SALE1003, SALE1002, SALE1004, SALE1005, SALE1006, SALE1007

}
