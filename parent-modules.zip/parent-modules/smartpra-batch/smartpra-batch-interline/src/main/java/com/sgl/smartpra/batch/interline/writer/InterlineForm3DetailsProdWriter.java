package com.sgl.smartpra.batch.interline.writer;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;

import com.sgl.smartpra.batch.interline.model.InterlineForm3CompositeModel;
import com.sgl.smartpra.interline.domain.entity.prod.form3.InterlineForm3Details;
import com.sgl.smartpra.interline.domain.entity.stg.form3.InterlineForm3CsvStg;
import com.sgl.smartpra.interline.domain.repository.prod.form3.InterlineForm3DetailsRepository;
import com.sgl.smartpra.interline.domain.repository.stg.form3.InterlineForm3CsvStgRepository;
import com.sgl.smartpra.interline.domain.util.InterlineCommonConstants;

import lombok.extern.slf4j.Slf4j;
@Slf4j
public class InterlineForm3DetailsProdWriter implements ItemWriter<InterlineForm3CompositeModel> {

	@Autowired
	InterlineForm3DetailsRepository interlineForm3DetailsRepository;
	@Autowired
	InterlineForm3CsvStgRepository interlineForm3CsvStgRepository;
	
	@Override
	public void write(List<? extends InterlineForm3CompositeModel> items) throws Exception {
		List<InterlineForm3Details> form3ProdItems = items.stream().map( data -> { 
			return data.getInterlineForm3Details();
		}).collect(Collectors.toList());
		interlineForm3DetailsRepository.saveAll(form3ProdItems);
		log.debug("Data write completed in prod" + form3ProdItems.size());
		List<InterlineForm3CsvStg> form3StgItems = items.stream().map( data -> { 
			InterlineForm3CsvStg interlineForm3CsvStg = data.getInterlineForm3CsvStg();
			interlineForm3CsvStg.setTransferFlag(InterlineCommonConstants.Y);
			return interlineForm3CsvStg;
		}).collect(Collectors.toList());
		log.debug("Data write completed in stg" + form3StgItems.size());
		interlineForm3CsvStgRepository.saveAll(form3StgItems);
	}

}
