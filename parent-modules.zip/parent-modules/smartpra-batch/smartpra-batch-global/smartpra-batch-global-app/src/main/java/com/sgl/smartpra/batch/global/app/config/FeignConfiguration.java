package com.sgl.smartpra.batch.global.app.config;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.sgl.smartpra.master.model.ListOfValues;

@Configuration
public class FeignConfiguration {

	@FeignClient(value = "smartpra-master-app")
	public interface SmartpraMasterAppClient {
		
		@GetMapping("/listofvalues/{clientId}/{tableName}/{columnName}/{fieldValue}")
		public ListOfValues getListOfValues(@PathVariable(value = "clientId") String clientId,
				@PathVariable(value = "tableName") String tableName,
				@PathVariable(value = "columnName") String columnName,
				@PathVariable(value = "fieldValue") Integer fieldValue);
	}
	
}
