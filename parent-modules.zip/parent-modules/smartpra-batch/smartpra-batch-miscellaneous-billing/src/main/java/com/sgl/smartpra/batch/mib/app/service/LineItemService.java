/**
 * 
 */
package com.sgl.smartpra.batch.mib.app.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.batch.mib.app.mapper.LineItemMapper;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingConstants;
import com.sgl.smartpra.batch.mib.app.validator.CommonValidator;
import com.sgl.smartpra.global.master.model.ChargeCode;
import com.sgl.smartpra.mib.entity.MiscBillingAddOnChargeDtlEntity;
import com.sgl.smartpra.mib.entity.MiscBillingInvLineitemEntity;
import com.sgl.smartpra.mib.entity.MiscBillingTaxDetailsEntity;
import com.sgl.smartpra.mib.jaxb.standard.LineItem;
import com.sgl.smartpra.mib.jaxb.standard.Quantity;
import com.sgl.smartpra.mib.jaxb.standard.UnitPrice;

import lombok.extern.slf4j.Slf4j;

/**
 * @author kanprasa
 *
 */
@Service
@Slf4j
public class LineItemService {
	
	@Autowired
	private LineItemMapper lineItemMapper;
	
	@Autowired
	private CommonValidator commonValidator; 

	@Autowired
	private TaxDetailsService taxDetailsService;
	
	@Autowired
	private AddOnChargeDtlService addOnChargeDtlService;

/*
	public boolean isLocationCodeDifferentForLineItems(List<MiscBillingInvLineitemEntity> lineItemEntity) {
		boolean isDifferent = false;
		if(lineItemEntity != null && lineItemEntity.size() > 0) {
			return lineItemEntity.stream().map(i -> i.getLocationCode()).distinct().count() > 1;
		}
		return isDifferent;
	}
*/	
	
	public List<LineItem> getLineItems(List<MiscBillingInvLineitemEntity> lineItems, boolean isInvoiceRejected){
		List<LineItem> lineItemList = new ArrayList<>();
		for (MiscBillingInvLineitemEntity lineItemEntity : lineItems) {
			LineItem lineItem = new LineItem();
			Quantity quantity = new Quantity(); lineItem.setQuantity(quantity);
			UnitPrice unitPrice = new UnitPrice(); lineItem.setUnitPrice(unitPrice);
			lineItemMapper.mapEntityToLineItem(lineItemEntity, lineItem);
			List<ChargeCode> chargeCodeList = commonValidator.getChargeCodeMap().get(lineItemEntity.getChargeCatCode());
			Optional<String> chargeCodeName = chargeCodeList.stream().filter(x -> x.getChargeCode().isPresent() && x.getChargeCode().get().equalsIgnoreCase(lineItemEntity.getChargeCode()))
								   .map(x -> x.getChargeCodeName().get()).findAny();
			if(chargeCodeName.isPresent()) {
				lineItem.setChargeCode(chargeCodeName.get());
			}
			LineItem.ChargeAmount ca = new LineItem.ChargeAmount();
			ca.setValue(lineItemEntity.getChargeAmount());
			lineItem.getChargeAmount().add(ca);
			lineItemList.add(lineItem);
			if(!isInvoiceRejected) {
				lineItem.setOriginalLineItemNumber(null);
			}
			if(lineItemEntity.getMiscBillingTaxDetails() != null && lineItemEntity.getMiscBillingTaxDetails().size() > 0) {
				List<MiscBillingTaxDetailsEntity> taxEntityList = lineItemEntity.getMiscBillingTaxDetails().stream()
						.filter(x -> MiscBillingConstants.LINE_ITEM.equalsIgnoreCase(x.getTaxLevel())).collect(Collectors.toList());
				lineItem.getTax().addAll(taxDetailsService.getTaxDetails(taxEntityList));
			}
			if(lineItemEntity.getMiscBillingAddOnChargeDtl() != null && lineItemEntity.getMiscBillingAddOnChargeDtl().size() > 0) {
				List<MiscBillingAddOnChargeDtlEntity> aocEntityList = lineItemEntity.getMiscBillingAddOnChargeDtl().stream()
						.filter(x -> MiscBillingConstants.LINE_ITEM.equalsIgnoreCase(x.getAddOnLevel())).collect(Collectors.toList());
				lineItem.getAddOnCharges().addAll(addOnChargeDtlService.getAddOnChargeDetails(aocEntityList));
			}
		}
		return lineItemList;
	}
}
