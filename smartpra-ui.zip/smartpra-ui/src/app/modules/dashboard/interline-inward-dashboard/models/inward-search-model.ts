export interface InwardSearchModel {
  area: string;
  billingMonth: string;
  billingPeriod: string;
  carrierGroup: string;
  settlementIndicator: string;
  billingCarrier: string;
}

export interface InvoiceSearchModel {
  area: string;
  billingMonth: string;
  billingPeriod: string;
  billingCarrier: string;
}
