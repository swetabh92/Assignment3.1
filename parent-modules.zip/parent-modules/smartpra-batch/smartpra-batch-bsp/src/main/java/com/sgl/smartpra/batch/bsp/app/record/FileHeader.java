package com.sgl.smartpra.batch.bsp.app.record;

import java.util.ArrayList;

import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;
import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;

public class FileHeader extends BSPBaseRecord {

	@Override
	public String getRecordType() {
		return BSPRecordType.FILE_HEADER;
	}

	// Layout of BSP File Header Record
	class FileHeaderLayout extends FixedLengthRecordLayout {

		public FileHeaderLayout() {
			fixedLengthFieldLayoutList = new ArrayList<FixedLengthFieldLayout>();

			// entire line
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("line", 1, 136));

			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdMessageIdentifier", 1, 3));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("seqNumber", 4, 11));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdNumericQuaifier", 12, 13));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("bspIdentifier", 14, 16));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("tktAirlineCodeNumber", 17, 19));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("handbookRevisionNumber", 20, 22));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("prodStatus", 23, 26));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("processingDate", 27, 32));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("processingTime", 33, 36));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("isoCityCode", 37, 38));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("fileSeqNumber", 39, 44));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("filler", 45, 136));
		}
	}

	@Override
	public LineTokenizer lineTokenizer(String handbookRevisionNumber) {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		FileHeaderLayout fileHeaderLayout = new FileHeaderLayout();
		tokenizer.setColumns(fileHeaderLayout.getColumns());
		tokenizer.setNames(fileHeaderLayout.getNames());
		return tokenizer;

	}

	@Override
	public FieldSetMapper<BSPBaseRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<BSPBaseRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<BSPBaseRecord>();
		fieldSetMapper.setTargetType(this.getClass());
		return fieldSetMapper;
	}

	// variables to hold the record values
	private String stdMessageIdentifier;
	private String seqNumber;
	private String stdNumericQuaifier;
	private String bspIdentifier;
	private String tktAirlineCodeNumber;
	private String handbookRevisionNumber;
	private String prodStatus;
	private String processingDate;
	private String processingTime;
	private String isoCityCode;
	private String fileSeqNumber;
	private String filler;

	public String getStdMessageIdentifier() {
		return stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getSeqNumber() {
		return seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdNumericQuaifier() {
		return stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getBspIdentifier() {
		return bspIdentifier;
	}

	public void setBspIdentifier(String bspIdentifier) {
		this.bspIdentifier = bspIdentifier;
	}

	public String getTktAirlineCodeNumber() {
		return tktAirlineCodeNumber;
	}

	public void setTktAirlineCodeNumber(String tktAirlineCodeNumber) {
		this.tktAirlineCodeNumber = tktAirlineCodeNumber;
	}

	public String getHandbookRevisionNumber() {
		return handbookRevisionNumber;
	}

	public void setHandbookRevisionNumber(String handbookRevisionNumber) {
		this.handbookRevisionNumber = handbookRevisionNumber;
	}

	public String getProdStatus() {
		return prodStatus;
	}

	public void setProdStatus(String prodStatus) {
		this.prodStatus = prodStatus;
	}

	public String getProcessingDate() {
		return processingDate;
	}

	public void setProcessingDate(String processingDate) {
		this.processingDate = processingDate;
	}

	public String getProcessingTime() {
		return processingTime;
	}

	public void setProcessingTime(String processingTime) {
		this.processingTime = processingTime;
	}

	

	public String getIsoCityCode() {
		return isoCityCode;
	}

	public void setIsoCityCode(String isoCityCode) {
		this.isoCityCode = isoCityCode;
	}

	public String getFileSeqNumber() {
		return fileSeqNumber;
	}

	public void setFileSeqNumber(String fileSeqNumber) {
		this.fileSeqNumber = fileSeqNumber;
	}

	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}
}
