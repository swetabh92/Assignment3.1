import { Directive,HostListener} from '@angular/core';
import { NgControl } from "@angular/forms";

@Directive({
  selector: '[appAlphabeat]'
})
export class AlphabeatDirective {
	
	constructor(private control : NgControl){}
 @HostListener('input', ['$event']) onKeyup(event: KeyboardEvent) {
	this.control.control.setValue((<HTMLInputElement>event.target).value.replace(/[^a-zA-Z]/g, ''));
 }
}
