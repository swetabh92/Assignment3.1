package com.sgl.smartpra.batch.amadeus.app.writer;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.amadeus.app.common.AppConstants;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusBatchRecord;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusNewTaxStaging;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusRecordDetailStaging;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusRecordStaging;
import com.sgl.smartpra.batch.amadeus.app.repository.AmadeusRecordStagingRepository;
import com.sgl.smartpra.common.util.SmartPRACommonUtil;

@Component
public class StagingEMDV1_01Writer<T extends AmadeusBatchRecord> implements ItemWriter<AmadeusRecordStaging> {

	private static final Logger log = LoggerFactory.getLogger(StagingEMDV1_01Writer.class);

	@Autowired
	private AmadeusRecordStagingRepository amadeusRecordStagingRepository;

	@Override
	public void write(List<? extends AmadeusRecordStaging> amadeusRecordStagingList) throws Exception {

		for (AmadeusRecordStaging amadeusRecordStaging : amadeusRecordStagingList) {

			ArrayList<AmadeusRecordDetailStaging> amadeusRecordDetailStagingList;
			ArrayList<AmadeusNewTaxStaging> amadeusNewTaxStagingList;
			String couponNumber;
			AmadeusRecordDetailStaging amadeusRecordDetailStaging;
			AmadeusNewTaxStaging amadeusNewTaxStaging;
			amadeusNewTaxStagingList = new ArrayList<AmadeusNewTaxStaging>();
			String taxDetailStr = amadeusRecordStaging.getNewTax();
			int taxCount = taxDetailStr.length() / 14;

			for (int k = 0; k < taxCount; k++) {

				amadeusNewTaxStaging = new AmadeusNewTaxStaging();
				amadeusNewTaxStaging.setNewTaxCode(taxDetailStr.substring((k * 14), (k * 14) + 2));
				amadeusNewTaxStaging.setNewTaxValue(taxDetailStr.substring((k * 14) + 2, (k * 14) + 14));
				amadeusNewTaxStaging.setCreatedBy(AppConstants.CREATED_BY);
				amadeusNewTaxStaging.setCreatedDate(new Timestamp(new Date().getTime()));
				amadeusNewTaxStaging.setAmadeusRecordStg(amadeusRecordStaging);
				amadeusNewTaxStagingList.add(amadeusNewTaxStaging);

			}

			amadeusRecordDetailStagingList = new ArrayList<AmadeusRecordDetailStaging>();
			String couponDetailStr = amadeusRecordStaging.getCoupons();
			int couponCount = couponDetailStr.length() / AppConstants.COUPON_LENGTH_EMD;
			if (couponDetailStr.length() != couponCount * AppConstants.COUPON_LENGTH_EMD) {
				couponDetailStr = SmartPRACommonUtil.postNoTrimPadString(couponDetailStr, " ",((couponCount + 1) * AppConstants.COUPON_LENGTH_EMD));
				couponCount = couponDetailStr.length() / AppConstants.COUPON_LENGTH_EMD;
			}
			log.info("Coupon Count of Emd Data------->" + couponCount);
			for (int i = 0; i < couponCount; i++) {
				log.info("Enter into Amadeus Emd Writer");
				couponNumber = couponDetailStr.substring((i * AppConstants.COUPON_LENGTH_EMD), (i * AppConstants.COUPON_LENGTH_EMD) + 2);
				log.info("Coupon Number occuring in  Emd---->" + couponNumber);	
				if (couponNumber != null && couponNumber.length() > 0) {
					amadeusRecordDetailStaging = new AmadeusRecordDetailStaging();
					amadeusRecordDetailStaging.setCouponNumber(amadeusRecordStaging.getCouponNumber());

					amadeusRecordDetailStaging.setSaleCouponNumber(couponNumber);
					amadeusRecordDetailStaging.setAirlineCode(couponDetailStr.substring((i * AppConstants.COUPON_LENGTH_EMD) + 2, (i * AppConstants.COUPON_LENGTH_EMD) + 5));
					amadeusRecordDetailStaging.setOrigin(couponDetailStr.substring((i * AppConstants.COUPON_LENGTH_EMD) + 5, (i * AppConstants.COUPON_LENGTH_EMD) + 10));
					amadeusRecordDetailStaging.setDestination(couponDetailStr.substring((i * AppConstants.COUPON_LENGTH_EMD) + 10, (i * AppConstants.COUPON_LENGTH_EMD) + 15));
					amadeusRecordDetailStaging
							.setReasonForIssuanceSubCode(couponDetailStr.substring((i * AppConstants.COUPON_LENGTH_EMD) + 15, (i * AppConstants.COUPON_LENGTH_EMD) + 18));
					amadeusRecordDetailStaging
							.setEmdTotalNoOfUnits(couponDetailStr.substring((i * AppConstants.COUPON_LENGTH_EMD) + 18, (i * AppConstants.COUPON_LENGTH_EMD) + 33));
					amadeusRecordDetailStaging
							.setEbtChargeQualify(couponDetailStr.substring((i * AppConstants.COUPON_LENGTH_EMD) + 33, (i * AppConstants.COUPON_LENGTH_EMD) + 36));
					amadeusRecordDetailStaging
							.setEbtUnitQualifier(couponDetailStr.substring((i * AppConstants.COUPON_LENGTH_EMD) + 36, (i * AppConstants.COUPON_LENGTH_EMD) + 39));

					amadeusRecordDetailStaging
							.setEbtChargeCurrency(couponDetailStr.substring((i * AppConstants.COUPON_LENGTH_EMD) + 39, (i * AppConstants.COUPON_LENGTH_EMD) + 42));
					amadeusRecordDetailStaging
							.setEbtRatePerUnit(couponDetailStr.substring((i * AppConstants.COUPON_LENGTH_EMD) + 42, (i * AppConstants.COUPON_LENGTH_EMD) + 60));

					amadeusRecordDetailStaging.setFeeOwner(couponDetailStr.substring((i * AppConstants.COUPON_LENGTH_EMD) + 60, (i * AppConstants.COUPON_LENGTH_EMD) + 63));
					amadeusRecordDetailStaging.setCouponValue(couponDetailStr.substring((i * AppConstants.COUPON_LENGTH_EMD) + 63, (i * AppConstants.COUPON_LENGTH_EMD) + 75));

					amadeusRecordDetailStaging
							.setNotValidBeforeDate(couponDetailStr.substring((i * AppConstants.COUPON_LENGTH_EMD) + 75, (i * AppConstants.COUPON_LENGTH_EMD) + 83));
					amadeusRecordDetailStaging
							.setNotValidAfterDate(couponDetailStr.substring((i * AppConstants.COUPON_LENGTH_EMD) + 83, (i * AppConstants.COUPON_LENGTH_EMD) + 91));
					amadeusRecordDetailStaging
							.setNonExchangeableIndicator(couponDetailStr.substring((i * AppConstants.COUPON_LENGTH_EMD) + 91, (i * AppConstants.COUPON_LENGTH_EMD) + 92));
					amadeusRecordDetailStaging
							.setNonInterlinableIndicator(couponDetailStr.substring((i * AppConstants.COUPON_LENGTH_EMD) + 92, (i * AppConstants.COUPON_LENGTH_EMD) + 93));
					amadeusRecordDetailStaging
							.setConsumedAtIssuanceIndicator(couponDetailStr.substring((i * AppConstants.COUPON_LENGTH_EMD) + 93, (i * AppConstants.COUPON_LENGTH_EMD) + 94));
					amadeusRecordDetailStaging
							.setInvoluntaryIndicator(couponDetailStr.substring((i * AppConstants.COUPON_LENGTH_EMD) + 94, (i * AppConstants.COUPON_LENGTH_EMD) + 95));
					amadeusRecordDetailStaging.setCreatedBy(AppConstants.CREATED_BY);
					amadeusRecordDetailStaging.setCreatedDate(new Timestamp(new Date().getTime()));
					amadeusRecordDetailStaging.setAmadeusRecordStg(amadeusRecordStaging);
					amadeusRecordDetailStagingList.add(amadeusRecordDetailStaging);

				} else {
					break;
				}

			}
			// Add coupon
			amadeusRecordStaging.setAmadeusRecordDetailStgs(amadeusRecordDetailStagingList);
			// Add tax
			amadeusRecordStaging.setAmadeusNewTaxStgs(amadeusNewTaxStagingList);
			amadeusRecordStaging.setFileSource(AppConstants.FILE_SOURCE_EMD);
			amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_LOADED);

		}

		amadeusRecordStagingRepository.saveAll(amadeusRecordStagingList);
		amadeusRecordStagingRepository.flush();
	}

}
