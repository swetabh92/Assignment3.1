package com.sgl.smartpra.batch.bhr.app.processor;

import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.bhr.app.config.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.batch.bhr.app.domain.FlightBatchHeaderStg;
import com.sgl.smartpra.master.model.Aircraft;

@Component
@Scope(value = "step")
public class BatchHeaderFileProcessor extends RecordProcessor
		implements ItemProcessor<FlightBatchHeaderStg, FlightBatchHeaderStg> {

	private static Logger LOGGER = LoggerFactory.getLogger(BatchHeaderFileProcessor.class);

	@Autowired
	SmartpraMasterAppClient smartpraMasterAppClient;

	@Value("#{stepExecution}")
	private StepExecution stepExecution;
	
	@Override
	public FlightBatchHeaderStg process(FlightBatchHeaderStg fileDetail) throws Exception {
		LOGGER.info("BatchHeaderFileProcessor.process() - start");
		super.process(fileDetail);
		
		String clientId = stepExecution.getJobExecution().getJobParameters().getString("clientId");
		
		fileDetail.setClientId(clientId);
		if (StringUtils.isEmpty(fileDetail.getFirstClassCapacity())
				|| StringUtils.isEmpty(fileDetail.getBusinessClassCapacity())
				|| StringUtils.isEmpty(fileDetail.getEconomyClassCapacity())
				|| StringUtils.isEmpty(fileDetail.getPremiumEcoClassCapacity())) {
			
			List<Aircraft> aircrafts = smartpraMasterAppClient.getAllAircraft(fileDetail.getAircraftRegistration(), null, null);
			if (CollectionUtils.isNotEmpty(aircrafts)) {
				Aircraft aircraft = aircrafts.get(0);
				fileDetail.setFirstClassCapacity(aircraft.getFirstClassCapacity().get());
				fileDetail.setBusinessClassCapacity(aircraft.getBusinessClassCapacity().get());
				fileDetail.setEconomyClassCapacity(aircraft.getEconomyClassCapacity().get());
				fileDetail.setPremiumEcoClassCapacity(aircraft.getPremiumEconomyClassCapacity().get());
			} else {
				fileDetail.setFirstClassCapacity("000");
				fileDetail.setBusinessClassCapacity("000");
				fileDetail.setEconomyClassCapacity("000");
				fileDetail.setPremiumEcoClassCapacity("000");
			}

		}

		LOGGER.info("BatchHeaderFileProcessor.process() - end");
		return fileDetail;
	}
}
