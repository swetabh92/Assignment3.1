package com.sgl.smartpra.batch.mib.app.validator;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.common.collect.Multimap;
import com.sgl.smartpra.batch.mib.app.enums.ErrorCode;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingConstants;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.mib.entity.MiscBillingInvLineitemDtlEntity;
import com.sgl.smartpra.mib.entity.MiscBillingInvLineitemEntity;
import com.sgl.smartpra.mib.entity.MiscBillingTrnInvoiceEntity;

@Component
public class LineItemDetailValidator {

	@Autowired
	private CommonValidator commonValidator;
	
	@Autowired
    private LineItemValidator lineItemValidator;
	
    @Autowired
    private TaxDetailsValidator taxDetailValidator;
    
    @Autowired
    private AddOnChargeDetailsValidator addOnChargeDetailsValidator;
	
	@Autowired
	private SupportingDetailValidator supportingDetailValidator;
	   
	public void validateLineItemsDetails(MiscBillingInvLineitemDtlEntity lineitemDtlEntity, Multimap<String, ExceptionTransactionModel> mErrorCode) {

		MiscBillingInvLineitemEntity lineItemEntity = lineitemDtlEntity.getMiscBillingInvLineitem();
		MiscBillingTrnInvoiceEntity invoiceEntity = lineItemEntity.getMiscBillingTrnInvoice();
		String invoiceNo = commonValidator.getInvoiceNo();
		Integer lineItemNumber = lineItemEntity.getLineItemNumber();
		Integer lineItemDtlNumber = lineitemDtlEntity.getLineItemDetailNumber();
		commonValidator.requiredValidationForLineItemDetail(MiscBillingConstants.DESCRIPTION,
						lineitemDtlEntity.getDescription(), mErrorCode, lineItemNumber, 
						lineItemDtlNumber, MiscBillingPredicates.isEmptyObject());
		commonValidator.requiredValidationForLineItemDetail(MiscBillingConstants.START_DATE,
						lineitemDtlEntity.getStartDate(), mErrorCode, lineItemNumber,
						lineItemDtlNumber, MiscBillingPredicates.isEmptyObject());
		commonValidator.requiredValidationForLineItemDetail(MiscBillingConstants.END_DATE,
						lineitemDtlEntity.getEndDate(), mErrorCode, lineItemNumber, 
						lineItemDtlNumber, MiscBillingPredicates.isEmptyObject());
		commonValidator.requiredValidationForLineItemDetail(MiscBillingConstants.QUANTITY,
						lineitemDtlEntity.getQuantity(), mErrorCode, lineItemNumber, 
						lineItemDtlNumber, MiscBillingPredicates.isEmptyObject());
		commonValidator.requiredValidationForLineItemDetail(MiscBillingConstants.UNIT_PRICE,
						lineitemDtlEntity.getUnitPrice(), mErrorCode, lineItemNumber, 
						lineItemDtlNumber, MiscBillingPredicates.isEmptyObject());
		commonValidator.requiredValidationForLineItemDetail(MiscBillingConstants.CHARGE_AMOUNT,
						lineitemDtlEntity.getChargeAmt(), mErrorCode, lineItemNumber, 
						lineItemDtlNumber, MiscBillingPredicates.isEmptyObject());
		commonValidator.requiredValidationForLineItemDetail(MiscBillingConstants.TOTAL_NET_AMOUNT,
						lineitemDtlEntity.getTotalNetAmt(), mErrorCode, lineItemNumber, 
						lineItemDtlNumber, MiscBillingPredicates.isEmptyObject());

		if (commonValidator.isRequired(commonValidator.getChargeCodeObj(), MiscBillingPredicates.isProductIdRequired())) {
			if(commonValidator.isValueEmpty(lineitemDtlEntity.getProductId(), MiscBillingPredicates.isEmptyObject())) {
				commonValidator.requiredValidationForLineItemDetail(MiscBillingConstants.PRODUCT_ID,
							lineitemDtlEntity.getProductId(), mErrorCode, lineItemNumber, 
							lineItemDtlNumber, MiscBillingPredicates.isEmptyObject());
			}
		}
		
		Map<String, String> map = new HashMap<>();
		if (!lineItemValidator.validateStartDate(lineitemDtlEntity.getStartDate(), lineitemDtlEntity.getEndDate())) {
			map = new HashedMap<>();
			map.put("Start Date", String.valueOf(lineitemDtlEntity.getStartDate()));
			map.put("End Date", String.valueOf(lineitemDtlEntity.getEndDate()));
			map.put("Invoice No.", invoiceNo);
			commonValidator.setErrorCode(mErrorCode, map, ErrorCode.MISC1105);
		}
		if (!lineItemValidator.validateEndDate(lineitemDtlEntity.getStartDate(), lineitemDtlEntity.getEndDate(),
				invoiceEntity.getBillingMonth(), invoiceEntity.getBillingPeriod(), map = new HashMap<>())) {
			map.put("Invoice No.", invoiceNo);
			commonValidator.setErrorCode(mErrorCode, map, ErrorCode.MISC1106);
		}
		if (!lineItemValidator.validateChargeAmount(lineitemDtlEntity.getQuantity(),
				lineitemDtlEntity.getUnitPrice(), lineitemDtlEntity.getChargeAmt())) {
			map = new HashedMap<>();
			map.put("Charge Amount", String.valueOf(lineitemDtlEntity.getChargeAmt()));
			map.put("Invoice No.", invoiceNo);
			map.put("Quantity", String.valueOf(lineitemDtlEntity.getQuantity()));
			map.put("Unit Price", String.valueOf(lineitemDtlEntity.getUnitPrice()));
			commonValidator.setErrorCode(mErrorCode, map, ErrorCode.MISC1108);
		}
		if (!lineItemValidator.validateTotalNetAmount(lineitemDtlEntity.getChargeAmt(),
				lineitemDtlEntity.getTaxAmt(), lineitemDtlEntity.getVatAmt(),
			lineitemDtlEntity.getAddOnChargeAmt(), lineitemDtlEntity.getTotalNetAmt())) {
			map = new HashedMap<>();
			map.put("Invoice No.", invoiceNo);
			map.put("Line item No.", String.valueOf(lineitemDtlEntity.getLineItemNumber()));
			commonValidator.setErrorCode(mErrorCode, map, ErrorCode.MISC1109);
		}
		if (commonValidator.isRequired(commonValidator.getChargeCodeObj(), MiscBillingPredicates.isLocationCodeRequiredForChargeCode())) {
			if(commonValidator.isValueEmpty(lineItemEntity.getLocationCode(), MiscBillingPredicates.isEmptyObject())) {
				map = new HashedMap<>();
				map.put("Charge Code",commonValidator.getChargeCode());
				map.put("Invoice No.",commonValidator.getInvoiceNo());
				commonValidator.setErrorCode(mErrorCode, map, ErrorCode.MISC2014);
			}
		}
		if (commonValidator.isRequired(commonValidator.getChargeCodeObj(), MiscBillingPredicates.isProductIdRequired())) {
			if(commonValidator.isValueEmpty(lineItemEntity.getProductId(), MiscBillingPredicates.isEmptyObject())) {
				map = new HashedMap<>();
				map.put("Charge Code",commonValidator.getChargeCode());
				map.put("Invoice No.",commonValidator.getInvoiceNo());
				commonValidator.setErrorCode(mErrorCode,map, ErrorCode.MISC2014);
			}
		}
		if (commonValidator.isRequired(commonValidator.getChargeCodeObj(), MiscBillingPredicates.isPoLineItemRequired())) {
			if(commonValidator.isValueEmpty(lineItemEntity.getPoLineItemNumber(), MiscBillingPredicates.isEmptyObject())) {
				map = new HashedMap<>();
				map.put("Charge Code",commonValidator.getChargeCode());
				map.put("Invoice No.",commonValidator.getInvoiceNo());
				commonValidator.setErrorCode(mErrorCode, map, ErrorCode.MISC2015);
			}
		}

		taxDetailValidator.validateTaxDetails(lineitemDtlEntity.getMiscBillingTaxDetails(), mErrorCode, MiscBillingConstants.LINE_ITEM_DETAIL);
		addOnChargeDetailsValidator.validateAddOnDetails(lineitemDtlEntity.getMiscBillingAddOnChargeDtl(), mErrorCode, MiscBillingConstants.LINE_ITEM_DETAIL);
		supportingDetailValidator.validateSupportingDetails(mErrorCode, lineItemNumber,
				lineitemDtlEntity.getLineItemDetailNumber(), lineitemDtlEntity.getMiscBillingSupportingDetail());
				
	}
}
