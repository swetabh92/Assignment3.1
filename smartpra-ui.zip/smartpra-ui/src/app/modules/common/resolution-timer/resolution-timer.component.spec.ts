import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ResolutionTimerComponent } from './resolution-timer.component';

describe('ResolutionTimerComponent', () => {
  let component: ResolutionTimerComponent;
  let fixture: ComponentFixture<ResolutionTimerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ResolutionTimerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ResolutionTimerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
