package com.sgl.smartpra.allocation.master.app.dao;

import java.util.List;

import com.sgl.smartpra.allocation.master.app.entity.AllocationMasterEntity;

public interface AllocationMasterDao {

    AllocationMasterEntity save(AllocationMasterEntity allocationMasterEntity);

    AllocationMasterEntity update(AllocationMasterEntity allocationMasterEntity);

    AllocationMasterEntity findById(Integer allocationMasterId);

    List<AllocationMasterEntity> findAll(List<Integer> fileMappingId);

    List<AllocationMasterEntity> findByModuleLovId(Integer moduleLovId);

}
