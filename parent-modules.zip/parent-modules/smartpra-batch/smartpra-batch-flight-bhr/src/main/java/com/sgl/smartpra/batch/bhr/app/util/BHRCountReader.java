package com.sgl.smartpra.batch.bhr.app.util;

public class BHRCountReader {
	private static BHRCountReader instance = null;

	private static Integer transferCount = 0;
	private static Integer errorCount = 0;
	private static Integer totalCount = 0;

	private BHRCountReader() {

	}

	public static BHRCountReader getInstance() {
		if (instance == null) {
			synchronized (BHRCountReader.class) {
				if (instance == null) {
					instance = new BHRCountReader();
				}
			}
		}
		return instance;
	}

	synchronized public static void incErrorCount() {
		errorCount++;
	}

	synchronized public static void incTransferCount() {
		transferCount++;
	}

	synchronized public static void incTotalCount() {
		totalCount++;
	}

	synchronized public static Integer getErrorCount() {
		return errorCount;
	}

	synchronized public static Integer getTransferCount() {
		return transferCount;
	}

	synchronized public static Integer getTotalCount() {
		return totalCount;
	}

	synchronized public static void resetCounts() {
		transferCount = 0;
		errorCount = 0;
		totalCount = 0;
	}
}
