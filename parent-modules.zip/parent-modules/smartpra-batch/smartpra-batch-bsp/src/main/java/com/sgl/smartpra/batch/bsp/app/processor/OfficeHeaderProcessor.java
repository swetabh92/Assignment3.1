package com.sgl.smartpra.batch.bsp.app.processor;

import org.springframework.batch.core.StepExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.sgl.smartpra.batch.bsp.app.config.FeignConfiguration.CarrierMasterFeignClient;
import com.sgl.smartpra.batch.bsp.app.config.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.batch.bsp.app.domain.staging.BSPStagingDomainObject;
import com.sgl.smartpra.batch.bsp.app.domain.staging.OfficeHeaderWrapperStg;
import com.sgl.smartpra.batch.bsp.app.mapper.OfficeHeaderMapper;
import com.sgl.smartpra.batch.bsp.app.record.BSPBaseRecord;
import com.sgl.smartpra.batch.bsp.app.record.OfficeHeader;

public class OfficeHeaderProcessor extends BSPBaseItemProcessor {
	@Value("#{stepExecution}")
	private StepExecution stepExecution;
	
	@Value("#{jobParameters['clientId']}")
	 String clientId;

	@Autowired
	 SmartpraMasterAppClient smartpraMasterAppClient ;
	
	@Autowired
	 CarrierMasterFeignClient carrierMasterFeignClient;
	
	@Override
	public BSPStagingDomainObject process(BSPBaseRecord bspBaseRecord) throws Exception {

		String bspIdentifier = stepExecution.getJobExecution().getExecutionContext().getString("bspIdentifier");
		String processingDate = stepExecution.getJobExecution().getExecutionContext().getString("processingDate");
		OfficeHeaderWrapperStg officeHeaderWrapperStg = OfficeHeaderMapper
				.mapOfficeHeaderRecord((OfficeHeader) bspBaseRecord, bspIdentifier, processingDate,
						smartpraMasterAppClient,carrierMasterFeignClient,clientId);
		return officeHeaderWrapperStg;
	}
}
