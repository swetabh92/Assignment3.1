import { Component, OnInit, Input, Output, EventEmitter, OnDestroy, ElementRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { GeneralService } from '../../../../commons/services/general.service';
import { UserroleService } from '../../services/userrole.service';
import { Userrole } from '../../models/userrole';
import { Subject } from 'rxjs';
import swal from 'sweetalert2';

@Component({
  selector: 'app-userrole',
  templateUrl: './userrole.component.html',
  styleUrls: ['./userrole.component.css']
})
export class UserroleComponent  implements OnInit, OnDestroy {
  @ViewChild('closeModalAdd') closeModalAdd: ElementRef;
  @ViewChild('closeModalEdit') closeModalEdit: ElementRef;
  dtOptions: any = {};
  // We use this trigger because fetching the list of persons can be quite long,
  // thus we ensure the data is fetched before rendering
  dtTrigger: Subject<any> = new Subject<any>();
  public renderDT = false;
  createdBy = 'admin';
  lastUpdatedBy = 'admin';
  collapse_search_form = true;
  box_search_status = true;
  addNewForm: FormGroup;
  addNewsubmitted = false;
  editNewForm: FormGroup;
  editsubmitted = false;
  searchForm: FormGroup;
  searchsubmitted = false;
  searchresult = false;
  searchstring = '';
  checkdata: any;
  userrolesList$: any;
  previewUrl = '';
  constructor(private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder,
    private generalService: GeneralService,
    private userroleservice: UserroleService,
  ) { }

  ngOnInit() {
    this.dtOptions = {
      searching: false, // to hide the search field in the data table top
      pagingType: 'full_numbers',
      lengthMenu: [[5, 10, 25, 50, -1], [5, 10, 25, 50, 'All']], // used to display records size( no of rows)
      language: {
        lengthMenu: 'Page size _MENU_',
        paginate: {
          next: '<i style="color:#0079c1" class="fa fa-angle-right fa-lg"></i>',
          previous: '<i style="color:#0079c1" class="fa fa-angle-left fa-lg"></i>',
          first: '<i style="color:#0079c1" class="fa fa-step-backward"></i>',
          last: '<i style="color:#0079c1" class="fa fa-step-forward"></i>'
        }
      },
      dom: 'tflrp<"datatableclass"i>',
      // used for fixed columns
      // scrollX: true,
      // scrollY: 'auto',
      // scrollCollapse: true,
      // fixedColumns:   {
      //   leftColumns: 2,
      //   rightColumns: 2
      // },
      // end of fixed columns
      // disable search and order
      // aoColumnDefs: [{ bSortable: false, aTargets: [0, 4, 5] }],
      columnDefs: [
        {
          'searchable': false,
          'orderable': false,
          'targets': [-1, -2]
        }
      ],
      // end of disable search and order
    };
    this.GetAlluserroles();
    this.addNewForm = this.formBuilder.group({
      createdBy: [''], // , Validators.required],
      masRoleId: [''], // , Validators.required],
      masUserRoleId: [''], // , Validators.required],
      masUsersId: [''], // , Validators.required],
    });
    this.editNewForm = this.formBuilder.group({
      lastUpdatedBy: [''],
      masRoleId: [''], // , Validators.required],
      masUserRoleId: [''], // , Validators.required],
      masUsersId: [''], // , Validators.required],
    });
    this.searchForm = this.formBuilder.group({
      active: ['', ],
    });
  }
  showSearchBox(e) {
    this.box_search_status = !this.box_search_status;
    this.collapse_search_form = true;
  }
  collapseSearchform(event) {
    const targetclass = event.target.className;
    // console.log(targetclass);
    // this.collapse_search_form = !this.collapse_search_form;
    if (targetclass === 'btn btn-box-tool fa fa-angle-up') {
      this.collapse_search_form = !this.collapse_search_form;
      event.target.className = 'btn btn-box-tool fa fa-angle-down';
    } else if (targetclass === 'btn btn-box-tool fa fa-angle-down') {
      this.collapse_search_form = !this.collapse_search_form;
      event.target.className = 'btn btn-box-tool fa fa-angle-up';
    }
  }
  onResetSearch() {
    this.searchForm.reset();
    this.renderDT = false;
    this.GetAlluserroles();
  }
  onSearch() {

  }
  GetAlluserroles() {
    this.userroleservice.getUserroleAll().subscribe((res: any[]) => {
      this.userrolesList$ = res;
      setTimeout(() => {
        this.renderDT = true;
      }, 100);
    });
  }
  get f() { return this.addNewForm.controls; }

  onResetAdd() {
    this.addNewForm.reset();
  }
  addNewuserrole(): void {
    this.addNewsubmitted = true;
    // stop here if form is invalid
    if (this.addNewForm.invalid) {
      return;
    } else {
      this.userroleservice.addUserrole(this.addNewForm.value).subscribe(
        userroleservice => {
          // console.log(userroleservice);
          if (!!userroleservice && userroleservice.masUserRoleId) {
            this.userrolesList$.push(userroleservice);
            this.closeModalAdd.nativeElement.click();
            swal(
              'Success',
              'New Records Addeded',
              'success'
            );
            this.onResetAdd();
          }
        });
    }
  }
  get u() { return this.editNewForm.controls; }
  showEditvalues(getId) {
    this.userroleservice.UserroleByUserroleId(getId).subscribe(
      userroleservice => {
        if (!!userroleservice && userroleservice.masUserRoleId) {
          this.userrolesList$ = userroleservice;
        } else {
          swal(
            'Error',
            'Error fetching record',
            'error'
          );
        }
      });
  }
  onResetEdit() {
  }
  editNewuserrole() {
    this.editsubmitted = true;
    // console.log(this.editNewForm);
    // stop here if form is invalid
    if (this.editNewForm.invalid) {
      swal(
        'Error',
        'sorry error in the form',
        'error'
      );
      return;
    } else {
      // console.log(this.editNewForm.value); return;
      this.userroleservice.updateUserrole(this.editNewForm.value).subscribe(
        userroleservice => {
          if (!!userroleservice && userroleservice.masUserRoleId) {
            const ix = userroleservice ? this.userrolesList$.findIndex(h => h.masUserRoleId === userroleservice.masUserRoleId) : -1;
            if (ix > -1) { this.userrolesList$[ix] = userroleservice; }
            this.closeModalEdit.nativeElement.click();
            swal(
              'Updated!',
              'Userrole has been Updated.',
              'success'
            );
          }
        });
    }
  }
  removeafterDeactivate(user: Userrole): void {
    this.userrolesList$ = this.userrolesList$.filter(h => h !== user);
  }
  changeStatususerrole(userrole, e, Id) {
    if (e.target.checked) {
      swal({
        type: 'warning',
        title: 'Are you sure to activate this userrole?',
        text: 'You will not be able to recover the data of userrolesprofile',
        showCancelButton: true,
        confirmButtonColor: '#049F0C',
        cancelButtonColor: '#ff0000',
        confirmButtonText: 'Yes, activate it!',
        cancelButtonText: 'No, keep it deactivated',
        closeOnClickOutside: false,
        closeOnEsc: false,
        allowOutsideClick: false,
      } as any).then((result) => {
        if (result.value) {
          this.userroleservice.activateUserrole(Id).subscribe(
            data => {
              console.log('data->' + data);
            }, error => {
              console.log('error->' + error);
            });
          swal(
            'Activated!',
            'userrolesprofile has been activated.',
            'success'
          );
        } else if (
          // Read more about handling dismissals
          result.dismiss === swal.DismissReason.cancel
        ) {
          e.target.checked = false;
          swal(
            'Cancelled',
            'userrolesprofile is status unchanged',
            'error'
          );
        }
      });
    } else {
      swal({
        type: 'warning',
        title: 'Are you sure to deactivate this userrole?',
        text: 'You will not be able to recover the data of userrolesprofile',
        showCancelButton: true,
        confirmButtonColor: '#049F0C',
        cancelButtonColor: '#ff0000',
        confirmButtonText: 'Yes, deactivate it!',
        cancelButtonText: 'No, keep it as active',
        closeOnClickOutside: false,
        closeOnEsc: false,
        allowOutsideClick: false,
      } as any).then((result) => {
        if (result.value) {
          this.userroleservice.deactivateUserrole(Id).subscribe(
            data => {
              console.log('data->' + data);
            }, error => {
              console.log('error->' + error);
            });
          swal(
            'Deactivated!',
            'userrolesprofile has been deactivated.',
            'success'
          );
          this.removeafterDeactivate(userrole);
        } else if (
          // Read more about handling dismissals
          result.dismiss === swal.DismissReason.cancel
        ) {
          e.target.checked = true;
          swal(
            'Cancelled',
            'userrolesprofile is status unchanged',
            'error'
          );
        }
      });
    }
  }

  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }

}
