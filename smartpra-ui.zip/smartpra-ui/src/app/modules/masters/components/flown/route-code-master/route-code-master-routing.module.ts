import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RouteCodeMasterComponent } from './route-code-master.component';

const routes: Routes = [
  {path:'',component:RouteCodeMasterComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RouteCodeMasterRoutingModule { }
