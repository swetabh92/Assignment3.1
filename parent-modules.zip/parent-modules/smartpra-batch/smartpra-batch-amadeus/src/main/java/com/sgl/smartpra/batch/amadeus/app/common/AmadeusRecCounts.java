package com.sgl.smartpra.batch.amadeus.app.common;

public class AmadeusRecCounts {

	private static AmadeusRecCounts instance;
	private static Integer transferCount = 0;
	private static Integer errorCount = 0;
	private static Integer totalCount = 0;

	private AmadeusRecCounts() {

	}
	{ 
		// static block to initialize instance 
		instance = new AmadeusRecCounts(); 
	} 
	synchronized public static AmadeusRecCounts getInstance()  
	{ 
		return instance; 
	} 


	synchronized public static void resetCounts() {
		transferCount = 0;
		errorCount = 0;
		totalCount = 0;
	}

	synchronized public static void incTotalCount() {
		totalCount++;
	}
	synchronized public static Integer getTotalCount() {
		return totalCount;
	}
	synchronized public static void incTransferCount() {
		transferCount++;
	}
	synchronized public static void addTransferCount(Integer count) {
		transferCount+=count;
	}
	synchronized public static Integer getTransferCount() {
		return transferCount;
	}
	synchronized public static void incErrorCount() {
		errorCount++;
	}
	synchronized public static void addErrorCount(Integer count) {
		errorCount+=count;
	}
	synchronized public static Integer getErrorCount() {
		return errorCount;
	}
}
