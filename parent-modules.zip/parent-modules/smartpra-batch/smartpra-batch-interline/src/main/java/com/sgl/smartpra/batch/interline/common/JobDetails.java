package com.sgl.smartpra.batch.interline.common;

import java.util.Map;

import lombok.Data;

@Data
public class JobDetails {
	String jobName;
	Map<String, String> jobParams;
}
