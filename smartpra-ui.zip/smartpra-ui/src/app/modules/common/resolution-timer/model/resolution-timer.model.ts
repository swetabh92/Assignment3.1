export class ResolutionTimerModel {
  startTime: any;
  endTime: any;
  taskId: number;
  userId: number;
  hideFloater:boolean = true;
  isTimerOnHold:boolean = false;
  resolutionTime: any;
}

export class GlobalTaskModel {
  taskId: number;
  startTime: any;
  endTime: any;
}
