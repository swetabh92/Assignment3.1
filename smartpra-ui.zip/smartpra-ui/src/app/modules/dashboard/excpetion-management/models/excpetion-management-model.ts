import {FormGroup, FormArray} from "@angular/forms";
import {DatepickerOptions} from "ng2-datepicker";
import {Injectable} from "@angular/core";
import {
  getAssignExceptionErrorMsg, getExceptionDateConfig,
  getExceptionForm,
  getExceptionValidationMessage,
  getUserForm, ModulesEnum
} from "./excpetion-resolution-model";
import {PaginationService} from "../../../../commons/services/pagination/pagination.service";
import {ExceptionTransactionModel} from "./excpetion-transaction-model";

@Injectable()
export class ExceptionManagementModel {

  constructor(private paginateService: PaginationService) {
  }

  page: any = this.paginateService.setCustomPaginationConfig({"pageSize": 5});
  userForm: FormGroup;
  userFormObj: any = getUserForm();
  exceptionForm: any = getExceptionForm();
  groupArr: any;
  teamArr: any;
  userArr: any;
  moduleName: any;
  selectedModuleId: number = -1;
  selected = [];
  searchSubmitted = false;
  searchForm: FormGroup;
  resultData: ExceptionTransactionModel;
  modulesList: any = [];
  exceptionStatus: any;
  searchFormErrorsList: any = getExceptionValidationMessage();
  assignFormErrorList: any = getAssignExceptionErrorMsg();
  selectUsersFlag: any;
  moduleIdFlag: boolean = false;
  onAssignSelected: boolean = false;
  options: DatepickerOptions = getExceptionDateConfig();
  moduleEnum = ModulesEnum();
  activeTab: any = 'open_exception';
  taskForm: FormGroup;
  taskList: FormArray;
  taskSubmitted: boolean;
  pendingApprovalData: any;
  isUserComponentVisible: boolean = false;
  approvedOrRejectData:any;
  remarks:string;
  advanceSearch: boolean = false;
  searchParams: any;
}
