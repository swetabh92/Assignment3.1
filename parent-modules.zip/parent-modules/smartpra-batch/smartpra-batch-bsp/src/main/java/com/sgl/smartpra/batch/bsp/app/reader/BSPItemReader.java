package com.sgl.smartpra.batch.bsp.app.reader;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemStreamException;
import org.springframework.batch.item.ItemStreamReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.FlatFileParseException;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.mapping.PatternMatchingCompositeLineMapper;
import org.springframework.batch.item.file.transform.LineTokenizer;
import org.springframework.batch.item.support.SingleItemPeekableItemReader;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.bsp.app.record.AdditionalCardInfo;
import com.sgl.smartpra.batch.bsp.app.record.AdditionalItineraryData;
import com.sgl.smartpra.batch.bsp.app.record.AddlInfoFormOfPayment;
import com.sgl.smartpra.batch.bsp.app.record.AddlInfoPassenger;
import com.sgl.smartpra.batch.bsp.app.record.AddlTaxesInfo;
import com.sgl.smartpra.batch.bsp.app.record.BSPBaseRecord;
import com.sgl.smartpra.batch.bsp.app.record.BSPRecordType;
import com.sgl.smartpra.batch.bsp.app.record.BillingCycleHeader;
import com.sgl.smartpra.batch.bsp.app.record.BillingCycleTotals;
import com.sgl.smartpra.batch.bsp.app.record.CardAuthInfo;
import com.sgl.smartpra.batch.bsp.app.record.Commission;
import com.sgl.smartpra.batch.bsp.app.record.CouponTaxInformation;
import com.sgl.smartpra.batch.bsp.app.record.DocumentAmounts;
import com.sgl.smartpra.batch.bsp.app.record.EMDCouponDetail;
import com.sgl.smartpra.batch.bsp.app.record.EMDRemarks;
import com.sgl.smartpra.batch.bsp.app.record.FareCalculation;
import com.sgl.smartpra.batch.bsp.app.record.FileHeader;
import com.sgl.smartpra.batch.bsp.app.record.FileTotals;
import com.sgl.smartpra.batch.bsp.app.record.FormOfPayment;
import com.sgl.smartpra.batch.bsp.app.record.ItineraryDataSegment;
import com.sgl.smartpra.batch.bsp.app.record.NettingValues;
import com.sgl.smartpra.batch.bsp.app.record.OfficeHeader;
import com.sgl.smartpra.batch.bsp.app.record.OfficeSubtotals;
import com.sgl.smartpra.batch.bsp.app.record.OfficeTotals;
import com.sgl.smartpra.batch.bsp.app.record.QualIssueInfo;
import com.sgl.smartpra.batch.bsp.app.record.RelatedTicketDocumentInfo;
import com.sgl.smartpra.batch.bsp.app.record.StdDocumentAmounts;
import com.sgl.smartpra.batch.bsp.app.record.TDSCardAuthInfo;
import com.sgl.smartpra.batch.bsp.app.record.TaxOnCommission;
import com.sgl.smartpra.batch.bsp.app.record.TicketDocumentIdentification;
import com.sgl.smartpra.batch.bsp.app.record.TransactionHeader;
import com.sgl.smartpra.batch.bsp.app.record.TransactionRecord;
import com.sgl.smartpra.batch.bsp.app.record.UnticketedPointInfo;

@Component
@StepScope
public class BSPItemReader implements ItemStreamReader<BSPBaseRecord> {

	private SingleItemPeekableItemReader<BSPBaseRecord> delegate;

	@Value("${batch.directory.bsp.input}")
	private String batchInputDir;

	@BeforeStep
	public void beforeStep(StepExecution stepExecution) {
		FlatFileItemReader<BSPBaseRecord> fileReader = new FlatFileItemReader<BSPBaseRecord>();
		fileReader.setResource(new FileSystemResource(
				batchInputDir + File.separator + stepExecution.getJobParameters().getString("fileName")));
		// get the version number
		String handbookRevisionNumber = stepExecution.getJobExecution().getExecutionContext()
				.getString("handbookRevisionNumber");
		fileReader.setLineMapper(bspLineMapper(handbookRevisionNumber));
		delegate = new SingleItemPeekableItemReader<BSPBaseRecord>();
		delegate.setDelegate(fileReader);
	}

	@Override
	public void open(ExecutionContext executionContext) throws ItemStreamException {
		delegate.open(executionContext);
	}

	@Override
	public void update(ExecutionContext executionContext) throws ItemStreamException {
		delegate.update(executionContext);
	}

	@Override
	public void close() throws ItemStreamException {
		delegate.close();

	}

	@Override
	public BSPBaseRecord read()
			throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {

		TransactionRecord transaction = null;
		BSPBaseRecord bspBaseRecord = null;
		OfficeHeader officeHeader = null;

		while ((bspBaseRecord = (BSPBaseRecord) delegate.read()) != null) {

			switch (bspBaseRecord.getRecordType()) {

			case BSPRecordType.OFFICE_HEADER:
				officeHeader = (OfficeHeader) bspBaseRecord;
				if (isEndOfOfficeHeader()) {
					return officeHeader;
				}
				break;

			case BSPRecordType.TRANSACTION_HEADER:
				if (officeHeader == null) {
					String errorMessage = "Transaction Header Record (" + BSPRecordType.TRANSACTION_HEADER
							+ ") found without corresponding Office Header Record (" + BSPRecordType.OFFICE_HEADER
							+ ")";
					throw new FlatFileParseException(errorMessage, bspBaseRecord.getLine());
				}

				transaction = new TransactionRecord();
				transaction.setTransactionHeader((TransactionHeader) bspBaseRecord);
				transaction.addLine(((TransactionHeader) bspBaseRecord).getLine());
				if (isEndOfTransaction()) {
					officeHeader.addTransactionRecord(transaction);
					transaction = null;
				}
				break;

			case BSPRecordType.TICKET_DOCUMENT_IDENTIFICATION:
				if (transaction == null) {
					String errorMessage = "Ticket/Document Identification Record ("
							+ BSPRecordType.TICKET_DOCUMENT_IDENTIFICATION
							+ ") found without corresponding Transaction Header Record ("
							+ BSPRecordType.TRANSACTION_HEADER + ")";
					throw new FlatFileParseException(errorMessage, bspBaseRecord.getLine());
				}

				transaction.addTicketDocumentIdentification((TicketDocumentIdentification) bspBaseRecord);
				transaction.addLine(((TicketDocumentIdentification) bspBaseRecord).getLine());
				if (isEndOfTransaction()) {
					officeHeader.addTransactionRecord(transaction);
					transaction = null;
				}
				break;

			case BSPRecordType.STD_DOCUMENT_AMOUNTS:
				if (transaction == null) {
					if (transaction == null) {
						String errorMessage = "STD/Document Amounts Record (" + BSPRecordType.STD_DOCUMENT_AMOUNTS
								+ ") found without corresponding Transaction Header Record ("
								+ BSPRecordType.TRANSACTION_HEADER + ")";
						throw new FlatFileParseException(errorMessage, bspBaseRecord.getLine());
					}
				}
				transaction.addStdDocumentAmounts((StdDocumentAmounts) bspBaseRecord);
				transaction.addLine(((StdDocumentAmounts) bspBaseRecord).getLine());
				if (isEndOfTransaction()) {
					officeHeader.addTransactionRecord(transaction);
					transaction = null;
				}
				break;

			case BSPRecordType.COUPON_TAX_INFO:
				if (transaction == null) {
					String errorMessage = "Coupon Tax Information Record (" + BSPRecordType.COUPON_TAX_INFO
							+ ") found without corresponding Transaction Header Record ("
							+ BSPRecordType.TRANSACTION_HEADER + ")";
					throw new FlatFileParseException(errorMessage, bspBaseRecord.getLine());
				}
				transaction.addCouponTaxInformation((CouponTaxInformation) bspBaseRecord);
				transaction.addLine(((CouponTaxInformation) bspBaseRecord).getLine());
				if (isEndOfTransaction()) {
					officeHeader.addTransactionRecord(transaction);
					transaction = null;
				}
				break;

			case BSPRecordType.COMMISSION:
				if (transaction == null) {
					String errorMessage = "Commission Record (" + BSPRecordType.COMMISSION
							+ ") found without corresponding Transaction Header Record ("
							+ BSPRecordType.TRANSACTION_HEADER + ")";
					throw new FlatFileParseException(errorMessage, bspBaseRecord.getLine());
				}
				transaction.addCommission((Commission) bspBaseRecord);
				transaction.addLine(((Commission) bspBaseRecord).getLine());
				if (isEndOfTransaction()) {
					officeHeader.addTransactionRecord(transaction);
					transaction = null;
				}
				break;

			case BSPRecordType.TAX_ON_COMMISSION:
				if (transaction == null) {
					String errorMessage = "Tax on Commission Record (" + BSPRecordType.TAX_ON_COMMISSION
							+ ") found without corresponding Transaction Header Record ("
							+ BSPRecordType.TRANSACTION_HEADER + ")";
					throw new FlatFileParseException(errorMessage, bspBaseRecord.getLine());
				}
				transaction.addTaxOnCommission((TaxOnCommission) bspBaseRecord);
				transaction.addLine(((TaxOnCommission) bspBaseRecord).getLine());
				if (isEndOfTransaction()) {
					officeHeader.addTransactionRecord(transaction);
					transaction = null;
				}
				break;

			case BSPRecordType.RELATED_TICKET_DOCUMENT_INFO:
				if (transaction == null) {
					String errorMessage = "Related Ticket/Document Information Record ("
							+ BSPRecordType.RELATED_TICKET_DOCUMENT_INFO
							+ ") found without corresponding Transaction Header Record ("
							+ BSPRecordType.TRANSACTION_HEADER + ")";
					throw new FlatFileParseException(errorMessage, bspBaseRecord.getLine());
				}
				transaction.addRelatedTicketDocumentInfo((RelatedTicketDocumentInfo) bspBaseRecord);
				transaction.addLine(((RelatedTicketDocumentInfo) bspBaseRecord).getLine());
				if (isEndOfTransaction()) {
					officeHeader.addTransactionRecord(transaction);
					transaction = null;
				}
				break;

			case BSPRecordType.QUAL_ISSUE_INFO:
				if (transaction == null) {
					String errorMessage = "Qualifying Issue Information for Sales Transactions Record ("
							+ BSPRecordType.QUAL_ISSUE_INFO
							+ ") found without corresponding Transaction Header Record ("
							+ BSPRecordType.TRANSACTION_HEADER + ")";
					throw new FlatFileParseException(errorMessage, bspBaseRecord.getLine());
				}
				transaction.addQualIssueInfo((QualIssueInfo) bspBaseRecord);
				transaction.addLine(((QualIssueInfo) bspBaseRecord).getLine());
				if (isEndOfTransaction()) {
					officeHeader.addTransactionRecord(transaction);
					transaction = null;
				}
				break;

			case BSPRecordType.NETTING_VALUES:
				if (transaction == null) {
					String errorMessage = "Netting Values Record (" + BSPRecordType.NETTING_VALUES
							+ ") found without corresponding Transaction Header Record ("
							+ BSPRecordType.TRANSACTION_HEADER + ")";
					throw new FlatFileParseException(errorMessage, bspBaseRecord.getLine());
				}
				transaction.addNettingValues((NettingValues) bspBaseRecord);
				transaction.addLine(((NettingValues) bspBaseRecord).getLine());
				if (isEndOfTransaction()) {
					officeHeader.addTransactionRecord(transaction);
					transaction = null;
				}
				break;

			case BSPRecordType.UNTICKETED_POINT_INFO:
				if (transaction == null) {
					String errorMessage = "Unticketed Point Information Record (" + BSPRecordType.UNTICKETED_POINT_INFO
							+ ") found without corresponding Transaction Header Record ("
							+ BSPRecordType.TRANSACTION_HEADER + ")";
					throw new FlatFileParseException(errorMessage, bspBaseRecord.getLine());
				}
				transaction.addUnticketedPointInfo((UnticketedPointInfo) bspBaseRecord);
				transaction.addLine(((UnticketedPointInfo) bspBaseRecord).getLine());
				if (isEndOfTransaction()) {
					officeHeader.addTransactionRecord(transaction);
					transaction = null;
				}
				break;

			case BSPRecordType.ADDITIONAL_ITINERARY_DATA:
				if (transaction == null) {
					String errorMessage = "Additional Itinerary Data Record (" + BSPRecordType.ADDITIONAL_ITINERARY_DATA
							+ ") found without corresponding Transaction Header Record ("
							+ BSPRecordType.TRANSACTION_HEADER + ")";
					throw new FlatFileParseException(errorMessage, bspBaseRecord.getLine());
				}
				transaction.addAdditionalItineraryData((AdditionalItineraryData) bspBaseRecord);
				transaction.addLine(((AdditionalItineraryData) bspBaseRecord).getLine());
				if (isEndOfTransaction()) {
					officeHeader.addTransactionRecord(transaction);
					transaction = null;
				}
				break;

			case BSPRecordType.ITINERARY_DATA_SEGMENT:
				if (transaction == null) {
					String errorMessage = "Itinerary Data Segment Record (" + BSPRecordType.ITINERARY_DATA_SEGMENT
							+ ") found without corresponding Transaction Header Record ("
							+ BSPRecordType.TRANSACTION_HEADER + ")";
					throw new FlatFileParseException(errorMessage, bspBaseRecord.getLine());
				}
				transaction.addItineraryDataSegment((ItineraryDataSegment) bspBaseRecord);
				transaction.addLine(((ItineraryDataSegment) bspBaseRecord).getLine());
				if (isEndOfTransaction()) {
					officeHeader.addTransactionRecord(transaction);
					transaction = null;
				}
				break;

			case BSPRecordType.DOCUMENT_AMOUNTS:
				if (transaction == null) {
					String errorMessage = "Document Amounts Record (" + BSPRecordType.DOCUMENT_AMOUNTS
							+ ") found without corresponding Transaction Header Record ("
							+ BSPRecordType.TRANSACTION_HEADER + ")";
					throw new FlatFileParseException(errorMessage, bspBaseRecord.getLine());
				}
				transaction.setDocumentAmounts((DocumentAmounts) bspBaseRecord);
				transaction.addLine(((DocumentAmounts) bspBaseRecord).getLine());
				if (isEndOfTransaction()) {
					officeHeader.addTransactionRecord(transaction);
					transaction = null;
				}
				break;

			case BSPRecordType.ADDITIONAL_INFO_PASSENGER:
				if (transaction == null) {
					String errorMessage = "Additional Information–Passenger Record ("
							+ BSPRecordType.ADDITIONAL_INFO_PASSENGER
							+ ") found without corresponding Transaction Header Record ("
							+ BSPRecordType.TRANSACTION_HEADER + ")";
					throw new FlatFileParseException(errorMessage, bspBaseRecord.getLine());
				}
				transaction.setAddlInfoPassenger((AddlInfoPassenger) bspBaseRecord);
				transaction.addLine(((AddlInfoPassenger) bspBaseRecord).getLine());
				if (isEndOfTransaction()) {
					officeHeader.addTransactionRecord(transaction);
					transaction = null;
				}
				break;

			case BSPRecordType.ADDITIONAL_INFO_FORM_OF_PAYMENT:
				if (transaction == null) {
					String errorMessage = "Additional Information–Form of Payment Record ("
							+ BSPRecordType.ADDITIONAL_INFO_FORM_OF_PAYMENT
							+ ") found without corresponding Transaction Header Record ("
							+ BSPRecordType.TRANSACTION_HEADER + ")";
					throw new FlatFileParseException(errorMessage, bspBaseRecord.getLine());
				}
				transaction.addAddlInfoFormOfPayment((AddlInfoFormOfPayment) bspBaseRecord);
				transaction.addLine(((AddlInfoFormOfPayment) bspBaseRecord).getLine());
				if (isEndOfTransaction()) {
					officeHeader.addTransactionRecord(transaction);
					transaction = null;
				}
				break;

			case BSPRecordType.ADDITIONAL_TAX_INFO:
				if (transaction == null) {
					String errorMessage = "Additional Tax Information Record (" + BSPRecordType.ADDITIONAL_TAX_INFO
							+ ") found without corresponding Transaction Header Record ("
							+ BSPRecordType.TRANSACTION_HEADER + ")";
					throw new FlatFileParseException(errorMessage, bspBaseRecord.getLine());
				}
				transaction.addAddlTaxesInfo((AddlTaxesInfo) bspBaseRecord);
				transaction.addLine(((AddlTaxesInfo) bspBaseRecord).getLine());
				if (isEndOfTransaction()) {
					officeHeader.addTransactionRecord(transaction);
					transaction = null;
				}
				break;

			case BSPRecordType.EMD_COUPON_DETAIL:
				if (transaction == null) {
					String errorMessage = "Electronic Miscellaneous Document Coupon Detail Record ("
							+ BSPRecordType.EMD_COUPON_DETAIL
							+ ") found without corresponding Transaction Header Record ("
							+ BSPRecordType.TRANSACTION_HEADER + ")";
					throw new FlatFileParseException(errorMessage, bspBaseRecord.getLine());
				}
				transaction.addEMDCouponDetail((EMDCouponDetail) bspBaseRecord);
				transaction.addLine(((EMDCouponDetail) bspBaseRecord).getLine());
				if (isEndOfTransaction()) {
					officeHeader.addTransactionRecord(transaction);
					transaction = null;
				}
				break;

			case BSPRecordType.EMD_REMARKS:
				if (transaction == null) {
					String errorMessage = "Electronic Miscellaneous Document Remarks Record ("
							+ BSPRecordType.EMD_REMARKS + ") found without corresponding Transaction Header Record ("
							+ BSPRecordType.TRANSACTION_HEADER + ")";
					throw new FlatFileParseException(errorMessage, bspBaseRecord.getLine());
				}
				transaction.addEMDRemarks((EMDRemarks) bspBaseRecord);
				transaction.addLine(((EMDRemarks) bspBaseRecord).getLine());
				if (isEndOfTransaction()) {
					officeHeader.addTransactionRecord(transaction);
					transaction = null;
				}
				break;

			case BSPRecordType.FARE_CALCULATION:
				if (transaction == null) {
					String errorMessage = "Fare Calculation Record (" + BSPRecordType.FARE_CALCULATION
							+ ") found without corresponding Transaction Header Record ("
							+ BSPRecordType.TRANSACTION_HEADER + ")";
					throw new FlatFileParseException(errorMessage, bspBaseRecord.getLine());
				}
				transaction.addFareCalculation((FareCalculation) bspBaseRecord);
				transaction.addLine(((FareCalculation) bspBaseRecord).getLine());
				if (isEndOfTransaction()) {
					officeHeader.addTransactionRecord(transaction);
					transaction = null;
				}
				break;

			case BSPRecordType.ADDITIONAL_CARD_INFO:
				if (transaction == null) {
					String errorMessage = "Additional Card Information Record (" + BSPRecordType.ADDITIONAL_CARD_INFO
							+ ") found without corresponding Transaction Header Record ("
							+ BSPRecordType.TRANSACTION_HEADER + ")";
					throw new FlatFileParseException(errorMessage, bspBaseRecord.getLine());
				}
				transaction.addAdditionalCardInfo((AdditionalCardInfo) bspBaseRecord);
				transaction.addLine(((AdditionalCardInfo) bspBaseRecord).getLine());
				if (isEndOfTransaction()) {
					officeHeader.addTransactionRecord(transaction);
					transaction = null;
				}
				break;

			case BSPRecordType.CARD_AUTH_INFO:
				if (transaction == null) {
					String errorMessage = "Card Authentication Information Record (" + BSPRecordType.CARD_AUTH_INFO
							+ ") found without corresponding Transaction Header Record ("
							+ BSPRecordType.TRANSACTION_HEADER + ")";
					throw new FlatFileParseException(errorMessage, bspBaseRecord.getLine());
				}
				transaction.addCardAuthInfo((CardAuthInfo) bspBaseRecord);
				transaction.addLine(((CardAuthInfo) bspBaseRecord).getLine());
				if (isEndOfTransaction()) {
					officeHeader.addTransactionRecord(transaction);
					transaction = null;
				}
				break;

			case BSPRecordType.TDS_CARD_AUTH_INFO:
				if (transaction == null) {
					String errorMessage = "3DS Card Authentication Information Record ("
							+ BSPRecordType.TDS_CARD_AUTH_INFO
							+ ") found without corresponding Transaction Header Record ("
							+ BSPRecordType.TRANSACTION_HEADER + ")";
					throw new FlatFileParseException(errorMessage, bspBaseRecord.getLine());
				}
				transaction.addTDSCardAuthInfo((TDSCardAuthInfo) bspBaseRecord);
				transaction.addLine(((TDSCardAuthInfo) bspBaseRecord).getLine());
				if (isEndOfTransaction()) {
					officeHeader.addTransactionRecord(transaction);
					transaction = null;
				}
				break;

			case BSPRecordType.FORM_OF_PAYMENT:
				if (transaction == null) {
					String errorMessage = "Form of Payment Record (" + BSPRecordType.FORM_OF_PAYMENT
							+ ") found without corresponding Transaction Header Record ("
							+ BSPRecordType.TRANSACTION_HEADER + ")";
					throw new FlatFileParseException(errorMessage, bspBaseRecord.getLine());
				}
				transaction.addFormOfPayment((FormOfPayment) bspBaseRecord);
				transaction.addLine(((FormOfPayment) bspBaseRecord).getLine());
				if (isEndOfTransaction()) {
					officeHeader.addTransactionRecord(transaction);
					transaction = null;
				}
				break;

			case BSPRecordType.OFFICE_SUBTOTALS_PER_TRANCODE_CURRTYPE:
				if (officeHeader == null) {
					String errorMessage = "Office Subtotals per Transaction Code and Currency Type Record ("
							+ BSPRecordType.OFFICE_SUBTOTALS_PER_TRANCODE_CURRTYPE
							+ ") found without corresponding Office Header Record (" + BSPRecordType.OFFICE_HEADER
							+ ")";
					throw new FlatFileParseException(errorMessage, bspBaseRecord.getLine());
				}

				officeHeader.addOfficeSubtotals((OfficeSubtotals) bspBaseRecord);
				if (isEndOfOfficeHeader()) {
					return officeHeader;
				}
				break;

			default:
				if (officeHeader != null) {
					String errorMessage = "Office Header Record (" + BSPRecordType.OFFICE_HEADER
							+ ") not completed properly.";
					throw new FlatFileParseException(errorMessage, bspBaseRecord.getLine());

				}
				return bspBaseRecord;

			}
		}

		return bspBaseRecord;

	}

	private boolean isEndOfOfficeHeader() throws UnexpectedInputException, ParseException, Exception {
		// peek what is coming next
		BSPBaseRecord nextRecord = (BSPBaseRecord) delegate.peek();

		if (nextRecord == null) {
			return true;
		}

		if (nextRecord.getRecordType().equals(BSPRecordType.OFFICE_TOTALS_PER_CURRTYPE)) {
			return true;
		}

		return false;
	}

	private boolean isEndOfTransaction() throws UnexpectedInputException, ParseException, Exception {
		// peek what is coming next
		BSPBaseRecord nextRecord = (BSPBaseRecord) delegate.peek();

		if (nextRecord == null) {
			return true;
		}

		String nextRecordType = nextRecord.getRecordType();

		switch (nextRecordType) {

		case BSPRecordType.TICKET_DOCUMENT_IDENTIFICATION:
		case BSPRecordType.STD_DOCUMENT_AMOUNTS:
		case BSPRecordType.COUPON_TAX_INFO:
		case BSPRecordType.COMMISSION:
		case BSPRecordType.TAX_ON_COMMISSION:
		case BSPRecordType.RELATED_TICKET_DOCUMENT_INFO:
		case BSPRecordType.QUAL_ISSUE_INFO:
		case BSPRecordType.NETTING_VALUES:
		case BSPRecordType.UNTICKETED_POINT_INFO:
		case BSPRecordType.ADDITIONAL_ITINERARY_DATA:
		case BSPRecordType.ITINERARY_DATA_SEGMENT:
		case BSPRecordType.DOCUMENT_AMOUNTS:
		case BSPRecordType.ADDITIONAL_INFO_PASSENGER:
		case BSPRecordType.ADDITIONAL_INFO_FORM_OF_PAYMENT:
		case BSPRecordType.ADDITIONAL_TAX_INFO:
		case BSPRecordType.EMD_COUPON_DETAIL:
		case BSPRecordType.EMD_REMARKS:
		case BSPRecordType.FARE_CALCULATION:
		case BSPRecordType.ADDITIONAL_CARD_INFO:
		case BSPRecordType.CARD_AUTH_INFO:
		case BSPRecordType.TDS_CARD_AUTH_INFO:
		case BSPRecordType.FORM_OF_PAYMENT:
			return false;
		default:
			return true;
		}
	}

	public LineMapper<BSPBaseRecord> bspLineMapper(String handbookRevisionNumber) {

		PatternMatchingCompositeLineMapper<BSPBaseRecord> mapper = new PatternMatchingCompositeLineMapper<>();

		Map<String, LineTokenizer> tokenizers = new HashMap<String, LineTokenizer>(100);

		tokenizers.put("BFH????????01*", (new FileHeader().lineTokenizer(handbookRevisionNumber)));
		tokenizers.put("BCH????????02*", (new BillingCycleHeader().lineTokenizer(handbookRevisionNumber)));
		tokenizers.put("BOH????????03*", (new OfficeHeader().lineTokenizer(handbookRevisionNumber)));
		tokenizers.put("BKT????????06*", (new TransactionHeader().lineTokenizer(handbookRevisionNumber)));
		tokenizers.put("BKS????????24*", (new TicketDocumentIdentification().lineTokenizer(handbookRevisionNumber)));
		tokenizers.put("BKS????????30*", (new StdDocumentAmounts().lineTokenizer(handbookRevisionNumber)));
		tokenizers.put("BKS????????31*", (new CouponTaxInformation().lineTokenizer(handbookRevisionNumber)));
		tokenizers.put("BKS????????39*", (new Commission().lineTokenizer(handbookRevisionNumber)));
		tokenizers.put("BKS????????42*", (new TaxOnCommission().lineTokenizer(handbookRevisionNumber)));
		tokenizers.put("BKS????????45*", (new RelatedTicketDocumentInfo().lineTokenizer(handbookRevisionNumber)));
		tokenizers.put("BKS????????46*", (new QualIssueInfo().lineTokenizer(handbookRevisionNumber)));
		tokenizers.put("BKS????????47*", (new NettingValues().lineTokenizer(handbookRevisionNumber)));
		tokenizers.put("BKI????????61*", (new UnticketedPointInfo().lineTokenizer(handbookRevisionNumber)));
		tokenizers.put("BKI????????62*", (new AdditionalItineraryData().lineTokenizer(handbookRevisionNumber)));
		tokenizers.put("BKI????????63*", (new ItineraryDataSegment().lineTokenizer(handbookRevisionNumber)));
		tokenizers.put("BAR????????64*", (new DocumentAmounts().lineTokenizer(handbookRevisionNumber)));
		tokenizers.put("BAR????????65*", (new AddlInfoPassenger().lineTokenizer(handbookRevisionNumber)));
		tokenizers.put("BAR????????66*", (new AddlInfoFormOfPayment().lineTokenizer(handbookRevisionNumber)));
		tokenizers.put("BAR????????67*", (new AddlTaxesInfo().lineTokenizer(handbookRevisionNumber)));
		tokenizers.put("BMD????????75*", (new EMDCouponDetail().lineTokenizer(handbookRevisionNumber)));
		tokenizers.put("BMD????????76*", (new EMDRemarks().lineTokenizer(handbookRevisionNumber)));
		tokenizers.put("BKF????????81*", (new FareCalculation().lineTokenizer(handbookRevisionNumber)));
		tokenizers.put("BCC????????82*", (new AdditionalCardInfo().lineTokenizer(handbookRevisionNumber)));
		tokenizers.put("BCC????????83*", (new CardAuthInfo().lineTokenizer(handbookRevisionNumber)));
		tokenizers.put("BCX????????83*", (new TDSCardAuthInfo().lineTokenizer(handbookRevisionNumber)));
		tokenizers.put("BKP????????84*", (new FormOfPayment().lineTokenizer(handbookRevisionNumber)));
		tokenizers.put("BOT????????93*", (new OfficeSubtotals().lineTokenizer(handbookRevisionNumber)));
		tokenizers.put("BOT????????94*", (new OfficeTotals().lineTokenizer(handbookRevisionNumber)));
		tokenizers.put("BCT????????95*", (new BillingCycleTotals().lineTokenizer(handbookRevisionNumber)));
		tokenizers.put("BFT????????99*", (new FileTotals().lineTokenizer(handbookRevisionNumber)));

		mapper.setTokenizers(tokenizers);

		Map<String, FieldSetMapper<BSPBaseRecord>> mappers = new HashMap<String, FieldSetMapper<BSPBaseRecord>>();

		mappers.put("BFH????????01*", (new FileHeader().fieldSetMapper()));
		mappers.put("BCH????????02*", (new BillingCycleHeader().fieldSetMapper()));
		mappers.put("BOH????????03*", (new OfficeHeader().fieldSetMapper()));
		mappers.put("BKT????????06*", (new TransactionHeader().fieldSetMapper()));
		mappers.put("BKS????????24*", (new TicketDocumentIdentification().fieldSetMapper()));
		mappers.put("BKS????????30*", (new StdDocumentAmounts().fieldSetMapper()));
		mappers.put("BKS????????31*", (new CouponTaxInformation().fieldSetMapper()));
		mappers.put("BKS????????39*", (new Commission().fieldSetMapper()));
		mappers.put("BKS????????42*", (new TaxOnCommission().fieldSetMapper()));
		mappers.put("BKS????????45*", (new RelatedTicketDocumentInfo().fieldSetMapper()));
		mappers.put("BKS????????46*", (new QualIssueInfo().fieldSetMapper()));
		mappers.put("BKS????????47*", (new NettingValues().fieldSetMapper()));
		mappers.put("BKI????????61*", (new UnticketedPointInfo().fieldSetMapper()));
		mappers.put("BKI????????62*", (new AdditionalItineraryData().fieldSetMapper()));
		mappers.put("BKI????????63*", (new ItineraryDataSegment().fieldSetMapper()));
		mappers.put("BAR????????64*", (new DocumentAmounts().fieldSetMapper()));
		mappers.put("BAR????????65*", (new AddlInfoPassenger().fieldSetMapper()));
		mappers.put("BAR????????66*", (new AddlInfoFormOfPayment().fieldSetMapper()));
		mappers.put("BAR????????67*", (new AddlTaxesInfo().fieldSetMapper()));
		mappers.put("BMD????????75*", (new EMDCouponDetail().fieldSetMapper()));
		mappers.put("BMD????????76*", (new EMDRemarks().fieldSetMapper()));
		mappers.put("BKF????????81*", (new FareCalculation().fieldSetMapper()));
		mappers.put("BCC????????82*", (new AdditionalCardInfo().fieldSetMapper()));
		mappers.put("BCC????????83*", (new CardAuthInfo().fieldSetMapper()));
		mappers.put("BCX????????83*", (new TDSCardAuthInfo().fieldSetMapper()));
		mappers.put("BKP????????84*", (new FormOfPayment().fieldSetMapper()));
		mappers.put("BOT????????93*", (new OfficeSubtotals().fieldSetMapper()));
		mappers.put("BOT????????94*", (new OfficeTotals().fieldSetMapper()));
		mappers.put("BCT????????95*", (new BillingCycleTotals().fieldSetMapper()));
		mappers.put("BFT????????99*", (new FileTotals().fieldSetMapper()));

		mapper.setFieldSetMappers(mappers);

		return mapper;
	}
}
