import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedModule } from 'src/app/shared/shared.module';
import {RoleFuntionActionComponent} from "./role-funtion-action.component";
import {RolefunctionRoutingModule} from "./rolefunction-routing.module";
import { CoreDataModule } from 'src/app/core-data/core-data.module';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    CoreDataModule,
    RolefunctionRoutingModule
  ],
  declarations: [
    RoleFuntionActionComponent
  ]
})
export class RolefunctionModule { }
