import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RouteCodeMasterComponent } from './route-code-master.component';

describe('RouteCodeMasterComponent', () => {
  let component: RouteCodeMasterComponent;
  let fixture: ComponentFixture<RouteCodeMasterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RouteCodeMasterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RouteCodeMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
