import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup} from '@angular/forms';
import {DatepickerOptions} from 'ng2-datepicker';

@Component({
  selector: 'app-exception-trend',
  templateUrl: './exception-trend.component.html',
  styleUrls: ['./exception-trend.component.css']
})
export class ExceptionTrendComponent implements OnInit {
  showBarChart: boolean;
  fileStatus : any;
  inInterfaceTabChange: any;
  exceptionTrendsChange: boolean=false;
  exceptionTrendForm:FormGroup;
   fileTypesArr=[];

  constructor(private formBuilder:FormBuilder) { }


  private var;
  date = new Date();
  options: DatepickerOptions = {
    displayFormat: 'YYYY/MM/DD',
    useEmptyBarTitle: false,
    addClass: 'currency-date-picker',
    fieldId: 'currency-date-picker-id',
    addStyle: {'width': '100%'},

    maxDate:new Date(this.date.getFullYear(),this.date.getMonth()+1,0),
  };
  moduleName: any = {
    'Sale': ['BSP', 'ARC', 'ASR', 'SITA HOT', 'Amadeus HOT'],
    'Uplift': ['Sabre XL', 'VCR', 'AmadeusEtkt', 'Sita E-txt', 'SSIM'],
    'Interline': ['IS-IDEC', 'IS-MISC', 'CodeShare'],
    'Other': ['PMP', 'Exch.Rate'],
  };
  ngOnInit() {
     this.exceptionTrendForm = this.formBuilder.group({
       module: [''],
     })
  }
  onModuleChange(event) {
    const moduleKey = event.currentTarget.value;

    this.fileTypesArr = [];
    const moduleArr = this.moduleName[moduleKey];
    for (let i = 0; i < moduleArr.length; i++) {
      this.fileTypesArr.push(moduleArr[i]);
    }

  }
  openExceptionTrends(){
    this.exceptionTrendsChange = true;
  }
  in_interface_tab_change(type){
    this.inInterfaceTabChange=type;
  } 
  openGraph() {
    this.showBarChart = !this.showBarChart;
    // this.showFileDataIn_Interface =  ! this.showFileDataIn_Interface;
  }
  public barChartOptions = {
    scaleShowVerticalLines: false,
    responsive: true,
    // maintainAspectRatio: false,	
    scales: {
      xAxes: [{
        barPercentage: 0.9
      }],
      yAxes: [{
        ticks: {
          max: 1000,
          min: 0,
          stepSize: 100,
        }
      }],
    },
    legend: { position: 'top' }

  };
  public barChartLabels = ['Jan-19', 'Dec-18', 'Nov-18', 'Oct-18', 'Sep-18', 'Aug-18', 'Jul-18'];
  public barChartType = 'bar';
  public barChartLegend = true;
  public colors: Array<any> = [
    { // first color
      backgroundColor: '#5abae0',
      borderColor: 'red',
      pointBackgroundColor: 'red',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'red'
    },
    { // second color
      backgroundColor: '#0577b3',
      borderColor: 'green',
      pointBackgroundColor: 'green',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'green'
    }];
  public barChartData = [
    { data: [65, 59, 80, 81, 56, 55, 40], label: 'IS-IDEC' },
    { data: [28, 48, 40, 19, 86, 27, 90], label: 'IS-MISC' },
  ];



}

$(document).ready(function () {
  $(".tbtn").click(function () {
    $(this).parents(".custom-table").find(".toggler1").removeClass("toggler1");
    $(this).parents("tbody").find(".toggler").addClass("toggler1");
    $(this).parents(".custom-table").find(".fa-minus-circle").removeClass("fa-minus-circle");
    $(this).parents("tbody").find(".fa-plus-circle").addClass("fa-minus-circle");
  });

});	
