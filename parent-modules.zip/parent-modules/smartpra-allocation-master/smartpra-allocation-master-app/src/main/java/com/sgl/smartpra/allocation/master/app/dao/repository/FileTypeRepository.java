package com.sgl.smartpra.allocation.master.app.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.sgl.smartpra.allocation.master.app.entity.FileTypeEntity;

public interface FileTypeRepository
		extends JpaRepository<FileTypeEntity, Integer>, JpaSpecificationExecutor<FileTypeEntity> {
	
	@Query("select a from FileTypeEntity a  where a.fileTypeId IN :fileTypeIds and (:clientId is null or a.clientId = :clientId) ")
	public List<FileTypeEntity> findByFileTypeId(@Param("fileTypeIds") List<Integer> fileTypeIds , @Param("clientId") String clientId);

}
