package com.sgl.smartpra.batch.interline.common;

public class InterlineBatchConstants {
	
	public static final String CREATED_BY_INTERLINE = "INTERLINE";
	
	public static final String PROCESSED_BY_MANUAL = "Manual";
	
	public static final String PROCESSED_BY_SCHEDULER = "Scheduler";
	
	public static final String DDMMYY_FORMAT = "ddMMyy";

	public static final String YYYYMMDD_FORMAT = "yyyyMMdd";
	
	public static final String INVALID_DATE_FORMAT = "Invalid Date Format";

	public static final String PARAM_DEFAULT_CARRIER_NUMERIC_CODE = "DEFAULT_CARRIER_NUMERIC_CODE";

	public static final String PARAM_DEFAULT_CARRIER_ALPHA_CODE = "DEFAULT_CARRIER_ALPHA_CODE";
	
	public static final String CARRIER_NUMERIC_CODE = "Carrier Numeric Code";

	public static final String CARRIER_ALPHA_CODE = "Carrier Alpha code";
	
	public static final String INVOKE_SUCCESS = "Interline Batch job has been invoked and completed successfully...";
	
	public static final String INVOKE_FAILURE = "Interline Batch job has been invoked and execution failed...";
	
	public static final String PARTIAL_TRANSFER = "Due to errors in the file only partial records transferred...";
	
	public static final String[] FORM3_SQL_MAPPING = { "REPORT_TYPE", "CLEARANCE", "REPORT_OF_MEMBER", "ZONE_OF_MEMBER", "ZONE_CODE", "MEMBER_CLEARING", "CURRENCY_CLEARANCE", "PAX_AMOUNT", "UATP_AMOUNT ", "CARGO_AMOUNT", "MISC_AMOUNT",	"TOTAL_DEBIT_AMOUNT", "TOTAL_CREDIT_AMOUNT", "TOTAL_BALANCE", "EXCHANGE_RATE", "CURRENCY_OF_SETTLEMENT"};

	public static final Integer MODULE_ID = 1;

	public static final String FILECATEGORY_CSV = "CSV";
	
	public static final String FILETYPE_FORM3 = "FORM3";
	
	public static final String FILETYPE_IDEC = "IDEC";
	
	public static final String FILE_ID = "fileId";
	
	public static final String FILE_NAME = "fileName";
	
	public static final String JOB_NAME = "jobName";
	
	public static final String TIME = "time";
	
	public static final String STAGING = "Staging";
	
	public static final String PRODUCTION = "Production";
	
	public static final String Y = "Y";
	
	public static final String N = "N";
	
	public static final String REGEX_ONLY_NUMBERS = "^[0-9]*$";
	
	public static final String REGEX_ONLY_LETTERS = "^[a-zA-Z]*$";
	
	public static final String REGEX_NUM_LETTERS = "[a-zA-Z0-9]*";
	
	public static final String REGEX_EMPTY = ".*\\w.*";
	
	public static final int MAX_THREADS = 10;

	public static final String STG2PROD_DATA_TRANSFER_JOB = "stg2ProdDataTransferJob";

	public static final String INVOICE_IDS = "invoiceIds";
	
}
