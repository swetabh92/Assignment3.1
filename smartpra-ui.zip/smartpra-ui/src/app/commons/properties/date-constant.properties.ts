export const DateConstant = {
    DATE : 'dd/MM/yyyy',
    MONTHYEAR : 'MMM-YY'
}