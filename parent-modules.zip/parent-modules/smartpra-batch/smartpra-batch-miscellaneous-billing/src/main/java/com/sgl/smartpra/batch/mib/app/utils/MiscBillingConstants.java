package com.sgl.smartpra.batch.mib.app.utils;

public class MiscBillingConstants {
	
	private MiscBillingConstants() {}
	
	//Common constants
	public static final String UNDERSCORE="_";
	public static final String SLASH="\\";
	public static final String SINGLE_SPCACE=" ";

	public static final String PARAM_DEFAULT_CARRIER_ALPHA_CODE = "DEFAULT_CARRIER_ALPHA_CODE";
	public static final String PARAM_DEFAULT_CARRIER_NUMERIC_CODE = "DEFAULT_CARRIER_NUMERIC_CODE";
	public static final String PARAM_DEFAULT_CURRENCY_CODE = "DEFAULT_CURRENCY_CODE";
	public static final String PARAM_DEFAULT_PROCESSING_MANAGER = "Default_Processing_Manager";
	
	public static final String BATCHJOB_SUCCESS = "SUCCESS";
	public static final String BATCHJOB_FAILED = "FAILED";
	public static final String CREATEDBY = "MISC_BLNG_BATCH";
	public static final String UPDATEDBY = "MISC_BLNG_BATCH";
	
	//File Logging Constants
	public static final String FILELOGGING_MODULE="Misc Billing";
	public static final Integer MODULE_ID = 4;
	public static final String FILELOGGING_SOURCE="SIS";
	
	public static final String FILE_EXTENSION=".xml";
	public static final String MISC_BILLING_IN_JOB_NAME ="inwardIataXmlJob";
	public static final String MISC_BILLING_OUT_JOB_NAME ="outwardIataXmlJob";
	public static final String MISC_BILLING_FILENAME_CONSTANT="MXMLT-";

	public static final String DIR_INPUT = "input";
	public static final String DIR_PROCESSED = "processed";
	public static final String DIR_FAILED = "failed";
	public static final String DIR_DUPLICATE = "duplicate";
	public static final String DIR_OUTPUT = "output";
	
	public static final String IATA_XML_FILE = "MXMLT-31220190402.xml";
	public static final String INVOICE_TRANSMISSION = "InvoiceTransmission";
	public static final String YES = "Y";
	public static final String NO = "N";
	public static final String TOTAL_AMOUNT = "AMT";
	public static final String ADD_ON_CHARGE = "AOC";
	public static final String VAT = "VAT";
	public static final String TAX = "TAX";
	public static final String INWARD = "I";
	public static final String OUTWARD = "O";
	public static final String DIGITAL_SIGNATURE_DEFAULT = "D";
	public static final String EMPTY_STRING = "";
	public static final String INVOICE = "Invoice";
	public static final String CREDIT_NOTE = "CreditNote";
	public static final String I = "I";
	public static final String C = "C";
	public static final String LINE_ITEM = "LineItem";
	public static final String LINE_ITEM_DETAIL = "LineItemDetail";
	public static final String DETAIL = "Detail";
	
	public static final String BUYER = "Buyer";
	public static final String SELLER = "Seller";
	
	public static final String STATUS="Status";
	public static final String START_POSITION = "Start Position";
	public static final String END_POSITION = "End Position";
	public static final String ELEMENT_NAME = "Element Name";
	
	public static final String BILLED = "Billed";
	public static final String ACCEPTED = "Accepted";
	public static final String DIFFERENCE = "Difference";
	
	public static final String MAIL_DETAILS = "MailDetails";
	public static final String AIRCRAFT_DETAILS = "AircraftDetails";
	public static final String FLIGHT_DETAILS = "FlightDetails";
	public static final String ROUTE_DETAILS = "RouteDetails";
	public static final String PARKING_DETAILS = "ParkingDetails";
	public static final String EMPLOYEE_DETAILS = "EmployeeDetails";
	public static final String AREA_DETAILS = "AreaDetails";
	public static final String DESKGATES_DETAILS = "DeskGateDetails";
	public static final String CONSUMPTION_DETAILS = "ConsumptionDetails";
	public static final String SETTLEMENT_DETAILS = "SettlementDetails";
	public static final String SERVICE_PROVIDER_DETAILS = "ServiceProviderDetails";
	public static final String ACCOMODATION_DETAILS = "AccommodationDetails";
	public static final String CAR_DETAILS = "CarDetails";
	public static final String UATP_DETAILS = "UATPDetails";
	public static final String PASSENGER_DETAILS = "PassengerDetails";
	public static final String CATERING_DETAILS = "CateringDetails";
	public static final String MISC_DETAILS = "MiscDetails";
	public static final String COUPON_DETAILS = "CouponDetails";
	public static final String SAMPLINGFORMD_DETAILS = "SamplingFormDDetails";
	public static final String AIRWAYBILL_DETAILS = "AirWaybillDetails";
	public static final String REJECTION_MEMO_DETAILS = "RejectionMemoDetails";
	public static final String BILLING_MEMO_DETAILS = "BillingMemoDetails";
	public static final String CREDIT_MEMO_DETAILS = "CreditMemoDetails";
	public static final String CONTRACT_NO = "ContractNo";
	public static final String POOL_NO = "PoolNo";
	public static final String RECEIPT_NO = "ReceiptNo";
	public static final String REFERENCE_NO = "ReferenceNo";
	public static final String RECIPIENT = "Recipient";
	public static final String MISHANDLING_TYPE = "MishandlingType";
	
	public static final String STATUS_OPEN = "OP";
	
	public static final String BKR = "BKR";
	public static final String USD = "USD";
	public static final String INR = "INR";
	
	//Exception codes
	public static final String MISC9001 = "MISC9001";
	public static final String MISC9002 = "MISC9002";
	public static final String MISC9003 = "MISC9003";
	public static final String MISC9004 = "MISC9004";
	public static final String MISC1001 = "MISC1001";
	public static final String MISC1002 = "MISC1002";
	public static final String MISC1003 = "MISC1003";
	public static final String MISC1004 = "MISC1004";
	public static final String MISC1005 = "MISC1005";
	public static final String MISC9006 = "MISC9006";
	public static final String MISC1006 = "MISC1006";
	public static final String MISC1007 = "MISC1007";
	public static final String MISC1008 = "MISC1008";
	public static final String MISC1009 = "MISC1009";
	public static final String MISC1010 = "MISC1010";
	public static final String MISC1011 = "MISC1011";
	public static final String MISC1012 = "MISC1012";
	public static final String MISC1103 = "MISC1103";
	public static final String MISC1104 = "MISC1104";
	public static final String MISC1105 = "MISC1105";
	public static final String MISC1106 = "MISC1106";
	public static final String MISC1107 = "MISC1107";
	public static final String MISC1108 = "MISC1108";
	public static final String MISC1109 = "MISC1109";
	
	public static final String IATA_XSD_PATH = "src/main/resources/xsd/IATA_IS_XML_Invoice_Standard_V3.9.xsd";
	public static final String JAXB_SCHEMA_LOCATION = "http://www.IATA.com/IATAAviationInvoiceStandard http://www.iata.org/services/finance/sis/Documents/schemas/IATA_IS_XML_Invoice_Standard_V3.9.0.1.xsd";
	public static final String MISC1005_P1 = "Element Name(Total Amt/Tax Amt/VAT Amt/Addon)"; 
	public static final String MISC1005_P2 = "Invoice Currency";
	public static final String MISC1005_P3 = "Total element value in all the invoices";
	public static final String INVOICE_NO = "Invoice No.";
	public static final String LOCATION_CODE = "LocationCode";
	public static final String SETTLEMENT_METHOD = "Settlement Method";
	public static final String BILLING_CARRIER_CODE = "Billing Carrier Code";
	public static final String CHARGE_CATEGORY_CODE = "Charge Category Code";
	public static final String CHARGE_CODE_TYPE = "Charge Code Type";
	public static final String PO_LINE_ITEM_NO = "PO Line Item Number";
	public static final String DESCRIPTION = "Discription";
	public static final String PRODUCT_ID = "Product Id";
	public static final String START_DATE = "Start Date";
	public static final String END_DATE = "End Date";
	public static final String ROOT_TAG_NAME = "InvoiceTransmission";
	
	public static final String QUANTITY = "Quantity";
	public static final String UNIT_PRICE = "Unit Price";
	public static final String CHARGE_AMOUNT = "Charge Amount";
	public static final String TOTAL_NET_AMOUNT = "Total Net Amount";
	public static final String LINE_ITEM_NO = "Line Item No.";
	public static final String LINE_ITEM_DTL_NO = "Line item Detail No.";
	public static final String BATCH_INPUT_DIR = "/opt/smartpra/misc_billing/input";
	public static final String TAX_TYPE = "TaxType";
	
	public static final String FILE_NAME_PREFIX = "MXMLF-";
	public static final String TELEPHONE = "Telephone";
	public static final String EMAIL = "Email";
	public static final String FAX = "Fax";
	public static final String TELEX = "Telex";
	public static final String AFTN = "AFTN";
	public static final String SITA = "SITA";
	public static final String WEBSITE = "Website";
	public static final String XML = ".XML";
	public static final String TWENTY = "20";
	public static final String ZERO = "0";
	public static final String IATA_VERSION = "IATA:ISXMLInvoiceV3.9.0.1";
	public static final String BILLING_CATEGORY = "Miscellaneous";
}
