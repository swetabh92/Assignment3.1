package com.sgl.smartpra.batch.mib.app.enums;

public enum InvoiceStatus {
    OPEN("OP"), ERROR("ER");

    String status;

    private InvoiceStatus(String status){
        this.status = status;
    }
}
