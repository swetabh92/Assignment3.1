import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FlownDashboardComponent } from './flown-dashboard.component';

describe('FlownDashboardComponent', () => {
  let component: FlownDashboardComponent;
  let fixture: ComponentFixture<FlownDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FlownDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FlownDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
