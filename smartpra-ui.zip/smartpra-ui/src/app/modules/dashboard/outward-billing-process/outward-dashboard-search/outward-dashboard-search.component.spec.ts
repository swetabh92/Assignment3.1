import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OutwardDashboardSearchComponent } from './outward-dashboard-search.component';

describe('OutwardDashboardSearchComponent', () => {
  let component: OutwardDashboardSearchComponent;
  let fixture: ComponentFixture<OutwardDashboardSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OutwardDashboardSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OutwardDashboardSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
