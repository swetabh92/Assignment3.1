import { Component, OnInit } from '@angular/core';
import { GeneralService } from 'src/app/commons/services/general.service';
import { ChargeCodeService } from 'src/app/modules/masters/services/interline/charge-code/charge-code.service';

@Component({
  selector: 'app-miscellaneous-billing',
  templateUrl: './miscellaneous-billing.component.html',
  styleUrls: ['./miscellaneous-billing.component.css']
})
export class MiscellaneousBillingComponent implements OnInit {

  showChargeCategory: Boolean = true;
  showSectionMaster: Boolean = false;
  headingName: string = "Charge Category & Code Details"

  constructor(private generalService: GeneralService, private chargeCode: ChargeCodeService) { }

  ngOnInit() {
    this.onClickChargeCode();
  }

  setHeading() {
    if (this.showChargeCategory) {
      this.headingName = "Charge Category & Code Details"
    } else {
      this.headingName = "Section Details"
    }
  }

  onClickChargeCode() {
    this.chargeCode.onClickChargeCode.subscribe((data: any) => {
      this.headingName = "Section Details";
      this.showChargeCategory = false;
      this.showSectionMaster = true;
    })
  }


}
