import {Component, OnInit, AfterContentInit, AfterViewInit} from '@angular/core';
import {Router} from '@angular/router';
import {GeneralService} from '../../../commons/services/general.service';
@Component({
  selector: 'app-appregister',
  templateUrl: './appregister.component.html',
  styleUrls: ['./appregister.component.css']
})
export class AppregisterComponent implements OnInit,AfterViewInit{
  passwordViewType = 'password';

  constructor(
    private router: Router,
    private Gservice: GeneralService
    ) { }

  ngAfterViewInit() {
  }
  ngOnInit() {
    this.Gservice.LoadFormSettingJs();
  }
  login() {
      this.router.navigate(['login']);
  }
  register() {
    this.router.navigate(['profile']);
  }
  onClickShowHidePwd(){
    this.passwordViewType = this.passwordViewType == "password" ? "text" : "password";
  }
}
