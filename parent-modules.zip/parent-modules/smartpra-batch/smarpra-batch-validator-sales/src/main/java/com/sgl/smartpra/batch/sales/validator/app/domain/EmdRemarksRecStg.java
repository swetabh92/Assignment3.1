package com.sgl.smartpra.batch.sales.validator.app.domain;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the emd_remarks_rec_stg database table.
 * 
 */
@Entity
@Table(name="emd_remarks_rec_stg")
public class EmdRemarksRecStg extends BSPRecord implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="emd_cpn_remarks_id")
	private int emdCpnRemarksId;

	@Column(name="check_digit")
	private String checkDigit;

	@Column(name="cpn_number")
	private String cpnNumber;

	@Column(name="created_by")
	private String createdBy;

	@Column(name="created_date")
	private Timestamp createdDate;

	@Column(name="date_of_issue")
	private String dateOfIssue;

	@Column(name="emd_remarks")
	private String emdRemarks;

	private String filler;

	@Column(name="last_updated_by")
	private String lastUpdatedBy;

	@Column(name="last_updated_date")
	private Timestamp lastUpdatedDate;

	@Column(name="seq_number")
	private String seqNumber;

	@Column(name="std_message_identifier")
	private String stdMessageIdentifier;

	@Column(name="std_numeric_quaifier")
	private String stdNumericQuaifier;

	@Column(name="tkt_doc_number")
	private String tktDocNumber;

	@Column(name="transaction_number")
	private String transactionNumber;

	//bi-directional many-to-one association to TransactionHdrStg
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.MERGE)
	@JoinColumn(name="transaction_hdr_id")
	private TransactionHdrStg transactionHdrStg;

	public EmdRemarksRecStg() {
	}

	public int getEmdCpnRemarksId() {
		return this.emdCpnRemarksId;
	}

	public void setEmdCpnRemarksId(int emdCpnRemarksId) {
		this.emdCpnRemarksId = emdCpnRemarksId;
	}

	public String getCheckDigit() {
		return this.checkDigit;
	}

	public void setCheckDigit(String checkDigit) {
		this.checkDigit = checkDigit;
	}

	public String getCpnNumber() {
		return this.cpnNumber;
	}

	public void setCpnNumber(String cpnNumber) {
		this.cpnNumber = cpnNumber;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDateOfIssue() {
		return this.dateOfIssue;
	}

	public void setDateOfIssue(String dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}

	public String getEmdRemarks() {
		return this.emdRemarks;
	}

	public void setEmdRemarks(String emdRemarks) {
		this.emdRemarks = emdRemarks;
	}

	public String getFiller() {
		return this.filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}

	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getLastUpdatedDate() {
		return this.lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getSeqNumber() {
		return this.seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdMessageIdentifier() {
		return this.stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getStdNumericQuaifier() {
		return this.stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getTktDocNumber() {
		return this.tktDocNumber;
	}

	public void setTktDocNumber(String tktDocNumber) {
		this.tktDocNumber = tktDocNumber;
	}

	public String getTransactionNumber() {
		return this.transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

	public TransactionHdrStg getTransactionHdrStg() {
		return this.transactionHdrStg;
	}

	public void setTransactionHdrStg(TransactionHdrStg transactionHdrStg) {
		this.transactionHdrStg = transactionHdrStg;
	}
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
/*	@Override
	public LineTokenizer lineTokenizer() {

		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		EmdRemarksStgLayout emdRemarksStgLayout = new EmdRemarksStgLayout();
		tokenizer.setColumns(emdRemarksStgLayout.getColumns());
		tokenizer.setNames(emdRemarksStgLayout.getNames());
		return tokenizer;

	}

	@Override
	public FieldSetMapper<BSPRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<BSPRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<BSPRecord>();
		fieldSetMapper.setTargetType(EmdRemarksRecStg.class);
		return fieldSetMapper;
	}

	@Override
	public ItemProcessor<? extends BSPRecord, ? extends BSPRecord> processor() {
		return new EmdRemarksStgProcessor();
	}

	@Override
	public ItemWriter<? super BSPRecord> writer() {
		return new EmdRemarksStgWriter();
	}*/

}