package com.sgl.smartpra.allocation.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.allocation.master.app.entity.FileTypeMappingEntity;
import com.sgl.smartpra.allocation.master.model.FileTypeMapping;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface FileTypeMappingMapper extends BaseMapper<FileTypeMapping, FileTypeMappingEntity> {
	
}
