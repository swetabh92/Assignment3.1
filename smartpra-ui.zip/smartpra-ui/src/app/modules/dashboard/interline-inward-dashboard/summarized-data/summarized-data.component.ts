import {Component, OnInit, Input, ElementRef, ViewChild, EventEmitter, Output} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {InwardDashboardService} from '../inward-dashboard.service';
import {DatePipe} from '@angular/common';
import {PaginationService} from '../../../../commons/services/pagination/pagination.service';
import {CommonService} from '../../../masters/services/commons/common.service';
import { InterlineConstant } from '../constants/interline-constants';
import { InwardSearchModel, InvoiceSearchModel } from '../models/inward-search-model';
import { MessageBoxService } from '../../../masters/services/commons/message-box.service';
import { BsDatepickerConfig, BsDatepickerViewMode } from 'ngx-bootstrap/datepicker';
declare var moment: any;
import * as _ from 'underscore';

@Component({
  selector: 'app-summarized-data',
  templateUrl: './summarized-data.component.html',
  styleUrls: ['../inward-dashboard.component.css']
})
export class SummarizedDataComponent implements OnInit {
  summarizedDownArrow:boolean = true;
  showSummarizesdDT:boolean = true;
  singleSelectIcon:boolean = true;
  multiSelectIcon:boolean = true;
  form3EditSubmitted:boolean = false;
  form3AddSubmitted:boolean = false;
  productionMode:boolean = false;
  selectedForm3List:any[] = [];
  selectedCoupon:any;
  selectedParams:InvoiceSearchModel;
  page: any;
  recordsForm3: any;
  form3EditFormStaging: FormGroup;
  form3EditFormProd: FormGroup;
  form3AddFormProd: FormGroup;
  statusExpansion = InterlineConstant.STATUS_EXPANSION;
  minMode: BsDatepickerViewMode = 'month';
  bsConfig: Partial<BsDatepickerConfig>;
  maxDate = new Date(Date.now());
  clientID: string;
  clientCode: number;
  @ViewChild('closeModalEdit') closeModalEdit: ElementRef;
  @ViewChild('closeModalAdd') closeModalAdd: ElementRef;
  selectedIDs: any[] = [];
  @Output() invoiceSearchParams = new EventEmitter<any>();
  @Output() form3Empty = new EventEmitter<any>();
  @Output() carriersList = new EventEmitter<any>();
  exceptionsViewlList: any[] = [];
  _requestParams: any;
  get requestParams(): any {
      return this._requestParams;
  }

  @Input('requestParams')
  set requestParams(value: any) {
    this._requestParams = value;
    this.page  = this.paginateService.setCustomPaginationConfig({"pageSize": 5});
    this.loadForm3Data(this._requestParams);
  }

  _airlineUpdateFlag: boolean = true;
  get airlineUpdateFlag(): boolean {
      return this._airlineUpdateFlag;
  }
  @Input('airlineUpdateFlag')
  set airlineUpdateFlag(value: boolean) {
    this._airlineUpdateFlag = value;
  }

  constructor(private paginateService: PaginationService, private commonService: CommonService, private formBuilder: FormBuilder,private inwardService: InwardDashboardService,private messageService: MessageBoxService) {

  }


  ngOnInit() {
    this.clientID = this.commonService.getClientId();
    this.clientCode = this.commonService.getClientCode();
    this.form3EditFormStaging = this.formBuilder.group({
      interlineForm3CsvId:['', Validators.required],
      clearance: ['',[Validators.required]],
      reportOfMember:['',[Validators.required]],
      zoneOfMember: ['',[Validators.required]],
      invoiceCurrency:[''],
      paxAmount: ['',[Validators.required, Validators.pattern('[0-9]+(\.[0-9][0-9]?)?')]],
      cargoAmount:['',[Validators.required, Validators.pattern('[0-9]+(\.[0-9][0-9]?)?')]],
      uatpAmount: ['',[Validators.required, Validators.pattern('[0-9]+(\.[0-9][0-9]?)?')]],
      miscAmount:['',[Validators.required, Validators.pattern('[0-9]+(\.[0-9][0-9]?)?')]],
      reportType:['',[Validators.required]],
      status:[''],
      exchangeRate:['',[Validators.required, Validators.pattern('[0-9]+(\.[0-9][0-9][0-9][0-9][0-9]?)?')]],
      clientId:[''],
      zoneCode:['',[Validators.pattern('[A-D]*'), Validators.minLength(1),  Validators.maxLength(1)]],
      memberClearing:['',[Validators.required]],
      fileId:[''],
      totalDebitAmount: ['',[Validators.required, Validators.pattern('[0-9]+(\.[0-9][0-9]?)?')]],
      totalCreditAmount: ['',[Validators.required, Validators.pattern('[0-9]+(\.[0-9][0-9]?)?')]],
      totalBalance: ['',[Validators.required, Validators.pattern('^-?[0-9]+(\.[0-9][0-9]?)?')]],
      currencyClearance:['',[Validators.pattern('[A-Z]*'), Validators.minLength(3),  Validators.maxLength(3)]],
      currencyOfSettlement:['',[Validators.pattern('[A-Z]*'), Validators.minLength(3),  Validators.maxLength(3)]],
    });
    this.form3EditFormProd = this.formBuilder.group({
      interlineForm3Id: ['', Validators.required],
      clientId:[this.clientID],
      billingAirlineNumCode: ['',[Validators.pattern('[0-9]*'), Validators.minLength(3),  Validators.maxLength(3)]],
      billedAirlineNumCode: ['',[Validators.pattern('[0-9]*'), Validators.minLength(3),  Validators.maxLength(3)]],
      billingMonth: [''],
      billingPeriod:['', Validators.required],
      carrierGroup: ['', Validators.required],
      invoiceCurrency: ['',[Validators.pattern('[A-Z]*'), Validators.minLength(3),  Validators.maxLength(3)]],
      paxAmount: [null,[Validators.required, Validators.pattern('[0-9]+(\.[0-9][0-9]?)?')]],
      cargoAmount: [null,[Validators.required, Validators.pattern('[0-9]+(\.[0-9][0-9]?)?')]],
      uatpAmount: [null,[Validators.required, Validators.pattern('[0-9]+(\.[0-9][0-9]?)?')]],
      miscellaneousAmount: [null,[Validators.required, Validators.pattern('[0-9]+(\.[0-9][0-9]?)?')]],
      debitAmount: [null,[Validators.required, Validators.pattern('[0-9]+(\.[0-9][0-9]?)?')]],
      creditAmount: [null,[Validators.required, Validators.pattern('[0-9]+(\.[0-9][0-9]?)?')]],
      balanceAmount: [null,[Validators.required, Validators.pattern('^-?[0-9]+(\.[0-9][0-9]?)?')]],
    });
    this.form3AddFormProd = this.formBuilder.group({
      clientId:[this.clientID],
      billingAirlineNumCode: ['',[Validators.pattern('[0-9]*'), Validators.minLength(3),  Validators.maxLength(3)]],
      billedAirlineNumCode: [this.clientCode,[Validators.pattern('[0-9]*'), Validators.minLength(3),  Validators.maxLength(3)]],
      billingMonth: ['', Validators.required],
      billingPeriod:['', Validators.required],
      carrierGroup: ['', Validators.required],
      invoiceCurrency: ['',[Validators.pattern('[A-Z]*'), Validators.minLength(3),  Validators.maxLength(3)]],
      paxAmount: [null,[Validators.required, Validators.pattern('[0-9]+(\.[0-9][0-9]?)?')]],
      cargoAmount: [null,[Validators.required, Validators.pattern('[0-9]+(\.[0-9][0-9]?)?')]],
      uatpAmount: ['',[Validators.required, Validators.pattern('[0-9]+(\.[0-9][0-9]?)?')]],
      miscellaneousAmount: ['',[Validators.required, Validators.pattern('[0-9]+(\.[0-9][0-9]?)?')]],
      debitAmount: ['',[Validators.required, Validators.pattern('[0-9]+(\.[0-9][0-9]?)?')]],
      creditAmount: ['',[Validators.required, Validators.pattern('[0-9]+(\.[0-9][0-9]?)?')]],
      balanceAmount: ['',[Validators.required, Validators.pattern('^-?[0-9]+(\.[0-9][0-9]?)?')]],
    });
    this.bsConfig = Object.assign({}, {
      minMode : this.minMode,
      maxDate: this.maxDate,
      dateInputFormat: 'MMM YY'
    });
  }

  changeDateFormat(date:any) {
    let d = new Date(date);
    if(typeof date != "object" && date.indexOf("-") != -1){
      let year = date.split('-');
      return (moment(d).format('MMM')).toUpperCase()+"-"+moment(year[1],'YY').format('YY');
    } else {
      return (moment(d).format('MMM-YY')).toUpperCase();
    }
  }

  get sem() { return this.form3EditFormStaging.controls; }
  get pem() { return this.form3EditFormProd.controls; }
  get pam() { return this.form3AddFormProd.controls; }

	getserverSideData(pageInfo) {
		this.page = this.paginateService.mergePageObj(pageInfo, this.page);
		this.loadForm3Data(this._requestParams);
	}

  loadForm3Data(data: InwardSearchModel) {
    if (data.area && data.area == InterlineConstant.PRODUCTION) {
      this.productionMode = true;
    } else {
      this.productionMode = false;
    }
    this.selectedForm3List = [];
    let paginates = this.paginateService.getQueryObj(this.page);
    this.inwardService.getForm3Data(data, paginates).subscribe((response:any)=> {
      if (response) {
				this.page.count = response.totalCount;
        if(!this.productionMode) {
          this.recordsForm3 = response.form3CsvList;
          if (this.recordsForm3.length > 0 && this.recordsForm3[0])
            this.createInvoiceParams(parseInt(this.recordsForm3[0].billingPeriod), this.recordsForm3[0].billingCarrier);
        } else {
          this.recordsForm3 = response.form3DetailsList;
          if (this.recordsForm3.length > 0 && this.recordsForm3[0])
            this.createInvoiceParams(parseInt(this.recordsForm3[0].billingPeriod), this.recordsForm3[0].billingAirlineNumCode);
        }
        if (this._airlineUpdateFlag && response.airlineList)
          this.carriersList.emit(response.airlineList);
        if (this.recordsForm3.length > 0) {
          this.selectedForm3List = [this.recordsForm3[0]];
          this.selectedCoupon = this.recordsForm3[0];
          if(this.selectedCoupon.transferFlag == "Y") {
            this.singleSelectIcon = true;
            this.multiSelectIcon = true;
          } else {
            this.singleSelectIcon = false;
            this.multiSelectIcon = false;
          }
        } else {
          this.form3Empty.emit();
        }
      }
    });
  }

  onSelectRow(event:any, type?:string, inputevent?:any){
    if(type == InterlineConstant.ALL && event.selected) {
      if (event.selected.length > 0) {
        this.selectedForm3List = event.selected;
      } else {
        this.selectedForm3List = [];
      }
    } else {
      if(inputevent && inputevent.target.checked) {
          this.selectedForm3List.push(event);
          this.selectedCoupon = event;
          if(!this.productionMode)
            this.createInvoiceParams(parseInt(event.billingPeriod),event.billingCarrier);
          else
            this.createInvoiceParams(parseInt(event.billingPeriod),event.billingAirlineNumCode);
      } else {
        if (this.selectedForm3List.length > 0) {
          let ind:number, index:number;
          if(!this.productionMode) {
            ind = this.selectedForm3List.findIndex(item => item['interlineForm3CsvId'] == event['interlineForm3CsvId']);
          } else {
            ind = this.selectedForm3List.findIndex(item => item['interlineForm3Id'] == event['interlineForm3Id']);
          }
          this.selectedForm3List.splice(ind,1);
        }
      }
    }
    if (this.selectedForm3List.length == 1) {
      if(this.selectedCoupon.transferFlag == "Y") {
        this.singleSelectIcon = true;
      } else {
        this.singleSelectIcon = false;
      }
    } else {
      this.singleSelectIcon = true;
    }
    if (this.selectedForm3List.length > 0){
      let transferFlagSuccessList: any[] = [];
      transferFlagSuccessList = this.selectedForm3List.filter(res => res.transferFlag == "Y");
      if(transferFlagSuccessList.length > 0)
        this.multiSelectIcon = true;
      else
        this.multiSelectIcon = false;
    } else {
      this.multiSelectIcon = true;
    }
  }

  onCancelChange(){
    this.closeModalEdit.nativeElement.click();
  }

  createInvoiceParams(billingPeriod:any, billingCarrier: any) {
    this.selectedParams = {
      area: this.requestParams.area,
      billingMonth: this.requestParams.billingMonth,
      billingPeriod: billingPeriod,
      billingCarrier: billingCarrier
    };
    this.invoiceSearchParams.emit(this.selectedParams);
  }

  onResetEdit(){}

  editRecords() {
    if(!this.productionMode) {
      this.form3EditFormStaging.patchValue(this.removeCommaFromAmount(this.selectedCoupon));
    } else {
      this.form3EditFormProd.patchValue(this.selectedCoupon);
    }
  }

  onSave() {
    this.form3AddSubmitted = true;
    if (this.form3AddFormProd.valid) {
      this.form3AddFormProd.value.billingMonth = this.changeDateFormat(this.form3AddFormProd.value.billingMonth);
      this.inwardService.saveForm3ProdData(this.form3AddFormProd.value).subscribe((response:any)=> {
        if (response){
          this.updateDataTable(response, InterlineConstant.ADD);
          this.messageService.getSuccessMessage(InterlineConstant.SUCCESS,'Saved Successfully');
          if (!(response.error))
            this.closeModalAdd.nativeElement.click();
        }
      });
    }
  }

  onUpdate(){
    this.form3EditSubmitted = true;
    if(!this.productionMode) {
      if (this.form3EditFormStaging.valid) {
        this.inwardService.updateForm3StagData(this.form3EditFormStaging.value).subscribe((response:any)=> {
          if (response === null) {
            this.loadForm3Data(this._requestParams);
            this.messageService.getSuccessMessage(InterlineConstant.SUCCESS, InterlineConstant.RECORDUPDATESUCCESS);
            this.closeModalEdit.nativeElement.click();
            //this.updateDataTable(response, InterlineConstant.UPDATE);
          }
        });
      }
    } else {
      if (this.form3EditFormProd.valid) {
        this.form3EditFormProd.value.billingMonth = this.changeDateFormat(this.form3EditFormProd.value.billingMonth);
        this.inwardService.updateForm3ProdData(this.form3EditFormProd.value).subscribe((response:any)=> {
          if (response === null) {
            this.loadForm3Data(this._requestParams);
            this.messageService.getSuccessMessage(InterlineConstant.SUCCESS,InterlineConstant.RECORDUPDATESUCCESS);
            this.closeModalEdit.nativeElement.click();
            //this.updateDataTable(response, InterlineConstant.UPDATE);
          }
        });
      }
    }
  }

  deleteRecords() {
    if(!this.productionMode) {
      this.selectedIDs = this.selectedForm3List.map(res => res.interlineForm3CsvId);
    } else {
      this.selectedIDs = this.selectedForm3List.map(res => res.interlineForm3Id);
    }
    let ids = this.selectedIDs.toString();
    this.messageService.deleteRecordMessage(this.selectedIDs.length).then((result) => {
			if (result.value) {
        if(!this.productionMode) {
          this.inwardService.deleteForm3StgData(ids).subscribe((response:any)=> {
            this.loadForm3Data(this._requestParams);
            this.singleSelectIcon = true;
            this.multiSelectIcon = true;
            this.selectedForm3List = [];
            this.messageService.getSuccessMessage(InterlineConstant.SUCCESS,InterlineConstant.DELETEMESSAGE);
          });
        } else {
          this.inwardService.deleteForm3ProdData(ids).subscribe((response:any)=> {
            this.loadForm3Data(this._requestParams);
            this.singleSelectIcon = true;
            this.multiSelectIcon = true;
            this.selectedForm3List = [];
            this.messageService.getSuccessMessage(InterlineConstant.SUCCESS,InterlineConstant.DELETEMESSAGE);
          });
        }
      }
    });
  }

	updateDataTable(data, type) {
		if (type == InterlineConstant.ADD) {
      this.recordsForm3.unshift(data);
    } else {
			const ind = this.recordsForm3.findIndex((item) => { return data.interlineForm3CsvId == item.interlineForm3CsvId; });
      if (ind == -1) return false;
      if (type == InterlineConstant.UPDATE) {
        this.recordsForm3[ind] = data;
        this.selectedForm3List = [];
        this.singleSelectIcon = true;
      }
		}
		this.recordsForm3 = [...this.recordsForm3];
  }

  validateRecords(){
    this.selectedIDs = this.selectedForm3List.map(res => res.interlineForm3CsvId);
    this.inwardService.validateForm3Data(this.selectedIDs).subscribe((response:any)=> {
      if (response) {
        this.loadForm3Data(this._requestParams);
        this.messageService.getSuccessMessage(InterlineConstant.SUCCESS,'Validated Successfully');
      }
    });
  }

  removeCommaFromAmount(data : any){
    Object.keys(data).forEach((key) => {
      if (data[key] && data[key] !== null && data[key] !== undefined &&(key == 'paxAmount' || key == 'cargoAmount' || key == 'uatpAmount' || key == 'miscAmount' || key == 'miscellaneousAmount' || key == 'totalDebitAmount' || key == 'totalCreditAmount' || key == 'debitAmount' || key == 'creditAmount' || key == 'totalBalance' || key == 'balanceAmount')) {
        if(data[key].indexOf(",") != -1)
          data[key] = data[key].replace(/\,/g,"");
      }
    });
    return data;
  }

  amountForm3StgChanged(event){
    if(event.target.value && !isNaN(event.target.value) && parseFloat(event.target.value) >= 0) {
      let totalDebitAmount = parseFloat(this.form3EditFormStaging.get('paxAmount').value || 0)+parseFloat(this.form3EditFormStaging.get('cargoAmount').value || 0)+parseFloat(this.form3EditFormStaging.get('uatpAmount').value || 0)+ parseFloat(this.form3EditFormStaging.get('miscAmount').value || 0);
      let balance = totalDebitAmount - parseFloat(this.form3EditFormStaging.get('totalCreditAmount').value || 0);
      this.form3EditFormStaging.get('totalDebitAmount').setValue(totalDebitAmount.toFixed(2));// paxAmount+cargoAmount+uatpAmount+miscAmount
      this.form3EditFormStaging.get('totalBalance').setValue(balance.toFixed(2)); //totalDebitAmount - totalCreditAmount
    }
  }

  creditAmountForm3StgChanged(event){
    if(event.target.value && !isNaN(event.target.value) && parseFloat(event.target.value) >= 0) {
      let balance = parseFloat(this.form3EditFormStaging.get('totalDebitAmount').value || 0) - (event.target.value);
      this.form3EditFormStaging.get('totalBalance').setValue(balance.toFixed(2)); //totalDebitAmount - totalCreditAmount
    }
  }

  amountForm3ProdChanged(event){
    if(event.target.value && !isNaN(event.target.value) && parseFloat(event.target.value) >= 0) {
      let totalDebitAmount = parseFloat(this.form3EditFormProd.get('paxAmount').value || 0)+parseFloat(this.form3EditFormProd.get('cargoAmount').value || 0)+parseFloat(this.form3EditFormProd.get('uatpAmount').value || 0)+ parseFloat(this.form3EditFormProd.get('miscellaneousAmount').value || 0);
      let balance = totalDebitAmount - parseFloat(this.form3EditFormProd.get('creditAmount').value || 0);
      this.form3EditFormProd.get('debitAmount').setValue(totalDebitAmount.toFixed(2));// paxAmount+cargoAmount+uatpAmount+miscellaneousAmount
      this.form3EditFormProd.get('balanceAmount').setValue(balance.toFixed(2));//debitAmount - creditAmount
    }
  }

  creditAmountEditProdChanged(event){
    if(event.target.value && !isNaN(event.target.value) && parseFloat(event.target.value) >= 0) {
      let balance = parseFloat(this.form3EditFormProd.get('debitAmount').value || 0) - (event.target.value);
      this.form3EditFormProd.get('balanceAmount').setValue(balance.toFixed(2)); //debitAmount - creditAmount
    }
  }

  amountForm3ProdAddChanged(event){
    if(event.target.value && !isNaN(event.target.value) && parseFloat(event.target.value) >= 0) {
      let totalDebitAmount = parseFloat(this.form3AddFormProd.get('paxAmount').value || 0)+parseFloat(this.form3AddFormProd.get('cargoAmount').value || 0)+parseFloat(this.form3AddFormProd.get('uatpAmount').value || 0)+ parseFloat(this.form3AddFormProd.get('miscellaneousAmount').value || 0);
      let balance = totalDebitAmount - parseFloat(this.form3AddFormProd.get('creditAmount').value || 0);
      this.form3AddFormProd.get('debitAmount').setValue(totalDebitAmount.toFixed(2));// paxAmount+cargoAmount+uatpAmount+miscellaneousAmount
      this.form3AddFormProd.get('balanceAmount').setValue(balance.toFixed(2));//debitAmount - creditAmount
    }
  }

  creditAmountAddProdChanged(event){
    if(event.target.value && !isNaN(event.target.value) && parseFloat(event.target.value) >= 0) {
      let balance = parseFloat(this.form3AddFormProd.get('debitAmount').value || 0) - (event.target.value);
      this.form3AddFormProd.get('balanceAmount').setValue(balance.toFixed(2)); //debitAmount - creditAmount
    }
  }

}

