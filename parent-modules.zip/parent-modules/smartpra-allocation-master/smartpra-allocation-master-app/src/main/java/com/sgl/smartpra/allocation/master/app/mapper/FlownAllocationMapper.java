package com.sgl.smartpra.allocation.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.allocation.master.app.entity.AllocationMasterEntity;
import com.sgl.smartpra.allocation.master.model.AllocationMasterSearchModel;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface FlownAllocationMapper extends BaseMapper<AllocationMasterSearchModel, AllocationMasterEntity>  {

	@Mapping(source = "flightStatus", target = "allocationKey1")
	@Mapping(source = "flightCategory", target = "allocationKey2")
	@Mapping(source = "oal", target = "allocationKey3")
	@Mapping(source = "routeCode", target = "allocationKey4")
	@Mapping(source = "flightFromDate", target = "allocationKey5")
	@Mapping(source = "flightToDate", target = "allocationKey6")
	AllocationMasterEntity mapToEntity(AllocationMasterSearchModel allocationMasterSearchModel);

}
