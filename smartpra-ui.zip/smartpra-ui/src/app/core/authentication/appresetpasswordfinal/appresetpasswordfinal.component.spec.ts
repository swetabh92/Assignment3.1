import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AppresetpasswordfinalComponent } from './appresetpasswordfinal.component';

describe('AppresetpasswordfinalComponent', () => {
  let component: AppresetpasswordfinalComponent;
  let fixture: ComponentFixture<AppresetpasswordfinalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppresetpasswordfinalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppresetpasswordfinalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
