import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AppforgetuseridComponent } from './appforgetuserid.component';

describe('AppforgetuseridComponent', () => {
  let component: AppforgetuseridComponent;
  let fixture: ComponentFixture<AppforgetuseridComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppforgetuseridComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppforgetuseridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
