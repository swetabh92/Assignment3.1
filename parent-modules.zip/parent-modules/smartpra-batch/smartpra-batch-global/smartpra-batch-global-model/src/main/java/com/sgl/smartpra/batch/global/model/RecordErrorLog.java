package com.sgl.smartpra.batch.global.model;

import java.io.Serializable;
import java.math.BigInteger;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.sgl.smartpra.common.model.BaseMaster;

@JsonInclude(Include.NON_NULL)
public class RecordErrorLog extends BaseMaster implements Serializable {
	
	private static final long serialVersionUID = -6315249015227519257L;

	private BigInteger recordErrorId;
	
	private BigInteger fileId;
	
	private Integer recordNumber;
	
	private String recordValue;
	
	private String recordStatus;
	
	private String errorDescription;
	
	private String errorDetail;

	public BigInteger getRecordErrorId() {
		return recordErrorId;
	}

	public void setRecordErrorId(BigInteger recordErrorId) {
		this.recordErrorId = recordErrorId;
	}

	public BigInteger getFileId() {
		return fileId;
	}

	public void setFileId(BigInteger fileId) {
		this.fileId = fileId;
	}

	public Integer getRecordNumber() {
		return recordNumber;
	}

	public void setRecordNumber(Integer recordNumber) {
		this.recordNumber = recordNumber;
	}

	public String getRecordValue() {
		return recordValue;
	}

	public void setRecordValue(String recordValue) {
		this.recordValue = recordValue;
	}

	public String getRecordStatus() {
		return recordStatus;
	}

	public void setRecordStatus(String recordStatus) {
		this.recordStatus = recordStatus;
	}

	public String getErrorDescription() {
		return errorDescription;
	}

	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}

	public String getErrorDetail() {
		return errorDetail;
	}

	public void setErrorDetail(String errorDetail) {
		this.errorDetail = errorDetail;
	}
	
	

}
