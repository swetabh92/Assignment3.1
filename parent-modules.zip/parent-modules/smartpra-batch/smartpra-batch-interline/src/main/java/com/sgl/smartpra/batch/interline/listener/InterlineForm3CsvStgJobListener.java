package com.sgl.smartpra.batch.interline.listener;

import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.beans.factory.annotation.Autowired;

import com.sgl.smartpra.batch.interline.configuration.FeignConfiguration.BatchGlobalFeignClient;
import com.sgl.smartpra.batch.interline.service.BatchJobService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class InterlineForm3CsvStgJobListener implements JobExecutionListener {

	@Autowired
	BatchGlobalFeignClient batchGlobalFeignClient;

	@Autowired
	BatchJobService batchJobService;

	@Override
	public void beforeJob(JobExecution jobExecution) {
		log.info("before job");
	}

	@Override
	public void afterJob(JobExecution jobExecution) {
		log.info("Job Execution Time : "+ ((jobExecution.getEndTime().getTime() - jobExecution.getStartTime().getTime()) / 1000.0) + " seconds");
		if (jobExecution.getStatus() == BatchStatus.COMPLETED) {
			log.info("JOB COMPLETED!!!");
			batchJobService.afterJobConfiguration(jobExecution);
		} else {
			log.error("JOB FAILED!!!");
		}
	}
}
