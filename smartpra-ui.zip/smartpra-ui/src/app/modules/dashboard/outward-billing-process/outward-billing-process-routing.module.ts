import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { OutwardDashboardSearchComponent } from './outward-dashboard-search/outward-dashboard-search.component';

const routes: Routes = [
  {
     path: '',
     component: OutwardDashboardSearchComponent
   }
 ];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class OutwardBillingProcessRoutingModule { }
