import { TestBed } from '@angular/core/testing';

import { MustMatch.ValidatorService } from './must-match.validator.service';

describe('MustMatch.ValidatorService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MustMatch.ValidatorService = TestBed.get(MustMatch.ValidatorService);
    expect(service).toBeTruthy();
  });
});
