import { Directive,Input,OnChanges,ElementRef,HostListener} from '@angular/core';
import { timer } from 'rxjs';
@Directive({
  selector: '[appAutoScroll]'
})
export class AutoScrollDirective  implements OnChanges {
  @Input('scroll-switch') scrollSwitch;
  @Input('scroll-id') scrollId;
  constructor(private el: ElementRef) { }
  @HostListener('click', ['$event.target'])
  onClickn(){
    this.scrollIntoView();
  }
  ngOnChanges(changes) {
     this.scrollIntoView();
  }
  scrollIntoView(){
    if(this.scrollSwitch){
      timer(100).subscribe(()=>{
        const elem = document.getElementById(this.scrollId);
        if(elem){
          let height = elem.getBoundingClientRect().height;
          let elemExpanded = true;
          // if(elem.hasAttribute('aria-expanded')){
          //   if(elem.getAttribute('aria-expanded') == 'true') elemExpanded = true;
          //   else elemExpanded = false;
          // }
          if(height > 0 && elemExpanded){
            elem.scrollIntoView({ behavior: 'smooth', block: 'start' });
          }
        }
      })
    } 
  }
}
