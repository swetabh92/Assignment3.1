import { Component, OnInit, ViewChild, Input, Output, ElementRef, OnDestroy } from '@angular/core';
import { GeneralService } from '../../../../../commons/services/general.service';
import { MessageBoxService } from '../../../services/commons/message-box.service';
import { RegionmasterService } from '../../../services/flown/region-master/regionmaster.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Region } from '../../../models/flown/region.model';
import { RegionCountryMasterComponent } from 'src/app/modules/masters/components/flown/region-master/region-country-master/region-country-master.component';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
declare var $;
import swal from 'sweetalert2';
import { PaginationService } from '../../../../../commons/services/pagination/pagination.service';
import { CountryMasterService } from '../../../services/others/country-master/country-master.service';
import { NgSelectConfig } from '@ng-select/ng-select';
import { CommonService } from '../../../services/commons/common.service';
import { HotkeysService } from 'angular2-hotkeys/src/hotkeys.service';
import { Hotkey } from 'angular2-hotkeys/src/hotkey.model';
import { MasterHotkeys } from '../../../../../commons/properties/master/master-hotkeys.enum'
@Component({
  selector: 'app-region-master',
  templateUrl: './region-master.component.html',
  styleUrls: ['./region-master.component.css']
})
export class RegionMasterComponent implements OnInit, OnDestroy {
  @ViewChild(RegionCountryMasterComponent) child: RegionCountryMasterComponent;
  @ViewChild('closeModalAdd') closeModalAdd: ElementRef;
  @ViewChild('closeModalEdit') closeModalEdit: ElementRef;
  dtOptions: DataTables.Settings = {};
  // We use this trigger because fetching the list of persons can be quite long,
  // thus we ensure the data is fetched before rendering
  dtTrigger: Subject<any> = new Subject<any>();
  public renderDTRegion = false;

  clientId: any;
  formObj: any = {
    clientId: [''],
    regionId: [''],
    regionCode: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(6)]],
    regionName: ['', [Validators.required, Validators.maxLength(30)]],
    continentName: ['', [Validators.required, Validators.maxLength(13)]],
    countryCode: ['', [Validators.required]],
    countryCodeList: [''],
  }

  createdBy = 'admin';
  lastUpdatedBy = 'admin';
  searchstring: any;
  successresult: any;
  regionsList: any = [];
  regiondetail$: any;
  marked = false;
  collapse_search_form = true;
  box_search_status = false;
  addNewRegionForm: FormGroup;
  addNewsubmitted = false;
  editsubmittedForm: FormGroup;
  editsubmitted = false;
  searchForm: FormGroup;
  searchsubmitted = false;
  searchresult = false;
  showRegionDetailsList = false;
  countryArray: any = [];
  error: any = { isError: false, errorMessage: '' };
  formFlag: string = "";
  page: any = this.paginateService.getPageinateConfig();
  countryData: any = [];
  countryDataAdd: any = [];

  constructor(private Gservice: GeneralService, private regionservice: RegionmasterService,
    private formBuilder: FormBuilder, private router: Router, private messageBoxService: MessageBoxService,
    private paginateService: PaginationService, private countryService: CountryMasterService,
    private commonService: CommonService, private hotkeysService: HotkeysService) {
    this.hotkeysService.add(new Hotkey(MasterHotkeys.save, (event: KeyboardEvent): boolean => {
      if (this.formFlag == 'addRegion') {
        this.onSubmit();
      } else if (this.formFlag == 'editRegion') {
        this.onUpdate();
      }
      return false;
    }));

    this.hotkeysService.add(new Hotkey(MasterHotkeys.clear, (event: KeyboardEvent): boolean => {
      if (this.formFlag == 'addRegion') {
        this.onResetAdd();
      } else if (this.formFlag == 'editRegion') {
        this.onResetEdit(this.u.regionId.value)
      } else if (this.formFlag == 'searchRegion') {
        this.onResetSearch()
      }
      return false;
    }));

    this.hotkeysService.add(new Hotkey(MasterHotkeys.cancel, (event: KeyboardEvent): boolean => {
      if (this.formFlag == 'addRegion') {
        this.onCancelChange()
      } else if (this.formFlag == 'editRegion') {
        this.onCancelChange()
      }
      else if (this.formFlag == 'searchRegion') {
        this.showSearchBox(event)
      }
      return false;
    }));

  }

  ngOnInit() {
    this.clientId = this.commonService.getClientId();
    this.GetAllRegions();
    this.GetAllCountries();
    //let orderFalse =  [-1,-2];
    //this.dtOptions = this.Gservice.getDataTableOptionsNew(orderFalse);
    let addForm = Object.assign({}, this.formObj);
    addForm['createdBy'] = 'Admin';
    addForm['clientId'] = this.clientId;
    this.addNewRegionForm = this.formBuilder.group(addForm);
    let editForm = Object.assign({}, this.formObj);
    editForm['lastUpdatedBy'] = 'Admin';
    this.editsubmittedForm = this.formBuilder.group(editForm);

    this.searchForm = this.formBuilder.group({
      regionCode: ['', [Validators.maxLength(6)]],
      regionName: ['', [Validators.maxLength(30)]],
      continentName: ['', [Validators.maxLength(13)]],
      isActive: ['',],
    });
  }



  closeAlertValidation() {
    var tempThis = this;
    window.setTimeout(function () {
      tempThis.error = { isError: false, errorMessage: '' };
    }, 6000);
  }

  updateDataTable(data,type){
		if(type == 'add') this.regionsList.unshift(data);	
		else{
			const ind = this.regionsList.findIndex((item) => { return data.regionId == item.regionId;});
			if(ind == -1) return false;if(type =='update')  this.regionsList[ind] = data;else if(type == 'remove') this.regionsList.splice(ind, 1);
		}
		this.regionsList = [...this.regionsList];
	}

  GetAllRegions(): void {
    this.renderDTRegion = false;
    this.regionservice.getAllRegion().subscribe((res: any[]) => {
      this.regionsList = res;
      setTimeout(() => {
        this.renderDTRegion = true;
      }, 100);
    });
  }

  GetAllCountries(): void {
    this.countryService.getAllCountryCodeName().subscribe((res: any[]) => {
      this.countryArray = res;
    });
  }



  get f() { return this.addNewRegionForm.controls; }
  get u() { return this.editsubmittedForm.controls; }
  get sf() { return this.searchForm.controls }


  onSearch() {
    this.searchsubmitted = true;
    if (this.searchForm.invalid) return false;
    this.searchstring = 'regions?';
    if (this.searchForm.value.regionCode) {
      this.searchstring += 'regionCode=' + this.searchForm.value.regionCode + '&&';
    }
    if (this.searchForm.value.regionName) {
      this.searchstring += 'regionName=' + this.searchForm.value.regionName + '&&';
    }
    if (this.searchForm.value.continentName) {
      this.searchstring += 'continentName=' + this.searchForm.value.continentName + '&&';
    }
    if (this.searchForm.value.isActive) {
      this.searchstring += 'isActive=' + this.searchForm.value.isActive + '&&';
    }
    this.renderDTRegion = false;
    this.regionservice.searchRegion(this.searchstring).subscribe(
      regionservice => {
        this.regionsList = regionservice;
        setTimeout(() => {
          this.renderDTRegion = true;
        }, 100);

      });
  }

  onResetSearch(): void {
    this.searchForm.reset();
    this.renderDTRegion = false;
    this.GetAllRegions();
  }

  showSearchBox(e): void {
    this.box_search_status = !this.box_search_status;
    this.collapse_search_form = true;
  }

  onSubmit(): void {
    this.addNewsubmitted = true;
    if (this.addNewRegionForm.invalid) {
      return;
    } else {
      const data = this.addNewRegionForm.value.countryCodeList.substring(0, 1);
      this.addNewRegionForm.value.countryCodeList = data == "," ? this.addNewRegionForm.value.countryCodeList.substring(1) : this.addNewRegionForm.value.countryCodeList;
      const region = Object.assign({}, this.addNewRegionForm.value);
      delete (region.countryCode);
      delete (region.regionId);
      this.regionservice.addRegion(region).subscribe(
        regionservice => {
          if (!!regionservice && regionservice.regionId) {
            this.updateDataTable(regionservice, 'add');
            this.closeModalAdd.nativeElement.click();
            this.error = { isError: true, errorMessage: "Record has been successfully saved" };
            this.closeAlertValidation();
            this.onResetAdd();
          }
        });
    }
  }

  onResetAdd() {
    this.countryDataAdd = [];
    this.addNewRegionForm.reset();
    this.editsubmittedForm.markAsPristine();
    this.editsubmittedForm.markAsUntouched();
    this.editsubmittedForm.updateValueAndValidity();
    this.addNewsubmitted = false;
    this.addNewRegionForm.patchValue({
      createdBy: 'admin',
      clientId: this.clientId,
    });
  }

  onResetEdit(regionId: string) {
    this.countryData = [];
    this.editsubmittedForm.reset();
    this.editsubmittedForm.markAsPristine();
    this.editsubmittedForm.markAsUntouched();
    this.editsubmittedForm.updateValueAndValidity();
    this.editsubmitted = false;
    this.editsubmittedForm.patchValue({
      regionId: regionId,
      lastUpdatedBy: 'admin',
      clientId: this.clientId,
    });
  }

  showEditvalues(getId): void {
    this.regionservice.getRegionByRegionCode(getId).subscribe(
      regionservice => {
        if (!!regionservice && regionservice.regionId) {
          this.editsubmittedForm.patchValue({
            regionId: regionservice['regionId'],
            regionCode: regionservice['regionCode'].trim(),
            regionName: regionservice['regionName'],
            continentName: regionservice['continentName'],
            countryCodeList: regionservice['countryCodeList'],
            clientId: regionservice['clientId'],
          });
          this.box_search_status = false;
          this.updateCountryListOnEdit(regionservice['countryCodeList']);
        } else {
          this.messageBoxService.showFetchErrorMessage();
        }
      });
  }

  showCopyValues(regionId): void {
    this.regionservice.getRegionByRegionCode(regionId).subscribe(
      response => {
        if (!!response && response.regionId) {
          this.addNewRegionForm.patchValue({
            regionCode: response['regionCode'].trim(),
            regionName: response['regionName'],
            continentName: response['continentName'],
            countryCodeList: response['countryCodeList'],
            clientId: response['clientId'],
            createdBy: 'admin',
          });
          this.box_search_status = false;
          this.updateCountryListOnEdit(response['countryCodeList']);
        } else {
          this.messageBoxService.showFetchErrorMessage();
        }
      });
  }

  onUpdate() {
    this.editsubmitted = true;
    if (this.editsubmittedForm.invalid) {
      return;
    } else {
      const data = this.editsubmittedForm.value.countryCodeList.substring(0, 1);
      this.editsubmittedForm.value.countryCodeList = data == "," ? this.editsubmittedForm.value.countryCodeList.substring(1) : this.editsubmittedForm.value.countryCodeList;
      const region = Object.assign({}, this.editsubmittedForm.value);
      delete (region.countryCode);
      this.regionservice.updateRegion(region).subscribe(
        regionservice => {
          if (!!regionservice && regionservice.regionId) {
            this.updateDataTable(regionservice, 'remove');
            this.closeModalEdit.nativeElement.click();
            this.error = { isError: true, errorMessage: "Record has been successfully saved" };
            this.closeAlertValidation();
            this.onSearch();
          }
        });
    }
  }

  removeafterDeactivate(region: Region): void {
    this.regionsList = this.regionsList.filter(h => h !== region);
  }

  changeStatusRegion(region, e, Id) {
    if (e.target.checked) {
      this.messageBoxService.showActivationMessage('Region').then((result) => {
        if (result.value) {
          this.regionservice.activateRegion(Id).subscribe(
            data => {
              console.log('data->' + data);
              this.onSearch();
            }, error => {
              console.log('error->' + error);
            });
          this.messageBoxService.showActivationSuccess('Region');
        }else{
          e.target.checked = false;
          this.messageBoxService.showStatusUnchangedMessage('Region');
        }
      });
    } else {
      this.messageBoxService.showDeactivationMessage('Region').then((result) => {
        if (result.value) {
          this.regionservice.deactivateRegion(Id).subscribe(
            data => {
              this.messageBoxService.showDeactivationSuccess('Region');
              this.updateDataTable(region, 'remove');
              e.target.checked = true;
            }, error => {
              console.log('error->' + error);
            });
          this.messageBoxService.showDeactivationSuccess('Region');
          this.removeafterDeactivate(region);
        } else {
          e.target.checked = true;
          this.messageBoxService.showStatusUnchangedMessage('Region');
        }
      });
    }
  }

  OnItemSelectCountry(data, form) {
    console.log(this.addNewRegionForm.value.countryCodeList);
    let newString = "";
    if (form === "add") {
      let countryListAdd = this.addNewRegionForm.value.countryCodeList == null || this.addNewRegionForm.value.countryCodeList == "" ? "" : this.addNewRegionForm.value.countryCodeList;
      newString = countryListAdd + ',' + data['id'];
    } else {
      let countryListUpdate = this.editsubmittedForm.value.countryCodeList == null || this.editsubmittedForm.value.countryCodeList == "" ? "" : this.editsubmittedForm.value.countryCodeList;
      newString = countryListUpdate + ',' + data['id'];
    }

    form === 'add' ? this.addNewRegionForm.controls['countryCodeList'].setValue(newString) : this.editsubmittedForm.controls['countryCodeList'].setValue(newString);
    console.log(this.addNewRegionForm.value.countryCodeList);
  }

  OnItemDeSelectCountry(data, form) {
    console.log(this.addNewRegionForm.value.countryCodeList);
    const stringToSplit = form === 'add' ? this.addNewRegionForm.value.countryCodeList : this.editsubmittedForm.value.countryCodeList;
    const x = stringToSplit.split(',');
    x.splice(x.indexOf(data['id']), 1);
    form === 'add' ? this.addNewRegionForm.controls['countryCodeList'].setValue(x.toString()) : this.editsubmittedForm.controls['countryCodeList'].setValue(x.toString());
    console.log(this.addNewRegionForm.value.countryCodeList);
  }

  updateCountryListOnEdit(list) {
    const x = list.split(',');
    const country = [];
    for (let i = 0; i < x.length; i++) {
      if (x[i] !== '') {
        const value = x[i];
        const data1 = this.countryArray.filter(x => x.id === value);
        if (data1.length > 0) {
          country.push(data1[0]);
        }
      }
    }
    this.countryData = country;
    this.countryDataAdd = country;
  }

  onCountryClear(form) {
    if (form == "add") {
      this.addNewRegionForm.controls['countryCodeList'].setValue("");
      this.addNewRegionForm.controls['countryCode'].setValue(null);
    } else {
      this.editsubmittedForm.controls['countryCodeList'].setValue("");
      this.editsubmittedForm.controls['countryCode'].setValue(null);
    }
  }

  onCancelChange() {
    this.onResetAdd();
    this.onResetEdit(null);
    this.closeModalAdd.nativeElement.click();
    this.closeModalEdit.nativeElement.click();
    this.addNewsubmitted = false;
    this.editsubmitted = false;
  }

  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }

}
