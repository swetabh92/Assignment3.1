export const PatternConstants = {
    PERCENTAGE_VALIDATOR : '^([0-9]{1,2}([\.][0-9]{1,})?$|100([\.][0]{1,})?)$',
    BILLING_PERIOD : /^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)-[0-9]{2}\/(01|02|03|04)/gi,
    AMOUNT_TWO_DECIMAL: '[0-9]+(\.[0-9][0-9]?)?',
    NEG_AMOUNT_TWO_DECIMAL: '^-?[0-9]+(\.[0-9][0-9]?)?',
    UPPER_CASE:'[A-Z]*',
    NUMERIC: '[0-9]*',
};
