import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-field-error-display',
  templateUrl: 'field-error-message.component.html',
})
export class FieldErrorMessageComponent {
  @Input() errorMsg: string;
  @Input() displayError: boolean;
}
