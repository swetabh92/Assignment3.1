package com.sgl.smartpra.batch.bsp.app.processor;

import com.sgl.smartpra.batch.bsp.app.domain.staging.BSPStagingDomainObject;
import com.sgl.smartpra.batch.bsp.app.domain.staging.BillingCycleTotalsStg;
import com.sgl.smartpra.batch.bsp.app.mapper.BSPRecordMapper;
import com.sgl.smartpra.batch.bsp.app.record.BSPBaseRecord;
import com.sgl.smartpra.batch.bsp.app.record.BillingCycleTotals;

public class BillingCycleTotalsProcessor extends BSPBaseItemProcessor {

	@Override
	public BSPStagingDomainObject process(BSPBaseRecord bspBaseRecord) throws Exception {

		BillingCycleTotalsStg billingCycleTotalsStg = BSPRecordMapper.INSTANCE
				.mapBillingCycleTotalsRecord((BillingCycleTotals) bspBaseRecord);
		return billingCycleTotalsStg;
	}
}
