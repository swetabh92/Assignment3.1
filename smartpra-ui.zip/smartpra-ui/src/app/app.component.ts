import {AfterViewInit, Component, OnInit} from '@angular/core';
import {TranslateService} from "./commons/translate/transalation.service";
import {StorageConstants} from "./commons/constants/storage-constants";
import * as _ from 'underscore';
import {AppConstants} from "./commons/constants/app-constants";
import {GeneralService} from "./commons/services/general.service";
import {DateFormatService} from "./commons/services/date-format/date-format.service"
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements AfterViewInit, OnInit {

  

  constructor(private dateFormat:DateFormatService, translate: TranslateService, private generalService: GeneralService, private router:Router) {
    let langCode = _.isEmpty(localStorage.getItem(StorageConstants.CURRENT_LANG)) ? AppConstants.DEFAULT_LANG_CODE : localStorage.getItem(StorageConstants.CURRENT_LANG);
    translate.use(langCode).then(() => {
    });
    this.dateFormat.initDateFormat();
  }

  ngAfterViewInit() {
    this.generalService.LoadTreeViewJs();
    this.generalService.LoadProfileSettingJs();
    this.generalService.LoadFormSettingJs();
  }

  ngOnInit(){
    window.addEventListener('storage',(event)=>{
      const value = 'logout-event'
      if (event.key == value) { 
          this.router.navigate(['/login'])
      }
  });
  }
}
