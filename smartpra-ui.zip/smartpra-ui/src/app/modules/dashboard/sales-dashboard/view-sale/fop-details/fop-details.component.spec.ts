import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FopDetailsComponent } from './fop-details.component';

describe('FopDetailsComponent', () => {
  let component: FopDetailsComponent;
  let fixture: ComponentFixture<FopDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FopDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FopDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
