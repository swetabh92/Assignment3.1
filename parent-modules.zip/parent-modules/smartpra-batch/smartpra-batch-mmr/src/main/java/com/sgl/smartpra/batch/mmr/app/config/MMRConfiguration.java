package com.sgl.smartpra.batch.mmr.app.config;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManagerFactory;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.mapping.PatternMatchingCompositeLineMapper;
import org.springframework.batch.item.file.transform.IncorrectLineLengthException;
import org.springframework.batch.item.file.transform.LineTokenizer;
import org.springframework.batch.item.support.ClassifierCompositeItemProcessor;
import org.springframework.batch.item.support.ClassifierCompositeItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.classify.Classifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.transaction.PlatformTransactionManager;

import com.sgl.smartpra.batch.mmr.app.domain.CurrencyHeader;
import com.sgl.smartpra.batch.mmr.app.domain.CurrencyRate;
import com.sgl.smartpra.batch.mmr.app.domain.CurrencyRecord;
import com.sgl.smartpra.batch.mmr.app.listener.JobCompletionNotificationListener;

@Configuration
@EnableBatchProcessing
public class MMRConfiguration {

	@Autowired
	public JobBuilderFactory jobBuilderFactory;

	@Autowired
	public StepBuilderFactory stepBuilderFactory;

	@Autowired
	EntityManagerFactory emf;

	@Value("${max-threads}")
	private int maxThreads;

	@Value("${batch.directory.mmr.input}")
	private String batchInputDir;

	@Autowired
	private PlatformTransactionManager transactionManager;

	@Bean
	public TaskExecutor taskExecutor() {
		SimpleAsyncTaskExecutor taskExecutor = new SimpleAsyncTaskExecutor();
		taskExecutor.setConcurrencyLimit(maxThreads);
		return taskExecutor;
	}

	@Bean
	public Job importMmrJob(JobCompletionNotificationListener listener, Step importData) {

		// @formatter:off
		return jobBuilderFactory.get("importMmrJob").incrementer(new RunIdIncrementer()).listener(listener)
				.flow(importData).end().build();
		// @formatter:on
	}

	@SuppressWarnings("unchecked")
	@Bean
	public Step importData() {

		// @formatter:off
		return stepBuilderFactory.get("MMR").<CurrencyRecord, CurrencyRecord>chunk(1).reader(mmrReader(null))
				.processor((ItemProcessor<? super CurrencyRecord, ? extends CurrencyRecord>) mmrRecordProcessor(
						mmrHeaderProcessor(), mmrProcessor()))
				.writer((ItemWriter<? super CurrencyRecord>) mmrRecordWriter(mmrHeaderWriter(), mmrWriter()))
				.faultTolerant().skipLimit(100).skip(DataIntegrityViolationException.class)
				.transactionManager(transactionManager).taskExecutor(taskExecutor()).throttleLimit(maxThreads).build();
		// @formatter:on
	}

	@Bean
	@StepScope
	public FlatFileItemReader<CurrencyRecord> mmrReader(@Value("#{jobParameters[fileName]}") String fileName) {

		FlatFileItemReader<CurrencyRecord> reader = new FlatFileItemReader<CurrencyRecord>();
		reader.setResource(new FileSystemResource(batchInputDir + File.separator + fileName));
		reader.setLineMapper(lineMapper());
		return reader;
	}

	@Bean
	public LineMapper<CurrencyRecord> lineMapper() {

		PatternMatchingCompositeLineMapper<CurrencyRecord> mapper = new PatternMatchingCompositeLineMapper<>();

		Map<String, LineTokenizer> tokenizers = new HashMap<String, LineTokenizer>(10);
		tokenizers.put("1*", (new CurrencyHeader()).lineTokenizer());
		tokenizers.put("2*", (new CurrencyRate()).lineTokenizer());
		mapper.setTokenizers(tokenizers);

		Map<String, FieldSetMapper<CurrencyRecord>> mappers = new HashMap<String, FieldSetMapper<CurrencyRecord>>();
		mappers.put("1*", (new CurrencyHeader()).fieldSetMapper());
		mappers.put("2*", (new CurrencyRate()).fieldSetMapper());

		BeanWrapperFieldSetMapper<CurrencyRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<>();
		fieldSetMapper.setTargetType(CurrencyRecord.class);

		mapper.setFieldSetMappers(mappers);
		return mapper;

	}

	@Bean
	@StepScope
	public ItemWriter<? super CurrencyRecord> mmrHeaderWriter() {
		return new CurrencyHeader().writer();
	}

	@Bean
	@StepScope
	public ItemWriter<? super CurrencyRecord> mmrWriter() {
		return new CurrencyRate().writer();
	}

	@SuppressWarnings("serial")
	@Bean
	@StepScope
	public ClassifierCompositeItemWriter<? extends CurrencyRecord> mmrRecordWriter(
			ItemWriter<? super CurrencyRecord> mmrHeaderWriter, ItemWriter<? super CurrencyRecord> mmrWriter

	) {
		ClassifierCompositeItemWriter<CurrencyRecord> classifierCompositeItemWriter = new ClassifierCompositeItemWriter<>();
		classifierCompositeItemWriter
				.setClassifier(new Classifier<CurrencyRecord, ItemWriter<? super CurrencyRecord>>() {

					@Override
					public ItemWriter<? super CurrencyRecord> classify(CurrencyRecord classifiable) {
						if (classifiable instanceof CurrencyHeader) {
							return mmrHeaderWriter;
						} else if (classifiable instanceof CurrencyRate) {
							return mmrWriter;
						}
						return null;
					}

				});
		return classifierCompositeItemWriter;
	}

	@Bean
	@StepScope
	public ItemProcessor<? extends CurrencyRecord, ? extends CurrencyRecord> mmrHeaderProcessor() {
		return new CurrencyHeader().processor();
	}

	@Bean
	@StepScope
	public ItemProcessor<? extends CurrencyRecord, ? extends CurrencyRecord> mmrProcessor() {
		return new CurrencyRate().processor();
	}

	@Bean
	@StepScope
	public ClassifierCompositeItemProcessor<? extends CurrencyRecord, ? extends CurrencyRecord> mmrRecordProcessor(
			ItemProcessor<? extends CurrencyRecord, ? extends CurrencyRecord> mmrHeaderProcessor,
			ItemProcessor<? extends CurrencyRecord, ? extends CurrencyRecord> mmrProcessor

	) {
		ClassifierCompositeItemProcessor<CurrencyRecord, CurrencyRecord> classifierCompositeItemProcessor = new ClassifierCompositeItemProcessor<>();
		classifierCompositeItemProcessor
				.setClassifier(new Classifier<CurrencyRecord, ItemProcessor<?, ? extends CurrencyRecord>>() {

					@Override
					public ItemProcessor<?, ? extends CurrencyRecord> classify(CurrencyRecord classifiable) {
						if (classifiable instanceof CurrencyHeader) {
							return mmrHeaderProcessor;
						} else if (classifiable instanceof CurrencyRate) {
							return mmrProcessor;
						}
						return null;

					}

				});
		return classifierCompositeItemProcessor;

	}
}