package com.sgl.smartpra.batch.amadeus.app;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableScheduling;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableBatchProcessing
@EnableScheduling
@EnableDiscoveryClient
@EnableCircuitBreaker
@EnableSwagger2
@EnableFeignClients
@EntityScan({"com.sgl.smartpra.batch.amadeus.app", "com.sgl.smartpra.sales", "com.sgl.smartpra.flown"})
@EnableJpaRepositories({"com.sgl.smartpra.batch.amadeus.app", "com.sgl.smartpra.sales", "com.sgl.smartpra.flown"})

public class AmadeusBatchApplication {

	private static final Logger LOGGER = LoggerFactory.getLogger(AmadeusBatchApplication.class);

	public static void main(String[] args) throws Exception {
		LOGGER.info("Entering Amadeus  Application");
		SpringApplication.run(AmadeusBatchApplication.class, args);
	}

}