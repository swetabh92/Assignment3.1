import { Component, OnInit, ElementRef, ViewChild, HostListener, OnDestroy, Input, EventEmitter } from '@angular/core';
import { PaginationService } from '../../../../commons/services/pagination/pagination.service';
import { FlownListModel, flownKey, flownStatusList, flownIconStatusList } from '../model/flown-model';
import { timer } from 'rxjs';
import { FlownService } from '../services/flown.service';
import { MessageBoxService } from '../../../masters/services/commons/message-box.service'
import swal from 'sweetalert2';
import { DateFormatService } from '../../../../commons/services/date-format/date-format.service';
@Component({
  selector: 'app-flown-flight-list',
  templateUrl: './flown-flight-list.component.html',
  styleUrls: ['./flown-flight-list.component.css']
})

export class FlownFlightListComponent implements OnInit {
  @ViewChild('statusPopup') statusPopup: ElementRef;
  @ViewChild('statusParent') statusParent: ElementRef;
  scrollEnabled: boolean = false;
  selectionRadio = false;
  viewFlown: FlownListModel;
  flownList: FlownListModel[] = [];
  selectedFlownList: FlownListModel[] = [];
  showMessage: boolean = false;
  message: string = "";
  systemDateFormat = this.dateFormatService.getAngularPipeDateFormat();
  searhFlownParams: any;
  currencyCode = this.flownService.currencyCode;
  @Input('searchParams')
  set searchParams(data: any) {
    if (data) {
      this.searhFlownParams = data;
      this.searchFlown();
    }
  }
  @HostListener('document:click', ['$event.target'])
  public outsideClick(targetElement) {
    if (!(targetElement.classList.contains("status-indicator-icon") || this.statusPopup.nativeElement.contains(targetElement))) {
      this.statusPopup.nativeElement.style.display = 'none';
    }
  }
  page: any = this.paginateService.getPageinateConfig();
  constructor(private dateFormatService: DateFormatService, private messageBoxService: MessageBoxService, private flownService: FlownService, private paginateService: PaginationService) { }
  ngOnInit() {
  }
  searchFlown() {
    this.flownService.getSearchDet(this.searhFlownParams).subscribe((res: FlownListModel[]) => {
      this.flownList = this.mappingStatus(res);
    })
  }
  statusOpen(e) {
    this.statusPopup.nativeElement.style.display = 'block';
    let parent = this.statusParent.nativeElement.getBoundingClientRect();
    let child = e.target.getBoundingClientRect();
    let popup = this.statusPopup.nativeElement.getBoundingClientRect();
    let pos = { top: (child.top - parent.top - 100), left: (child.left - parent.left - popup.width + 15) };
    this.statusPopup.nativeElement.style.left = pos.left + 'px';
    this.statusPopup.nativeElement.style.top = pos.top + 'px';
  }
  viewFlownInfo() {
    let selectedLength = this.selectedFlownList.length;
    if ((selectedLength == 0 || selectedLength > 1) && !this.selectionRadio) {
      this.iconErrAlert();
      return false
    }
    this.selectionRadio = !this.selectionRadio;
    if (this.selectionRadio) {
      this.viewFlown = this.selectedFlownList[0];
      this.triggerScroll();
    }
    else {
      this.viewFlown = undefined
    }
  }
  onSelect(event, type?: string, inputevent?: any) {
    if (type == 'all' && event.selected) this.selectedFlownList = event.selected;
    else {
      if (this.selectionRadio) {
        if (inputevent && inputevent.target.checked) { this.selectedFlownList = [event]; this.viewFlown = event; }
        else { this.selectedFlownList = []; this.viewFlown = undefined; }
        this.triggerScroll();
      }
      else {
        let ind = this.selectedFlownList.findIndex(item => item[flownKey] == event[flownKey]);
        if (ind === -1) this.selectedFlownList.push(event); else this.selectedFlownList.splice(ind, 1);
      }
    }
  }
  iconErrAlert() {
    let title = "Please select any flight to proceed!"
    this.messageBoxService.getWarningMessage(title, "");
  }
  developmentProgressIcon() {
    let title = "Development in Progress . . ."
    this.messageBoxService.getWarningMessage(title, "");
  }
  deleteFlight() {
    if ((this.selectedFlownList.length == 0 || this.selectedFlownList.length > 1)) {
      this.iconErrAlert();
      return false;
    }
    if (this.searhFlownParams["flightStatus"] == 'O') {
      this.cancelFlights();
      return false;
    }
    //this.developmentProgressIcon();
    this.messageBoxService.deleteRecordMessage().then((result) => {
      if (result.value) {
        this.flownService.deleteFlight(this.selectedFlownList[0]).subscribe((res: number) => {
          if (Number.isInteger(res)) {
            this.message = "Flight has been successfully deleted";
            this.showMessage = true;
            this.selectedFlownList = []; this.viewFlown = undefined;
            this.searchFlown();
          }
        })
      }
    });
  }
  flightReopen() {
    if (this.selectedFlownList.length < 1) {
      this.iconErrAlert();
      return false;
    }
    let reOpenList = [];
    this.selectedFlownList.forEach((item) => {
      reOpenList.push(item.flightKey);
    })
    let title = "Are you sure you want to reopen this flights?";
    let cancel = "Yes, process it";
    swal({
      type: 'warning',
      title: title,
      text: reOpenList.length + " item selected!",
      showCancelButton: true,
      confirmButtonColor: '#ff0000',
      cancelButtonColor: '#049F0C',
      confirmButtonText: cancel,
      cancelButtonText: 'No, keep it!',
      closeOnClickOutside: false,
      closeOnEsc: false,
      allowOutsideClick: false,
      customClass: 'Custom_Cancel',
    } as any).then((result) => {
      if (result.value) {
        this.flownService.flightReopen(reOpenList.join()).subscribe((res: number) => {
          if (res >= 0) {
            this.message = "Flights has been reopened successfully.";
            this.showMessage = true;
            if (this.viewFlown) {
              this.viewFlown = undefined;
              setTimeout(() => {
                this.viewFlown = this.selectedFlownList[0];
              }, 100)
            }
          }
        })
      }
    })
  }
  cancelFlights() {
    if (this.selectedFlownList.length < 1) {
      this.iconErrAlert();
      return false;
    }
    let canceList = [];
    this.selectedFlownList.forEach((item) => {
      canceList.push(item.flightKey);
    })
    let status = this.searhFlownParams["flightStatus"]
    let title = (status == 'C') ? "Are you sure you want to move this flights to outstanding?" : (status == 'O') ? "Are you sure you want to delete this record?" : "Are you sure you want to cancel this flights?";
    let cancel = (status == 'C') ? "Yes, process it" : (status == 'O') ? "Yes, delete it!" : "Yes, cancel it";

    swal({
      type: 'warning',
      title: title,
      text: (status == 'O') ? '' : canceList.length + " item selected!",
      showCancelButton: true,
      confirmButtonColor: '#ff0000',
      cancelButtonColor: '#049F0C',
      confirmButtonText: cancel,
      cancelButtonText: 'No, keep it!',
      closeOnClickOutside: false,
      closeOnEsc: false,
      allowOutsideClick: false,
      customClass: 'Custom_Cancel',
    } as any).then((result) => {
      if (result.value) {
        this.flownService.cancelFlight(canceList.join()).subscribe((res: number) => {
          if (res > 0) {
            this.message = (status == 'C') ? "Flights has been successfully moved to outstanding." : (status == 'O') ? "Flight has been successfully deleted." : "Flights has been successfully cancelled.";
            this.showMessage = true;
            this.selectedFlownList = []; this.viewFlown = undefined;
            this.searchFlown();
          }
        })
      }
    })
  }
  disableIcon(iconType) {
    let status = flownIconStatusList[flownStatusList[this.searhFlownParams["flightStatus"]]][iconType];
    if (status == 'disable') return true;
    else return false;
  }
  triggerScroll() {
    this.scrollEnabled = true;
    timer(10).subscribe(() => {
      this.scrollEnabled = false;
    })
  }
  convertDecimal(val) {
    if (val == null) val = 0;
    return val.toFixed(this.flownService.currencyDecimalPression);
  }
  nullToZero(val) {
    if (val == null) val = 0;
    return val;
  }
  updateFlown(obj) {
    let ind = this.flownList.findIndex(item => item['flightKey'] == obj['flightKey']);
    this.flownList[ind] = obj;
  }
  mappingStatus(arr) {
    arr.forEach((flightList) => {
      flightList["statusIndicators"].forEach((item) => {
        flightList[item["statusName"]] = item["value"];
      });
      return flightList;
    })
    return arr;
  }

}
