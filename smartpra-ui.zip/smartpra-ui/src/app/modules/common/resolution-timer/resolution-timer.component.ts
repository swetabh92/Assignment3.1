import {AfterViewInit, Component, OnInit} from '@angular/core';
import {ResolutionTimerContractService} from "./contract/resolution-timer-contract.service";
import {ResolutionTimerModel} from "./model/resolution-timer.model";
import * as _ from "underscore";
import {StorageService} from "../../../commons/services/storage/storage.service";

@Component({
  selector: 'app-resolution-timer',
  templateUrl: './resolution-timer.component.html',
  styleUrls: ['./resolution-timer.component.css']
})
export class ResolutionTimerComponent implements OnInit, AfterViewInit {

  public showContent: boolean = false;
  position = {"x": 520, "y": -354};
  zIndexMoving: string;
  hideFloater: boolean = true;
  timerModel: ResolutionTimerModel;

  constructor(private resolutionContract: ResolutionTimerContractService,
              private storageService: StorageService) {

  }

  ngOnInit() {
    this.resolutionContract.instance.subscribe((data: ResolutionTimerModel) => {
      this.timerModel = !data ? StorageService.getResolutionTimerInstance() : data;
    })
  }

  onClickFloater() {
    this.showContent = !this.showContent;
  }


  ngAfterViewInit(): void {
    document.getElementById("countdown").style.transform = 'translate(510px, -354px)';
  }


  onSelectHoldIcon(): void {
    let resolutionTimer = StorageService.getResolutionTimerInstance();
    resolutionTimer.isTimerOnHold = false;
    this.storageService.setResolutionTimerInstance(resolutionTimer);
  }

  startTimer(): void {
    setInterval(() => {
      this["resolutionTimer"].timerModel = new Date();
    }, 1000);
  }


}
