import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ModulesRoutingModule } from './modules-routing.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { ModulesComponent } from './modules.component';
import { CoreDataModule } from 'src/app/core-data/core-data.module';

@NgModule({
  imports: [
    CommonModule,
    CoreDataModule,
    SharedModule,
    ModulesRoutingModule
  ],
  declarations: [
    ModulesComponent
  ]
})
export class ModulesModule { }
