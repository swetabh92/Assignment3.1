import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProvisoRoutingComponent } from './proviso-routing.component';

describe('ProvisoRoutingComponent', () => {
  let component: ProvisoRoutingComponent;
  let fixture: ComponentFixture<ProvisoRoutingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProvisoRoutingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProvisoRoutingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
