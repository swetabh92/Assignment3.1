/**
 * 
 */
package com.sgl.smartpra.batch.mib.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;

import com.sgl.smartpra.batch.mib.app.utils.QualifiedByUtil;
import com.sgl.smartpra.batch.mib.app.utils.QualifiedByUtil.BigIntegerToInteger;
import com.sgl.smartpra.batch.mib.app.utils.QualifiedByUtil.BigIntegerToString;
import com.sgl.smartpra.batch.mib.app.utils.QualifiedByUtil.IntegerToBigInteger;
import com.sgl.smartpra.batch.mib.app.utils.QualifiedByUtil.ListToBigDecimal;
import com.sgl.smartpra.batch.mib.app.utils.QualifiedByUtil.ObjectToString;
import com.sgl.smartpra.batch.mib.app.utils.QualifiedByUtil.ReturnSumFromList;
import com.sgl.smartpra.batch.mib.app.utils.QualifiedByUtil.StringToBigInteger;
import com.sgl.smartpra.batch.mib.app.utils.QualifiedByUtil.StringToDate;
import com.sgl.smartpra.mib.entity.MiscBillingInvLineitemEntity;
import com.sgl.smartpra.mib.jaxb.standard.LineItem;

/**
 * @author kanprasa
 *
 */
@Mapper(uses = QualifiedByUtil.class, componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
public interface LineItemMapper {
	
	@Mapping(source = "POLineItemNumber", target = "poLineItemNumber", qualifiedBy=BigIntegerToInteger.class)
	@Mapping(source = "productID", target = "productId")
	@Mapping(source = "startDate", target = "startDate", qualifiedBy=StringToDate.class)
	@Mapping(source = "endDate", target = "endDate", qualifiedBy=StringToDate.class)
	@Mapping(source = "quantity.value", target = "quantity")
	@Mapping(source = "quantity.UOMCode", target = "uomCode")	
	@Mapping(source = "unitPrice.value", target = "unitPrice")
	@Mapping(source = "unitPrice.SF", target = "scallingFactor", qualifiedBy=BigIntegerToString.class)
	@Mapping(target = "chargeAmount", source="chargeAmount", qualifiedBy = ListToBigDecimal.class)
	@Mapping(target = "addonChargeAmount", source="addOnCharges", qualifiedBy = ReturnSumFromList.class)
	@Mapping(target = "originalLineItemNumber", source="originalLineItemNumber", qualifiedBy = BigIntegerToInteger.class)
	@Mapping(target = "detailCount", source="detailCount", defaultValue="0", qualifiedBy = BigIntegerToInteger.class)
	@Mapping(source = "totalAddOnChargeAmount", target = "totalAddonChargeAmount")
	@Mapping(source = "totalVATAmount", target = "totalVatAmount")
	public void mapLineItemToEntity(LineItem lineItem, @MappingTarget MiscBillingInvLineitemEntity lineItemEntity);

	
	@Mapping(source = "poLineItemNumber", target = "POLineItemNumber", qualifiedBy=IntegerToBigInteger.class)
	@Mapping(source = "productId", target = "productID")
	@Mapping(source = "startDate", target = "startDate", qualifiedBy=ObjectToString.class)
	@Mapping(source = "endDate", target = "endDate", qualifiedBy=ObjectToString.class)
	@Mapping(source = "quantity", target = "quantity.value")
	@Mapping(source = "uomCode", target = "quantity.UOMCode")	
	@Mapping(source = "unitPrice", target = "unitPrice.value")
	@Mapping(source = "scallingFactor", target = "unitPrice.SF", qualifiedBy=StringToBigInteger.class)
	@Mapping(source = "chargeAmount", target = "chargeAmount", ignore=true)
	@Mapping(target = "originalLineItemNumber", source="originalLineItemNumber", qualifiedBy = BigIntegerToInteger.class)
	@Mapping(target = "detailCount", source="detailCount", defaultValue="0", qualifiedBy = BigIntegerToInteger.class)
	@Mapping(source = "totalAddonChargeAmount", target = "totalAddOnChargeAmount")
	@Mapping(source = "totalVatAmount", target = "totalVATAmount")
	public void mapEntityToLineItem(MiscBillingInvLineitemEntity lineItemEntity, @MappingTarget LineItem lineItem);
	
}