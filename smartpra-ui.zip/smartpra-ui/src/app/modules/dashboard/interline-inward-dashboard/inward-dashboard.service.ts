import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { environment } from '../../../../environments/environment';
import { CommonService } from '../../masters/services/commons/common.service';
import { MessageBoxService } from '../../masters/services/commons/message-box.service';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class InwardDashboardService {
  apiInterlineUrl = environment.apiUrl+ 'interline/';
  //apiInterlineUrl = 'http://10.100.27.53:8063/';
  //apiInterlineUrl = 'http://10.100.27.118:8063/';
  //{params:this.commonService.SearchParams(data)}
  apiUrl = environment.apiUrl;
  clientID: string = this.commonService.getClientId();
  constructor(private http: HttpClient, private commonService: CommonService, private messageBoxService:MessageBoxService) { }


  getForm3Data(data:any, paginate:any): Observable <any> {
    paginate.page = (paginate.page == undefined) ? 0 : paginate.page;
    data = this.commonService.convertApiObj(data);
    return this.http.post <any >(this.apiInterlineUrl + 'search/form3?page='+paginate.page+'&size='+paginate.size, data, httpOptions).pipe(
      tap(_ => this.log(`getting form3 datas`)),
      catchError(this.handleError <any>('get form3 datas'))
    );
  }

  getListofValues(): Observable <any> {
    return this.http.get<any >(this.apiInterlineUrl + 'search?clientId='+ this.clientID, httpOptions).pipe(
      tap(_ => this.log(`getting ListofValues datas`)),
      catchError(this.handleError <any>('get ListofValues datas'))
    );
  }

  getForm3DatabyID(anyID: number): Observable <any > {
    return this.http.get <any >(this.apiInterlineUrl + 'form3/' + anyID).pipe(
      tap(_ => this.log(`fetched aircraft=${ anyID}`)),
      catchError(this.handleError <any >(`getanyBy anyID  anyID=${ anyID}`))
    );
  }

  updateForm3StagData(data:any): Observable <any > {
     return this.http.put <any >(this.apiInterlineUrl + 'form3/stg', data, httpOptions).pipe(
       tap(_ => this.log(`updated stage data  anyID=${data}`)),
       catchError(this.handleError <any >('update stage data'))
     );
  }

  updateForm3ProdData(data:any): Observable <any > {
    return this.http.put <any >(this.apiInterlineUrl + 'form3/prod', data, httpOptions).pipe(
      tap(_ => this.log(`updated Production data  anyID=${data}`)),
      catchError(this.handleError <any >('update Production data'))
    );
  }

  saveForm3ProdData(data:any): Observable <any > {
    return this.http.post <any >(this.apiInterlineUrl + 'form3/prod', data, httpOptions).pipe(
      tap(_ => this.log(`Added Production data  anyID=${data}`)),
      catchError(this.handleError <any >('add Production data'))
    );
  }

  deleteForm3StgData(anyID: string): Observable <any > {
    return this.http.delete<any >(this.apiInterlineUrl + 'form3/stg?ids='+ anyID, httpOptions).pipe(
      tap(_ => this.log(`deleted anyID=${anyID}`)),
      catchError(this.handleError <any >('delete any'))
    );
  }

  deleteForm3ProdData(anyID: string): Observable <any > {
    return this.http.delete<any >(this.apiInterlineUrl + 'form3/prod?ids='+ anyID, httpOptions).pipe(
      tap(_ => this.log(`deleted anyID=${anyID}`)),
      catchError(this.handleError <any >('delete any'))
    );
  }

  validateForm3Data(data: any): Observable <any > {
    return this.http.post<any >(this.apiInterlineUrl + 'validation/form3', data, httpOptions).pipe(
      tap(_ => this.log(`validated anyID=${data}`)),
      catchError(this.handleError <any >('validate any'))
    );
  }

  exceptionForm3Data(data: any): Observable <any > {
    return this.http.post<any >(this.apiUrl + 'exception-transaction/common/findByStagingId', data, httpOptions).pipe(
      tap(_ => this.log(`deleted anyID=${data}`)),
      catchError(this.handleError <any >('exception any'))
    );
  }

  getInvoicesData(data:any, paginate:any): Observable <any > {
    paginate.page = (paginate.page == undefined) ? 0 : paginate.page;
    data = this.commonService.convertApiObj(data);
    return this.http.post<any>(this.apiInterlineUrl + 'search/invoice?page='+paginate.page+'&size='+paginate.size, data, httpOptions).pipe(
      tap(_ => this.log(`get Invoice data  anyID=${data}`)),
      catchError(this.handleError <any >('get Invoice data'))
    );
  }

  getInvoiceById(anyID: number): Observable <any > {
    return this.http.get<any>(this.apiInterlineUrl + 'idec/invoice/stg/' + anyID).pipe(
      tap(_ => this.log(`fetched invoice=${ anyID}`)),
      catchError(this.handleError <any >(`get invoice anyID=${ anyID}`))
    );
  }

  updateInvoiceStagData(anyID: number, data:any): Observable <any > {
    return this.http.put <any >(this.apiInterlineUrl + 'idec/invoice/stg/'+ anyID, data, httpOptions).pipe(
      tap(_ => this.log(`updated stage data  anyID=${data}`)),
      catchError(this.handleError <any >('update Invoice stage data'))
    );
  }

  deleteInvoiceStgData(anyID: string): Observable <any > {
    return this.http.delete<any >(this.apiInterlineUrl + 'idec/invoice/stg?ids='+ anyID, httpOptions).pipe(
      tap(_ => this.log(`deleted Invoice anyID=${anyID}`)),
      catchError(this.handleError <any >('delete Invoice any'))
    );
  }

  getBatchData(data:any, paginate:any): Observable <any > {
    paginate.page = (paginate.page == undefined) ? 0 : paginate.page;
    return this.http.post<any>(this.apiInterlineUrl + 'search/batch?page='+paginate.page+'&size='+paginate.size, data, httpOptions).pipe(
      tap(_ => this.log(`get Invoice data  anyID=${data}`)),
      catchError(this.handleError <any >('get Invoice data'))
    );
  }

  getCouponData(data:any, paginate:any): Observable <any > {
    paginate.page = (paginate.page == undefined) ? 0 : paginate.page;
    return this.http.post<any>(this.apiInterlineUrl + 'search/transaction?page='+paginate.page+'&size='+paginate.size, data, httpOptions).pipe(
      tap(_ => this.log(`get Invoice data  anyID=${data}`)),
      catchError(this.handleError <any >('get Invoice data'))
    );
  }

  deleteBatchStgData(anyID: string): Observable <any > {
    return this.http.delete<any >(this.apiInterlineUrl + 'idec/batch/stg?ids='+ anyID, httpOptions).pipe(
      tap(_ => this.log(`deleted Batch anyID=${anyID}`)),
      catchError(this.handleError <any >('delete Batch any'))
    );
  }

  deleteCouponStgData(anyID: string): Observable <any > {
    return this.http.delete<any >(this.apiInterlineUrl + 'idec/PrimeCoupon/stg?ids='+ anyID, httpOptions).pipe(
      tap(_ => this.log(`deleted Coupon anyID=${anyID}`)),
      catchError(this.handleError <any >('delete Coupon any'))
    );
  }

  getTaxData(data:any): Observable <any > {
    return this.http.post<any >(this.apiInterlineUrl + 'search/tax', data, httpOptions).pipe(
      tap(_ => this.log(`get Tax anyID=${data}`)),
      catchError(this.handleError <any >('get Tax any'))
    );
  }

  getTaxById(anyID: number): Observable <any > {
    return this.http.get<any>(this.apiInterlineUrl + 'idec/tax/stg/' + anyID).pipe(
      tap(_ => this.log(`fetched tax=${ anyID}`)),
      catchError(this.handleError <any >(`get tax anyID=${ anyID}`))
    );
  }

  updateTaxStagById(data:any): Observable <any > {
    return this.http.put<any>(this.apiInterlineUrl + 'idec/tax/stg', data, httpOptions).pipe(
      tap(_ => this.log(`updated tax data  anyID=${data}`)),
      catchError(this.handleError <any >('update tax stage data'))
    );
  }

  deleteTaxById(anyID: number): Observable <any > {
    return this.http.delete<any >(this.apiInterlineUrl + 'idec/tax/stg/'+ anyID, httpOptions).pipe(
      tap(_ => this.log(`deleted tax anyID=${anyID}`)),
      catchError(this.handleError <any >('delete tax any'))
    );
  }


  getVatData(data:any): Observable <any > {
    return this.http.post<any >(this.apiInterlineUrl + 'search/vat', data, httpOptions).pipe(
      tap(_ => this.log(`get Tax anyID=${data}`)),
      catchError(this.handleError <any >('get Tax any'))
    );
  }

  getVatById(anyID: number): Observable <any > {
    return this.http.get<any>(this.apiInterlineUrl + 'idec/vat/stg/' + anyID).pipe(
      tap(_ => this.log(`fetched vat=${ anyID}`)),
      catchError(this.handleError <any >(`get vat anyID=${ anyID}`))
    );
  }

  updateVatStagById(data:any): Observable <any > {
    return this.http.put<any>(this.apiInterlineUrl + 'idec/vat/stg', data, httpOptions).pipe(
      tap(_ => this.log(`updated tax data  anyID=${data}`)),
      catchError(this.handleError <any >('update tax stage data'))
    );
  }

  deleteVatById(anyID: number): Observable <any > {
    return this.http.delete<any >(this.apiInterlineUrl + 'idec/vat/stg/'+ anyID, httpOptions).pipe(
      tap(_ => this.log(`deleted vat anyID=${anyID}`)),
      catchError(this.handleError <any >('delete vat any'))
    );
  }

  private handleError<T>(operation = 'operation', result?: T) {
    return (e: any): Observable<T> => {
      if (e['error'] && e['error']['subErrors'] && e['error']['subErrors'].length > 0) {
        this.messageBoxService.getErrorMessage('ERROR', e['error']['subErrors'][0]['message']);
        return of(result as T);
      } else if(e['error'] && e['error']['message']) {
        this.messageBoxService.getErrorMessage('ERROR', e['error']['message']);
        return of(result as T);
      }
    };
  }

  private log(error: any) {
    if (error.message) {
      this.messageBoxService.getErrorMessage('ERROR', error.message);
    }
  }


}
