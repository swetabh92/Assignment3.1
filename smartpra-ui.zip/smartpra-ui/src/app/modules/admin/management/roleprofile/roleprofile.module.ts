import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RoleprofileRoutingModule } from './roleprofile-routing.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { RoleprofileComponent } from './roleprofile.component';
import { CoreDataModule } from 'src/app/core-data/core-data.module';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    CoreDataModule,
    RoleprofileRoutingModule
  ],
  declarations: [
    RoleprofileComponent
  ]
})
export class RoleprofileModule { }
