package com.sgl.smartpra.batch.sales.validator.app.domain;

import java.io.Serializable;
import javax.persistence.*;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.fasterxml.jackson.annotation.JsonIgnore;
/*import com.sgl.smartpra.batch.bsp.app.processor.TicketPaymentDetailsStgProcessor;
import com.sgl.smartpra.batch.bsp.app.processor.TicketSalesDataStgProcessor;*/
/*import com.sgl.smartpra.batch.bsp.app.writer.TicketPaymentDetailsStgWriter;
import com.sgl.smartpra.batch.bsp.app.writer.TicketSalesDataStgWriter;
*/
import java.sql.Timestamp;


/**
 * The persistent class for the ticket_sales_data_stg database table.
 * 
 */
@Entity
@Table(name="ticket_sales_data_stg")
public class TicketSalesDataStg  implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="tkt_sales_data_dtl_id")
	private int tktSalesDataDtlId;

	@Column(name="created_by")
	private String createdBy;

	@Column(name="created_date")
	private Timestamp createdDate;

	@Column(name="doc_class")
	private String docClass;

	@Column(name="document_number")
	private String documentNumber;

	@Column(name="file_id")
	private String fileId;

	@Column(name="issue_airline")
	private String issueAirline;

	@Column(name="last_updated_by")
	private String lastUpdatedBy;

	@Column(name="last_updated_date")
	private Timestamp lastUpdatedDate;

	@Column(name="last_updated_program")
	private String lastUpdatedProgram;

	@Column(name="main_document")
	private String mainDocument;

	@Column(name="month_closed_date")
	private String monthClosedDate;

	private String pnr;

	@Column(name="process_date")
	private String processDate;

	@Column(name="process_status")
	private String processStatus;

	@Column(name="sales_key")
	private int salesKey;

	private String source;

	@Column(name="transaction_code")
	private String transactionCode;

	@Column(name="transaction_type")
	private String transactionType;

	@Column(name="unprocess_date")
	private String unprocessDate;

	@Column(name="unprocess_status")
	private String unprocessStatus;

	//bi-directional many-to-one association to TicketMainStg
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="trn_tkt_id")
	private TicketMainStg ticketMainStg;

	public TicketSalesDataStg() {
	}

	public int getTktSalesDataDtlId() {
		return this.tktSalesDataDtlId;
	}

	public void setTktSalesDataDtlId(int tktSalesDataDtlId) {
		this.tktSalesDataDtlId = tktSalesDataDtlId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDocClass() {
		return this.docClass;
	}

	public void setDocClass(String docClass) {
		this.docClass = docClass;
	}

	public String getDocumentNumber() {
		return this.documentNumber;
	}

	public void setDocumentNumber(String documentNumber) {
		this.documentNumber = documentNumber;
	}

	public String getFileId() {
		return this.fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	public String getIssueAirline() {
		return this.issueAirline;
	}

	public void setIssueAirline(String issueAirline) {
		this.issueAirline = issueAirline;
	}

	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getLastUpdatedDate() {
		return this.lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getLastUpdatedProgram() {
		return this.lastUpdatedProgram;
	}

	public void setLastUpdatedProgram(String lastUpdatedProgram) {
		this.lastUpdatedProgram = lastUpdatedProgram;
	}

	public String getMainDocument() {
		return this.mainDocument;
	}

	public void setMainDocument(String mainDocument) {
		this.mainDocument = mainDocument;
	}

	public String getMonthClosedDate() {
		return this.monthClosedDate;
	}

	public void setMonthClosedDate(String monthClosedDate) {
		this.monthClosedDate = monthClosedDate;
	}

	public String getPnr() {
		return this.pnr;
	}

	public void setPnr(String pnr) {
		this.pnr = pnr;
	}

	public String getProcessDate() {
		return this.processDate;
	}

	public void setProcessDate(String processDate) {
		this.processDate = processDate;
	}

	public String getProcessStatus() {
		return this.processStatus;
	}

	public void setProcessStatus(String processStatus) {
		this.processStatus = processStatus;
	}

	public int getSalesKey() {
		return this.salesKey;
	}

	public void setSalesKey(int salesKey) {
		this.salesKey = salesKey;
	}

	public String getSource() {
		return this.source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getTransactionCode() {
		return this.transactionCode;
	}

	public void setTransactionCode(String transactionCode) {
		this.transactionCode = transactionCode;
	}

	public String getTransactionType() {
		return this.transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getUnprocessDate() {
		return this.unprocessDate;
	}

	public void setUnprocessDate(String unprocessDate) {
		this.unprocessDate = unprocessDate;
	}

	public String getUnprocessStatus() {
		return this.unprocessStatus;
	}

	public void setUnprocessStatus(String unprocessStatus) {
		this.unprocessStatus = unprocessStatus;
	}

	public TicketMainStg getTicketMainStg() {
		return this.ticketMainStg;
	}

	public void setTicketMainStg(TicketMainStg ticketMainStg) {
		this.ticketMainStg = ticketMainStg;
	}

}