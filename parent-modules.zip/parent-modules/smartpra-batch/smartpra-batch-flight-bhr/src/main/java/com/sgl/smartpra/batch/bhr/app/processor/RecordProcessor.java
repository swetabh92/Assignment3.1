package com.sgl.smartpra.batch.bhr.app.processor;

import java.sql.Timestamp;
import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.bhr.app.domain.BatchRecord;
import com.sgl.smartpra.batch.bhr.app.util.BHRConstants;

@Component
@Scope(value = "Prototype")
public class RecordProcessor {

	@Value("#{jobParameters['fileId']}")
	public Integer fileId;

	public Integer getFileId() {
		return fileId;
	}

	public void setFileId(Integer fileId) {
		this.fileId = fileId;
	}

	public void process(BatchRecord record) {
		if(fileId !=null) 
			record.setFileId(fileId);
		record.setCreatedBy(BHRConstants.CREATEDBY);
		record.setCreatedDate(new Timestamp(new Date().getTime()));
	}
}
