package com.sgl.smartpra.batch.interline.common;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;

import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.global.model.FileLogging;
import com.sgl.smartpra.batch.interline.configuration.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.common.util.FileLoggingConstants;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.master.model.SystemParameter;

@Component
public class InterlineUtils {

	public static FileLogging initFileLogging() {
		FileLogging fileLogging = new FileLogging();
		return initFileLogging(fileLogging);
	}

	public static FileLogging initFileLogging(FileLogging fileLogging) {
		fileLogging.setFileCategory(InterlineBatchConstants.FILECATEGORY_CSV);
		fileLogging.setFileType(InterlineBatchConstants.FILETYPE_FORM3);
		fileLogging.setProcessedBy(InterlineBatchConstants.PROCESSED_BY_MANUAL);
		fileLogging.setSource(InterlineBatchConstants.CREATED_BY_INTERLINE);
		fileLogging.setCreatedBy(InterlineBatchConstants.CREATED_BY_INTERLINE);
		fileLogging.setModuleName(InterlineBatchConstants.CREATED_BY_INTERLINE);
		fileLogging.setModuleId(InterlineBatchConstants.MODULE_ID);
		fileLogging.setInterfaceType(FileLoggingConstants.FILELOGGING_INTERFACE_INPUT);
		fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_STARTED);
		fileLogging.setIsEncryptedPostSuccess(InterlineBatchConstants.N);
		fileLogging.setIsEncryptedPriorLoading(InterlineBatchConstants.N);
		fileLogging.setIsRenamedPostSuccess(InterlineBatchConstants.N);
		fileLogging.setIsMovedToRelevantFolder(InterlineBatchConstants.N);
		fileLogging.setIsNotificationSent(InterlineBatchConstants.N);
		fileLogging.setScheduleDateTime(new Timestamp(new Date().getTime()));
		fileLogging.setStartDateTime(new Timestamp(new Date().getTime()));
		fileLogging.setCreatedDate(new Timestamp(new Date().getTime()));
		fileLogging.setHeaderCounts(1);
		fileLogging.setTotalCounts(0);
		fileLogging.setDetailCounts(0);
		fileLogging.setTransferredCounts(0);
		fileLogging.setErrorCounts(0);
		return fileLogging;
	}

	public static String getHostCarrierDesigCode(SmartpraMasterAppClient smartpraMasterAppClient) {
		String hostCarrierDesigCode = null;
		ArrayList<SystemParameter> systemParameterList = (ArrayList<SystemParameter>) smartpraMasterAppClient.getSystemParameterByparameterName(InterlineBatchConstants.PARAM_DEFAULT_CARRIER_ALPHA_CODE);
		if (systemParameterList != null && !systemParameterList.isEmpty()) {
			hostCarrierDesigCode = OptionalUtil.getValue(systemParameterList.get(0).getParameterRangeFrom());
		}
		return hostCarrierDesigCode;
	}
	
	public static String getHostCarrierCode(SmartpraMasterAppClient smartpraMasterAppClient) {
		String hostCarrierCode = null;
		ArrayList<SystemParameter> systemParameterList = (ArrayList<SystemParameter>) smartpraMasterAppClient.getSystemParameterByparameterName(InterlineBatchConstants.PARAM_DEFAULT_CARRIER_NUMERIC_CODE);
		if (systemParameterList != null && !systemParameterList.isEmpty()) {
			hostCarrierCode = systemParameterList.get(0).getParameterRangeFrom().get();
		}
		return hostCarrierCode;
	}
}
