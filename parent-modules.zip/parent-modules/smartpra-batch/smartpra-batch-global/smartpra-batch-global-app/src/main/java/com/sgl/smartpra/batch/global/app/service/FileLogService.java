package com.sgl.smartpra.batch.global.app.service;

import java.math.BigInteger;
import java.util.List;

import com.sgl.smartpra.batch.global.model.FileLogging;

public interface FileLogService {
	FileLogging createFileLog(FileLogging fileLogging);
	FileLogging getFileLogByFileId(BigInteger fileID);
	List<FileLogging> getAllFileLog();
	List<FileLogging> getFileLogByFileName(String fileName);

	FileLogging updateFileLog(FileLogging fileLogging);
	
	void deleteFileLog(BigInteger fileId);
}
