package com.sgl.smartpra.batch.amadeus.app.domain;

import java.io.Serializable;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.sgl.smartpra.batch.amadeus.app.processor.ProdEMDCouponProcessor;
import com.sgl.smartpra.batch.amadeus.app.processor.ProdETLCouponProcessor;
import com.sgl.smartpra.batch.amadeus.app.processor.ProdETLTicketProcessor;
import com.sgl.smartpra.batch.amadeus.app.writer.ProdCouponDataWriter;
import com.sgl.smartpra.batch.amadeus.app.writer.ProdTicketDataWriter;
import com.sgl.smartpra.flown.domain.BsaCouponDetail;
import com.sgl.smartpra.flown.domain.FlownCoupon;
import com.sgl.smartpra.flown.domain.FlownEsac;

@SuppressWarnings("serial")
public class StgCouponModel   {

	private BsaCouponDetail bsaCouponDetail;
	private FlownCoupon flownCoupon;
	private FlownEsac flownEsac;


	public BsaCouponDetail getBsaCouponDetail() {
		return bsaCouponDetail;
	}

	public void setBsaCouponDetail(BsaCouponDetail bsaCouponDetail) {
		this.bsaCouponDetail = bsaCouponDetail;
	}

	public FlownCoupon getFlownCoupon() {
		return flownCoupon;
	}

	public void setFlownCoupon(FlownCoupon flownCoupon) {
		this.flownCoupon = flownCoupon;
	}

	public FlownEsac getFlownEsac() {
		return flownEsac;
	}

	public void setFlownEsac(FlownEsac flownEsac) {
		this.flownEsac = flownEsac;
	}
}
