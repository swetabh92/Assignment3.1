import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MiscellaneousBillingRoutingModule } from './miscellaneous-billing-routing.module';
import { MiscellaneousBillingComponent } from './miscellaneous-billing/miscellaneous-billing.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { ChargeCodeMasterComponent } from '../charge-category-master/charge-code-master/charge-code-master.component';
import { ChargeCategoryMasterComponent } from '../charge-category-master/charge-category-master.component';
import { SectionMasterComponent } from '../section-master/section-master.component';
import { SectionMasterDetailsComponent } from '../section-master/section-master-details/section-master-details.component';
import { CoreDataModule } from 'src/app/core-data/core-data.module';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    CoreDataModule,
    MiscellaneousBillingRoutingModule
  ],
  declarations: [
    MiscellaneousBillingComponent,
    ChargeCodeMasterComponent,
    ChargeCategoryMasterComponent,
    SectionMasterComponent,
    SectionMasterDetailsComponent
  ]
})
export class MiscellaneousBillingModule { }
