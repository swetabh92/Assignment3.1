import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import {CommonService} from '../../masters/services/commons/common.service';
import {BatchListModel} from './model/sale-model';
const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
}
@Injectable({
  providedIn: 'root'
})
export class SalesdashboardserviceService {
   apiUrl = environment.apiUrl;
   currencyDecimalPression:number=2;
  // apiUrl = 'http://10.245.240.63:8060/smartpra/';
   actionUrl="http://localhost:2222/smartpra/global/barvs-report";
   viewSaleTaxNo="http://localhost:2222/global/view-salestxn";
   /*batchSummaryDetails="http://localhost:8073/sales-service/batch-summary"*/
   batchSummaryDetails= this.apiUrl+"sales-service/batch-summary";
   //batchSummaryDetails= "http://10.100.26.73:8073/batch-summary?agencyCode=60501066&reportingAgencyCode=9999999"
   exchangeRefundUrl=this.apiUrl+"global/exchange-refund";
   clientForSales="QR";
   clientForDocType="CM";
   doccTypeTable="mas_interline_service_charge";
   docTypeColumn="document_type";
   salesSourceTable="mas_emd";
   salesSourceColumn="sales_source";
   masterServiceUrl=this.apiUrl+"master/listofvalues/"+this.commonService.getClientId()+"/mas_emd/sales_source";
   docTypeUrl="http://10.245.240.63:8060/smartpra/master/listofvalues/"+this.commonService.getClientId() +"/mas_form_code/document_type";
   fopUrl="http://10.245.240.63:8060/smartpra/sales-service/payment-details";
  constructor(private http:HttpClient,private commonService:CommonService) {
  }

   public getAll<T>(data : object): Observable<T> {
    return this.http.get<T>(this.apiUrl+"sales-service/barvs-report",{params:this.commonService.SearchParams(data)});
    /*return this.http.get<T>("http://10.100.26.73:8073/"+"/barvs-report",{params:this.commonService.SearchParams(data)});*/
    
  }
  public getSaleSource<T>(): Observable<T> {
    console.log(this.masterServiceUrl);
    return this.http.get<T>(this.masterServiceUrl);
  }
  public getDocTypes<T>(): Observable<T> {
    console.log(this.docTypeUrl);
    return this.http.get<T>(this.docTypeUrl);
  }
  public viewSaleTxNo<T>(agencyCode,reportingAgencyCode): Observable<T> {
    console.log(this.viewSaleTaxNo);
    return this.http.get<T>(this.apiUrl+"sales-service/view-salestxn"+"?agencyCode="+agencyCode+"&reportingAgencyCode="+reportingAgencyCode);
    /*return this.http.get<T>("http://10.100.26.73:8073/"+"sales-service/view-salestxn"+"?agencyCode="+agencyCode+"&reportingAgencyCode="+reportingAgencyCode);*/
  }

  public getBatchSummaryDetails(agencyCode,reportingAgencyCode):Observable<BatchListModel[]>{
     return this.http.get<BatchListModel[]>(this.batchSummaryDetails+"?agencyCode="+agencyCode+"&reportingAgencyCode="+reportingAgencyCode);
     //return this.http.get<BatchListModel[]>(this.batchSummaryDetails);
  }

  public getExchangeRefund<T>(documentNumber): Observable<T> {
    console.log(this.exchangeRefundUrl);
    return this.http.get<T>(this.apiUrl+"sales-service/exchange-refund?documentNumber="+documentNumber);
    // return this.http.get<T>("http://10.100.26.73:8073/"+"sales-service/exchange-refund?documentNumber="+documentNumber);
  }
  public getFopData<T>(documentNumber):Observable<T>{
    return this.http.get<T>(this.apiUrl+"sales-service/payment-details?documentNumber="+documentNumber);
    // return this.http.get<T>("http://10.100.26.73:8073/"+"sales-service/payment-details?documentNumber="+documentNumber);
  }
  
  public getAgencyDetails<T>(agencyCode):Observable<T>{
    return this.http.get<T>(this.apiUrl+"sales-service/agency-detail?agencyCode="+agencyCode);
  }

  public getReportedTaxDetials<T>(documentNumber:any):Observable<T>{
    return this.http.get<T>(this.apiUrl+"sales-service/reported-taxdetails?documentNumber="+documentNumber);
  }
  public getTransactionsCount<T>(reportingAgency,agencyCode):Observable<T>{
    return this.http.get<T>(this.apiUrl+"sales-service/transaction-summary?reportingAgency="+reportingAgency+"&agencyCode="+agencyCode);
  }
  /*public getTransactionsSummary<T>(salesKey:any,reportingAgencyCode):Observable<T>{
    return this.http.get<T>(this.apiUrl+"sales-service/transaction-summary?salesKey="+salesKey+"&reportingAgencyCode="+reportingAgencyCode);
  }*/
  public getTransactionsTotals<T>(reportingAgency,agencyCode,):Observable<T>{
    return this.http.get<T>(this.apiUrl+"sales-service/transaction-summary?reportingAgency="+reportingAgency+"&agencyCode="+agencyCode);
  }
  public getCurrencyDP<T>(): Observable<T> {
    let url = environment.apiUrlSystemParameter+"DECIMAL_PRECISION";
    return this.http.get<T>(url,httpOptions)
  }
  
}


