package com.sgl.smartpra.batch.fdr.app.domain;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.sgl.smartpra.batch.fdr.app.layout.FDRLayout;
import com.sgl.smartpra.batch.fdr.app.processor.FDRProcessor;
import com.sgl.smartpra.batch.fdr.app.writer.FDRWriter;

@Entity
@Table(name = "global_mas_currency_rate")
public class CurrencyRate extends CurrencyRecord implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "currency_rate_id")
	private Integer currencyRateId;

	@Column(name = "currency_rate_type")
	private String currencyRateType = "FDR";

	private transient String eurExchangeRate;

	private transient String gbpExchangeRate;

	private transient String usdExchangeRate;

	@Column(name = "exchange_rate")
	private Double exchangeRate;

	@Column(name = "currency_from_code")
	private String currencyFromCode;

	@Column(name = "currency_to_code")
	private String currencyToCode;

	@Column(name = "effective_from_date")
	private Date effectiveFromDate;

	@Column(name = "effective_to_date")
	private Date effectiveToDate;

	@Column(name = "inbound_file_id")
	private int inboundFileId;

	@Column(name = "is_active")
	private boolean isActive = true;

	@Column(name = "created_by")
	private String createdBy="Admin_FDR_Load";

	@Column(name = "created_date")
	private Timestamp createdDate=new Timestamp(new Date().getTime());

	@Column(name = "last_updated_by")
	private String lastUpdatedBy;

	@Column(name = "last_updated_date")
	private Timestamp lastUpdatedDate;

	// setter and getter
	public Integer getCurrencyRateId() {
		return currencyRateId;
	}

	public void setCurrencyRateId(Integer currencyRateId) {
		this.currencyRateId = currencyRateId;
	}

	
	public String getCurrencyRateType() {
		return currencyRateType;
	}

	public void setCurrencyRateType(String currencyRateType) {
		this.currencyRateType = currencyRateType;
	}

	public Double getExchangeRate() {
		return exchangeRate;
	}

	public void setExchangeRate(Double exchangeRate) {
		this.exchangeRate = exchangeRate;
	}

	public String getCurrencyFromCode() {
		return currencyFromCode;
	}

	public void setCurrencyFromCode(String currencyFromCode) {
		this.currencyFromCode = currencyFromCode;
	}

	public String getCurrencyToCode() {
		return currencyToCode;
	}

	public void setCurrencyToCode(String currencyToCode) {
		this.currencyToCode = currencyToCode;
	}

	public Date getEffectiveFromDate() {
		return effectiveFromDate;
	}

	public void setEffectiveFromDate(Date effectiveFromDate) {
		this.effectiveFromDate = effectiveFromDate;
	}

	public Date getEffectiveToDate() {
		return effectiveToDate;
	}

	public void setEffectiveToDate(Date effectiveToDate) {
		this.effectiveToDate = effectiveToDate;
	}

	public int getInboundFileId() {
		return inboundFileId;
	}

	public void setInboundFileId(int inboundFileId) {
		this.inboundFileId = inboundFileId;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getEurExchangeRate() {
		return eurExchangeRate;
	}

	public void setEurExchangeRate(String eurExchangeRate) {
		this.eurExchangeRate = eurExchangeRate;
	}

	public String getGbpExchangeRate() {
		return gbpExchangeRate;
	}

	public void setGbpExchangeRate(String gbpExchangeRate) {
		this.gbpExchangeRate = gbpExchangeRate;
	}

	public String getUsdExchangeRate() {
		return usdExchangeRate;
	}

	public void setUsdExchangeRate(String usdExchangeRate) {
		String usdExchangesRate=usdExchangeRate.substring(0, 12);
		this.usdExchangeRate = usdExchangesRate;
	}

	@Override
	public LineTokenizer lineTokenizer() {

		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		FDRLayout roeLayout = new FDRLayout();
		tokenizer.setColumns(roeLayout.getColumns());
		tokenizer.setNames(roeLayout.getNames());
		return tokenizer;

	}

	@Override
	public FieldSetMapper<CurrencyRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<CurrencyRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<CurrencyRecord>();
		fieldSetMapper.setTargetType(CurrencyRate.class);
		return fieldSetMapper;
	}

	@Override
	public ItemProcessor<? extends CurrencyRecord, ? extends CurrencyRecord> processor() {
		return new FDRProcessor();
	}

	@Override
	public ItemWriter<? super CurrencyRecord> writer() {
		return new FDRWriter();
	}

}