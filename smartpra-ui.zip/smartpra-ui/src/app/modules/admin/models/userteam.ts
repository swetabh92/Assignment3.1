export class Userteam {
  isActive: true;
  masTeamId: number;
  masUserTeamId: number;
  masUsersId: number;
      constructor() { }
    }
