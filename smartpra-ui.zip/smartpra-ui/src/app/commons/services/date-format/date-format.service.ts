import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
@Injectable({
  providedIn: 'root'
})

export class DateFormatService {
  constructor(private http: HttpClient) { 
  }
  initDateFormat(){
    let url = environment.apiUrlSystemParameter+'DISPLAY_DATE_FORMAT';
    this.http.get(url).subscribe((res:any)=>{
        let dateFormat = res["parameterRangeFrom"];
        this.setDateFormat(dateFormat);
    })
  }
  setDateFormat(format){
    localStorage.setItem("dateFormat",format)
  }
  getDateFormat(){
    let dateFormat = localStorage.getItem("dateFormat")
    if(dateFormat == null) dateFormat = 'DD-MM-YYYY';
    return dateFormat;
  }
  getAngularPipeDateFormat() {
    let dateFormat = this.getDateFormat();
    dateFormat = dateFormat.replace(/m/g, "M").replace(/D/g,"d").replace(/Y/g,"y");
    return dateFormat;

  }
}
