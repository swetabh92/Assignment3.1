import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SalesdashboardserviceService } from './salesdashboardservice.service';
import { timer } from 'rxjs';

@Component({
  selector: 'app-sales-dashboard',
  templateUrl: './sales-dashboard.component.html',
  styleUrls: ['./sales-dashboard.component.css'],
})
export class SalesDashboardComponent implements OnInit {
  searchParams: any;
  searchForm: FormGroup;
  advanceSearchForm: FormGroup  = this.createAdvanceForm();
  collapseAdvanceForm: boolean = true;
  salesSource: any;
  docTypes: any;
  toMinDate: any;
  fromMaxDate: any;
  searchSubmitted: boolean = false;
  scrollListEnabled: any;
  constructor(private salesService: SalesdashboardserviceService, private formBuilder: FormBuilder) { }
  ngOnInit() {
    this.searchForm = this.formBuilder.group({
      fromperiod: ['', [Validators.required]],
      toperiod: ['', [Validators.required]],
      source: ['ALL', [Validators.required]],
      docType : [''],
      batchType: [''],
      batchStatus: ['']
    });
    this.searchForm.controls['fromperiod'].valueChanges.subscribe((minDate) => {
      this.toMinDate = minDate;
    });
    this.searchForm.controls['toperiod'].valueChanges.subscribe((maxDate) => {
      this.fromMaxDate = maxDate;
    });


    this.salesService.getSaleSource().subscribe(
      data => {
        this.salesSource = data,
          this.salesSource.join('ALL');
        error => console.log(error);
      });
    this.salesService.getDocTypes().subscribe(
      data => {
        this.docTypes = data,
          error => console.log(error);
      });


    this.salesService.getCurrencyDP().subscribe((res: any) => {
      if (res && res["parameterRangeFrom"]) this.salesService.currencyDecimalPression = res["parameterRangeFrom"];
    })
  }
  get sf() {
    return this.searchForm.controls;
  }

  searchSales(type?: any) {
    this.searchSubmitted = true;
    console.log(this.searchForm)
    console.log(this.advanceSearchForm.value)
    if (this.searchForm.invalid) return false;
    let data = Object.assign({}, this.searchForm.value, this.advanceSearchForm.value)
    this.searchParams = undefined;
    timer(10).subscribe(() => {
      this.searchParams = data;
    })
  }
  setScrollStyle(elem) {
    let temp = {};
    let footer = document.getElementsByClassName("page_footer");
    if (elem) temp["top"] = elem.offsetHeight + elem.offsetTop + 4;
    if (footer && footer.length) temp["bottom"] = footer[0]["offsetHeight"];
    return temp;
  }
  createAdvanceForm() {
    return this.formBuilder.group({
      reportingAgency: [''],
      reportedDate: [''],
      currencyCode: [''],
      agencyCode: [''],
      documentNo: [''],
      channel: [''],
      agencyType: ['']
    });
  }

  resetForm(type?: string) {
    this.advanceSearchForm = this.createAdvanceForm();
    if (type == 'advance') return false;
    this.searchForm.reset();
    this.searchParams = undefined;
    this.collapseAdvanceForm = this.searchSubmitted = false;
    setTimeout(() => {
      this.collapseAdvanceForm = true;
    }, 10)
  }

}

