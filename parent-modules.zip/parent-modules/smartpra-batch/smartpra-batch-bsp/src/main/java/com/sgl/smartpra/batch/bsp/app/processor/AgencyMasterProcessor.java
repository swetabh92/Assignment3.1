package com.sgl.smartpra.batch.bsp.app.processor;

import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Value;

import com.sgl.smartpra.master.model.AgencyMaster;

@StepScope
public class AgencyMasterProcessor implements ItemProcessor<AgencyMaster, AgencyMaster> {

	@Value("#{stepExecution}")
	private StepExecution stepExecution;


	@Override
	public AgencyMaster process(AgencyMaster agencyMaster) throws Exception {
		
		return agencyMaster;
	}
}