import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FlownDashboardRoutingModule } from './flown-dashboard-routing.module';
import { FlownDashboardComponent } from './flown-dashboard/flown-dashboard.component';
import { SharedModule } from '../../..//shared/shared.module';
import { FlownFlightListComponent } from './flown-flight-list/flown-flight-list.component';

import { FlightTabsViewComponent } from './flight-tabs-view/flight-tabs-view.component';
import { FlightCouponTableComponent } from './flight-coupon-table/flight-coupon-table.component';
import { FlightInfoComponent } from './flight-info/flight-info.component';
import {TicketqueryModule} from "../../miscellaneous/components/ticketquery/ticketquery.module";
import { SectorMismatchComponent } from './sector-mismatch/sector-mismatch.component';
import { CoreDataModule } from 'src/app/core-data/core-data.module';
@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    CoreDataModule,
    FlownDashboardRoutingModule,
    TicketqueryModule
  ],
  exports: [
    FlownFlightListComponent
  ],
  declarations: [FlownDashboardComponent, FlownFlightListComponent, FlightTabsViewComponent, FlightCouponTableComponent, FlightInfoComponent, SectorMismatchComponent]
})
export class FlownDashboardModule { }
