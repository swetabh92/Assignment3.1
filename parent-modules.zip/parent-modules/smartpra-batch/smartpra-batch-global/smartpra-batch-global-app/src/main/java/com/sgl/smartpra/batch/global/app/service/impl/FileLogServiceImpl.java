package com.sgl.smartpra.batch.global.app.service.impl;

import java.math.BigInteger;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sgl.smartpra.batch.global.app.config.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.batch.global.app.entity.FileLoggingEntity;
import com.sgl.smartpra.batch.global.app.exception.ResourceNotFoundException;
import com.sgl.smartpra.batch.global.app.mapper.FileLogMapper;
import com.sgl.smartpra.batch.global.app.repository.FileLogRepository;
import com.sgl.smartpra.batch.global.app.service.FileLogService;
import com.sgl.smartpra.batch.global.model.FileLogging;
import com.sgl.smartpra.common.util.FileLoggingConstants;
import com.sgl.smartpra.master.model.ListOfValues;

@Service
public class FileLogServiceImpl implements FileLogService {

	@Autowired
	FileLogRepository fileLogRepository;

	@Autowired
	SmartpraMasterAppClient smartpraMasterAppClient;

	@Autowired
	FileLogMapper fileLogMapper;

	@Override
	@Transactional(readOnly = false)
	public FileLogging createFileLog(FileLogging fileLogging) {
		ListOfValues listOfValues = null;
		if (fileLogging != null && StringUtils.isNotEmpty(fileLogging.getClientId())) {
			listOfValues = smartpraMasterAppClient.getListOfValues(fileLogging.getClientId(),
					FileLoggingConstants.MODULE_TABLE_NAME, FileLoggingConstants.MODULE_COLUMN_NAME,
					fileLogging.getModuleId());
			fileLogging.setModuleId(listOfValues != null ? listOfValues.getLovId() : null);
		}
		return fileLogMapper
				.mapToFileLogModel(fileLogRepository.saveAndFlush(fileLogMapper.mapToFileLoggingEntity(fileLogging)));
	}

	@Override
	@Transactional(readOnly = true)
	public FileLogging getFileLogByFileId(BigInteger fileID) {
		FileLoggingEntity fileLoggingEntity;
		Optional<FileLoggingEntity> fileLoggingEntityOpt = fileLogRepository.findById(fileID);
		if (fileLoggingEntityOpt.isPresent()) {
			fileLoggingEntity = fileLoggingEntityOpt.get();
			return fileLogMapper.mapToFileLogModel(fileLoggingEntity);
		} else {
			throw new ResourceNotFoundException("File id ", "id", fileID);

		}

	}

	@Override
	@Transactional(readOnly = true)
	public List<FileLogging> getAllFileLog() {
		return fileLogMapper.mapToFileLogModelList(fileLogRepository.findAll());
	}

	@Override
	@Transactional(readOnly = true)
	public List<FileLogging> getFileLogByFileName(String fileName) {
		return fileLogMapper.mapToFileLogModelList(fileLogRepository.getFileLogByFileName(fileName));

	}

	@Override
	@Transactional
	public FileLogging updateFileLog(FileLogging fileLogging) {
		return fileLogMapper
				.mapToFileLogModel(fileLogRepository.saveAndFlush(fileLogMapper.mapToFileLoggingEntity(fileLogging)));
	}

	@Override
	@Transactional
	public void deleteFileLog(BigInteger fileId) {
		fileLogRepository.deleteById(fileId);

	}

}
