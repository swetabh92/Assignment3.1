package com.sgl.smartpra.batch.amadeus.app.layout;

import java.util.ArrayList;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;
import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;

public class StagingEMDV1_01Layout extends FixedLengthRecordLayout {

	public StagingEMDV1_01Layout() {

		fixedLengthFieldLayoutList = new ArrayList<FixedLengthFieldLayout>();
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("recordType", 1, 1));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("issAirline", 2, 4));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("documentNumber", 5, 14));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("checkDigit", 15, 15));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("couponNumber", 16, 16));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageType", 17, 17));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("manualIndicator", 18, 18));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usagePerformer", 19, 78));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageMarketingCarrierCode", 79, 80));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageOperatingCarrier", 81, 82));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageOriginCode", 83, 87));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageDestinationCode", 88, 92));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("settlementAuthorizationCode", 93, 107));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("inConnectionDocNo", 108, 120));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("inConnectionCouponNo", 121, 121));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("associationStatus", 122, 124));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageEmdDate", 125, 132));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageAirline", 133, 136));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageOperatingFlightNumber", 137, 141));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageOriginCodeEmd", 142, 146));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageDestinationCodeEmd", 147, 151));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("airlineCodeEmd", 152, 154));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("settlementAuthorizationEmd", 155, 169));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("soldMarketingCarrier", 170, 171));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("soldOperatingCarrier", 172, 173));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("reasonForIssuanceSubCode", 174, 176));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("soldOriginCode", 177, 181));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("soldDestinationCode", 182, 186));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("emdTotalNoOfUnits", 187, 201));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("emdChargeQualifier", 202, 204));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("emdUnitQualifier", 205, 207));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("emdChargeCurrency", 208, 210));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("emdRatePerUnit", 211, 228));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("couponValue", 229, 240));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("reportedFare", 241, 252));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("currencyOfReportedFare", 253, 255));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("equivalentFare", 256, 267));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("paymentCurrency", 268, 270));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("agencyNumber", 271, 277));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("issueDate", 279, 286));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("issuingOfficeLocation", 287, 291));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("bookingReference", 292, 297));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("tourCode", 298, 311));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("passengerName", 312, 351));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("reasonForIssuanceCode", 352, 352));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageDocNumber", 353, 362));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("coupons", 393, 1912));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("emdDocumentAmount", 1913, 1924));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("emdDocumentAmountCurrency", 1925, 1927));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("nonExchangeableAmount", 1928, 1939));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("nonExchangeableAmtCurr", 1940, 1942));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("nonRefundableAmount", 1943, 1954));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("nonRefundableAmountCurr", 1955, 1957));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("transactionTotalAmount", 1958, 1969));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("currencyOfTransTotalAmt", 1970, 1972));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("additionalCollectionTotal", 1973, 1984));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("currencyOfAddlCollection", 1985, 1987));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("fareConstruction", 1988, 2337));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("fareCalcModeIndicator", 2338, 2340));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("commissionRate", 2341, 2345));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("commissionAmount", 2346, 2357));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("currencyOfCommissionAmount", 2358, 2360));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("bankersExchangeRate", 2361, 2372));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("netFare", 2373, 2384));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("currencyOfNetFare", 2385, 2387));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("newTax", 2388, 3774));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("formOfIdentificationType", 5160, 5162));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("formOfIdentificationNumber", 5163, 5197));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("formOfIdentVendorCode", 5198, 5201));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("frequentFlyerAirlineCode", 5202, 5204));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("frequentFlyerCustomerCode", 5205, 5229));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("originalIssueInformation", 5230, 5299));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("originalEmdDocNumber1", 5300, 5312));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("originalEmdDocNumber2", 5313, 5325));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("originalEmdDocNumber3", 5326, 5338));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("originalEmdDocNumber4", 5339, 5351));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("originalEmdDocNumber5", 5352, 5364));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("originalEmdDocNumber6", 5365, 5377));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("originalEmdDocNumber7", 5378, 5390));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("formOfPayment", 5391, 5463));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("oldFormOfPayment", 5610, 5682));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("internationalSaleIndicaor", 5829, 5829));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("endorsementRestrictionText", 5830, 6459));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("ticketingModeIndicator", 6460, 6460));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("netRemitIndicator", 6461, 6461));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("nonEndorsableIndicator", 6462, 6462));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("presentCreditCardIndicator", 6463, 6463));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("filler", 6464, null));

	}
}
