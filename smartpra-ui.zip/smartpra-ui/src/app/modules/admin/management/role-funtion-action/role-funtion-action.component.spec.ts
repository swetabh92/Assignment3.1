import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RoleFuntionActionComponent } from './role-funtion-action.component';

describe('RoleFuntionActionComponent', () => {
  let component: RoleFuntionActionComponent;
  let fixture: ComponentFixture<RoleFuntionActionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RoleFuntionActionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RoleFuntionActionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
