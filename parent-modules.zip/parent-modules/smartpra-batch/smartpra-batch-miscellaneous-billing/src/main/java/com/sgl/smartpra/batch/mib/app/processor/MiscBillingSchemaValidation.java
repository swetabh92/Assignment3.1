/**
 * 
 */
package com.sgl.smartpra.batch.mib.app.processor;

import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.batch.mib.app.validator.SchemaValidator;

import lombok.extern.slf4j.Slf4j;

/**
 * @author kanprasa
 *
 */

@Scope(value = "step")
@Service
@Slf4j
public class MiscBillingSchemaValidation implements Tasklet{

	private SchemaValidator schemaValidator;
	
	public MiscBillingSchemaValidation(SchemaValidator schemaValidator) {
    	this.schemaValidator = schemaValidator;
    }
	
	@Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
    	log.debug("#################### Entering schemaValidation Tasklet ####################");
    	boolean isError = false;
       	JobParameters jobParameters = chunkContext.getStepContext().getStepExecution().getJobParameters();
       	Integer fileId = Integer.valueOf(jobParameters.getLong("fileId").intValue());
		String fileName = jobParameters.getString("fileName");
		String clientId = jobParameters.getString("clientId");
   		isError = schemaValidator.validateXMLSchema(fileName, clientId, fileId);
        log.debug("Error while processing SchemaValidation tasklet: " + isError);
        log.debug("#################### Exiting schemaValidation Tasklet ####################");
        return RepeatStatus.FINISHED;
    }
}
