package com.sgl.smartpra.batch.amadeus.app.config;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.context.annotation.Configuration;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.sgl.smartpra.batch.global.model.FileLogging;
import com.sgl.smartpra.common.validator.DateFormat;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.flown.model.EMDQueue;
import com.sgl.smartpra.flown.model.FlightDataDetails;
import com.sgl.smartpra.global.master.model.Carrier;
import com.sgl.smartpra.master.model.AgencyMaster;
import com.sgl.smartpra.master.model.BookingClassModel;
import com.sgl.smartpra.master.model.CarrierAlliance;
import com.sgl.smartpra.master.model.FormCode;
import com.sgl.smartpra.master.model.SystemParameter;
import com.sgl.smartpra.sales.domain.TicketMain;
import com.sgl.smartpra.sales.model.PAXTypeModel;

@Configuration
public class FeignConfiguration {

	@FeignClient(value = "smartpra-batch-global-app")
	public interface BatchGlobalFeignClient {

		@PostMapping("/filelog")
		public FileLogging createFileLog(@Valid @RequestBody FileLogging fileLog);

		@GetMapping("/filelogs/filename/{fileName}")
		public List<FileLogging> getFileLogByFileName(@PathVariable(value = "fileName") String fileName);

		@GetMapping("/filelog/{fileId}")
		public FileLogging getFileLogByFileId(@PathVariable(value = "fileId") BigInteger fileId);

		@PutMapping("/filelog/{fileId}")
		public FileLogging updateFileLog(@PathVariable(value = "fileId") BigInteger fileId,
				@Valid @RequestBody FileLogging fileLog);
	}

	@FeignClient(value = "smartpra-flown-app")
	public interface FlownFeignClient {

		@GetMapping("/flight-data-details")
		public List<FlightDataDetails> getAllFlightDataDetails(
				@RequestParam(value = "flightNumber", required = false) String flightNumber,
				@RequestParam(value = "fromAirport", required = false) String fromAirport,
				@RequestParam(value = "toAirport", required = false) String toAirport,
				@RequestParam(value = "flightStatus", required = false) String flightStatus);
		
		
		@GetMapping("/flight-data-details/search")
		public FlightDataDetails getFlightDataDetails(
				@RequestParam(value = "flightNumber", required = true) String flightNumber,
				@RequestParam(value = "fromAirport", required = true) String fromAirport,
				@RequestParam(value = "toAirport", required = true) String toAirport,
				@RequestParam(value = "flightDate", required = true) LocalDate flightDate,
				@RequestParam(value = "flightStatus", required = false) String flightStatus);
			
		

		@PostMapping("/emd-queue")
		public EMDQueue loadfromFlownEmd(@RequestBody EMDQueue eMDQueue);

		@GetMapping("/couponvalidation/fileid/{fileId}")
		public Integer validateCouponsForFileId(@PathVariable(value = "fileId") Integer fileId);

	}

	@FeignClient(value = "smartpra-master-app")
	public interface MasterFeignClient {

		@GetMapping("/form-code")
		public List<FormCode> getAllFormCode(@RequestParam(value = "formCode", required = false) String formCode,
				@RequestParam(value = "documentType", required = false) String documentType,
				@RequestParam(value = "numberOfCoupon", required = false) String numberOfCoupon,
				@RequestParam(value = "effectiveFromDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveFromDate,
				@RequestParam(value = "effectiveToDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> effectiveToDate);

		@GetMapping("/system-parameters-with-date/{parameterName}")
		public List<SystemParameter> getSystemParameterByparameterName(
				@PathVariable(value = "parameterName") String parameterName);

		@GetMapping("/agency-master")
		public List<AgencyMaster> getAllAgency(@RequestParam(value = "agencyCode", required = true) String agencyCode,
				@RequestParam(value = "reportingAgency", required = false) String reportingAgency,
				@RequestParam(value = "agencyType", required = false) String agencyType,
				@RequestParam(value = "areaOfOperation", required = false) String areaOfOperation,
				@RequestParam(value = "reportingAgencyType", required = false) String reportingAgencyType,
				@RequestParam(value = "activate", required = false) Boolean activate);
		
		
		@PostMapping("/agency-master")
		@ResponseStatus(value = HttpStatus.CREATED)
		public AgencyMaster createAgencyMaster(@Validated(Create.class)@RequestBody AgencyMaster agencyMaster);

		@GetMapping("/booking-class")
		public List<BookingClassModel> getListOfBookingClassByUtilizationEffectiveDate(
				@RequestParam(value = "utilizationEffectiveDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> utilizationEffectiveDate,
				@RequestParam(value = "rbd", required = false) String rbd,
				@RequestParam(value = "salesEffectiveDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") Optional<String> salesEffectiveDate,
				@RequestParam(value = "cabin", required = false) String cabin,
				@RequestParam(value = "marketingCarrier", required = false) String marketingCarrier,
				@RequestParam(value = "fromAirport", required = false) String fromAirport,
				@RequestParam(value = "toAirport", required = false) String toAirport);
		
		
		
		
		@GetMapping("/carrier-alliance/searchByCarrierCode")
		public List<CarrierAlliance> search(
				@RequestParam(value = "carrierCode", required = true) @NotEmpty String carrierCode,
				@RequestParam(value = "effectiveDate", required = false) @DateFormat(pattern = "yyyy-MM-dd") String effectiveDate);
	}

	@FeignClient(value = "smartpra-global-master-app")
	public interface CarrierMasterFeignClient {
		@GetMapping("/carriers")
		public List<Carrier> getAllCarrier(
				@RequestParam(value = "carrierCode", required = false) @Valid String carrierCode,
				@RequestParam(value = "carrierDesignatorCode", required = false) String carrierDesignatorCode,
				@RequestParam(value = "carrierName1", required = false) String carrierName1,
				@RequestParam(value = "carrierName2", required = false) String carrierName2,
				@RequestParam(value = "isActive", required = false) Boolean isActive);
	}

	/*
	 * @FeignClient(value = "smartpra-exception-txn-app") public interface
	 * ExceptionTxnFeignClient {
	 * 
	 * @PostMapping("/exceptions/transaction") public Long
	 * createExceptionTransaction(@RequestBody ExceptionTransactionModel
	 * exceptionTransaction); }
	 */

	@FeignClient(value = "smartpra-exception-transaction-integration")
	public interface ExceptionTxnFeignClient {
		@PostMapping("/api/init-exceptionmessage")
		public void initExceptionTrasaction(@RequestBody ExceptionTransactionModel exceptionTransactionModel);
	}

	@FeignClient(value = "smartpra-sales-service")
	public interface PaxFeignClient {
		@PostMapping("/paxtype")
		String getPaxTypeFromTicketMain(@RequestBody PAXTypeModel paxTypeModel);
	}

}
