import {Component, Input, OnInit, ViewChild} from '@angular/core';
import {DatatableComponent} from '@swimlane/ngx-datatable';

@Component({
  selector: 'app-sale-transferred',
  templateUrl: './sale-transferred.component.html',
  styleUrls: ['./sale-transferred.component.css']
})
export class SaleTransferredComponent implements OnInit {


  currentSort1:any = [{ prop: "", dir: 'asc'}];
  @ViewChild('sortTable') sortTable: DatatableComponent;

  saleProductionData =[{"name":"SALE","key":"sale"},{"name":"REFUND","key":"refund"},{"name":"EXCHANGE","key":"exchange"},{"name":"ADM","key":"adm"},{"name":"ACM","key":"acm"}];

  constructor() { }

  ngOnInit() {
  }

  @Input() fileSaleTransferredDetails;
  @Input() page;


  onCustomSort(sortCol: string) {
    let sortDir = 'asc';
    if(this.currentSort1[0].prop === sortCol) sortDir = this.currentSort1[0].dir === 'asc'?'desc':'asc';
    this.currentSort1 = [{ prop: sortCol, dir: sortDir }];
    this.sortTable.onColumnSort({ sorts: this.currentSort1});
  }

}
