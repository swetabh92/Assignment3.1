import { Injectable } from '@angular/core';
import swal from 'sweetalert2';

@Injectable({
  providedIn: 'root'
})
export class MessageBoxService {

  constructor() { }

  getErrorMessage(title: string , message: string) {
    return swal({
      title: title ,
      text: message ,
      type: 'error',
      confirmButtonColor: '#ffb000',
    } as any);

  }

  getSuccessMessage(title: string , message: string) {
    return swal({
      title: title ,
      text: message ,
      type: 'success',
      confirmButtonColor: '#ffb000',
    }as any);
  }

  showFormError() {
    return this.getErrorMessage('Error', 'Sorry error in the form');
  }

  showSaveErrorMessage() {
    return this.getErrorMessage('Error', 'Sorry could not save');
  }

  showFetchErrorMessage() {
    return this.getErrorMessage('Error', 'Sorry error fetching record');
  }

  showStatusUnchangedMessage(recordType: string) {
    return this.getErrorMessage('Cancelled', recordType + ' status remains unchanged');
  }

  showDataUpdateMessage() {
    return this.getSuccessMessage('Success' , 'Record has been successfully saved');
  }

  showDeactivationSuccess(recordType: string) {
    return this.getSuccessMessage('Deactivated!' , recordType + ' has been deactivated.');
  }

  showActivationSuccess(recordType: string) {
    return this.getSuccessMessage('Activated!' , recordType + ' has been activated.');
  }

  showGeneralErrorMessage(errorType, errorMessage){
    this.getErrorMessage(errorType,errorMessage);
  }

  showDeactivationMessage(recordType) {
    return swal({
      type: 'warning',
      title: 'Are you sure to deactivate this record of ' + recordType + '?',
      text: 'Record will not be considered for any processing post deactivation',
      showCancelButton: true,
      confirmButtonColor: '#ff0000',
      cancelButtonColor: '#049F0C',
      confirmButtonText: 'Yes, deactivate it!',
      cancelButtonText: 'No, keep it as active',
      closeOnClickOutside: false,
      closeOnEsc: false,
      allowOutsideClick: false,
    } as any);
  }

  showActivationMessage(recordType) {
    return swal({
      type: 'warning',
      title: 'Are you sure to activate this record of ' + recordType + '?',
      showCancelButton: true,
      confirmButtonColor: '#049F0C',
      cancelButtonColor: '#ff0000',
      confirmButtonText: 'Yes, Activate it!',
      cancelButtonText: 'No, keep it as inactive',
      closeOnClickOutside: false,
      closeOnEsc: false,
      allowOutsideClick: false,
    } as any);
  }

}