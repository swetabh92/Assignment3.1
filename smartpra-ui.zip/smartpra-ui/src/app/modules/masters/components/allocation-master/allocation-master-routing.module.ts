import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AllocationMasterComponent } from './allocation-master.component';

const routes: Routes = [
  {path:'',component:AllocationMasterComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AllocationMasterRoutingModule { }
