export enum AllocationMasterEnums {
  "mas_pos" = "Station",
  "mas_region" = "Region",
  "mas_list_of_values" = "Zone"
}

export function zonesList() {
  return ["A", "B", "C", "D"]
}

export function getFormObj() {
  return {
    fileTypeMappingId: [],
    moduleLovId: [],
    referenceTableName: [],
    effectiveToDate: [],
    exceptionfromDate: [],
    groupId: [],
    fileType: [],
    exceptiontoDate: [],
    salesPeriodToDate: [],
    salesperiodFromDate: [],
    utilizationToDate: [],
    utilizationFromDate: [],
    flightStatus: [],
    flightCategory: [],
    flightFromDate: [],
    flightToDate: [],
    oal: [],
    routeCode: [],
    Region: [],
    teamId: [],
    billingCurrency: [],
    billingCarrier: [],
    billingMonth: [],
    stationName: [],
    allianceName: [],
    zones: [],
    sourceCode: [],
    listingCurrency: [],
    createdBy: ['Admin']
  };
}

export function getDateOptions() {
  return {
    format: 'YYYY-MM-DD',
    displayFormat: 'MM/DD/YYYY',
    useEmptyBarTitle: false,
    maxDate: new Date(Date.now()),
    addStyle: {'width': '100%'},
    displayValue: 'YYYY-MM-DD',
  };
}

export function allocationMasterConstant() {
  return {
    "SALE": ["moduleLovId", "moduleName", "groupId", "teamId", "stationName", "fileType", "exceptiontoDate", "exceptionfromDate", "salesperiodRange", "salesPeriodToDate", "utilizationFromDate", "utilizationToDate"],
    "FLOWN": ["moduleLovId", "moduleName", "groupId", "teamId", "flightStatus", "flightCategory", "flightFromDate", "flightToDate", "oal", "routeCode"],
    "INTERLINE": ["moduleLovId", "moduleName", "groupId", "teamId", "filetype", "billingCurrency", "zones", "billingCarrier", "allianceName", "listingCurrency"],
    "SIMPLE_DATE_FORMAT": "yyyy-MM-dd"
  }
};


export function getFileTypes() {
  return {
    'SALES': ['BSP', 'ARC', 'ASR', 'SITA HOT', 'Amadeus HOT'],
    'FLOWN': ['Sabre XL', 'VCR', 'AmadeusEtkt', 'Sita E-txt', 'SSIM'],
    'INTERLINE': ['IS-IDEC', 'IS-MISC', 'CodeShare']
  };
}

export function ModulesEnum() {
  return {
    'SALES': 'SALE',
    'FLOWN': 'FLOWN',
    'INWARD': 'INWARD',
    'INTERLINE': 'INTERLINE',
    'OTHERS': 'OTHERS',
    'OUTWARD': 'OUTWARD',
  }
}


