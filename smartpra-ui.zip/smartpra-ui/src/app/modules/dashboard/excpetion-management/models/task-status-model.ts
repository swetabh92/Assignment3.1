
export interface TaskStatusModel{
  taskStatusList : TaskStatusObject[];
  teamName : string;
  teamId: number;
}

export class TaskStatusEnumModel{
  "WORK_IN_PROGRESS":number;
  "PENDING_APPROVAL":number;
  "RESOLVED":number;
  "CLOSED":number;
  "ASSIGNED":number;
}


export interface TaskStatusObject{
  count:number;
  status:string;
}



