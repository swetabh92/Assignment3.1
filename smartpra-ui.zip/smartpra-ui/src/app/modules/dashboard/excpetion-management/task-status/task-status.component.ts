import {Component, EventEmitter, Input, OnInit, Output, TemplateRef, ViewChild, HostListener} from '@angular/core';
import * as _ from 'underscore';
import {Color, Label} from "ng2-charts";
import 'chartjs-plugin-labels';
import {ChartConstants} from "../../../../commons/constants/chart-constants";
import {ExceptionManagementService} from "../../../masters/services/dashboard/exception-management.service";
import {ExceptionManagementUtil} from "../utils/exception-management-util";
import { ExceptionConstant } from '../constants/exception-contants';

@Component({
  selector: 'app-task-status',
  templateUrl: './task-status.component.html',
  styleUrls: ['./task-status.component.css']
})
export class TaskStatusComponent implements OnInit {
  @Input() footerHeight: number;
  @Input() rowCount: number;
  @Input() pageSize: number = 1;
  @Input() offset: number;
  @Input() pagerLeftArrowIcon: string = "datatable-icon-left";
  @Input() pagerRightArrowIcon: string = "datatable-icon-right";
  @Input() pagerPreviousIcon: string = "datatable-icon-prev";
  @Input() pagerNextIcon: string = "datatable-icon-skip";
  @Input() totalMessage: string;
  @Input() footerTemplate: TemplateRef<any>;
  @Input() selectedCount: number = 1;
  @Input() selectedMessage: string | boolean;
  @Output() page: EventEmitter<any> = new EventEmitter();

  @Input('modules') modules;
  @Input('groups') groups;
  @ViewChild('closeModalAdd') closeModal;

  chartResponseData: any = [];
  doughnutChartData: any = [];
  userResponseData: any = [];
  showTeamMembers: boolean = false;
  exceptionStatusLabel: Label[] = [ExceptionConstant.WORK_IN_PROGRESS, ExceptionConstant.PENDING_APPROVAL, ExceptionConstant.RESOLVED, ExceptionConstant.CLOSED, ExceptionConstant.ASSIGNED];
  chartColours: Color[] = [{"backgroundColor": ["#FFC634", "#f58142", "#7AACFF", "#93f391", "#f9bbbb"]}];
  totalResponseData: any = [];
  doughnutChartType: any = ChartConstants.DOUGHNUT;
  chartOptions: any;
  currentPage: number = 1;
  recordLength: any;
  selectedGroupId: number;
  teamName: string;

  constructor(private exceptionManagementService: ExceptionManagementService, private exceptionManagementUtil: ExceptionManagementUtil) {
  }

  ngOnInit() {
   
      
  }

  @HostListener('document:keydown.escape', ['$event']) onKeydownHandler(event: KeyboardEvent) {
    this.closeModal.nativeElement.click();
  }

  onSelectGroups(groupId: number) {
    this.currentPage = 1;
    this.showTeamMembers = false;
    this.selectedGroupId = groupId;
    this.exceptionManagementService.getTaskStatusByGroupId(groupId).subscribe((res: any) => {
      this.chartResponseData = this.exceptionManagementUtil.parseTeamExceptionStatus(res, "T");
      this.rowCount = this.chartResponseData.length / 2;
      this.prepareTaskStatusResults(this.chartResponseData);
    });
  }

  viewTeamMembers(teamObj: any) {
    this.showTeamMembers = true;
    this.teamName = teamObj.name;
    this.exceptionManagementService.getTaskStatusByTeam(teamObj.id).subscribe((res: any) => {
      this.userResponseData = this.exceptionManagementUtil.parseTeamExceptionStatus(res, "U");
      this.rowCount = this.userResponseData.length / 2;
      this.prepareTaskStatusResults(this.userResponseData);
    });
  }

  prepareTaskStatusResults(datas: any) {
    let i, index, iterator, minus: number;
    this.totalResponseData = datas;
    this.recordLength = datas.length;
    minus = (datas.length) % 2;
    this.doughnutChartData = [];
    if (this.recordLength !== 0) {
      index = (this.currentPage - 1) * 2;
      if (minus && (((this.currentPage * 2) - 1) == this.recordLength)) {
        iterator = (this.currentPage * 2) - minus;
      } else {
        iterator = (this.currentPage * 2);
      }

      for (i = index; i < iterator; i++) {
        if (datas[i]) {
          let chartObj: any = {};
          chartObj.data = datas[i].chartValue;
          chartObj.name = datas[i].name;
          chartObj.id = datas[i].id;
          this.doughnutChartData.push(chartObj);
        }
      }
    }
  }

  onPageChange(event) {
    this.currentPage = event.page;
    this.prepareTaskStatusResults(this.totalResponseData);
  }
}
