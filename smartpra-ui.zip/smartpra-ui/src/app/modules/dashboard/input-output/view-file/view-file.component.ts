import {Component, Host, Input, OnInit,Output,EventEmitter} from '@angular/core';
import {InputOutputService} from '../../../masters/services/dashboard/input-output.service';
import {BatchListModel} from '../../sales-dashboard/model/sale-model';

@Component({
  selector: 'app-view-file',
  templateUrl: './view-file.component.html',
  styleUrls: ['./view-file.component.css'],
})
export class ViewFileComponent implements OnInit {

  constructor(private inputService: InputOutputService) {
  }

  @Output() getListOfFiles = new EventEmitter();


  ngOnInit() {

  }

  emitListOfFiles() {
    this.getListOfFiles.emit();
  }

}
