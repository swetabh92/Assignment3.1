export interface StandaloneProration {
    issueAirline:String;
    mainDocument:String;
    documentNumber:String;
    docType:String;
    agentCode:String;
    dateOfIssue:Date;
    placeOfSale:String;
    emdIndicator:String;
    btItIndicator:String;
    rfisc:String;
    paxType:String;
    uatpFlag:String;
    involFlag:String;
    ffyIndicator:string;
    originalDocumentNumber:String;
    originalDateOfIssue:Date;
    originalPlaceOfIssue:String;
    currencyOfSale:String;
    fareCompCurrency:String;
    grossFare:Number;
    equivalentCurrencyOfSale:String;
    equivalentFare:Number;
    commisionAmount:Number;
    discountAmount:Number;
    tourCode:String;
    netFareAmount:Number;
    passengerName:String;
    endorsements:String;
    fca:String;
    mprPercentage:Number,
    achFactor:Number,
    roeRate:Number,
    prorationMethod:String,
    prorationSource:String,
    equivalentFareCurrency:String,
    atbpCurrency:String,
    onlineInterlineOffline: String,
    involflag:Boolean;
    involIndicator:string;
   

    // <!-- Coupon Level -->
    ticketCoupons:[{
    pot:String;
    drIndicator:String;
    stopoverInd:String;
    couponNumber:Number;
    fromAirport:String;
    toAirport:String;
    marketingCarrierAlphaCode:String;
    ticketedRbd:String;
    fareBasis:String;
    marketingFlightNumber:String;
    marketingFlightDate:Date;
    departureTime:String;
    arrivalTime:String;
    arrivalDate:Date;
    fareComponentValue:String;
    sectorNumber:String;
    operatingCarrierAlphaCode:String;
    atbpNumber:Number;
    srpValue:Number,
    mpaWoOwnProviso:String,
    spaResidual:String,
    mpaResidual:String,
    otherDifferences:String,
    sirsRate:String,
    industryProrateValue:Number,
    srpMethod:String,
    provisoValue:Number,
    prorateFactor:Number,
    mprPercentage:number,
    settlementProrateValue:Number,
    finalQuotient:Number;
    atbpValue:Number;
    }
]

//     ticketLevelInfo:[{
//     ticketIssueDate:Date;
//     mprQuotient:Number;
//     prorationMethodType:String;
//     utilizationType:String;
//     equivalentFareCurrency:String;
//     atbpCurrency:String;
//         totalFare:[{
//             fareCompCurrency:Number;
//             roe:Number;
//             involflag:Boolean;
//     }]
// }]
}
