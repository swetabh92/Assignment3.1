package com.sgl.smartpra.batch.mmr.app.layout;

import java.util.ArrayList;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;
import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;

public class MMRHeaderLayout extends FixedLengthRecordLayout{

public MMRHeaderLayout() {
		
		fixedLengthFieldLayoutList = new ArrayList<FixedLengthFieldLayout>();
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("effectiveDate",16,23));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("value",24,26));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("variationTo",27,null));
	}
	
}
