package com.sgl.smartpra.allocation.master.app.dao.spec;

import java.util.List;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.allocation.master.app.entity.AllocationMasterEntity;

public final class AllocationMasSpecification {
	
	private AllocationMasSpecification(){
		
	}
	
	public static Specification<AllocationMasterEntity> fileTypeMappingIdsIn(final List<Integer> fileTypeMappingIds) {
		return (allocationMasterEntity, criteriaQuery, criteriaBuilder) -> allocationMasterEntity.get("fileTypeMappingId").in(fileTypeMappingIds);
	}

}
