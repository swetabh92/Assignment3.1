import { UpperalphaDirective } from './upperalpha.directive';

describe('UpperalphaDirective', () => {
  it('should create an instance', () => {
    const directive = new UpperalphaDirective();
    expect(directive).toBeTruthy();
  });
});
