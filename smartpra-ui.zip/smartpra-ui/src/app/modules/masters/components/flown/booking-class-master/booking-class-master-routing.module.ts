import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BookingClassMasterComponent } from './booking-class-master.component';

const routes: Routes = [
  {path:'',component:BookingClassMasterComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BookingClassMasterRoutingModule { }
