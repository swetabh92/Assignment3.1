import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FormelementsRoutingModule } from './formelements-routing.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { FormelementsComponent } from './formelements.component';
import { CoreDataModule } from 'src/app/core-data/core-data.module';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    CoreDataModule,
    FormelementsRoutingModule
  ],
  declarations: [
    FormelementsComponent
  ]
})
export class FormelementsModule { }
