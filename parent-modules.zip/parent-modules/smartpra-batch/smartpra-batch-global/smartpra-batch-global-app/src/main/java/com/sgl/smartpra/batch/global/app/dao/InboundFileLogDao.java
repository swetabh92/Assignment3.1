package com.sgl.smartpra.batch.global.app.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;

import com.sgl.smartpra.batch.global.app.entity.InboundFileLogEntity;
import com.sgl.smartpra.batch.global.app.mapper.InboundFileLogMapper;
import com.sgl.smartpra.batch.global.app.repository.InboundFileLogRepository;
import com.sgl.smartpra.batch.global.model.InboundFileLog;

@Service
public class InboundFileLogDao {

	@Autowired
	InboundFileLogRepository inboundFileLogRepository;

	@Autowired
	InboundFileLogMapper inboundFileLogMapper;

	public InboundFileLog save(InboundFileLog inboundFileLog) {

		return inboundFileLogMapper.mapToInboundFileLogModel(
				inboundFileLogRepository.save(inboundFileLogMapper.mapToInboundFileLogEntity(inboundFileLog)));

	}

	public List<InboundFileLog> findAll() {
		return inboundFileLogMapper.mapToInboundFileLogModelList(inboundFileLogRepository.findAll());

	}
	
	public List<InboundFileLog> getInboundFileLogByFileName(String inboundFileName) {
		return inboundFileLogMapper.mapToInboundFileLogModelList(inboundFileLogRepository.getInboundFilesByName(inboundFileName));

	}

	public InboundFileLog getInboundFileLogByInboundFileId(Integer inboundFileId) {
		Optional<InboundFileLogEntity> inboundFileLogEntity = inboundFileLogRepository.findById(inboundFileId);

		return inboundFileLogMapper.mapToInboundFileLogModel(inboundFileLogEntity.get());

	}

	public boolean isValidInboundFileId(Integer inboundFileId) {
		boolean isValid = false;
		String inboundFileIdDb = inboundFileLogRepository.getInboundFileId(inboundFileId);
		if (inboundFileIdDb != null) {
			return true;
		}
		return isValid;
	}

	public InboundFileLog updateLoadStatus(Integer inboundFileId, Boolean flag) {
		Optional<InboundFileLogEntity> inboundFileLogEntity=inboundFileLogRepository.findById(inboundFileId);
		if(flag) {
		inboundFileLogEntity.get().setLoadStatus("SUCCESS");
		}else {
			inboundFileLogEntity.get().setLoadStatus("FAILED");
		}
		return inboundFileLogMapper.mapToInboundFileLogModel(inboundFileLogRepository.save(inboundFileLogEntity.get()));
	}
	

}
