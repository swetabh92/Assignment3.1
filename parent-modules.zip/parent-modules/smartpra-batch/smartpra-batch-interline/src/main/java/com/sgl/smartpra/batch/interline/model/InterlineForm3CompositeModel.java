package com.sgl.smartpra.batch.interline.model;

import com.sgl.smartpra.interline.domain.entity.prod.form3.InterlineForm3Details;
import com.sgl.smartpra.interline.domain.entity.stg.form3.InterlineForm3CsvStg;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class InterlineForm3CompositeModel {
	
	private InterlineForm3CsvStg interlineForm3CsvStg;
	
	private InterlineForm3Details interlineForm3Details;
}
