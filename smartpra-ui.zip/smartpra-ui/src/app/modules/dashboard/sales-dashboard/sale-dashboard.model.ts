export const TransactionType={
  "S": "Sale",
  "R": "Refund",
  "E": "Exchange",
  "C": "ACM",
  "D": "ADM",
  "V": "Void"
}
export const FormOfPaymentType={
  "CC":"Credit Card",
  "DI":"Discount",
  "CA":"Cash",
  "CO":"Commission",
  "DB":"Debit",
  "GF":"Gross Fare",
  "IN":"Invoice",
  "TX":"Tax",
  "TT":"Total"
}
