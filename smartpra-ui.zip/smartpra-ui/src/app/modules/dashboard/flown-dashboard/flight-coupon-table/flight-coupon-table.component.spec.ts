import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FlightCouponTableComponent } from './flight-coupon-table.component';

describe('FlightCouponTableComponent', () => {
  let component: FlightCouponTableComponent;
  let fixture: ComponentFixture<FlightCouponTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FlightCouponTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FlightCouponTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
