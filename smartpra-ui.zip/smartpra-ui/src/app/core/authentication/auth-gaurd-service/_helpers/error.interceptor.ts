import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Router, ActivatedRoute } from '@angular/router';

import { AuthenticationService } from '../_services';
import { first } from 'rxjs/operators';
import { Cookie } from 'ng2-cookies';

@Injectable()
export class ErrorInterceptor implements HttpInterceptor {
    refreshToken = false;
    cachedRequests: Array<HttpRequest<any>> = [];
    constructor(private authenticationService: AuthenticationService, private router: Router) {}

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        return next.handle(request).pipe(catchError(err => {
            // console.log(err);
            // console.log(request);
            // console.log(next);
            if (err.status === 401) {
                // this.cachedRequests.push(request);
                if (!this.refreshToken ) {
                    this.refreshToken = true;
                    // console.log(request);
                    this.authenticationService.refreshToken().pipe(first()).subscribe(
                    (data) => {
                        console.log(data);
                    });
                 }
            }
            // const error = err.error.error || err.error.error_description;
           return throwError(err);
        }));
    }
}
