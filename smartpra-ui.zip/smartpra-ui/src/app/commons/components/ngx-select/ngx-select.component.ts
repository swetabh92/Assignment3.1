import { Component, OnInit,Input,EventEmitter,Output } from '@angular/core';

@Component({
  selector: 'app-ngx-select',
  templateUrl: './ngx-select.component.html',
  styleUrls: ['./ngx-select.component.css']
})
export class NgxSelectComponent implements OnInit {
  limits = [{key: 5,value: '5'},{key: 10,value: '10'},{key: 20,value: '20'}];
  @Input() value;
  @Input('length')  
  set length(val:any){
	if(val == undefined || val ==null ) val =0;
	// this.limits[this.limits.length-1].key = val;
  }
  @Output() valueChange = new EventEmitter();
  @Output() changeValue = new EventEmitter();
  constructor() { 
	
  }
  emitChange(){
    this.valueChange.emit(this.value);
    this.changeValue.emit();
  }
  ngOnInit() {
  }

}
