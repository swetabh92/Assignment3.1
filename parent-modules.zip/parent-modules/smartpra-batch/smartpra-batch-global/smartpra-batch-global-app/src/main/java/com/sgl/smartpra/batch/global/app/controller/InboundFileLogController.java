package com.sgl.smartpra.batch.global.app.controller;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.batch.global.app.dao.InboundFileLogDao;
import com.sgl.smartpra.batch.global.model.InboundFileLog;

@RestController
public class InboundFileLogController {

	@Autowired
	InboundFileLogDao inboundFileLogDAO;

	@GetMapping("/inboundFileLogs")
	public List<InboundFileLog> getAllInboundFileLog() {

		return inboundFileLogDAO.findAll();

	}

	@GetMapping("/inboundFileLogs/{inboundFileId}")
	public InboundFileLog getInboundFileLogByInboundFileId(
			@PathVariable(value = "inboundFileId") Integer inboundFileId) {
		return inboundFileLogDAO.getInboundFileLogByInboundFileId(inboundFileId);

	}
	
	@GetMapping("/inboundFileLogs/inboundFileName/{inboundFileName}")
	public List<InboundFileLog> getInboundFileLogByFileName(@PathVariable(value = "inboundFileName") String inboundFileName) {
		return inboundFileLogDAO.getInboundFileLogByFileName(inboundFileName);

	}
	

	@PostMapping("/inboundFileLogs")
	public InboundFileLog createInboundFileLog(@Valid @RequestBody InboundFileLog inboundFileLog) {

		inboundFileLog.setUploadStarttime(new Timestamp(new Date().getTime()));
		inboundFileLog.setUploadEndtime(new Timestamp(new Date().getTime()));

		return inboundFileLogDAO.save(inboundFileLog);

	}

	@GetMapping("/inboundFileLogs/{inboundFileId}/validate")
	public boolean validateInboundFileId(@PathVariable(value = "inboundFileId") Integer inboundFileId) {
		return inboundFileLogDAO.isValidInboundFileId(inboundFileId);
	}
	
	   //calling from mmr and fdr loading
		@PutMapping("/inboundFileLogs-update/{inboundFileId}/{flag}")
		public InboundFileLog updateLoadStatus(@PathVariable(value="inboundFileId")Integer inboundFileId,@PathVariable(value="flag") Boolean flag) {
			return inboundFileLogDAO.updateLoadStatus(inboundFileId,flag);
		}

}
