import {Component, OnInit} from '@angular/core';
import {UserprofileService} from "../../../modules/admin/services/userprofile.service";

@Component({
  selector: 'app-leftsidebar',
  templateUrl: './leftsidebar.component.html',
  styleUrls: ['./leftsidebar.component.css']
})
export class LeftsidebarComponent implements OnInit {

  constructor(private userservice: UserprofileService) {
  }

  userObj: any;

  ngOnInit() {
    this.displayUsername();
  }

  displayUsername() {
  /*  let userName = localStorage.getItem('currentUserName');
    if (userName != null && userName != "undefined") {
      this.userObj = userName;
    } else {
      let email = localStorage.getItem('loggedin_email');
      if (email != null) {
        this.userservice.searchUserprofile({'email': email}).subscribe(
          (userservice: any) => {
            if(!!userservice){
              this.userObj = userservice[0].userFullName;
              localStorage.setItem("currentUserName", this.userObj.userFullName)
            }         
          });
      }
    }*/
  }

}
