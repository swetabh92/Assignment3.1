export class Userrole {
  isActive: true;
  masRoleId: number;
  masUserRoleId: number;
  masUsersId: number;
    constructor() { }
  }
