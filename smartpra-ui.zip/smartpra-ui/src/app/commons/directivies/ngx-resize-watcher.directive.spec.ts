import { NgxResizeWatcherDirective } from './ngx-resize-watcher.directive';

describe('NgxResizeWatcherDirective', () => {
  it('should create an instance', () => {
    const directive = new NgxResizeWatcherDirective();
    expect(directive).toBeTruthy();
  });
});
