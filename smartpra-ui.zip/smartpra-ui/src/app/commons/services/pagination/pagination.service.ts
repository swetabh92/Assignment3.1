import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PaginationService {
  constructor() { }
  mergePageObj(tempObj,orgObj){
	if(tempObj.hasOwnProperty("count")) orgObj.count = tempObj.count;
	if(tempObj.hasOwnProperty("pageSize")) orgObj.pageSize = tempObj.pageSize;
	if(tempObj.hasOwnProperty("limit")) orgObj.limit = tempObj.limit;
	if(tempObj.hasOwnProperty("offset")) orgObj.offset = tempObj.offset;
	if(tempObj.hasOwnProperty("sorts")){
		orgObj.sort = tempObj.sorts[0].dir;
		orgObj.sortColumn = tempObj.sorts[0].prop;
		orgObj.offset = '0';
	}
	return orgObj;
  }

  getPageinateConfig() {
    return {
      "offset": '0',
      "count": '0',
      "pageSize": 5,
      "sort": '',
      "sortColumn": '',
      "PageLimits": [{key: 5, value: '5'}, {key: 10, value: '10'}, {key: 20, value: '20'}],
      "config": {
        "headerHeight": 50,
        "footerHeight": 50,
        "rowHeight": 25,
        "actionoption1": 90,
        "actionoption2": 160,
        "minWidth": 90,
        "maxWidth": 90
      }
    }
  }

  setCustomPaginationConfig(config: any) {
    return {
      "size" : config && config.size ? config.size : 0,
      "totalElements" : config && config.totalElements ? config.totalElements : 0,
      "totalPages" : config && config.totalPages ? config.totalPages : 0,
      "pageNumber" : config && config.pageNumber ? config.pageNumber : 0,
      "offset" : config && config.offset ? config.offset : 0,
      "count": config && config.count ? config.count : 0,
      "pageSize": config && config.pageSize ? config.pageSize : 10,
      "sort": config && config.sort ? config.sort : '',
      "sortColumn": config && config.sortColumn ? config.sortColumn : '',
      "PageLimits": config && config.pageLimits ? config.pageLimits : [{key: 5, value: '5'}, {key: 10, value: '10'}, {key: 20, value: '20'}],
      "config": {
        "headerHeight": config && config.headerHeight ? config.headerHeight : 50,
        "footerHeight": config && config.footerHeight ? config.footerHeight : 50,
        "rowHeight": config && config.rowHeight ? config.rowHeight : 25,
        "actionoption1": config && config.actionoption1 ? config.actionoption1 : 90,
        "actionoption2": config && config.actionoption2 ? config.actionoption2 : 160,
        "minWidth": config && config.minWidth ? config.minWidth : 90,
        "maxWidth": config && config.maxWidth ? config.maxWidth : 90,
      }
    }
  }

  getQueryObj(Obj) {
    let tempObj = {};
    if (!this.isEmpty(Obj.offset)) tempObj["page"] = Obj.offset;
    if (!this.isEmpty(Obj.pageSize)) tempObj["size"] = Obj.pageSize;
    if (!this.isEmpty(Obj.sort)) {
      tempObj["sort"] = Obj.sortColumn + "," + Obj.sort;
    }
    return tempObj;
  }
  isEmpty(val){
	  if((val == "" || val == undefined || val == null) && typeof val != 'boolean') return true;
	  else return false;
  }
}
