import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FlownFlightListComponent } from './flown-flight-list.component';

describe('FlownFlightListComponent', () => {
  let component: FlownFlightListComponent;
  let fixture: ComponentFixture<FlownFlightListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FlownFlightListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FlownFlightListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
