import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NgxGroupHeaderComponent } from './ngx-group-header.component';

describe('NgxGroupHeaderComponent', () => {
  let component: NgxGroupHeaderComponent;
  let fixture: ComponentFixture<NgxGroupHeaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NgxGroupHeaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NgxGroupHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
