package com.sgl.smartpra.batch.amadeus.app.domain;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.sgl.smartpra.batch.amadeus.app.layout.StagingETLV2_20Layout;
import com.sgl.smartpra.batch.amadeus.app.processor.StagingCommonProcessor;

/**
 * The persistent class for the amadeus_record_detail_stg database table.
 * 
 */
@Entity
@Table(name = "amadeus_record_detail_stg")
@NamedQuery(name = "AmadeusRecordDetailStaging.findAll", query = "SELECT a FROM AmadeusRecordDetailStaging a")
public class AmadeusRecordDetailStaging extends AmadeusBatchRecord implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "amadeus_cpn_dtl_id")
	private int amadeusCpnDtlId;

	@Column(name = "airline_code")
	private String airlineCode;

	@Column(name = "consumed_at_issuance_indicator")
	private String consumedAtIssuanceIndicator;

	@Column(name = "coupon_number")
	private String couponNumber;

	@Column(name = "coupon_value")
	private String couponValue;

	@Column(name = "destination")
	private String destination;

	@Column(name = "ebt_charge_currency")
	private String ebtChargeCurrency;

	@Column(name = "ebt_charge_qualify")
	private String ebtChargeQualify;

	@Column(name = "ebt_rate_per_unit")
	private String ebtRatePerUnit;

	@Column(name = "ebt_unit_qualifier")
	private String ebtUnitQualifier;

	@Column(name = "emd_total_no_of_units")
	private String emdTotalNoOfUnits;

	@Column(name = "fare_basis")
	private String fareBasis;

	@Column(name = "fee_owner")
	private String feeOwner;

	@Column(name = "flight_arrival_date")
	private String flightArrivalDate;

	@Column(name = "free_baggage_allowance")
	private String freeBaggageAllowance;

	@Column(name = "invl_coupon_no")
	private String invlCouponNo;

	@Column(name = "invl_destination_airport")
	private String invlDestinationAirport;

	@Column(name = "invl_disruption_indicator")
	private String invlDisruptionIndicator;

	@Column(name = "invl_doc_no")
	private String invlDocNo;

	@Column(name = "invl_flight_date")
	private String invlFlightDate;

	@Column(name = "invl_flight_depart_time")
	private String invlFlightDepartTime;

	@Column(name = "invl_flight_number")
	private String invlFlightNumber;

	@Column(name = "invl_marketing_carrier_code")
	private String invlMarketingCarrierCode;

	@Column(name = "invl_origin_airport_code")
	private String invlOriginAirportCode;

	@Column(name = "invl_reservation_bkng")
	private String invlReservationBkng;

	@Column(name = "invl_stopover_code")
	private String invlStopoverCode;

	@Column(name = "involuntary_indicator")
	private String involuntaryIndicator;

	@Column(name = "non_exchangeable_indicator")
	private String nonExchangeableIndicator;

	@Column(name = "non_interlinable_indicator")
	private String nonInterlinableIndicator;

	@Column(name = "not_valid_after_date")
	private String notValidAfterDate;

	@Column(name = "not_valid_before_date")
	private String notValidBeforeDate;

	private String origin;

	@Column(name = "reason_for_issuance_sub_code")
	private String reasonForIssuanceSubCode;

	@Column(name = "reservation_status")
	private String reservationStatus;

	@Column(name = "sale_coupon_number")
	private String saleCouponNumber;

	@Column(name = "sale_flight_number")
	private String saleFlightNumber;

	@Column(name = "sale_local_flight_date")
	private String saleLocalFlightDate;

	@Column(name = "selling_class")
	private String sellingClass;

	@Column(name = "stop_over_code")
	private String stopOverCode;

	// bi-directional many-to-one association to AmadeusRecordStg
	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "amadeus_load_id", referencedColumnName = "amadeus_load_id")
	private AmadeusRecordStaging amadeusRecordStg;

	@Transient
	private String coupons;

	public AmadeusRecordDetailStaging() {
	}

	public int getAmadeusCpnDtlId() {
		return this.amadeusCpnDtlId;
	}

	public void setAmadeusCpnDtlId(int amadeusCpnDtlId) {
		this.amadeusCpnDtlId = amadeusCpnDtlId;
	}

	public String getAirlineCode() {
		return this.airlineCode;
	}

	public void setAirlineCode(String airlineCode) {
		this.airlineCode = airlineCode;
	}

	public String getConsumedAtIssuanceIndicator() {
		return this.consumedAtIssuanceIndicator;
	}

	public void setConsumedAtIssuanceIndicator(String consumedAtIssuanceIndicator) {
		this.consumedAtIssuanceIndicator = consumedAtIssuanceIndicator;
	}

	public String getCouponNumber() {
		return this.couponNumber;
	}

	public void setCouponNumber(String couponNumber) {
		this.couponNumber = couponNumber;
	}

	public String getCouponValue() {
		return this.couponValue;
	}

	public void setCouponValue(String couponValue) {
		this.couponValue = couponValue;
	}

	public String getDestination() {
		return this.destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getEbtChargeCurrency() {
		return this.ebtChargeCurrency;
	}

	public void setEbtChargeCurrency(String ebtChargeCurrency) {
		this.ebtChargeCurrency = ebtChargeCurrency;
	}

	public String getEbtChargeQualify() {
		return this.ebtChargeQualify;
	}

	public void setEbtChargeQualify(String ebtChargeQualify) {
		this.ebtChargeQualify = ebtChargeQualify;
	}

	public String getEbtRatePerUnit() {
		return this.ebtRatePerUnit;
	}

	public void setEbtRatePerUnit(String ebtRatePerUnit) {
		this.ebtRatePerUnit = ebtRatePerUnit;
	}

	public String getEbtUnitQualifier() {
		return this.ebtUnitQualifier;
	}

	public void setEbtUnitQualifier(String ebtUnitQualifier) {
		this.ebtUnitQualifier = ebtUnitQualifier;
	}

	public String getEmdTotalNoOfUnits() {
		return this.emdTotalNoOfUnits;
	}

	public void setEmdTotalNoOfUnits(String emdTotalNoOfUnits) {
		this.emdTotalNoOfUnits = emdTotalNoOfUnits;
	}

	public String getFareBasis() {
		return this.fareBasis;
	}

	public void setFareBasis(String fareBasis) {
		this.fareBasis = fareBasis;
	}

	public String getFeeOwner() {
		return this.feeOwner;
	}

	public void setFeeOwner(String feeOwner) {
		this.feeOwner = feeOwner;
	}

	public String getFlightArrivalDate() {
		return this.flightArrivalDate;
	}

	public void setFlightArrivalDate(String flightArrivalDate) {
		this.flightArrivalDate = flightArrivalDate;
	}

	public String getFreeBaggageAllowance() {
		return this.freeBaggageAllowance;
	}

	public void setFreeBaggageAllowance(String freeBaggageAllowance) {
		this.freeBaggageAllowance = freeBaggageAllowance;
	}

	public String getInvlCouponNo() {
		return this.invlCouponNo;
	}

	public void setInvlCouponNo(String invlCouponNo) {
		this.invlCouponNo = invlCouponNo;
	}

	public String getInvlDestinationAirport() {
		return this.invlDestinationAirport;
	}

	public void setInvlDestinationAirport(String invlDestinationAirport) {
		this.invlDestinationAirport = invlDestinationAirport;
	}

	public String getInvlDisruptionIndicator() {
		return this.invlDisruptionIndicator;
	}

	public void setInvlDisruptionIndicator(String invlDisruptionIndicator) {
		this.invlDisruptionIndicator = invlDisruptionIndicator;
	}

	public String getInvlDocNo() {
		return this.invlDocNo;
	}

	public void setInvlDocNo(String invlDocNo) {
		this.invlDocNo = invlDocNo;
	}

	public String getInvlFlightDate() {
		return this.invlFlightDate;
	}

	public void setInvlFlightDate(String invlFlightDate) {
		this.invlFlightDate = invlFlightDate;
	}

	public String getInvlFlightDepartTime() {
		return this.invlFlightDepartTime;
	}

	public void setInvlFlightDepartTime(String invlFlightDepartTime) {
		this.invlFlightDepartTime = invlFlightDepartTime;
	}

	public String getInvlFlightNumber() {
		return this.invlFlightNumber;
	}

	public void setInvlFlightNumber(String invlFlightNumber) {
		this.invlFlightNumber = invlFlightNumber;
	}

	public String getInvlMarketingCarrierCode() {
		return this.invlMarketingCarrierCode;
	}

	public void setInvlMarketingCarrierCode(String invlMarketingCarrierCode) {
		this.invlMarketingCarrierCode = invlMarketingCarrierCode;
	}

	public String getInvlOriginAirportCode() {
		return this.invlOriginAirportCode;
	}

	public void setInvlOriginAirportCode(String invlOriginAirportCode) {
		this.invlOriginAirportCode = invlOriginAirportCode;
	}

	public String getInvlReservationBkng() {
		return this.invlReservationBkng;
	}

	public void setInvlReservationBkng(String invlReservationBkng) {
		this.invlReservationBkng = invlReservationBkng;
	}

	public String getInvlStopoverCode() {
		return this.invlStopoverCode;
	}

	public void setInvlStopoverCode(String invlStopoverCode) {
		this.invlStopoverCode = invlStopoverCode;
	}

	public String getInvoluntaryIndicator() {
		return this.involuntaryIndicator;
	}

	public void setInvoluntaryIndicator(String involuntaryIndicator) {
		this.involuntaryIndicator = involuntaryIndicator;
	}

	public String getNonExchangeableIndicator() {
		return this.nonExchangeableIndicator;
	}

	public void setNonExchangeableIndicator(String nonExchangeableIndicator) {
		this.nonExchangeableIndicator = nonExchangeableIndicator;
	}

	public String getNonInterlinableIndicator() {
		return this.nonInterlinableIndicator;
	}

	public void setNonInterlinableIndicator(String nonInterlinableIndicator) {
		this.nonInterlinableIndicator = nonInterlinableIndicator;
	}

	public String getNotValidAfterDate() {
		return this.notValidAfterDate;
	}

	public void setNotValidAfterDate(String notValidAfterDate) {
		this.notValidAfterDate = notValidAfterDate;
	}

	public String getNotValidBeforeDate() {
		return this.notValidBeforeDate;
	}

	public void setNotValidBeforeDate(String notValidBeforeDate) {
		this.notValidBeforeDate = notValidBeforeDate;
	}

	public String getOrigin() {
		return this.origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public String getReasonForIssuanceSubCode() {
		return this.reasonForIssuanceSubCode;
	}

	public void setReasonForIssuanceSubCode(String reasonForIssuanceSubCode) {
		this.reasonForIssuanceSubCode = reasonForIssuanceSubCode;
	}

	public String getReservationStatus() {
		return this.reservationStatus;
	}

	public void setReservationStatus(String reservationStatus) {
		this.reservationStatus = reservationStatus;
	}

	public String getSaleCouponNumber() {
		return this.saleCouponNumber;
	}

	public void setSaleCouponNumber(String saleCouponNumber) {
		this.saleCouponNumber = saleCouponNumber;
	}

	public String getSaleFlightNumber() {
		return this.saleFlightNumber;
	}

	public void setSaleFlightNumber(String saleFlightNumber) {
		this.saleFlightNumber = saleFlightNumber;
	}

	public String getSaleLocalFlightDate() {
		return this.saleLocalFlightDate;
	}

	public void setSaleLocalFlightDate(String saleLocalFlightDate) {
		this.saleLocalFlightDate = saleLocalFlightDate;
	}

	public String getSellingClass() {
		return this.sellingClass;
	}

	public void setSellingClass(String sellingClass) {
		this.sellingClass = sellingClass;
	}

	public String getStopOverCode() {
		return this.stopOverCode;
	}

	public void setStopOverCode(String stopOverCode) {
		this.stopOverCode = stopOverCode;
	}

	public AmadeusRecordStaging getAmadeusRecordStg() {
		return amadeusRecordStg;
	}

	public void setAmadeusRecordStg(AmadeusRecordStaging amadeusRecordStg) {
		this.amadeusRecordStg = amadeusRecordStg;
	}

	public String getCoupons() {
		return coupons;
	}

	public void setCoupons(String coupons) {
		this.coupons = coupons;
	}

	@Override
	public LineTokenizer lineTokenizer() {

		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		StagingETLV2_20Layout stagingETLV2_20Layout = new StagingETLV2_20Layout();
		tokenizer.setColumns(stagingETLV2_20Layout.getColumns());
		tokenizer.setNames(stagingETLV2_20Layout.getNames());
		return tokenizer;
	}

	@Override
	public FieldSetMapper<AmadeusBatchRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<AmadeusBatchRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<AmadeusBatchRecord>();
		fieldSetMapper.setTargetType(AmadeusRecordStaging.class);
		return fieldSetMapper;
	}

	@Override
	public ItemProcessor<? extends AmadeusBatchRecord, ? extends AmadeusBatchRecord> processor() {
		return new StagingCommonProcessor();
	}

	@Override
	public ItemWriter<? super AmadeusBatchRecord> writer() {
		// TODO Auto-generated method stub
		return null;
	}
}

