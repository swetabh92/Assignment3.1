package com.sgl.smartpra.batch.sales.validator.app.processor;

import org.springframework.stereotype.Component;

/**
 * 
 * @author mansound1
 *
 */
@Component
public interface SalesRules {

	public boolean checkCarrierCode(String carrierCode);

	public boolean validateDocumentNo(String documentNo);

	public boolean validateAirportCode(String airportCode);

	public boolean validateCityCode(String cityCode);

	public boolean validateAgentCode(String agentCode);

	
	public boolean validateCurrencyCode(String currencyCode);
}