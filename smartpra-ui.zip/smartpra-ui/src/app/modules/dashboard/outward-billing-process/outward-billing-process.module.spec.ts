import { OutwardBillingProcessModule } from './outward-billing-process.module';

describe('OutwardBillingProcessModule', () => {
  let outwardBillingProcessModule: OutwardBillingProcessModule;

  beforeEach(() => {
    outwardBillingProcessModule = new OutwardBillingProcessModule();
  });

  it('should create an instance', () => {
    expect(outwardBillingProcessModule).toBeTruthy();
  });
});
