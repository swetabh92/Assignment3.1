import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import swal from 'sweetalert2';

import { environment } from '../../../../environments/environment';
import { Process } from '../models/process';
import { MessageBoxService } from '../../masters/services/commons/message-box.service';
const httpOptions = {
  // headers: new HttpHeaders({ 'Content-Type': 'multipart/form-data' })
 };
 const httpOptions1 = {
   headers: new HttpHeaders({ 'Content-Type': 'multipart/form-data' })
  };
@Injectable({
  providedIn: 'root'
})
export class ProcessService {
  globalUrl = environment.apiUrlGlobal;
  masterUrl = environment.apiUrlMaster;
  authUrl = environment.apiUrlauth;
  constructor(private http: HttpClient, private messageBoxService: MessageBoxService) { }
  getProcessAll(): Observable<Process[]> {
    return this.http.get<Process[]>(this.authUrl + 'mas-processes')
      .pipe(
        tap(_ => this.log('fetched Process details')),
        catchError(this.handleError('getAllProcess', []))
      );
  }
  ProcessByProcessId(masProcessDTOId: string): Observable<Process> {
    return this.http.get<Process>(this.authUrl + 'mas-processes/' + masProcessDTOId).pipe(
      tap(_ => this.log(`fetched Process masProcessDTOId=${masProcessDTOId}`)),
      catchError(this.handleError<Process>(`ProcessByProcessId masProcessDTOId=${masProcessDTOId}`))
    );
  }
  searchProcess(parms: string): Observable<Process> {
    return this.http.get<Process>(this.authUrl + parms).pipe(
      tap(_ => this.log(`search Process masProcessDTOId by ${parms}`)),
      catchError(this.handleError<Process>(`search Process masProcessDTOId by ${parms}`))
    );
  }
  /** POST: add a new Process to the server */
  addProcess(formdata): Observable<Process> {
    // console.log(formdata); return;
    return this.http.post<Process>(this.authUrl + 'mas-processes/', formdata, httpOptions).pipe(
      tap(_ => this.log(`added Process masProcessDTOId=`)),
      catchError(this.handleError<Process>('addProcess'))
    );
  }
  updateProcess(process: Process): Observable<any> {
   // console.log(Process.masProcessDTOId);
    // console.log(Process);
    return this.http.put<Process>(this.authUrl + 'mas-processes/' + process.masProcessDTOId, Process, httpOptions).pipe(
      tap(_ => this.log(`updated Process masProcessDTOId=${process.masProcessDTOId}`)),
      catchError(this.handleError<Process>('addProcess'))
    );
  }
  activateProcess(masProcessDTOId: string): Observable<Process> {
    return this.http.put<Process>(this.authUrl + 'mas-processes/activateordeactivate/' + masProcessDTOId , httpOptions).pipe(
      tap(_ => this.log(`activate Process masProcessDTOId=${masProcessDTOId}`)),
      catchError(this.handleError<Process>('activateProcess'))
    );
  }
  deactivateProcess(masProcessDTOId: string): Observable<Process> {
    return this.http.put<Process>(this.authUrl + 'mas-processes/activateordeactivate/' + masProcessDTOId , httpOptions).pipe(
      tap(_ => this.log(`deactivate Process masProcessDTOId=${masProcessDTOId}`)),
      catchError(this.handleError<Process>('deactvateProcess'))
    );
  }

  private handleError<T>(operation = 'operation', result?: T) {
    return (e: any): Observable<T> => {
      console.log(e);
      const error = e.error.message || e.error.error || e.error.error_description || 'Could not connect server';
      console.log(error);
      this.messageBoxService.getErrorMessage('ERROR', error);
      return of(result as T);
    };
  }
  private log(error: any) {
    console.log(error);
    if (error.message) {
      this.messageBoxService.getErrorMessage('ERROR', error.message);
    }
  }
}

