package com.sgl.smartpra.batch.bhr.app.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.batch.bhr.app.config.FeignConfiguration.BatchGlobalFeignClient;
import com.sgl.smartpra.batch.bhr.app.config.FeignConfiguration.ExceptionTransIntgAppClient;
import com.sgl.smartpra.batch.bhr.app.config.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.batch.bhr.app.domain.FlightBatchHeaderStg;
import com.sgl.smartpra.batch.bhr.app.repository.FlightBatchHeaderRepository;
import com.sgl.smartpra.batch.bhr.app.util.BHRCommonUtil;
import com.sgl.smartpra.batch.bhr.app.util.BHRConstants;
import com.sgl.smartpra.batch.bhr.app.util.BHRCountReader;
import com.sgl.smartpra.batch.global.model.FileErrorLog;
import com.sgl.smartpra.batch.global.model.FileLogging;
import com.sgl.smartpra.common.model.FileType;
import com.sgl.smartpra.common.util.FileLoggingConstants;
import com.sgl.smartpra.common.util.SmartpraFileUtility;
import com.sgl.smartpra.exception.txn.model.ExceptionParametersValueModel;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;

@Service
public class BatchHeaderService {
	private static final Logger LOGGER = LoggerFactory.getLogger(BatchHeaderService.class);

	@Autowired
	JobLauncher jobLauncher;

	@Autowired
	@Qualifier(value = "importBhrFileJob")
	Job importBhrFileJob;

	@Autowired
	@Qualifier(value = "importBHRProdJob")
	Job importBHRProdJob;

	@Autowired
	BatchGlobalFeignClient batchGlobalFeignClient;

	@Autowired
	FlightBatchHeaderRepository flightBatchHeaderRepository;

	@Autowired
	ExceptionTransIntgAppClient exceptionTransIntgAppClient;

	@Autowired
	SmartpraMasterAppClient smartpraMasterAppClient;

	@Value("${batch.directory.bhr.duplicate}")
	private String duplicateDir;

	@Value("${batch.directory.bhr.failed}")
	private String failedDir;

	@Value("${batch.directory.bhr.input}")
	private String inputDir;

	ExceptionTransactionModel exceptionTransactionModel;
	List<ExceptionParametersValueModel> parametersValueModelList;
	ExceptionParametersValueModel parametersValueModel;

	public String executeBhrStgInboundJob(String fileName, String processedBy) throws Exception {

		LOGGER.info("BatchHeaderService : executeBhrStgInboundJob");

		String clientId = BHRCommonUtil.getHostCarrierDesigCode(smartpraMasterAppClient);

		String flightNumberOption = BHRCommonUtil.getFlightNumberOption(smartpraMasterAppClient);

		clientId = StringUtils.isEmpty(clientId) ? BHRConstants.DEFAULT_CLIENT_ID : clientId;
		List<FileLogging> fileLoggs = null;

		LOGGER.info("BatchHeaderService : clientId : " + clientId);

		FileLogging fileLogging = BHRCommonUtil.initFileLogging();
		fileLogging.setInterfaceType(FileLoggingConstants.FILELOGGING_INTERFACE_INPUT);
		fileLogging.setFileName(fileName);
		fileLogging.setProcessedBy(processedBy);
		fileLogging.setFileType(BHRConstants.FILELOGGING_FILETYPE_BHR_IN);
		fileLogging.setClientId(clientId);
		fileLogging.setJobName(importBhrFileJob.getName());
		FileErrorLog fileErrorLog;
		List<FileErrorLog> fileErrorLogList;

		fileLogging = batchGlobalFeignClient.createFileLog(fileLogging);

		// Validate file
		String valdationMessage = validateFile(inputDir + fileName, fileLogging);

		if (StringUtils.isNotEmpty(valdationMessage)) {
			String tmpName = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
			BHRCommonUtil.moveFile(inputDir + fileName, failedDir + fileName + tmpName);
			fileLogging.setIsMovedToRelevantFolder("Y");
			fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_TECHFAILED);
			fileLogging.setClientId(clientId);
			fileLogging.setRemarks(valdationMessage);
			fileErrorLog = new FileErrorLog();
			fileErrorLog.setFileId(fileLogging.getFileId());
			fileErrorLog.setErrorDetail("Invalid File Input");
			fileErrorLog.setErrorDescription(valdationMessage);
			fileErrorLogList = new ArrayList<>();
			fileErrorLogList.add(fileErrorLog);
			fileLogging.setFileErrorLog(fileErrorLogList);
			fileLogging = batchGlobalFeignClient.createFileLog(fileLogging);
			return valdationMessage;
		}
		// File duplicate check
		List<FileLogging> fileList = batchGlobalFeignClient.getFileLogByFileName(fileName);

		if (CollectionUtils.isNotEmpty(fileList)) {
			String tmpName = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
			String errorMsg = "File with same name " + fileName + " has been already loaded in system with file id "
					+ fileList.get(0).getFileId();

			exceptionTransactionModel = prepareExceptionTransactionModel(fileName, fileLogging);
			exceptionTransactionModel.setExceptionCode(BHRConstants.BHR_FILE_IS_ALREADY_LOADED);
			parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();

			parametersValueModel = new ExceptionParametersValueModel();
			parametersValueModel.setParameterName("File name");
			parametersValueModel.setParameterValue(fileName);
			parametersValueModelList.add(parametersValueModel);

			exceptionTransactionModel.setParametersValueList(parametersValueModelList);
			exceptionTransIntgAppClient.initExceptionTrasaction(exceptionTransactionModel);

			BHRCommonUtil.moveFile(inputDir + fileName, duplicateDir + fileName + tmpName);
			fileLogging.setIsMovedToRelevantFolder("Y");
			fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_TECHFAILED);
			fileLogging.setClientId(clientId);
			fileLogging.setRemarks(errorMsg);
			fileErrorLog = new FileErrorLog();
			fileErrorLog.setFileId(fileLogging.getFileId());
			fileErrorLog.setErrorDetail("Invalid File Input");
			fileErrorLog.setErrorDescription(errorMsg);
			fileErrorLogList = new ArrayList<>();
			fileErrorLogList.add(fileErrorLog);
			fileLogging.setFileErrorLog(fileErrorLogList);
			fileLogging = batchGlobalFeignClient.createFileLog(fileLogging);
			return errorMsg;
		}

		BHRCountReader.resetCounts();
		// @formatter:off
		JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis())
				.addString("fileName", fileName).addString("clientId", clientId)
				.addLong("fileId", fileLogging.getFileId().longValue()).toJobParameters();
		JobExecution jobExecution = jobLauncher.run(importBhrFileJob, jobParameters);
		// @formatter:on

		if (jobExecution.getExitStatus().equals(ExitStatus.COMPLETED)) {

			JobParameters jobParams = jobExecution.getJobParameters();

			long fileId = jobParams.getLong("fileId");

			// @formatter:off
			JobParameters jobParametersProd = new JobParametersBuilder().addLong("time", System.currentTimeMillis())
					.addLong("fileId", fileId).addString("clientId", clientId).addString("fileName", fileName)
					.addString("flightNumberOption", flightNumberOption).toJobParameters();

			jobLauncher.run(importBHRProdJob, jobParametersProd);
			// @formatter:on
		}

		return "BHR Job executed";

	}

	// Exception Management
	private String validateFile(String fileName, FileLogging fileLogging) {
		LOGGER.info("BatchHeaderService : Validate File : " + fileName);
		String errorMessage = null;
		File file = new File(fileName);
		String fileNm = file.getName();
		if (!SmartpraFileUtility.fileExists(fileName)) {
			LOGGER.info("BatchHeaderService : fileName : " + fileNm);
			exceptionTransactionModel = prepareExceptionTransactionModel(fileNm, fileLogging);
			exceptionTransactionModel.setExceptionCode(BHRConstants.BHR_FILE_NOT_FOUND);
			parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();

			parametersValueModel = new ExceptionParametersValueModel();
			parametersValueModel.setParameterName("File name");
			parametersValueModel.setParameterValue(fileNm);
			parametersValueModelList.add(parametersValueModel);

			exceptionTransactionModel.setParametersValueList(parametersValueModelList);
			exceptionTransIntgAppClient.initExceptionTrasaction(exceptionTransactionModel);

			return errorMessage = "File " + fileNm + " not found";
		}

		if (SmartpraFileUtility.isEmptyFile(fileName)) {
			LOGGER.info("BatchHeaderService : fileName : " + fileNm);
			exceptionTransactionModel = prepareExceptionTransactionModel(fileNm, fileLogging);
			exceptionTransactionModel.setExceptionCode(BHRConstants.BHR_FILE_NO_RECORD_FOUND);
			parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();

			parametersValueModel = new ExceptionParametersValueModel();
			parametersValueModel.setParameterName("File name");
			parametersValueModel.setParameterValue(fileNm);
			parametersValueModelList.add(parametersValueModel);

			exceptionTransactionModel.setParametersValueList(parametersValueModelList);
			exceptionTransIntgAppClient.initExceptionTrasaction(exceptionTransactionModel);

			return errorMessage = fileNm + " has no record i.e. Blank file reported";
		}

		if (!isValidFileName(fileName)) {
			LOGGER.info("BatchHeaderService : fileName : " + fileNm);
			exceptionTransactionModel = prepareExceptionTransactionModel(fileNm, fileLogging);
			exceptionTransactionModel.setExceptionCode(BHRConstants.BHR_FILE_NAME_NOT_SPECIFICATION);
			parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();

			parametersValueModel = new ExceptionParametersValueModel();
			parametersValueModel.setParameterName("File name");
			parametersValueModel.setParameterValue(fileNm);
			parametersValueModelList.add(parametersValueModel);

			exceptionTransactionModel.setParametersValueList(parametersValueModelList);
			exceptionTransIntgAppClient.initExceptionTrasaction(exceptionTransactionModel);

			return errorMessage = "File name " + fileNm + " is not as per specification";
		}

		if (!validateDate(fileName)) {

			exceptionTransactionModel = prepareExceptionTransactionModel(fileNm, fileLogging);
			exceptionTransactionModel.setExceptionCode(BHRConstants.BHR_FILE_NAME_NOT_SPECIFICATION);
			parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();

			parametersValueModel = new ExceptionParametersValueModel();
			parametersValueModel.setParameterName("File name");
			parametersValueModel.setParameterValue(fileNm);
			parametersValueModelList.add(parametersValueModel);

			exceptionTransactionModel.setParametersValueList(parametersValueModelList);
			exceptionTransIntgAppClient.initExceptionTrasaction(exceptionTransactionModel);

			return errorMessage = "File name " + fileNm + " is not as per specification";
		}
		if (!validateRecords(fileName)) {
			exceptionTransactionModel = prepareExceptionTransactionModel(fileNm, fileLogging);
			exceptionTransactionModel.setExceptionCode(BHRConstants.BHR_FILE_INCORRECT_DATA_REPORTED);
			parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();

			parametersValueModel = new ExceptionParametersValueModel();
			parametersValueModel.setParameterName("File name");
			parametersValueModel.setParameterValue(fileNm);
			parametersValueModelList.add(parametersValueModel);

			exceptionTransactionModel.setParametersValueList(parametersValueModelList);
			exceptionTransIntgAppClient.initExceptionTrasaction(exceptionTransactionModel);

			return errorMessage = "File name " + fileNm + "  is incorrect data reported";
		}
		return errorMessage;
	}

	private ExceptionTransactionModel prepareExceptionTransactionModel(String fileName, FileLogging fileLogging) {
		System.out.println("File Name:::::" + fileName);
		ExceptionTransactionModel exceptionTransactionModel = new ExceptionTransactionModel();
		String clientId = BHRCommonUtil.getHostCarrierDesigCode(smartpraMasterAppClient);
		String issueCxr = BHRCommonUtil.getHostCarrierNumericCode(smartpraMasterAppClient);
		exceptionTransactionModel.setFileId(fileLogging.getFileId().longValue());
		exceptionTransactionModel.setIssuedCarrier(issueCxr);
		exceptionTransactionModel.setClientId(clientId);
		exceptionTransactionModel.setOrderId(2);// for future use
		exceptionTransactionModel.setCreatedBy(BHRConstants.BHR_EXCEP_CREATEDBY);
		exceptionTransactionModel.setEnvironment(BHRConstants.BHR_EXCEP_ENVIRONMENT_S);
		// exceptionTransactionModel.setFileId((long) fileDetail.getFileId());
		exceptionTransactionModel.setExceptionDate(LocalDateTime.now());
		return exceptionTransactionModel;
	}

	private boolean isValidFileName(String fileName) {
		boolean isValid = true;
		File file = new File(fileName);
		String fName = file.getName();// BHR2606192247
		String fileConstant = fName.substring(0, 3);
		String fileExt = fName.substring(fName.lastIndexOf('.') + 1, fName.length());

		if (fName.length() < 13 || fName.length() > 17) {
			isValid = false;
		}
		if (!fileConstant.equals(BHRConstants.BHR)) {
			isValid = false;
		}

		if (!FileType.contains(fileExt)) {
			isValid = false;
		}
		return isValid;
	}

	private boolean isValidDate(int day, int month, int year) {
		boolean isValidDate = true;

		List<Integer> months31Days = Arrays.asList(1, 3, 5, 7, 8, 10, 12);
		List<Integer> months30Days = Arrays.asList(4, 6, 9, 11);
		if (day <= 0 || day > 31 || month <= 0 || month > 12 || year <= 0
				|| year != Calendar.getInstance().get(Calendar.YEAR)) {
			isValidDate = false;
		} else if (months31Days.contains(month)) {
			if (day > 31) {
				isValidDate = false;
			}
		} else if (months30Days.contains(month)) {
			if (day > 30) {
				isValidDate = false;
			}

		} else if (month == 2) // February check
		{
			if (year % 4 == 0) // Leap year check for February
			{
				if (day > 29) {
					isValidDate = false;
				}
			} else if (year % 4 != 0) {
				if (day > 28) {
					isValidDate = false;
				}
			}
		}

		return isValidDate;
	}

	private boolean validateDate(String fileName) {
		boolean isValid = true;
		File file = new File(fileName);
		String fName = file.getName();// BHR2606192247
		String days = fName.substring(3, 5);
		String month = fName.substring(5, 7);
		String year = fName.substring(7, 9);
		String hrs = fName.substring(9, 11);
		String mnts = fName.substring(11, 13);

		isValid = isValidDate(Integer.valueOf(days), Integer.valueOf(month), Integer.valueOf("20" + year));

		if (Integer.valueOf(hrs) < 0 || (Integer.valueOf(hrs) >= 24)) {
			isValid = false;
		}

		if (Integer.valueOf(mnts) < 0 || (Integer.valueOf(mnts) >= 60)) {
			isValid = false;
		}
		return isValid;
	}

	private boolean validateRecords(String fileName) {
		boolean isValid = true;
		File file = new File(fileName);
		// String fName = file.getName();// BHR2606192247z
		BufferedReader bufferedReader;
		String readLine = "";
		String record = null;
		try {
			bufferedReader = new BufferedReader(new FileReader(file));
			while ((readLine = bufferedReader.readLine()) != null) {
				record = readLine.trim();
				if (record.length() < 116) {
					isValid = false;
				}
			}
			if (bufferedReader != null) {
				bufferedReader.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return isValid;
	}
}
