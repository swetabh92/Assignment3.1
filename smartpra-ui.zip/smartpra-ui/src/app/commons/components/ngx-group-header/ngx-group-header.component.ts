import { Component, OnInit,Input,ElementRef,ViewChild,Output,EventEmitter  } from '@angular/core';

@Component({
  selector: 'app-ngx-group-header',
  templateUrl: './ngx-group-header.component.html',
  styleUrls: ['./ngx-group-header.component.css']
})
export class NgxGroupHeaderComponent implements OnInit {
  @Input() groupName:string;
  @Input() subHeaders:string[];
  @Input() sortDir:any;
  @Output() sort = new EventEmitter();
  constructor() { }
  ngOnInit() {
  }
  onSort(col){
    this.sort.emit(col)
  }
}
