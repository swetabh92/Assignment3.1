import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FlightControlMasterRoutingModule } from './flight-control-master-routing.module';
import { FlightControlMasterComponent } from './flight-control-master.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { CoreDataModule } from 'src/app/core-data/core-data.module';

@NgModule({
  imports: [
    CommonModule,
    CoreDataModule,
    SharedModule,
    FlightControlMasterRoutingModule
  ],
  declarations: [
    FlightControlMasterComponent
  ]
})
export class FlightControlMasterModule { }
