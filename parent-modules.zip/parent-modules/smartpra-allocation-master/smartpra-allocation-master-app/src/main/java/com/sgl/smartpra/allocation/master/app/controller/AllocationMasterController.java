package com.sgl.smartpra.allocation.master.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.allocation.master.app.service.AllocationMasterService;
import com.sgl.smartpra.allocation.master.enums.ModuleNameEnum;
import com.sgl.smartpra.allocation.master.model.AllocationMaster;
import com.sgl.smartpra.allocation.master.model.AllocationMasterSearchModel;
import com.sgl.smartpra.common.validator.group.Create;
import com.sgl.smartpra.common.validator.group.Update;

import java.util.List;

@RestController
@RequestMapping("/allocation-master")
public class AllocationMasterController {

    @Autowired
    private AllocationMasterService allocationMasterService;

    @GetMapping("/{moduleLovId}/{moduleName}")
    public List<AllocationMaster> getAllAllocations(@PathVariable ModuleNameEnum moduleName,
                                                    @PathVariable Integer moduleLovId) {
        return allocationMasterService.getAllAllocationsByModule(moduleName, moduleLovId);
    }

    @GetMapping("/preload/{moduleName}")
    public <T extends AllocationMaster> AllocationMaster getAllocationByModule(
            @PathVariable ModuleNameEnum moduleName) {
        return allocationMasterService.getPreloadByModule(moduleName);
    }

    @PostMapping
    @ResponseStatus(value = HttpStatus.CREATED)
    public void createAllocation(
            @RequestBody @Validated(value = Create.class) AllocationMasterSearchModel allocationMasterSearchModel) {
        allocationMasterService.assignAllocation(allocationMasterSearchModel);
    }

    @PutMapping("/{allocationMasterId}")
    @ResponseStatus(value = HttpStatus.OK)
    public void updateAllocationMaster(@PathVariable Integer allocationMasterId,
                                       @RequestBody @Validated(value = Update.class) AllocationMasterSearchModel allocationMasterSearchModel) {

        allocationMasterSearchModel.setAllocationMasterId(allocationMasterId);
        allocationMasterService.updateAllocationMaster(allocationMasterId, allocationMasterSearchModel);
    }

}