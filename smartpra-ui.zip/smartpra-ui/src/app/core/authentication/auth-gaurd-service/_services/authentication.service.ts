﻿import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { Cookie } from 'ng2-cookies';
import { environment } from '../../../../../environments/environment';
import swal from 'sweetalert2';
import { MessageBoxService} from '../../../../modules/masters/services/commons/message-box.service';

const httpOptions = {
    headers: new HttpHeaders({'Content-type': 'application/x-www-form-urlencoded; charset=utf-8',
     'Authorization': 'Basic ' + btoa('smartpra-client:smartpra-secret')})
  };

@Injectable({ providedIn: 'root' })

export class AuthenticationService {
  globalUrl = environment.apiUrlGlobal;
  masterUrl = environment.apiUrlMaster;
  authurl = environment.apiUrlauth;
  tokenurl = environment.apiUrltoken;
  logouturl = environment.apiUrllogout;
  constructor(private http: HttpClient, private messageBoxService: MessageBoxService) { }

    login(username: string, password: string, rememberme: string) {
        localStorage.clear();
        const params = new URLSearchParams();
        params.append('username', username);
        params.append('password', password);
        params.append('remember-me', rememberme);
        params.append('grant_type', 'password');
       //  console.log(params);
        return this.http.post<any>(this.tokenurl, params.toString(), httpOptions)
            .pipe(map(token => {
                // console.log(token);
                // login successful if there's a jwt token in the response
                if (token) {
                    // store user details and jwt token in local storage to keep user logged in between page refreshes
                    // localStorage.setItem('token', JSON.stringify(token));
                    // localStorage.setItem('refresh_token', token.refresh_token);
                    // const expireDate = new Date().getTime() + (1000 * token.expires_in);
                    // Cookie.set('expireDate', expireDate);
                    // Cookie.set('access_token', token.access_token);
                    // Cookie.set('refresh_token', token.refresh_token);
                    // localStorage.setItem('oauthtoken', token.access_token);                  
                    this.setToken(token); 
                    // this.refreshToken();
                }
                return token;
            }));
    }

    setToken(token){
      localStorage.setItem('access_token', token.access_token);
      localStorage.setItem('refresh_token', token.refresh_token);
      // Cookie.set('access_token', token.access_token);
      // Cookie.set('refresh_token', token.refresh_token);
      // console.log(Cookie.getAll());
      // console.log(Cookie.get('access_token'));
      // console.log(Cookie.get('refresh_token'));
      console.log(token);      
      setTimeout(() => {
        this.refreshToken();
      }, (token.expires_in * 1000));
    }

    refreshToken() {
      const params = new URLSearchParams();
      params.append('grant_type', 'refresh_token');
      params.append('refresh_token', localStorage.getItem('refresh_token'));
      params.append('Content-Type', 'application/x-www-form-urlencoded');
      params.append('Authorization', 'Basic  c21hcnRwcmEtY2xpZW50OnNtYXJ0cHJhLXNlY3JldA==');
      console.log('refresh token subscribed' + ' ------ ' + params.toString());
      return this.http.post<any>(this.tokenurl, params.toString(), httpOptions)
          .pipe(map(refresh_token => {
            console.log('refresh token subscribed');
              // login successful if there's a jwt token in the response
              if (refresh_token) {
                  // store user details and jwt token in local storage to keep user logged in between page refreshes
                  // localStorage.setItem('refresh_token', JSON.stringify(refresh_token));
                  // console.log(refresh_token);
                  // Cookie.set('refresh_token', refresh_token);
                  this.setToken(refresh_token);
              }
              return refresh_token;
          }));
  }

    logout() 
    {
        // remove user from local storage to log user out
        // return true;
        // return this.http.post<any>( this.logouturl , httpOptions).
        return this.http.post<any>( this.logouturl , {}).
      pipe(map(res => {        
         console.log(res);
         return res;
      }));
    }
    resetPasswordFinal(formdata): Observable<any> {
      return this.http.post<any>( this.authurl + 'profile/reset-password/finish/' , formdata).
      pipe(map(res => {
        // console.log(res);
          return res;
      }));
    }
    resetPasswordInit(formdata): Observable<any> {
     // const mail = formdata.mail;
     // console.log(formdata);
      return this.http.post<any>( this.authurl + 'profile/reset-password/init/', formdata).
      pipe(map(res => {
        // console.log(res);
          return res;          
      }));
    }
    firsttimePassword(formdata): Observable<any> {
      return this.http.post<any>( this.authurl + 'profile/firsttime-password/init/' , formdata).
      pipe(map(res => {
        // console.log(res);
          return res;
      }));
    }
    forgetUserid(formdata): Observable<any> {
      console.log(formdata);
      return this.http.post<any>( this.authurl + 'profile/request-username/init/', formdata)
      .pipe(map(res => {
        // console.log(res);
          return res;
      }));
    }
    private handleError<T>(operation = 'operation', result?: T) {
      return (e: any): Observable<T> => {
        console.log(e);
        const error = e.error.message || e.error.error || e.error.error_description || 'Could not connect server';
        console.log(error);
        this.messageBoxService.getErrorMessage('ERROR', error);
        return of(result as T);
      };
    }
    private log(error: any) {
      console.log(error);
      if (error.message) {
        this.messageBoxService.getErrorMessage('ERROR', error.message);
      }
    }
}
