package com.sgl.smartpra.batch.interline.listener;

import org.springframework.batch.core.SkipListener;
import org.springframework.beans.factory.annotation.Autowired;

import com.sgl.smartpra.batch.interline.common.ExceptionServiceIntegration;
import com.sgl.smartpra.interline.domain.entity.prod.form3.InterlineForm3Details;
import com.sgl.smartpra.interline.domain.entity.stg.form3.InterlineForm3CsvStg;
import com.sgl.smartpra.interline.domain.util.InterlineExceptionCodes;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class InterlineForm3ProdSkipListener implements SkipListener<InterlineForm3CsvStg, InterlineForm3Details> {
	
	@Autowired
	private ExceptionServiceIntegration exceptionServiceIntegration;

	@Override
	public void onSkipInRead(Throwable t) {
		log.error(t.getMessage());
	}

	@Override
	public void onSkipInWrite(InterlineForm3Details item, Throwable t) {
		exceptionServiceIntegration.postException(item, InterlineExceptionCodes.INWD1048);
		log.error(t.getMessage());
	}

	@Override
	public void onSkipInProcess(InterlineForm3CsvStg item, Throwable t) {
		log.error(t.getMessage());
	}
}
