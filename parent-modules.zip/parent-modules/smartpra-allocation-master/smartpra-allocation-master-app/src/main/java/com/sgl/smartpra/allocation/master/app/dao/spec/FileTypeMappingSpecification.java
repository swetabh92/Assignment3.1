package com.sgl.smartpra.allocation.master.app.dao.spec;

import java.util.List;

import org.springframework.data.jpa.domain.Specification;

import com.sgl.smartpra.allocation.master.app.entity.FileTypeEntity;
import com.sgl.smartpra.allocation.master.app.entity.FileTypeMappingEntity;

public final class FileTypeMappingSpecification {
	
	private FileTypeMappingSpecification(){
		
	}
	
	public static Specification<FileTypeMappingEntity> moduleIdEquals(final Integer moduleId) {
		return (fileTypeMappingEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fileTypeMappingEntity.get("moduleLovId"), moduleId);

	}
	
	public static Specification<FileTypeMappingEntity> fileTypeIdEquals(final Integer fileTypeId) {
		return (fileTypeMappingEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fileTypeMappingEntity.get("fileTypeId"), fileTypeId);

	}
	
	public static Specification<FileTypeEntity> clientIdEquals(final String clientId) {
		return (fileTypeEntity, criteriaQuery, criteriaBuilder) -> criteriaBuilder
				.equal(fileTypeEntity.get("clientId"), clientId);
	}
	
	public static Specification<FileTypeEntity> fileTypeIdsIn(final List<Integer> fileTypeIds) {
		return (fileTypeEntity, criteriaQuery, criteriaBuilder) -> fileTypeEntity.get("fileTypeId").in(fileTypeIds);
	}

}
