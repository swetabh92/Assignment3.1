import { DatePipe } from '@angular/common';
import { Injectable } from '@angular/core';
declare var $;
declare var jQuery: any;
declare var moment: any;
declare var inputmask: any;
declare var daterangepicker: any;
@Injectable({
  providedIn: 'root'
})
export class GeneralService {

  constructor() {
   }

   getDataTableOptions() {
    return {
      searching: false,
      pagingType: 'full_numbers',
      lengthMenu: [[5, 10, 25, 50, -1], [5, 10, 25, 50, 'All']],
      pageLength : 10,
      language : {
        lengthMenu: 'Page size _MENU_',
      paginate: {
        next: '<i style="color:#0079c1" class="fa fa-angle-right fa-lg"></i>',
        previous: '<i style="color:#0079c1" class="fa fa-angle-left fa-lg"></i>',
        first: '<i style="color:#0079c1" class="fa fa-step-backward"></i>',
        last: '<i style="color:#0079c1" class="fa fa-step-forward"></i>'
        }
      },
      dom: 'flrp<"datatableclass"i>t',
    };
   }
   getDataTableOptionsNew(orderFalse) {
    return {
      searching: false,
      pagingType: 'full_numbers',
      responsive: true,
      lengthMenu: [[5, 10, 25, 50, -1], [5, 10, 25, 50, 'All']],
      pageLength : 10,
      columnDefs: [
        { targets: orderFalse, orderable: false, searchable: false},
     ],
      language : {
        lengthMenu: 'Page size _MENU_',
      paginate: {
        next: '<i style="color:#0079c1" class="fa fa-angle-right fa-lg"></i>',
        previous: '<i style="color:#0079c1" class="fa fa-angle-left fa-lg"></i>',
        first: '<i style="color:#0079c1" class="fa fa-step-backward"></i>',
        last: '<i style="color:#0079c1" class="fa fa-step-forward"></i>'
        }
      },
      dom: 'flrp<"datatableclass"i>t',
    };
   }
   
   LoadTreeViewJs() {
       $(function() {
        'use strict';
        const DataKey = 'lte.tree';

        const Default = {
          animationSpeed: 500,
          accordion     : true,
          followLink    : false,
          trigger       : '.treeview a'
        };

        const Selector = {
          tree        : '.tree',
          treeview    : '.treeview',
          treeviewMenu: '.treeview-menu',
          open        : '.menu-open, .active',
          li          : 'li',
          data        : '[data-widget="tree"]',
          active      : '.active'
        };

        const ClassName = {
          open: 'menu-open',
          tree: 'tree'
        };

        const Event = {
          collapsed: 'collapsed.tree',
          expanded : 'expanded.tree'
        };

        // Tree Class Definition
        // =====================
        const Tree = function (element, options) {
          this.element = element;
          this.options = options;

          $(this.element).addClass(ClassName.tree);

          $(Selector.treeview + Selector.active, this.element).addClass(ClassName.open);

          this._setUpListeners();
        };

        Tree.prototype.toggle = function (link, event) {
          const treeviewMenu = link.next(Selector.treeviewMenu);
          const parentLi     = link.parent();
          const isOpen       = parentLi.hasClass(ClassName.open);

          if (!parentLi.is(Selector.treeview)) {
            return;
          }

          if (!this.options.followLink || link.attr('href') === '#') {
            event.preventDefault();
          }

          if (isOpen) {
            this.collapse(treeviewMenu, parentLi);
          } else {
            this.expand(treeviewMenu, parentLi);
          }
        };

        Tree.prototype.expand = function (tree, parent) {
          const expandedEvent = $.Event(Event.expanded);

          if (this.options.accordion) {
            const openMenuLi = parent.siblings(Selector.open);
            const openTree   = openMenuLi.children(Selector.treeviewMenu);
            this.collapse(openTree, openMenuLi);
          }

          parent.addClass(ClassName.open);
          tree.slideDown(this.options.animationSpeed, function () {
            $(this.element).trigger(expandedEvent);
          }.bind(this));
        };

        Tree.prototype.collapse = function (tree, parentLi) {
          const collapsedEvent = $.Event(Event.collapsed);

          // tree.find(Selector.open).removeClass(ClassName.open);
          parentLi.removeClass(ClassName.open);
          tree.slideUp(this.options.animationSpeed, function () {
            // tree.find(Selector.open + ' > ' + Selector.treeview).slideUp();
            $(this.element).trigger(collapsedEvent);
          }.bind(this));
        };

        // Private

        Tree.prototype._setUpListeners = function () {
          const that = this;

          $(this.element).on('click', this.options.trigger, function (event) {
            that.toggle($(this), event);
          });
        };
        // Plugin Definition
        // =================
        function Plugin(option) {
          return this.each(function () {
            const $this = $(this);
            const data  = $this.data(DataKey);
            if (!data) {
              const options = $.extend({}, Default, $this.data(), typeof option === 'object' && option);
              $this.data(DataKey, new Tree($this, options));
            }
          });
        }
        const old = $.fn.tree;
        $.fn.tree             = Plugin;
        $.fn.tree.Constructor = Tree;
        // No Conflict Mode
        // ================
        $.fn.tree.noConflict = function () {
          $.fn.tree = old;
          return this;
        };

        // Tree Data API
        // =============
        $( document ).ready(function() {
            $(Selector.data).each(function () {
              Plugin.call($(this));
            });
          });
       });
   }
   LoadProfileSettingJs() {
    $(function () {
      'use strict';
      /**
       * Get access to plugins
       */
       // alert('profile settings service works');

      $('[data-toggle="control-sidebar"]').controlSidebar();
      $('[data-toggle="push-menu"]').pushMenu();
      let $pushMenu = $('[data-toggle="push-menu"]').data('lte.pushmenu');
      let $controlSidebar = $('[data-toggle="control-sidebar"]').data('lte.controlsidebar');
      let $layout = $('body').data('lte.layout');
      $(window).on('load', function() {
          // Reinitialize letiables on load
          $pushMenu = $('[data-toggle="push-menu"]').data('lte.pushmenu');
          $controlSidebar = $('[data-toggle="control-sidebar"]').data('lte.controlsidebar');
          $layout = $('body').data('lte.layout');
      });
      const mySkins = [
          'skin-smart-navy-blue',
          'skin-smart-dark-purple',
          'skin-smart-mid-grey',
          'skin-smart-blue-dark',
          'skin-blue',
          'skin-black',
          'skin-red',
          'skin-yellow',
          'skin-purple',
          'skin-green',
          'skin-blue-light',
          'skin-black-light',
          'skin-red-light',
          'skin-yellow-light',
          'skin-purple-light',
          'skin-green-light'
      ];
      /**
       * Get a prestored setting
       *
       * @param String name Name of of the setting
       * @returns String The value of the setting | null
       */
      function get(name) {
          if (typeof (Storage) !== 'undefined') {
              return localStorage.getItem(name);
          } else {
              window.alert('Please use a modern browser to properly view this template!');
          }
      }
      /**
       * Store a new settings in the browser
       *
       * @param String name Name of the setting
       * @param String val Value of the setting
       * @returns void
       */
      function store(name, val) {
          if (typeof (Storage) !== 'undefined') {
              localStorage.setItem(name, val);
          } else {
              window.alert('Please use a modern browser to properly view this template!');
          }
      }
      /**
       * Toggles layout classes
       *
       * @param String cls the layout class to toggle
       * @returns void
       */
      function changeLayout(cls) {
          $('body').toggleClass(cls);
          $layout.fixSidebar();
          if ($('body').hasClass('fixed') && cls === 'fixed') {
              $pushMenu.expandOnHover();
              $layout.activate();
          }
          $controlSidebar.fix();
      }
      /**
       * Replaces the old skin with the new skin
       * @param String cls the new skin class
       * @returns Boolean false to prevent link's default action
       */
      function changeSkin(cls) {
          $.each(mySkins, function (i) {
              $('body').removeClass(mySkins[i]);
          });
          $('body').addClass(cls);
          store('skin', cls);
          return false;
      }
      /**
       * Retrieve default settings and apply them to the template
       *
       * @returns void
       */
      function setup() {
          var tmp = get('skin');
          if(tmp == 'null' || tmp == null) {
            tmp = 'skin-smart-dark-purple';//set default skin
          };
          if (tmp && $.inArray(tmp, mySkins)) { }
              changeSkin(tmp);
          // Add the change skin listener
          $('[data-skin]').on('click', function (e) {
              if ($(this).hasClass('knob')) { return; }
              e.preventDefault();
              changeSkin($(this).data('skin'));
          });
          // Add the layout manager
          $(document).on('ifChanged', '[data-layout]', function() {
          /*$('[data-layout]').on('click', function () {*/
              changeLayout($(this).data('layout'));
          });
          $(document).on('ifChanged', '[data-controlsidebar]', function() {
          /*$('[data-controlsidebar]').on('click', function () {*/
              changeLayout($(this).data('controlsidebar'));
              const slide = !$controlSidebar.options.slide;
              $controlSidebar.options.slide = slide;
              if (!slide) {
                $('.control-sidebar').removeClass('control-sidebar-open');
              }
          });
          $('[data-sidebarskin="toggle"]').on('click', function () {
              const $sidebar = $('.control-sidebar');
              if ($sidebar.hasClass('control-sidebar-dark')) {
                  $sidebar.removeClass('control-sidebar-dark');
                  $sidebar.addClass('control-sidebar-light');
              } else {
                  $sidebar.removeClass('control-sidebar-light');
                  $sidebar.addClass('control-sidebar-dark');
              }
          });
          $('[data-enable="expandOnHover"]').on('click', function () {
              $(this).attr('disabled', true);
              $pushMenu.expandOnHover();
              if (!$('body').hasClass('sidebar-collapse')) { $('[data-layout="sidebar-collapse"]').click(); }
          });
          //  Reset options
          if ($('body').hasClass('fixed')) {
              $('[data-layout="fixed"]').attr('checked', 'checked');
          }
          if ($('body').hasClass('layout-boxed')) {
              $('[data-layout="layout-boxed"]').attr('checked', 'checked');
          }
          if ($('body').hasClass('sidebar-collapse')) {
              $('[data-layout="sidebar-collapse"]').attr('checked', 'checked');
          }
      }

     // Create the new tab
      const $tabPane = $('<div />', {
          'id': 'control-sidebar-theme-demo-options-tab',
          'class': 'tab-pane active'
      });
      // Create the tab button
      const $tabButton = $('<li />', {'class': 'active'})
          .html('<a href=\'#control-sidebar-theme-demo-options-tab\' data-toggle=\'tab\'>'
              + '<i class="fa fa-wrench"></i>'
              + '</a>');
      // Add the tab button to the right sidebar tabs
      $('[href="#control-sidebar-home-tab"]')
          .parent()
          .before($tabButton);
      // Create the menu
      const $demoSettings = $('<div />');
      // Layout options
      $demoSettings.append(
        /* // '<h4 class="control-sidebar-heading">'
         // + 'Layout Options'
         // + '</h4>'
          // Fixed layout
         // + '<div class="form-group">'
         // + '<label class="control-sidebar-subheading">'
         // + '<input type="checkbox" data-layout="fixed"class="pull-right"/> '
         // + 'Fixed layout'
         // + '</label>'
         // + '<p>Activate the fixed layout. You can\'t use fixed and boxed layouts together</p>'
         // + '</div>'
          // Boxed layout
          + '<div class="form-group">'
          + '<label class="control-sidebar-subheading">'
          + '<input type="checkbox"data-layout="layout-boxed" class="pull-right"/> '
          + 'Boxed Layout'
          + '</label>'
          + '<p>Activate the boxed layout</p>'
          + '</div>'
          // Sidebar Toggle
          + '<div class="form-group">'
          + '<label class="control-sidebar-subheading">'
          + '<input type="checkbox"data-layout="sidebar-collapse"class="pull-right"/> '
          + 'Toggle Sidebar'
          + '</label>'
          + '<p>Toggle the left sidebar\'s state (open or collapse)</p>'
          + '</div>'
          // Sidebar mini expand on hover toggle
          // + '<div class="form-group">'
          // + '<label class="control-sidebar-subheading">'
          // + '<input type="checkbox"data-enable="expandOnHover"class="pull-right"/> '
          // + 'Sidebar Expand on Hover'
          // + '</label>'
          // + '<p>Let the sidebar mini expand on hover</p>'
          // + '</div>'
          // Control Sidebar Toggle
          + '<div class="form-group">'
          + '<label class="control-sidebar-subheading">'
          + '<input type="checkbox"data-controlsidebar="control-sidebar-open"class="pull-right"/> '
          + 'Toggle Right Sidebar Slide'
          + '</label>'
          + '<p>Toggle between slide over content and push content effects</p>'
          + '</div>'
          // Control Sidebar Skin Toggle
          // + '<div class="form-group">'
          // + '<label class="control-sidebar-subheading">'
          // + '<input type="checkbox"data-sidebarskin="toggle"class="pull-right"/> '
          // + 'Toggle Right Sidebar Skin'
          // + '</label>'
          // + '<p>Toggle between dark and light skins for the right sidebar</p>'
          // + '</div>' */
      );
      const $skinsList = $('<ul />', {'class': 'list-unstyled clearfix'});
      // Dark sidebar skins
      const $skinSmartnavyblue =
      $('<li />', {style: 'float:left; width: 33.33333%; padding: 5px;'})
              .append('<a href="javascript:void(0)" data-skin="skin-smart-navy-blue" style="display: block; box-shadow: 0 0 3px rgba(0,0,0,0.4)" class="clearfix full-opacity-hover">'
                  + '<div><span style="display:block; width: 20%; float: left; height: 7px; background: #2a416f"></span><span  style="display:block; width: 80%; float: left; height: 7px; background: #2a416f"></span></div>'
                  + '<div><span style="display:block; width: 20%; float: left; height: 20px; background: #fff"></span><span style="display:block; width: 80%; float: left; height: 20px; background: #f4f5f7"></span></div>'
                  + '</a>'
                  + '<p class="text-center no-margin">mid grey</p>');
      $skinsList.append($skinSmartnavyblue);
      const $skinSmartmaroongrey =
      $('<li />', {style: 'float:left; width: 33.33333%; padding: 5px;'})
              .append('<a href="javascript:void(0)" data-skin="skin-smart-dark-purple" style="display: block; box-shadow: 0 0 3px rgba(0,0,0,0.4)" class="clearfix full-opacity-hover">'
                  + '<div><span style="display:block; width: 20%; float: left; height: 7px; background: #64003e"></span><span  style="display:block; width: 80%; float: left; height: 7px; background: #64003e"></span></div>'
                  + '<div><span style="display:block; width: 20%; float: left; height: 20px; background: #fff"></span><span style="display:block; width: 80%; float: left; height: 20px; background: #f4f5f7"></span></div>'
                  + '</a>'
                  + '<p class="text-center no-margin">mid grey</p>');
      $skinsList.append($skinSmartmaroongrey);
      const $skinSmartmidgrey =
          $('<li />', {style: 'float:left; width: 33.33333%; padding: 5px;'})
              .append('<a href="javascript:void(0)" data-skin="skin-smart-mid-grey" style="display: block; box-shadow: 0 0 3px rgba(0,0,0,0.4)" class="clearfix full-opacity-hover">'
                  + '<div><span style="display:block; width: 20%; float: left; height: 7px; background: #cdc2ae"></span><span  style="display:block; width: 80%; float: left; height: 7px; background: #cdc2ae"></span></div>'
                  + '<div><span style="display:block; width: 20%; float: left; height: 20px; background: #cdc2ae"></span><span style="display:block; width: 80%; float: left; height: 20px; background: #f4f5f7"></span></div>'
                  + '</a>'
                  + '<p class="text-center no-margin">mid grey</p>');
      $skinsList.append($skinSmartmidgrey);
      const $skinSmartbluedark =
          $('<li />', {style: 'float:left; width: 33.33333%; padding: 5px;'})
              .append('<a href="javascript:void(0)" data-skin="skin-smart-blue-dark" style="display: block; box-shadow: 0 0 3px rgba(0,0,0,0.4)" class="clearfix full-opacity-hover">'
                  + '<div><span style="display:block; width: 20%; float: left; height: 7px; background: #b3d2ee"></span><span  style="display:block; width: 80%; float: left; height: 7px; background: #b3d2ee"></span></div>'
                  + '<div><span style="display:block; width: 20%; float: left; height: 20px; background: #0171a9"></span><span style="display:block; width: 80%; float: left; height: 20px; background: #f4f5f7"></span></div>'
                  + '</a>'
                  + '<p class="text-center no-margin">blue dark</p>');
      $skinsList.append($skinSmartbluedark);
      const $skinBlue =
          $('<li />', {style: 'float:left; width: 33.33333%; padding: 5px;'})
              .append('<a href="javascript:void(0)" data-skin="skin-blue" style="display: block; box-shadow: 0 0 3px rgba(0,0,0,0.4)" class="clearfix full-opacity-hover">'
                  + '<div><span style="display:block; width: 20%; float: left; height: 7px; background: #367fa9"></span><span class="bg-light-blue" style="display:block; width: 80%; float: left; height: 7px;"></span></div>'
                  + '<div><span style="display:block; width: 20%; float: left; height: 20px; background: #222d32"></span><span style="display:block; width: 80%; float: left; height: 20px; background: #f4f5f7"></span></div>'
                  + '</a>'
                  + '<p class="text-center no-margin">Blue</p>');
      $skinsList.append($skinBlue);
      const $skinBlack =
          $('<li />', {style: 'float:left; width: 33.33333%; padding: 5px;'})
              .append('<a href="javascript:void(0)" data-skin="skin-black" style="display: block; box-shadow: 0 0 3px rgba(0,0,0,0.4)" class="clearfix full-opacity-hover">'
                  + '<div style="box-shadow: 0 0 2px rgba(0,0,0,0.1)" class="clearfix"><span style="display:block; width: 20%; float: left; height: 7px; background: #fefefe"></span><span style="display:block; width: 80%; float: left; height: 7px; background: #fefefe"></span></div>'
                  + '<div><span style="display:block; width: 20%; float: left; height: 20px; background: #222"></span><span style="display:block; width: 80%; float: left; height: 20px; background: #f4f5f7"></span></div>'
                  + '</a>'
                  + '<p class="text-center no-margin">Black</p>');
      $skinsList.append($skinBlack);
      const $skinPurple =
          $('<li />', {style: 'float:left; width: 33.33333%; padding: 5px;'})
              .append('<a href="javascript:void(0)" data-skin="skin-purple" style="display: block; box-shadow: 0 0 3px rgba(0,0,0,0.4)" class="clearfix full-opacity-hover">'
                  + '<div><span style="display:block; width: 20%; float: left; height: 7px;" class="bg-purple-active"></span><span class="bg-purple" style="display:block; width: 80%; float: left; height: 7px;"></span></div>'
                  + '<div><span style="display:block; width: 20%; float: left; height: 20px; background: #222d32"></span><span style="display:block; width: 80%; float: left; height: 20px; background: #f4f5f7"></span></div>'
                  + '</a>'
                  + '<p class="text-center no-margin">Purple</p>');
      $skinsList.append($skinPurple);
      const $skinGreen =
          $('<li />', {style: 'float:left; width: 33.33333%; padding: 5px;'})
              .append('<a href="javascript:void(0)" data-skin="skin-green" style="display: block; box-shadow: 0 0 3px rgba(0,0,0,0.4)" class="clearfix full-opacity-hover">'
                  + '<div><span style="display:block; width: 20%; float: left; height: 7px;" class="bg-green-active"></span><span class="bg-green" style="display:block; width: 80%; float: left; height: 7px;"></span></div>'
                  + '<div><span style="display:block; width: 20%; float: left; height: 20px; background: #222d32"></span><span style="display:block; width: 80%; float: left; height: 20px; background: #f4f5f7"></span></div>'
                  + '</a>'
                  + '<p class="text-center no-margin">Green</p>');
      $skinsList.append($skinGreen);
      const $skinRed =
          $('<li />', {style: 'float:left; width: 33.33333%; padding: 5px;'})
              .append('<a href="javascript:void(0)" data-skin="skin-red" style="display: block; box-shadow: 0 0 3px rgba(0,0,0,0.4)" class="clearfix full-opacity-hover">'
                  + '<div><span style="display:block; width: 20%; float: left; height: 7px;" class="bg-red-active"></span><span class="bg-red" style="display:block; width: 80%; float: left; height: 7px;"></span></div>'
                  + '<div><span style="display:block; width: 20%; float: left; height: 20px; background: #222d32"></span><span style="display:block; width: 80%; float: left; height: 20px; background: #f4f5f7"></span></div>'
                  + '</a>'
                  + '<p class="text-center no-margin">Red</p>');
      $skinsList.append($skinRed);
      const $skinYellow =
          $('<li />', {style: 'float:left; width: 33.33333%; padding: 5px;'})
              .append('<a href="javascript:void(0)" data-skin="skin-yellow" style="display: block; box-shadow: 0 0 3px rgba(0,0,0,0.4)" class="clearfix full-opacity-hover">'
                  + '<div><span style="display:block; width: 20%; float: left; height: 7px;" class="bg-yellow-active"></span><span class="bg-yellow" style="display:block; width: 80%; float: left; height: 7px;"></span></div>'
                  + '<div><span style="display:block; width: 20%; float: left; height: 20px; background: #222d32"></span><span style="display:block; width: 80%; float: left; height: 20px; background: #f4f5f7"></span></div>'
                  + '</a>'
                  + '<p class="text-center no-margin">Yellow</p>');
      $skinsList.append($skinYellow);
      // Light sidebar skins
      const $skinBlueLight =
          $('<li />', {style: 'float:left; width: 33.33333%; padding: 5px;'})
              .append('<a href="javascript:void(0)" data-skin="skin-blue-light" style="display: block; box-shadow: 0 0 3px rgba(0,0,0,0.4)" class="clearfix full-opacity-hover">'
                  + '<div><span style="display:block; width: 20%; float: left; height: 7px; background: #367fa9"></span><span class="bg-light-blue" style="display:block; width: 80%; float: left; height: 7px;"></span></div>'
                  + '<div><span style="display:block; width: 20%; float: left; height: 20px; background: #f9fafc"></span><span style="display:block; width: 80%; float: left; height: 20px; background: #f4f5f7"></span></div>'
                  + '</a>'
                  + '<p class="text-center no-margin" style="font-size: 12px">Blue Light</p>');
      $skinsList.append($skinBlueLight);
      const $skinBlackLight =
          $('<li />', {style: 'float:left; width: 33.33333%; padding: 5px;'})
              .append('<a href="javascript:void(0)" data-skin="skin-black-light" style="display: block; box-shadow: 0 0 3px rgba(0,0,0,0.4)" class="clearfix full-opacity-hover">'
                  + '<div style="box-shadow: 0 0 2px rgba(0,0,0,0.1)" class="clearfix"><span style="display:block; width: 20%; float: left; height: 7px; background: #fefefe"></span><span style="display:block; width: 80%; float: left; height: 7px; background: #fefefe"></span></div>'
                  + '<div><span style="display:block; width: 20%; float: left; height: 20px; background: #f9fafc"></span><span style="display:block; width: 80%; float: left; height: 20px; background: #f4f5f7"></span></div>'
                  + '</a>'
                  + '<p class="text-center no-margin" style="font-size: 12px">Black Light</p>');
      $skinsList.append($skinBlackLight);
      const $skinPurpleLight =
          $('<li />', {style: 'float:left; width: 33.33333%; padding: 5px;'})
              .append('<a href="javascript:void(0)" data-skin="skin-purple-light" style="display: block; box-shadow: 0 0 3px rgba(0,0,0,0.4)" class="clearfix full-opacity-hover">'
                  + '<div><span style="display:block; width: 20%; float: left; height: 7px;" class="bg-purple-active"></span><span class="bg-purple" style="display:block; width: 80%; float: left; height: 7px;"></span></div>'
                  + '<div><span style="display:block; width: 20%; float: left; height: 20px; background: #f9fafc"></span><span style="display:block; width: 80%; float: left; height: 20px; background: #f4f5f7"></span></div>'
                  + '</a>'
                  + '<p class="text-center no-margin" style="font-size: 12px">Purple Light</p>');
      $skinsList.append($skinPurpleLight);
      const $skinGreenLight =
          $('<li />', {style: 'float:left; width: 33.33333%; padding: 5px;'})
              .append('<a href="javascript:void(0)" data-skin="skin-green-light" style="display: block; box-shadow: 0 0 3px rgba(0,0,0,0.4)" class="clearfix full-opacity-hover">'
                  + '<div><span style="display:block; width: 20%; float: left; height: 7px;" class="bg-green-active"></span><span class="bg-green" style="display:block; width: 80%; float: left; height: 7px;"></span></div>'
                  + '<div><span style="display:block; width: 20%; float: left; height: 20px; background: #f9fafc"></span><span style="display:block; width: 80%; float: left; height: 20px; background: #f4f5f7"></span></div>'
                  + '</a>'
                  + '<p class="text-center no-margin" style="font-size: 12px">Green Light</p>');
      $skinsList.append($skinGreenLight);
      const $skinRedLight =
          $('<li />', {style: 'float:left; width: 33.33333%; padding: 5px;'})
              .append('<a href="javascript:void(0)" data-skin="skin-red-light" style="display: block; box-shadow: 0 0 3px rgba(0,0,0,0.4)" class="clearfix full-opacity-hover">'
                  + '<div><span style="display:block; width: 20%; float: left; height: 7px;" class="bg-red-active"></span><span class="bg-red" style="display:block; width: 80%; float: left; height: 7px;"></span></div>'
                  + '<div><span style="display:block; width: 20%; float: left; height: 20px; background: #f9fafc"></span><span style="display:block; width: 80%; float: left; height: 20px; background: #f4f5f7"></span></div>'
                  + '</a>'
                  + '<p class="text-center no-margin" style="font-size: 12px">Red Light</p>');
      $skinsList.append($skinRedLight);
      const $skinYellowLight =
          $('<li />', {style: 'float:left; width: 33.33333%; padding: 5px;'})
              .append('<a href="javascript:void(0)" data-skin="skin-yellow-light" style="display: block; box-shadow: 0 0 3px rgba(0,0,0,0.4)" class="clearfix full-opacity-hover">'
                  + '<div><span style="display:block; width: 20%; float: left; height: 7px;" class="bg-yellow-active"></span><span class="bg-yellow" style="display:block; width: 80%; float: left; height: 7px;"></span></div>'
                  + '<div><span style="display:block; width: 20%; float: left; height: 20px; background: #f9fafc"></span><span style="display:block; width: 80%; float: left; height: 20px; background: #f4f5f7"></span></div>'
                  + '</a>'
                  + '<p class="text-center no-margin" style="font-size: 12px">Yellow Light</p>');
      $skinsList.append($skinYellowLight);
      $demoSettings.append('<h4 class="control-sidebar-heading">Skins</h4>');
      $demoSettings.append($skinsList);
      $tabPane.append($demoSettings);
      $('#control-sidebar-home-tab').after($tabPane);
      setup();
      $('[data-toggle="tooltip"]').tooltip();
   });
   }
   LoadLayoutSettingsJS() {
    // Make sure jQuery has been loaded
    if (typeof jQuery === 'undefined') {
        throw new Error('SmartPRA requires jQuery');
        }
    /* BoxRefresh()
     * =========
     * Adds AJAX content control to a box.
     *
     * @Usage: $('#my-box').boxRefresh(options)
     *         or add [data-widget="box-refresh"] to the box element
     *         Pass any option as data-option="value"
     */
    $(function () {
      'use strict';
      const DataKey = 'lte.boxrefresh';

      const Default = {
        source         : '',
        params         : {},
        trigger        : '.refresh-btn',
        content        : '.box-body',
        loadInContent  : true,
        responseType   : '',
        overlayTemplate: '<div class="overlay"><div class="fa fa-refresh fa-spin"></div></div>',
        onLoadStart    : function () {
        },
        onLoadDone     : function (response) {
          return response;
        }
      };

      const Selector = {
        data: '[data-widget="box-refresh"]',
        trigger: ''
      };
      // BoxRefresh Class Definition
      // =========================
      const BoxRefresh = function (element, options) {
        this.element  = element;
        this.options  = options;
        this.$overlay = $(options.overlay);

        if (options.source === '') {
          throw new Error('Source url was not defined. Please specify a url in your BoxRefresh source option.');
        }

        this._setUpListeners();
        this.load();
      };
      BoxRefresh.prototype.load = function () {
        this._addOverlay();
        this.options.onLoadStart.call($(this));
        $.get(this.options.source, this.options.params, function (response) {
          if (this.options.loadInContent) {
            $(this.options.content).html(response);
          }
          this.options.onLoadDone.call($(this), response);
          this._removeOverlay();
        }.bind(this), this.options.responseType !== '' && this.options.responseType);
      };
      // Private
      BoxRefresh.prototype._setUpListeners = function () {
        $(this.element).on('click', Selector.trigger, function (event) {
          if (event) {
              event.preventDefault();
          this.load(); }
        }.bind(this));
      };
      BoxRefresh.prototype._addOverlay = function () {
        $(this.element).append(this.$overlay);
      };
      BoxRefresh.prototype._removeOverlay = function () {
        $(this.element).remove(this.$overlay);
      };
      // Plugin Definition
      // =================
      function Plugin(option) {
        return this.each(function () {
          const $this = $(this);
          let data  = $this.data(DataKey);
          if (!data) {
            const options = $.extend({}, Default, $this.data(), typeof option === 'object' && option);
            $this.data(DataKey, (data = new BoxRefresh($this, options)));
          }

          if (typeof data === 'boolean') {
            if (typeof data[option] === 'undefined') {
              throw new Error('No method named ' + option);
            }
            data[option]();
          }
        });
      }
      const old = $.fn.boxRefresh;
      $.fn.boxRefresh             = Plugin;
      $.fn.boxRefresh.Constructor = BoxRefresh;
      // No Conflict Mode
      // ================
      $.fn.boxRefresh.noConflict = function () {
        $.fn.boxRefresh = old;
        return this;
      };
      // BoxRefresh Data API
      // =================
      $(window).on('load', function () {
        $(Selector.data).each(function () {
          Plugin.call($(this));
        });
      });
    });
    /* BoxWidget()
     * ======
     * Adds box widget functions to boxes.
     *
     * @Usage: $('.my-box').boxWidget(options)
     *         This plugin auto activates on any element using the `.box` class
     *         Pass any option as data-option="value"
     */
    $(function () {
      'use strict';
      const DataKey = 'lte.boxwidget';
      const Default = {
        animationSpeed : 500,
        collapseTrigger: '[data-widget="collapse"]',
        removeTrigger  : '[data-widget="remove"]',
        collapseIcon   : 'fa-minus',
        expandIcon     : 'fa-plus',
        removeIcon     : 'fa-times'
      };
      const Selector = {
        data     : '.box',
        collapsed: '.collapsed-box',
        header   : '.box-header',
        body     : '.box-body',
        footer   : '.box-footer',
        tools    : '.box-tools'
      };
      const ClassName = {
        collapsed: 'collapsed-box'
      };
      const Event = {
        collapsed: 'collapsed.boxwidget',
        expanded : 'expanded.boxwidget',
        removed  : 'removed.boxwidget'
      };
      // BoxWidget Class Definition
      // =====================
      const BoxWidget = function (element, options) {
        this.element = element;
        this.options = options;
        this._setUpListeners();
      };
      BoxWidget.prototype.toggle = function () {
        const isOpen = !$(this.element).is(Selector.collapsed);

        if (isOpen) {
          this.collapse();
        } else {
          this.expand();
        }
      };
      BoxWidget.prototype.expand = function () {
        const expandedEvent = $.Event(Event.expanded);
        const collapseIcon  = this.options.collapseIcon;
        const expandIcon    = this.options.expandIcon;
        $(this.element).removeClass(ClassName.collapsed);
        $(this.element)
          .children(Selector.header + ', ' + Selector.body + ', ' + Selector.footer)
          .children(Selector.tools)
          .find('.' + expandIcon)
          .removeClass(expandIcon)
          .addClass(collapseIcon);
        $(this.element).children(Selector.body + ', ' + Selector.footer)
          .slideDown(this.options.animationSpeed, function () {
            $(this.element).trigger(expandedEvent);
          }.bind(this));
      };
      BoxWidget.prototype.collapse = function () {
        const collapsedEvent = $.Event(Event.collapsed);
        const collapseIcon   = this.options.collapseIcon;
        const expandIcon     = this.options.expandIcon;
        $(this.element)
          .children(Selector.header + ', ' + Selector.body + ', ' + Selector.footer)
          .children(Selector.tools)
          .find('.' + collapseIcon)
          .removeClass(collapseIcon)
          .addClass(expandIcon);
        $(this.element).children(Selector.body + ', ' + Selector.footer)
          .slideUp(this.options.animationSpeed, function () {
            $(this.element).addClass(ClassName.collapsed);
            $(this.element).trigger(collapsedEvent);
          }.bind(this));
      };
      BoxWidget.prototype.remove = function () {
        const removedEvent = $.Event(Event.removed);
        $(this.element).slideUp(this.options.animationSpeed, function () {
          $(this.element).trigger(removedEvent);
          $(this.element).remove();
        }.bind(this));
      };
      // Private
      BoxWidget.prototype._setUpListeners = function () {
        const that = this;
        $(this.element).on('click', this.options.collapseTrigger, function (event) {
          if (event) { event.preventDefault();
          that.toggle($(this)); }
          return false;
        });
        $(this.element).on('click', this.options.removeTrigger, function (event) {
          if (event) { event.preventDefault();
          that.remove($(this)); }
          return false;
        });
      };
      // Plugin Definition
      // =================
      function Plugin(option) {
        return this.each(function () {
          const $this = $(this);
          let data  = $this.data(DataKey);
          if (!data) {
            const options = $.extend({}, Default, $this.data(), typeof option === 'object' && option);
            $this.data(DataKey, (data = new BoxWidget($this, options)));
          }
          if (typeof option === 'string') {
            if (typeof data[option] === 'undefined') {
              throw new Error('No method named ' + option);
            }
            data[option]();
          }
        });
      }
      const old = $.fn.boxWidget;
      $.fn.boxWidget             = Plugin;
      $.fn.boxWidget.Constructor = BoxWidget;
      // No Conflict Mode
      // ================
      $.fn.boxWidget.noConflict = function () {
        $.fn.boxWidget = old;
        return this;
      };
      // BoxWidget Data API
      // ==================
      $(window).on('load', function () {
        $(Selector.data).each(function () {
          Plugin.call($(this));
        });
      });
    });

    /* ControlSidebar()
     * ===============
     * Toggles the state of the control sidebar
     *
     * @Usage: $('#control-sidebar-trigger').controlSidebar(options)
     *         or add [data-toggle="control-sidebar"] to the trigger
     *         Pass any option as data-option="value"
     */
    $(function () {
      'use strict';
      const DataKey = 'lte.controlsidebar';

      const Default = {
        slide: true
      };
      const Selector = {
        sidebar: '.control-sidebar',
        data   : '[data-toggle="control-sidebar"]',
        open   : '.control-sidebar-open',
        bg     : '.control-sidebar-bg',
        wrapper: '.wrapper',
        content: '.content-wrapper',
        boxed  : '.layout-boxed'
      };

      const ClassName = {
        open : 'control-sidebar-open',
        fixed: 'fixed'
      };

      const Event = {
        collapsed: 'collapsed.controlsidebar',
        expanded : 'expanded.controlsidebar'
      };

      // ControlSidebar Class Definition
      // ===============================
      const ControlSidebar = function (element, options) {
        this.element         = element;
        this.options         = options;
        this.hasBindedResize = false;

        this.init();
      };

      ControlSidebar.prototype.init = function () {
        // Add click listener if the element hasn't been
        // initialized using the data API
        if (!$(this.element).is(Selector.data)) {
          $(this).on('click', this.toggle);
        }

        this.fix();
        $(window).resize(function () {
          this.fix();
        }.bind(this));
      };

      ControlSidebar.prototype.toggle = function (event) {
        if (event) { event.preventDefault();

        this.fix(); }
        if (!$(Selector.sidebar).is(Selector.open) && !$('body').is(Selector.open)) {
          this.expand();
        } else {
          this.collapse();
        }
      };

      ControlSidebar.prototype.expand = function () {
        if (!this.options.slide) {
          $('body').addClass(ClassName.open);
        } else {
          $(Selector.sidebar).addClass(ClassName.open);
        }

        $(this.element).trigger($.Event(Event.expanded));
      };

      ControlSidebar.prototype.collapse = function () {
        $('body, ' + Selector.sidebar).removeClass(ClassName.open);
        $(this.element).trigger($.Event(Event.collapsed));
      };

      ControlSidebar.prototype.fix = function () {
        if ($('body').is(Selector.boxed)) {
          this._fixForBoxed($(Selector.bg));
        }
      };

      // Private

      ControlSidebar.prototype._fixForBoxed = function (bg) {
        bg.css({
          position: 'absolute',
          height  : $(Selector.wrapper).height()
        });
      };

      // Plugin Definition
      // =================
      function Plugin(option) {
        return this.each(function () {
          const $this = $(this);
          let data  = $this.data(DataKey);

          if (!data) {
            const options = $.extend({}, Default, $this.data(), typeof option === 'object' && option);
            $this.data(DataKey, (data = new ControlSidebar($this, options)));
          }

          if (typeof option === 'string') { data.toggle(); }
        });
      }

      const old = $.fn.controlSidebar;

      $.fn.controlSidebar             = Plugin;
      $.fn.controlSidebar.Constructor = ControlSidebar;

      // No Conflict Mode
      // ================
      $.fn.controlSidebar.noConflict = function () {
        $.fn.controlSidebar = old;
        return this;
      };

      // ControlSidebar Data API
      // =======================
      $(document).on('click', Selector.data, function (event) {
        if (event) { event.preventDefault();
        Plugin.call($(this), 'toggle'); }
      });

    });


    /* DirectChat()
     * ===============
     * Toggles the state of the control sidebar
     *
     * @Usage: $('#my-chat-box').directChat()
     *         or add [data-widget="direct-chat"] to the trigger
     */
    $(function () {
      'use strict';

      const DataKey = 'lte.directchat';

      const Selector = {
        data: '[data-widget="chat-pane-toggle"]',
        box : '.direct-chat'
      };

      const ClassName = {
        open: 'direct-chat-contacts-open'
      };

      // DirectChat Class Definition
      // ===========================
      const DirectChat = function (element) {
        this.element = element;
      };

      DirectChat.prototype.toggle = function ($trigger) {
        $trigger.parents(Selector.box).first().toggleClass(ClassName.open);
      };

      // Plugin Definition
      // =================
      function Plugin(option) {
        return this.each(function () {
          const $this = $(this);
          let data  = $this.data(DataKey);

        if (!data) {
            $this.data(DataKey, (data = new DirectChat($this)));
          }

          if (typeof option === 'string') { data.toggle($this); }
        });
      }

      const old = $.fn.directChat;

      $.fn.directChat             = Plugin;
      $.fn.directChat.Constructor = DirectChat;

      // No Conflict Mode
      // ================
      $.fn.directChat.noConflict = function () {
        $.fn.directChat = old;
        return this;
      };

      // DirectChat Data API
      // ===================
      $(document).on('click', Selector.data, function (event) {
        if (event) { event.preventDefault();
        Plugin.call($(this), 'toggle');
        }
      });

    });


    /* Layout()
     * ========
     * Implements SmartPRA layout.
     * Fixes the layout height in case min-height fails.
     *
     * @usage activated automatically upon window load.
     *        Configure any options by passing data-option="value"
     *        to the body tag.
     */
    $(function () {
      'use strict';

      const DataKey = 'lte.layout';

      const Default = {
        slimscroll : true,
        resetHeight: true
      };

      const Selector = {
        wrapper       : '.wrapper',
        contentWrapper: '.content-wrapper',
        layoutBoxed   : '.layout-boxed',
        mainFooter    : '.main-footer',
        mainHeader    : '.main-header',
        sidebar       : '.sidebar',
        controlSidebar: '.control-sidebar',
        fixed         : '.fixed',
        sidebarMenu   : '.sidebar-menu',
        logo          : '.main-header .logo'
      };

      const ClassName = {
        fixed         : 'fixed',
        holdTransition: 'hold-transition'
      };

      const Layout = function (options) {
        this.options      = options;
        this.bindedResize = false;
        this.activate();
      };

      Layout.prototype.activate = function () {
        this.fix();
        this.fixSidebar();

        $('body').removeClass(ClassName.holdTransition);

        if (this.options.resetHeight) {
          $('body, html, ' + Selector.wrapper).css({
            'height'    : 'auto',
            'min-height': '100%'
          });
        }

        if (!this.bindedResize) {
          $(window).resize(function () {
            this.fix();
            this.fixSidebar();

            $(Selector.logo + ', ' + Selector.sidebar).one('webkitTransitionEnd otransitionend oTransitionEnd msTransitionEnd transitionend', function () {
              this.fix();
              this.fixSidebar();
            }.bind(this));
          }.bind(this));

          this.bindedResize = true;
        }

        $(Selector.sidebarMenu).on('expanded.tree', function () {
          this.fix();
          this.fixSidebar();
        }.bind(this));

        $(Selector.sidebarMenu).on('collapsed.tree', function () {
          this.fix();
          this.fixSidebar();
        }.bind(this));
      };

      Layout.prototype.fix = function () {
        // Remove overflow from .wrapper if layout-boxed exists
        $(Selector.layoutBoxed + ' > ' + Selector.wrapper).css('overflow', 'hidden');

        // Get window height and the wrapper height
        const footerHeight = $(Selector.mainFooter).outerHeight() || 0;
        const headerHeight  = $(Selector.mainHeader).outerHeight() || 0;
        const neg           = headerHeight + footerHeight;
        const windowHeight  = $(window).height();
        const sidebarHeight = $(Selector.sidebar).height() || 0;

        // Set the min-height of the content and sidebar based on
        // the height of the document.
        if ($('body').hasClass(ClassName.fixed)) {
          $(Selector.contentWrapper).css('min-height', windowHeight - footerHeight);
        } else {
          let postSetHeight;

          if (windowHeight >= sidebarHeight + headerHeight) {
            $(Selector.contentWrapper).css('min-height', windowHeight - neg);
            postSetHeight = windowHeight - neg;
          } else {
            $(Selector.contentWrapper).css('min-height', sidebarHeight);
            postSetHeight = sidebarHeight;
          }

          // Fix for the control sidebar height
          const $controlSidebar = $(Selector.controlSidebar);
          if (typeof $controlSidebar !== 'undefined') {
            if ($controlSidebar.height() > postSetHeight) {
              $(Selector.contentWrapper).css('min-height', $controlSidebar.height());
            }
          }
        }
      };

      Layout.prototype.fixSidebar = function () {
        // Make sure the body tag has the .fixed class
        if (!$('body').hasClass(ClassName.fixed)) {
          if (typeof $.fn.slimScroll !== 'undefined') {
            $(Selector.sidebar).slimScroll({ destroy: true }).height('auto');
          }
          return;
        }

        // Enable slimscroll for fixed layout
        if (this.options.slimscroll) {
          if (typeof $.fn.slimScroll !== 'undefined') {
            // Destroy if it exists
            // $(Selector.sidebar).slimScroll({ destroy: true }).height('auto')

            // Add slimscroll
            $(Selector.sidebar).slimScroll({
              height: ($(window).height() - $(Selector.mainHeader).height()) + 'px'
            });
          }
        }
      };

      // Plugin Definition
      // =================
      function Plugin(option) {
        return this.each(function () {
          const $this = $(this);
          let data  = $this.data(DataKey);

          if (!data) {
            const options = $.extend({}, Default, $this.data(), typeof option === 'object' && option);
            $this.data(DataKey, (data = new Layout(options)));
          }

          if (typeof option === 'string') {
            if (typeof data[option] === 'undefined') {
              throw new Error('No method named ' + option);
            }
            data[option]();
          }
        });
      }

      const old = $.fn.layout;

      $.fn.layout            = Plugin;
      $.fn.layout.Constuctor = Layout;

      // No conflict mode
      // ================
      $.fn.layout.noConflict = function () {
        $.fn.layout = old;
        return this;
      };

      // Layout DATA-API
      // ===============
      $(window).on('load', function () {
        Plugin.call($('body'));
      });
    });


    /* PushMenu()
     * ==========
     * Adds the push menu functionality to the sidebar.
     *
     * @usage: $('.btn').pushMenu(options)
     *          or add [data-toggle="push-menu"] to any button
     *          Pass any option as data-option="value"
     */
    $(function () {
      'use strict';

      const DataKey = 'lte.pushmenu';

      const Default = {
        collapseScreenSize   : 767,
        expandOnHover        : false,
        expandTransitionDelay: 200
      };

      const Selector = {
        collapsed     : '.sidebar-collapse',
        open          : '.sidebar-open',
        mainSidebar   : '.main-sidebar',
        contentWrapper: '.content-wrapper',
        searchInput   : '.sidebar-form .form-control',
        button        : '[data-toggle="push-menu"]',
        mini          : '.sidebar-mini',
        expanded      : '.sidebar-expanded-on-hover',
        layoutFixed   : '.fixed'
      };

      const ClassName = {
        collapsed    : 'sidebar-collapse',
        open         : 'sidebar-open',
        mini         : 'sidebar-mini',
        expanded     : 'sidebar-expanded-on-hover',
        expandFeature: 'sidebar-mini-expand-feature',
        layoutFixed  : 'fixed'
      };

      const Event = {
        expanded : 'expanded.pushMenu',
        collapsed: 'collapsed.pushMenu'
      };

      // PushMenu Class Definition
      // =========================
      const PushMenu = function (options) {
        this.options = options;
        this.init();
      };

      PushMenu.prototype.init = function () {
        if (this.options.expandOnHover
          || ($('body').is(Selector.mini + Selector.layoutFixed))) {
          this.expandOnHover();
          $('body').addClass(ClassName.expandFeature);
        }

        $(Selector.contentWrapper).click(function () {
          // Enable hide menu when clicking on the content-wrapper on small screens
          if ($(window).width() <= this.options.collapseScreenSize && $('body').hasClass(ClassName.open)) {
            this.close();
          }
        }.bind(this));

        // __Fix for android devices
        $(Selector.searchInput).click(function (e) {
          e.stopPropagation();
        });
      };

      PushMenu.prototype.toggle = function () {
        const windowWidth = $(window).width();
        let isOpen      = !$('body').hasClass(ClassName.collapsed);

       if (windowWidth <= this.options.collapseScreenSize) {
          isOpen = $('body').hasClass(ClassName.open);
        }

        if (!isOpen) {
          this.open();
        } else {
          this.close();
        }
      };

      PushMenu.prototype.open = function () {
        const windowWidth = $(window).width();

        if (windowWidth > this.options.collapseScreenSize) {
          $('body').removeClass(ClassName.collapsed)
            .trigger($.Event(Event.expanded));
        } else {
          $('body').addClass(ClassName.open)
            .trigger($.Event(Event.expanded));
        }
      };

      PushMenu.prototype.close = function () {
        const windowWidth = $(window).width();
        if (windowWidth > this.options.collapseScreenSize) {
          $('body').addClass(ClassName.collapsed)
            .trigger($.Event(Event.collapsed));
        } else {
          $('body').removeClass(ClassName.open + ' ' + ClassName.collapsed)
            .trigger($.Event(Event.collapsed));
        }
      };

      PushMenu.prototype.expandOnHover = function () {
        $(Selector.mainSidebar).hover(function () {
          if ($('body').is(Selector.mini + Selector.collapsed)
            && $(window).width() > this.options.collapseScreenSize) {
            this.expand();
          }
        }.bind(this), function () {
          if ($('body').is(Selector.expanded)) {
            this.collapse();
          }
        }.bind(this));
      };

      PushMenu.prototype.expand = function () {
        setTimeout(function () {
          $('body').removeClass(ClassName.collapsed)
            .addClass(ClassName.expanded);
        }, this.options.expandTransitionDelay);
      };

      PushMenu.prototype.collapse = function () {
        setTimeout(function () {
          $('body').removeClass(ClassName.expanded)
            .addClass(ClassName.collapsed);
        }, this.options.expandTransitionDelay);
      };

      // PushMenu Plugin Definition
      // ==========================
      function Plugin(option) {
        return this.each(function () {
          const $this = $(this);
          let data  = $this.data(DataKey);

          if (!data) {
            const options = $.extend({}, Default, $this.data(), typeof option === 'object' && option);
            $this.data(DataKey, (data = new PushMenu(options)));
          }

          if (option === 'toggle') { data.toggle(); }
        });
      }

      const old = $.fn.pushMenu;

      $.fn.pushMenu             = Plugin;
      $.fn.pushMenu.Constructor = PushMenu;

      // No Conflict Mode
      // ================
      $.fn.pushMenu.noConflict = function () {
        $.fn.pushMenu = old;
        return this;
      };

      // Data API
      // ========
      $(document).on('click', Selector.button, function (e) {
        e.preventDefault();
        Plugin.call($(this), 'toggle');
      });
      $(window).on('load', function () {
        Plugin.call($(Selector.button));
      });
    });


    /* TodoList()
     * =========
     * Converts a list into a todoList.
     *
     * @Usage: $('.my-list').todoList(options)
     *         or add [data-widget="todo-list"] to the ul element
     *         Pass any option as data-option="value"
     */
    $(function () {
      'use strict';

      const DataKey = 'lte.todolist';

      const Default = {
        onCheck  : function (item) {
          return item;
        },
        onUnCheck: function (item) {
          return item;
        }
      };

      const Selector = {
        data: '[data-widget="todo-list"]',
        li: 'li'
      };

      const ClassName = {
        done: 'done'
      };

      // TodoList Class Definition
      // =========================
      const TodoList = function (element, options) {
        this.element = element;
        this.options = options;

        this._setUpListeners();
      };

      TodoList.prototype.toggle = function (item) {
        item.parents(Selector.li).first().toggleClass(ClassName.done);
        if (!item.prop('checked')) {
          this.unCheck(item);
          return;
        }

        this.check(item);
      };

      TodoList.prototype.check = function (item) {
        this.options.onCheck.call(item);
      };

      TodoList.prototype.unCheck = function (item) {
        this.options.onUnCheck.call(item);
      };

      // Private

      TodoList.prototype._setUpListeners = function () {
        const that = this;
        $(this.element).on('change ifChanged', 'input:checkbox', function () {
          that.toggle($(this));
        });
      };

      // Plugin Definition
      // =================
      function Plugin(option) {
        return this.each(function () {
          const $this = $(this);
          let data  = $this.data(DataKey);

          if (!data) {
            const options = $.extend({}, Default, $this.data(), typeof option === 'object' && option);
            $this.data(DataKey, (data = new TodoList($this, options)));
          }

          if (typeof data === 'boolean') {
            if (typeof data[option] === 'undefined') {
              throw new Error('No method named ' + option);
            }
             data[option]();
          }
        });
      }

      const old = $.fn.todoList;

      $.fn.todoList             = Plugin;
      $.fn.todoList.Constructor = TodoList;

      // No Conflict Mode
      // ================
      $.fn.todoList.noConflict = function () {
        $.fn.todoList = old;
        return this;
      };

      // TodoList Data API
      // =================
      $(window).on('load', function () {
        $(Selector.data).each(function () {
          Plugin.call($(this));
        });
      });

    });


    /* Tree()
     * ======
     * Converts a nested list into a multilevel
     * tree view menu.
     *
     * @Usage: $('.my-menu').tree(options)
     *         or add [data-widget="tree"] to the ul element
     *         Pass any option as data-option="value"
     */
    $(function () {
      'use strict';

      const DataKey = 'lte.tree';

      const Default = {
        animationSpeed: 500,
        accordion     : true,
        followLink    : false,
        trigger       : '.treeview a'
      };

      const Selector = {
        tree        : '.tree',
        treeview    : '.treeview',
        treeviewMenu: '.treeview-menu',
        open        : '.menu-open, .active',
        li          : 'li',
        data        : '[data-widget="tree"]',
        active      : '.active'
      };

      const ClassName = {
        open: 'menu-open',
        tree: 'tree'
      };

      const Event = {
        collapsed: 'collapsed.tree',
        expanded : 'expanded.tree'
      };

      // Tree Class Definition
      // =====================
      const Tree = function (element, options) {
        this.element = element;
        this.options = options;

        $(this.element).addClass(ClassName.tree);

        $(Selector.treeview + Selector.active, this.element).addClass(ClassName.open);

        this._setUpListeners();
      };

      Tree.prototype.toggle = function (link, event) {
        const treeviewMenu = link.next(Selector.treeviewMenu);
        const parentLi     = link.parent();
        const isOpen       = parentLi.hasClass(ClassName.open);

        if (!parentLi.is(Selector.treeview)) {
          return;
        }

        if (!this.options.followLink || link.attr('href') === '#') {
          event.preventDefault();
        }

        if (isOpen) {
          this.collapse(treeviewMenu, parentLi);
        } else {
          this.expand(treeviewMenu, parentLi);
        }
      };

      Tree.prototype.expand = function (tree, parent) {
        const expandedEvent = $.Event(Event.expanded);

        if (this.options.accordion) {
          const openMenuLi = parent.siblings(Selector.open);
          const openTree   = openMenuLi.children(Selector.treeviewMenu);
          this.collapse(openTree, openMenuLi);
        }

        parent.addClass(ClassName.open);
        tree.slideDown(this.options.animationSpeed, function () {
          $(this.element).trigger(expandedEvent);
        }.bind(this));
      };

      Tree.prototype.collapse = function (tree, parentLi) {
        const collapsedEvent = $.Event(Event.collapsed);

        // tree.find(Selector.open).removeClass(ClassName.open);
        parentLi.removeClass(ClassName.open);
        tree.slideUp(this.options.animationSpeed, function () {
          // tree.find(Selector.open + ' > ' + Selector.treeview).slideUp();
          $(this.element).trigger(collapsedEvent);
        }.bind(this));
      };

      // Private

      Tree.prototype._setUpListeners = function () {
        const that = this;

        $(this.element).on('click', this.options.trigger, function (event) {
          that.toggle($(this), event);
        });
      };

      // Plugin Definition
      // =================
      function Plugin(option) {
        return this.each(function () {
          const $this = $(this);
          const data  = $this.data(DataKey);

          if (!data) {
            const options = $.extend({}, Default, $this.data(), typeof option === 'object' && option);
            $this.data(DataKey, new Tree($this, options));
          }
        });
      }

      const old = $.fn.tree;

      $.fn.tree             = Plugin;
      $.fn.tree.Constructor = Tree;

      // No Conflict Mode
      // ================
      $.fn.tree.noConflict = function () {
        $.fn.tree = old;
        return this;
      };

      // Tree Data API
      // =============
      $(window).on('load', function () {
        $(Selector.data).each(function () {
          Plugin.call($(this));
        });
      });

    });

   }
   LoadFormSettingJs() {
    $(() => {
      // $('.select2').select2();
      // $('[data-mask]').inputmask();
      // $('.datemask').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' });
      // $('.datemask2').inputmask('mm/dd/yyyy', { 'placeholder': 'mm/dd/yyyy' });
      // $('.reservation').daterangepicker();
      // $('.reservationtime').daterangepicker({ timePicker: true, timePickerIncrement: 30, format: 'MM/DD/YYYY h:mm A' });
      // $('.daterange-btn').daterangepicker(
      //   {
      //     ranges   : {
      //       'Today'       : [moment(), moment()],
      //       'Yesterday'   : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
      //       'Last 7 Days' : [moment().subtract(6, 'days'), moment()],
      //       'Last 30 Days': [moment().subtract(29, 'days'), moment()],
      //       'This Month'  : [moment().startOf('month'), moment().endOf('month')],
      //       'Last Month'  : [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
      //     },
      //     startDate: moment().subtract(29, 'days'),
      //     endDate  : moment()
      //   },
      //   function (start, end) {
      //     $('.daterange-btn span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
      //   }
      // );
      // $('.datepicker').datepicker({
      //   autoclose: true
      // });
      // $('.my-colorpicker1').colorpicker();
      // $('.my-colorpicker2').colorpicker();
      // $('.timepicker').timepicker({
      //   showInputs: false
      // });
      $('input[type="checkbox"].flat-blue, input[type="radio"].flat-blue').iCheck({
        checkboxClass: 'icheckbox_flat-blue',
        radioClass: 'iradio_flat-blue'
      });
      $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
        checkboxClass: 'icheckbox_minimal-blue',
        radioClass   : 'iradio_minimal-blue'
      });
      $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
        checkboxClass: 'icheckbox_minimal-red',
        radioClass   : 'iradio_minimal-red'
      });
      $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
        checkboxClass: 'icheckbox_flat-green',
        radioClass   : 'iradio_flat-green'
      });

      });
   }

  getHoursAndMinutesByDays(day) {
    let timeArr = [];
    for (let i = 0; i <= day; i++) {
      let n : any ;
      n = i % 2 == 0 ? i / 2 + '.00' : (i + 1) / 2 - 1 + '.30';
      if (n < 10)
        n = '0' + n;
      timeArr.push(n);
    }
    return timeArr;
  }

  splitDate(date: any) {
		if (date instanceof Date) {
		  const datePipe = new DatePipe('en-US');
		  return datePipe.transform(date, 'yyyy-MM-dd');
		} else {
		  return date.split('T')[0];
		}
	  }
}
