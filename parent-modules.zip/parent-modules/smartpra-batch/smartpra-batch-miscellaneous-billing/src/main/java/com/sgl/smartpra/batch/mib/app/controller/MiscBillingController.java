package com.sgl.smartpra.batch.mib.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.batch.mib.app.service.MiscBillingService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class MiscBillingController {
	@Autowired
	MiscBillingService miscBillingService;

	@RequestMapping("/miscellaneous-billing/invokejob")
	public String invokeInboundJob(@RequestParam("fileName") String fileName) throws Exception {
		log.debug("In invokeInboundJob()");
		return miscBillingService.executeInboundJob(fileName, "Manual");
	}
	
	@RequestMapping("/miscellaneous-billing/invokeoutwardjob")
	public String invokeGenerateOutwardXml() throws Exception {
		log.debug("In invokeGenerateOutwardXml()");
		return miscBillingService.executeOutBoundJob();
	}
}
