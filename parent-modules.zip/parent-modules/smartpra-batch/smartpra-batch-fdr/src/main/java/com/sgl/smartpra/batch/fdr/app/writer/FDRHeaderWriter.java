package com.sgl.smartpra.batch.fdr.app.writer;

import java.util.List;

import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ItemWriter;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.fdr.app.domain.CurrencyHeader;
import com.sgl.smartpra.batch.fdr.app.domain.CurrencyRecord;
import com.sgl.smartpra.batch.fdr.app.repository.FDRRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

@Component
@Scope(value = "step")
public class FDRHeaderWriter<T extends CurrencyRecord> implements ItemWriter<CurrencyHeader> {

	@Value("#{stepExecution}")
	private StepExecution stepExecution;

	@Autowired
	private FDRRepository fdrRepository;

	public StepExecution getStepExecution() {
		return stepExecution;
	}

	public void setStepExecution(StepExecution stepExecution) {
		this.stepExecution = stepExecution;
	}

	public void write(List<? extends CurrencyHeader> roeHeader) throws Exception {

		stepExecution.getExecutionContext().put("currencyHeader", roeHeader.get(0));
		stepExecution.getExecutionContext().put("currencyHeaderCount", roeHeader.size());

		stepExecution.getExecutionContext().put("effectiveDate", roeHeader.get(0).getEffectiveDate());
	}

}
