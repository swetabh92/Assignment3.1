import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ToastAlertMessageComponent } from './toast-alert-message.component';

describe('ToastAlertMessageComponent', () => {
  let component: ToastAlertMessageComponent;
  let fixture: ComponentFixture<ToastAlertMessageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ToastAlertMessageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ToastAlertMessageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
