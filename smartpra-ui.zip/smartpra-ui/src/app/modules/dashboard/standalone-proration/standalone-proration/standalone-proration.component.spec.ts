import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StandaloneProrationComponent } from './standalone-proration.component';

describe('StandaloneProrationComponent', () => {
  let component: StandaloneProrationComponent;
  let fixture: ComponentFixture<StandaloneProrationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StandaloneProrationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StandaloneProrationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
