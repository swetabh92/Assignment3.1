import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { InputOutputRoutingModule } from './input-output-routing.module';
import { SharedModule } from '../../../shared/shared.module';
import { InputOutputDashboardComponent } from './input-output-dashboard.component';
import { ExcpetionManagementComponent } from '../excpetion-management/excpetion-management.component';
import { ExceptionTrendComponent } from '../exception-trend/exception-trend.component';
import {DashboardModule} from "../dashboard.module";
import {TaskStatusComponent} from "../excpetion-management/task-status/task-status.component";
import {SearchExceptionComponent} from "../excpetion-management/search-exception/search-exception.component";
import {TaskAllocationComponent} from "../excpetion-management/task-allocation/task-allocation.component";
import {ViewFileComponent} from './view-file/view-file.component';
import { CoreDataModule } from 'src/app/core-data/core-data.module';
import { UpliftErroneousComponent } from './uplift-erroneous/uplift-erroneous.component';
import { SaleErroneousComponent } from './sale-erroneous/sale-erroneous.component';
import { SaleTransferredComponent } from './sale-transferred/sale-transferred.component';



@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    CoreDataModule,
    InputOutputRoutingModule,
    DashboardModule
  ],
  exports: [
    ViewFileComponent,
  ],
  declarations: [
    InputOutputDashboardComponent,
    ExcpetionManagementComponent,
    SearchExceptionComponent,
    TaskStatusComponent,
    ExceptionTrendComponent,
    TaskAllocationComponent,
    ViewFileComponent,
    UpliftErroneousComponent,
    SaleErroneousComponent,
    SaleTransferredComponent,
  ]
})
export class InputOutputModule { }
