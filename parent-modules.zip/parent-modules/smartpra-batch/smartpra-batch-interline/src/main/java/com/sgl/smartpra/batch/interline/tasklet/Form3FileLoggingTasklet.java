package com.sgl.smartpra.batch.interline.tasklet;

import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.sgl.smartpra.batch.global.model.FileLogging;
import com.sgl.smartpra.batch.interline.common.InterlineBatchConstants;
import com.sgl.smartpra.batch.interline.service.BatchJobService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class Form3FileLoggingTasklet implements Tasklet {

	@Autowired
	BatchJobService batchJobService;

	@Value("${batch.form3.path}")
	private String form3Path;

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

		String fileName = chunkContext.getStepContext().getStepExecution().getJobParameters().getString(InterlineBatchConstants.FILE_NAME);
		String jobName  = chunkContext.getStepContext().getStepExecution().getJobParameters().getString(InterlineBatchConstants.JOB_NAME);

		Path path = Paths.get(form3Path + fileName);
		FileLogging file = new FileLogging();
		file.setFileName(fileName);
		file.setJobName(jobName);
		file.setFileSize(batchJobService.getFileSize(path.toString()));
		if (batchJobService.checkFileLoggingError(path, file)) {
			batchJobService.logError(file);
			chunkContext.getStepContext().getStepExecution().setTerminateOnly();
			return RepeatStatus.FINISHED;
		} else {
			log.info("File Initialized for : " + path);
			chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put(InterlineBatchConstants.FILE_NAME, file.getFileName());
			chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put(InterlineBatchConstants.JOB_NAME, file.getJobName());
			chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put(InterlineBatchConstants.FILE_ID, batchJobService.initFileLogging(file).getFileId());
			return RepeatStatus.FINISHED;
		}
	}
}
