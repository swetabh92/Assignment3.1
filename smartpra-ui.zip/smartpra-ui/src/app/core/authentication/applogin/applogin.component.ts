import {AfterViewInit, Component, OnInit} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';

import { GeneralService } from '../../../commons/services/general.service';
import { AuthenticationService } from '../auth-gaurd-service/_services/authentication.service';
import swal from 'sweetalert2';
import { Cookie } from 'ng2-cookies';
import { tokenKey } from '@angular/core/src/view';
import {StorageConstants} from "../../../commons/constants/storage-constants";
declare var $;
declare var jQuery: any;
declare var iCheck;

@Component({
  selector: 'app-applogin',
  templateUrl: './applogin.component.html',
  styleUrls: ['./applogin.component.css']
})
export class ApploginComponent implements OnInit,AfterViewInit{
  loginForm: FormGroup;
  submitted = false;
  rememberme = true;
  returnUrl: string;
  error = '';
  remember_email = localStorage.getItem('remember_email');
  passwordViewType = "password";
  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private authenticationService: AuthenticationService,
    private Gservice: GeneralService
  ) { }

  ngAfterViewInit() {
    this.Gservice.LoadFormSettingJs();
  }
  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
      rememberme: [''] // , Validators.required],
    });

    // reset login status
    // const token = JSON.parse(localStorage.getItem('token'));
    // console.log(token);
    // console.log(Cookie.getAll());
    // Cookie.deleteAll();
    // Cookie.deleteAll();
    localStorage.removeItem('loggedin_email');
    if (Cookie.get('access_token')) {
      // this.logout();
      Cookie.deleteAll();
    }
    // get return url from route parameters or default to '/'
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
    this.Gservice.LoadFormSettingJs();

  }
  checkValue(event: any) {
    //  console.log(event);
    if (event.target.checked) {
      this.loginForm.value.rememberme = 'on';
    } else {
      this.loginForm.value.rememberme = 'off';
    }
  }
  remembermechange() {
    this.rememberme = !this.rememberme;
    this.loginForm.value.rememberme = this.rememberme;
    // console.log(this.loginForm.value.rememberme);
  }
  get f() { return this.loginForm.controls; }

  // onSubmit() {
  //   localStorage.setItem('loggedin_email', this.f.username.value);
  //   this.router.navigate(['/user/profile']);
  // }

  onSubmit() {
    // console.log(this.loginForm.value); // return;
    // alert();
    this.submitted = true;
    // stop here if form is invalid
    if (this.loginForm.invalid) {
      return;
    }
    this.authenticationService.login(this.f.username.value, this.f.password.value, this.f.rememberme.value)
      .pipe(first())
      .subscribe(
        (data : any)=> {
          let accessObj =  this.parseJwt(data.access_token);
          localStorage.setItem('loggedin_email', this.f.username.value);
          localStorage.setItem(StorageConstants.USER_NAME_EMAIL, this.f.username.value);
          if (this.f.rememberme.value) {
            localStorage.setItem('remember_email', this.f.username.value);
          } else {
            localStorage.setItem('remember_email', '');
          }setTimeout(() => {
            this.router.navigate(['dashboard/salesDashboard']);
          }, 100);
        },
        error => {
          const err = error.error.message || error.error.error_description || error.error.error || 'Could not connect server';
          swal(
            'error',
            err,
            'error'
          );
        });
  }
  
  parseJwt (token) {
    let base64Url = token.split('.')[1];
    let base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    let jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
      return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));

    return JSON.parse(jsonPayload);
  };

  onClickShowHidePwd() {
    this.passwordViewType = this.passwordViewType == "password" ? "text" : "password";
  }
}
