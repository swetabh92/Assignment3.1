import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {path:'formelements',loadChildren:'./formelements/formelements.module#FormelementsModule'},
  {path:'mail',loadChildren:'./mail/mail.module#MailModule'},
  {path:'profile',loadChildren:'./profile/profile.module#ProfileModule'},

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PagesRoutingModule { } 
