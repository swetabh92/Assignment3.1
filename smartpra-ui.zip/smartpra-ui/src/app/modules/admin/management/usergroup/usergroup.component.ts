import { Component, OnInit, Input, Output, EventEmitter, OnDestroy, ElementRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { GeneralService } from '../../../../commons/services/general.service';
import { UsergroupService } from '../../services/usergroup.service';
import { Usergroup } from '../../models/usergroup';
import { Subject } from 'rxjs';
import swal from 'sweetalert2';


@Component({
  selector: 'app-usergroup',
  templateUrl: './usergroup.component.html',
  styleUrls: ['./usergroup.component.css']
})
export class UsergroupComponent implements OnInit, OnDestroy {
  @ViewChild('closeModalAdd') closeModalAdd: ElementRef;
  @ViewChild('closeModalEdit') closeModalEdit: ElementRef;
  dtOptions: any = {};
  // We use this trigger because fetching the list of persons can be quite long,
  // thus we ensure the data is fetched before rendering
  dtTrigger: Subject<any> = new Subject<any>();
  public renderDT = false;
  createdBy = 'admin';
  lastUpdatedBy = 'admin';
  collapse_search_form = true;
  box_search_status = true;
  addNewForm: FormGroup;
  addNewsubmitted = false;
  editNewForm: FormGroup;
  editsubmitted = false;
  searchForm: FormGroup;
  searchsubmitted = false;
  searchresult = false;
  searchstring = '';
  checkdata: any;
  usergroupsList$: any;
  usergroupdetail: any;
  previewUrl = '';
  constructor(private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder,
    private generalService: GeneralService,
    private usergroupservice: UsergroupService,
  ) { }

  ngOnInit() {
    this.dtOptions = {
      searching: false, // to hide the search field in the data table top
      pagingType: 'full_numbers',
      lengthMenu: [[5, 10, 25, 50, -1], [5, 10, 25, 50, 'All']], // used to display records size( no of rows)
      language: {
        lengthMenu: 'Page size _MENU_',
        paginate: {
          next: '<i style="color:#0079c1" class="fa fa-angle-right fa-lg"></i>',
          previous: '<i style="color:#0079c1" class="fa fa-angle-left fa-lg"></i>',
          first: '<i style="color:#0079c1" class="fa fa-step-backward"></i>',
          last: '<i style="color:#0079c1" class="fa fa-step-forward"></i>'
        }
      },
      dom: 'tflrp<"datatableclass"i>',
      // used for fixed columns
      // scrollX: true,
      // scrollY: 'auto',
      // scrollCollapse: true,
      // fixedColumns:   {
      //   leftColumns: 2,
      //   rightColumns: 2
      // },
      // end of fixed columns
      // disable search and order
      // aoColumnDefs: [{ bSortable: false, aTargets: [0, 4, 5] }],
      columnDefs: [
        {
          'searchable': false,
          'orderable': false,
          'targets': [-1, -2]
        }
      ],
      // end of disable search and order
    };
    this.GetAllusergroups();
    this.addNewForm = this.formBuilder.group({
      createdBy: [''], // , Validators.required],
      masGroupId: [''], // , Validators.required],
      masUserGroupId: [''], // , Validators.required],
      masUsersId: [''], // , Validators.required],
    });
    this.editNewForm = this.formBuilder.group({
      lastUpdatedBy: [''],
      masGroupId: [''], // , Validators.required],
      masUserGroupId: [''], // , Validators.required],
      masUsersId: [''], // , Validators.required],
    });
    this.searchForm = this.formBuilder.group({
      active: ['', ],
    });
  }
  showSearchBox(e) {
    this.box_search_status = !this.box_search_status;
    this.collapse_search_form = true;
  }
  collapseSearchform(event) {
    const targetclass = event.target.className;
    // console.log(targetclass);
    // this.collapse_search_form = !this.collapse_search_form;
    if (targetclass === 'btn btn-box-tool fa fa-angle-up') {
      this.collapse_search_form = !this.collapse_search_form;
      event.target.className = 'btn btn-box-tool fa fa-angle-down';
    } else if (targetclass === 'btn btn-box-tool fa fa-angle-down') {
      this.collapse_search_form = !this.collapse_search_form;
      event.target.className = 'btn btn-box-tool fa fa-angle-up';
    }
  }
  onResetSearch() {
    this.searchForm.reset();
    this.renderDT = false;
    this.GetAllusergroups();
  }
  onSearch() {

  }
  GetAllusergroups() {
    this.usergroupservice.getUsergroupAll().subscribe((res: any[]) => {
      this.usergroupsList$ = res;
      setTimeout(() => {
        this.renderDT = true;
      }, 100);
    });
  }
  get f() { return this.addNewForm.controls; }

  onResetAdd() {
    this.addNewForm.reset();
  }
  addNewusergroup(): void {
    this.addNewsubmitted = true;
    // stop here if form is invalid
    if (this.addNewForm.invalid) {
      return;
    } else {
      this.usergroupservice.addUsergroup(this.addNewForm.value).subscribe(
        usergroupservice => {
          // console.log(usergroupservice);
          if (!!usergroupservice && usergroupservice.masUserGroupId) {
            this.usergroupsList$.push(usergroupservice);
            this.closeModalAdd.nativeElement.click();
            swal(
              'Success',
              'New Records Addeded',
              'success'
            );
            this.onResetAdd();
          }
        });
    }
  }
  get u() { return this.editNewForm.controls; }
  showEditvalues(getId) {
    this.usergroupservice.UsergroupByUsergroupId(getId).subscribe(
      usergroupservice => {
        if (!!usergroupservice && usergroupservice.masUserGroupId) {
          this.usergroupdetail = usergroupservice;
        } else {
          swal(
            'Error',
            'Error fetching record',
            'error'
          );
        }
      });
  }
  onResetEdit() {
  }
  editNewusergroup() {
    this.editsubmitted = true;
    // console.log(this.editNewForm);
    // stop here if form is invalid
    if (this.editNewForm.invalid) {
      swal(
        'Error',
        'sorry error in the form',
        'error'
      );
      return;
    } else {
      // console.log(this.editNewForm.value); return;
      this.usergroupservice.updateUsergroup(this.editNewForm.value).subscribe(
        usergroupservice => {
          if (!!usergroupservice && usergroupservice.masUserGroupId) {
            const ix = usergroupservice ? this.usergroupsList$.findIndex(h => h.masUserGroupId === usergroupservice.masUserGroupId) : -1;
            if (ix > -1) { this.usergroupsList$[ix] = usergroupservice; }
            this.closeModalEdit.nativeElement.click();
            swal(
              'Updated!',
              'Usergroup has been Updated.',
              'success'
            );
          }
        });
    }
  }
  removeafterDeactivate(user: Usergroup): void {
    this.usergroupsList$ = this.usergroupsList$.filter(h => h !== user);
  }
  changeStatususergroup(usergroup, e, Id) {
    if (e.target.checked) {
      swal({
        type: 'warning',
        title: 'Are you sure to activate this usergroup?',
        text: 'You will not be able to recover the data of usergroupsprofile',
        showCancelButton: true,
        confirmButtonColor: '#049F0C',
        cancelButtonColor: '#ff0000',
        confirmButtonText: 'Yes, activate it!',
        cancelButtonText: 'No, keep it deactivated',
        closeOnClickOutside: false,
        closeOnEsc: false,
        allowOutsideClick: false,
      } as any).then((result) => {
        if (result.value) {
          this.usergroupservice.activateUsergroup(Id).subscribe(
            data => {
              console.log('data->' + data);
            }, error => {
              console.log('error->' + error);
            });
          swal(
            'Activated!',
            'usergroupsprofile has been activated.',
            'success'
          );
        } else if (
          // Read more about handling dismissals
          result.dismiss === swal.DismissReason.cancel
        ) {
          e.target.checked = false;
          swal(
            'Cancelled',
            'usergroupsprofile is status unchanged',
            'error'
          );
        }
      });
    } else {
      swal({
        type: 'warning',
        title: 'Are you sure to deactivate this usergroup?',
        text: 'You will not be able to recover the data of usergroupsprofile',
        showCancelButton: true,
        confirmButtonColor: '#049F0C',
        cancelButtonColor: '#ff0000',
        confirmButtonText: 'Yes, deactivate it!',
        cancelButtonText: 'No, keep it as active',
        closeOnClickOutside: false,
        closeOnEsc: false,
        allowOutsideClick: false,
      } as any).then((result) => {
        if (result.value) {
          this.usergroupservice.deactivateUsergroup(Id).subscribe(
            data => {
              console.log('data->' + data);
            }, error => {
              console.log('error->' + error);
            });
          swal(
            'Deactivated!',
            'usergroupsprofile has been deactivated.',
            'success'
          );
          this.removeafterDeactivate(usergroup);
        } else if (
          // Read more about handling dismissals
          result.dismiss === swal.DismissReason.cancel
        ) {
          e.target.checked = true;
          swal(
            'Cancelled',
            'usergroupsprofile is status unchanged',
            'error'
          );
        }
      });
    }
  }

  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }

}
