/**
 * 
 */
package com.sgl.smartpra.batch.mib.app.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.batch.mib.app.mapper.LineItemDetailMapper;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingConstants;
import com.sgl.smartpra.mib.entity.MiscBillingAddOnChargeDtlEntity;
import com.sgl.smartpra.mib.entity.MiscBillingInvLineitemDtlEntity;
import com.sgl.smartpra.mib.entity.MiscBillingSupportingDetailEntity;
import com.sgl.smartpra.mib.entity.MiscBillingTaxDetailsEntity;
import com.sgl.smartpra.mib.jaxb.dictionary.MinimumQuantityFlag;
import com.sgl.smartpra.mib.jaxb.standard.ChargeAmount;
import com.sgl.smartpra.mib.jaxb.standard.LineItemDetail;
import com.sgl.smartpra.mib.jaxb.standard.Quantity;
import com.sgl.smartpra.mib.jaxb.standard.UnitPrice;

import lombok.extern.slf4j.Slf4j;

/**
 * @author kanprasa
 *
 */
@Service
@Slf4j
public class LineItemDetailService {
	
	@Autowired
	private LineItemDetailMapper lineItemDtlMapper;

	@Autowired
	private TaxDetailsService taxDetailsService;
	
	@Autowired
	private AddOnChargeDtlService addOnChargeDtlService;
	
	@Autowired
	private SupportingDetailService suppDtlService;

/*
	public Optional<Date> getMinStartDate(List<MiscBillingInvLineitemDtlEntity> lineItemDts){
		return lineItemDts.stream().map(v -> v.getStartDate()).min((b1,b2 ) -> b1.compareTo(b2));
	}
	
	public Optional<Date> getMaxEndDate(List<MiscBillingInvLineitemDtlEntity> lineItemDts){
		return lineItemDts.stream().map(v -> v.getEndDate()).max((b1,b2 ) -> b1.compareTo(b2));
	}
	
	public boolean isUOMcodeDifferent(List<MiscBillingInvLineitemDtlEntity> lineItemDts){
		return lineItemDts.stream().map(v -> v.getUomCode()).distinct().count() > 1;
	}
*/	
	public List<LineItemDetail> getLineItemDetails(BigInteger lineItemNumber, List<MiscBillingInvLineitemDtlEntity> lineItemDetails){
		List<LineItemDetail> lineItemDtlList = new ArrayList<>();
		for (MiscBillingInvLineitemDtlEntity lineItemDtlEntity : lineItemDetails) {
			LineItemDetail lineItemDtl = new LineItemDetail();
			lineItemDtl.setLineItemNumber(lineItemNumber);
			Quantity quantity = new Quantity(); lineItemDtl.setQuantity(quantity);
			UnitPrice unitPrice = new UnitPrice(); lineItemDtl.setUnitPrice(unitPrice);
			lineItemDtlMapper.mapEntityToLineItemDetail(lineItemDtlEntity, lineItemDtl);
			if(StringUtils.isNotBlank(lineItemDtlEntity.getMinQtyFlag()) && MiscBillingConstants.YES.equals(lineItemDtlEntity.getMinQtyFlag())){
				lineItemDtl.setMinimumQuantityFlag(MinimumQuantityFlag.fromValue(lineItemDtlEntity.getMinQtyFlag()));
			}
			ChargeAmount chargeAmount = new ChargeAmount();
			chargeAmount.setValue(lineItemDtlEntity.getChargeAmt());
			lineItemDtl.getChargeAmount().add(chargeAmount);
			lineItemDtlList.add(lineItemDtl);
			for (MiscBillingSupportingDetailEntity suppDtlEntity : lineItemDtlEntity.getMiscBillingSupportingDetail()) {
				suppDtlService.populateSectionDetails(lineItemDtl, suppDtlEntity);
			}
			if(lineItemDtlEntity.getMiscBillingTaxDetails() != null && lineItemDtlEntity.getMiscBillingTaxDetails().size() > 0) {
				List<MiscBillingTaxDetailsEntity> taxEntityList = lineItemDtlEntity.getMiscBillingTaxDetails().stream()
						.filter(x -> MiscBillingConstants.DETAIL.equalsIgnoreCase(x.getTaxLevel())).collect(Collectors.toList());
				lineItemDtl.getTax().addAll(taxDetailsService.getTaxDetails(taxEntityList));
			}
			if(lineItemDtlEntity.getMiscBillingAddOnChargeDtl() != null && lineItemDtlEntity.getMiscBillingAddOnChargeDtl().size() > 0) {
				List<MiscBillingAddOnChargeDtlEntity> aocEntityList = lineItemDtlEntity.getMiscBillingAddOnChargeDtl().stream()
						.filter(x -> MiscBillingConstants.DETAIL.equalsIgnoreCase(x.getAddOnLevel())).collect(Collectors.toList());
				lineItemDtl.getAddOnCharges().addAll(addOnChargeDtlService.getAddOnChargeDetails(aocEntityList));
			}
		}
		return lineItemDtlList;
	}
}
