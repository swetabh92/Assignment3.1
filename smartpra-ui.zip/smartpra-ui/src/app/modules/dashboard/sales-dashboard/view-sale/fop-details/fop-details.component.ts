import { Component, OnInit,Input } from '@angular/core';
import {PaginationService} from '../../../../../commons/services/pagination/pagination.service';
import {SalesdashboardserviceService} from '../../salesdashboardservice.service';
import { DateFormatService } from '../../../../../commons/services/date-format/date-format.service';
import {FormOfPaymentType} from '../../sale-dashboard.model';

@Component({
  selector: 'app-fop-details',
  templateUrl: './fop-details.component.html',
  styleUrls: ['./fop-details.component.css']
})
export class FopDetailsComponent implements OnInit {
  page: any = this.paginateService.setCustomPaginationConfig({'pageSize': 5});
  formOfPaymentType = FormOfPaymentType;
  constructor(private dateFormatService:DateFormatService,private salesService:SalesdashboardserviceService,private paginateService: PaginationService) { }
  fopData:any = [];
  @Input('value')
  set value(val:any){
      if(val) {
          this.getFopDetails(val.uniqueDocumentId) 
      }
  }
  ngOnInit() {
  }

  getFopDetails(saleUniqueDocumentId): void {
     this.salesService.getFopData(saleUniqueDocumentId).subscribe((data) => {
      this.fopData = data;
      console.log(this.fopData);
      let fopObj = {'formOfPayment': 'TT'};
      this.fopData.forEach(function (item) {
        if (item['formOfPayment'] && item['formOfPayment'].startsWith('CC')) {
          item['fopAmount'] = '';
        }
        if(item['fopCurrency'] !==null) fopObj['fopCurrency'] = item['fopCurrency'];
      });
      let componentTotal = fopComponent => fopComponent.reduce((input1, input2) => input1 + input2);
      let totalAmount = componentTotal(this.fopData.map(input1 => Number(input1.fopAmount)));
      fopObj['fopAmount'] = totalAmount.toFixed(2);
      fopObj['ccAmount'] = totalAmount.toFixed(2);
      this.fopData.push(fopObj);
    });
  
  }
}
