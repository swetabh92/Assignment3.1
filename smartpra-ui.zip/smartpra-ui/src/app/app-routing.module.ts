import { NgModule } from '@angular/core';
import { ChartsModule } from 'ng2-charts'; 
import { Routes, RouterModule, PreloadAllModules } from '@angular/router'; 
import { AuthGuard } from './core/authentication/auth-gaurd-service/_guards';
import { ApploginComponent } from './core/authentication/applogin/applogin.component';
 
const routes: Routes = [ 
    { path: '', redirectTo: '/login', pathMatch: 'full' },

    // Authentication Module start//
    { path: 'auth', loadChildren:'./core/authentication/authentication.module#AuthenticationModule'},
    //Authentication Module End// 

    //Sales Module lazy loading start //
    { path: 'master/sale', loadChildren:'./modules/masters/components/sale/sale.module#SaleModule', canActivate:[AuthGuard]},
    //Sales Module lazy loading End //

    // Flown Module Lazy Loading start
    { path: 'master/flown', loadChildren:'./modules/masters/components/flown/flown.module#FlownModule', canActivate:[AuthGuard]},
    // Flown Module Lazy Loading End

    //Interline Lazy loading start//
    { path: 'master/interline', loadChildren:'./modules/masters/components/interline/interline.module#InterlineModule', canActivate:[AuthGuard]},
    //Interline Lazy loading End//
     
    //Proration Lazy Loading start//
    { path: 'master/prorate', loadChildren:'./modules/masters/components/proration/proration.module#ProrationModule',canActivate:[AuthGuard]},
    //prorartion lazy loading End//
    { path: 'allocationMaster', loadChildren:'./modules/masters/components/allocation-master/allocation-master.module#AllocationMasterModule', canActivate:[AuthGuard]},

    { path: 'master/others', loadChildren:'./modules/masters/components/others/others.module#OthersModule', canActivate:[AuthGuard]},

    {path:'admin', loadChildren:'./modules/admin/admin.module#AdminModule', canActivate:[AuthGuard]},
 
    {path:'user', loadChildren:'./core/pages/pages.module#PagesModule', canActivate:[AuthGuard]}, 
    

    { path: 'readmail', loadChildren:'./core/pages/readmail/readmail.module#ReadmailModule', canActivate:[AuthGuard]}, 

    {path:'dashboard', loadChildren:'./modules/dashboard/dashboard.module#DashboardModule', canActivate:[AuthGuard]},

    {path:'miscellaneous', loadChildren:'./modules/miscellaneous/miscellaneous.module#MiscellaneousModule', canActivate:[AuthGuard]},

    {path:'reports', loadChildren:'./modules/reports/reports.module#ReportsModule', canActivate:[AuthGuard]},

    {path:'ticketquery', loadChildren:'./modules/miscellaneous/components/ticketquery/ticketquery.module#TicketqueryModule', canActivate:[AuthGuard]},

    { path: 'login', component: ApploginComponent }, 

     {path:'ngxGroupHeaderTable', loadChildren:'./modules/rnd/rnd.module#RNDModule', canActivate:[AuthGuard]},

    { path: 'misc-billing', loadChildren:'./modules/misc-billing/components/misc-billing.module#MiscBillingModule', canActivate:[AuthGuard]},


    // otherwise redirect to home
    // { path: '**', redirectTo: '' }
    // note this lines should be last
    // { 
    //     path: 'password-rest-final/:key',
    //     component: AppresetpasswordfinalComponent,
    //     children: [{  path: '*', component: AppresetpasswordfinalComponent }]
    // },
    // {
    //     path: 'first-time-password/:key',
    //     component: AppfirsttimepasswordComponent,
    //     children: [{  path: '*', component: AppfirsttimepasswordComponent }]
    // }
    
]

@NgModule({
    imports: [RouterModule.forRoot(routes, { onSameUrlNavigation: 'reload', useHash: true})],
    exports: [RouterModule]
})
export class AppRoutingModule { }
