import { TestBed } from '@angular/core/testing';

import { Password.ValidatorService } from './password.validator.service';

describe('Password.ValidatorService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: Password.ValidatorService = TestBed.get(Password.ValidatorService);
    expect(service).toBeTruthy();
  });
});
