import { Component, ViewChild, ElementRef, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { StandaloneProrationService } from './standalone-proration.service';
import { StandaloneProration } from './standalone-proration';
import { CommonService } from 'src/app/modules/masters/services/commons/common.service';
import { PaginationService } from 'src/app/commons/services/pagination/pagination.service';
import { Size } from 'angular2-draggable/lib/models/size';

@Component({
  selector: 'app-standalone-proration',
  templateUrl: './standalone-proration.component.html',
  styleUrls: ['./standalone-proration.component.css']
})
export class StandaloneProrationComponent implements OnInit {
  @ViewChild('closeModalSearch') closeModalSearch: ElementRef;
  searchForm: FormGroup;
  viewForm: FormGroup;
  prorateResultForm: FormGroup;
  paremetersForm:FormGroup;
  editView: boolean;
  showFca:boolean;
  showProrateOutput:boolean;
  searchView: boolean = true;
  prorateResultList: any;
  couponList : any[] = [];
  searchsubmitted = false;
  showProrateResult = false;
  showTraceOutput = false;
  toMinDate: any;
  fromMaxDate: any;
  fca:String;
  request:any;
  page: any = this.paginateService.getPageinateConfig();
  responseResult: any[] = [];
  showProrateFlag: boolean;
  parametersView: boolean;
  group1 =[{"name":"in ATBP Currency %","key":"atbpCurrency"},{"name":"Type","key":"type"},{"name":"Rec #","key":"rec"},{"name":"Curr Value","key":"currValue"}];
  group2 =[{"name":"in ATBP Currency %","key":"atbpCurrency"},{"name":"Rec #","key":"rec"}];
  group3 =[{"name":"in ATBP Currency %","key":"atbpCurrency"},{"name":"Curr Value","key":"currValue"}];
  showTicketMiscCharges:boolean;
  showRemarksTicketLabel:boolean;
  showFareBasisOutput: boolean;
  showSpaProvisoOutput: boolean;
  showTypeId:boolean;
  showSurcharge:boolean;
  showClassDiff:boolean;
  showStopover:boolean;
  showPlusUp:boolean;
  constructor(private formBuilder: FormBuilder,private commonService:CommonService,private paginateService: PaginationService,private standaloneProrationService: StandaloneProrationService,) { }

  ngOnInit() {
    this.viewForm =this.formBuilder.group({
        issueAirline:[''],
        mainDocument:[''],
        docType:[''],
        documentNumber:[''],
        agentCode:[''],
        dateOfIssue:[''],
        placeOfIssue:[''],
        placeOfSale:[''],
        emdIndicator:[''],
        btItIndicator:[''],
        rfisc:[''],
        paxType:[''],
        uatpFlag:[''],
        involFlag:[''],
        ffyIndicator:[''],
        originalDocumentNumber:[''],
        originalDateOfIssue:[''],
        originalPlaceOfIssue:[''],
        currencyOfSale:[''],
        grossFare:[''],
        equivalentCurrencyOfSale:[''],
        equivalentFare:[''],
        commisionAmount:[''],
        discountAmount:[''],
        tourCode:[''],
        netFareAmount:[''],
        passengerName:[''],
        endorsements:[''],
        fareCompCurrency:[''],
        fca:[''],
        pot:[''],
        drIndicator:[''],
        stopoverInd:[''],
        couponNumber:[''],
        fromAirport:[''],
        toAirport:[''],
        marketingCarrierAlphaCode:[''],
        ticketedRbd:[''],
        fareBasis:[''],
        marketingFlightNumber:[''],
        marketingFlightDate:[''],
        departureTime:[''],
        arrivalTime:[''],
        arrivalDate:[''],
        fareComponentValue:[''],
    })

    this.prorateResultForm = this.formBuilder.group({
      dateOfIssue:[''],
      mprPercentage:[''],
      roeRate: [''],
      prorationMethod:[''],
      prorationSource:[''],
      equivalentFareCurrency:[''],
      atbpCurrency:[''],
      onlineInterlineOffline:[''],
      fareCompCurrency:[''],
      involIndicator:['']
    })

    this.paremetersForm = this.formBuilder.group({
      utilization:[''],
      prorateCurrency:[''],
      utilizeCoupon:[''],
      upliftDate:[''],
      billingMonth:[''],
      billingCxr:[''],
      rates:[''],
      prorateSlip:[''],
      trackTrace:[''],
      sector:[''],
      cxr:[''],
      serial:[''],
      recSerial:[''],
    })

    this.searchForm = this.formBuilder.group({
      orderId: [''],
      pnr: [''],
      documentNumber: [''],
      ticketLabel: [''],
    });

    this.viewForm.controls['dateOfIssue'].valueChanges.subscribe((minDate) => {
      this.toMinDate = minDate;
       });
    this.viewForm.controls['originalDateOfIssue'].valueChanges.subscribe((maxDate) => {
      this.fromMaxDate = maxDate;
       });
  }

  onSearch() {
    this.searchsubmitted = true;
    this.couponList = [];
    if (this.searchForm.invalid) return false;
    this.standaloneProrationService.searchStandaloneProration(this.searchForm.value).subscribe((res) => {
      this.showFca = true;
      this.editView = true;
      this.searchView = false
      res[0].dateOfIssue = new Date(this.commonService.covertDate(res[0].dateOfIssue));
			res[0].originalDateOfIssue = new Date(this.commonService.covertDate(res[0].originalDateOfIssue));
      this.viewForm.patchValue(res[0]);
      for(let i= 0; i <res.length; i++){
        for(let j=0; j<res[i].ticketCoupons.length; j++){
          this.couponList.push(res[i].ticketCoupons[j]);
        }
      }
      this.fca = res[0].fca.trim();
      this.responseResult = res;
      this.searchForm.reset();
     });
  }

  showParameters(){
    this.parametersView = true;
    this.editView = false;
    this.searchView = false;
    this.showProrateFlag = false;
    this.showTraceOutput = false;
  }

  showProrateresult(){
    if(this.responseResult[0].status = "CC" ){
     this.showProrateFlag = true;
     this.showProrateOutput = true; 
     this.showFareBasisOutput = false; 
     this.showSpaProvisoOutput = false;
     this.showProrateOutput = true;
     this.editView = false;
     this.parametersView = false
     this.showTraceOutput = false
     this.prorateResultForm.patchValue(this.responseResult[0]);
     this.prorateResultList = this.couponList;
    }
  }

  

  onProrate(){
    let request = this.viewForm.value;
    request.ticketCoupons = this.couponList;
    this.standaloneProrationService.prorateStandaloneProration(request).subscribe((res)=>{
      this.prorateResultList = res;
    })
  }

  resetForm(type){
    if(type == 'search'){
     this.searchsubmitted=false;
     this.searchForm.reset();
   }
 }

}
