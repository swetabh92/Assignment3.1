import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { StandaloneProrationComponent } from './standalone-proration/standalone-proration.component';

const routes: Routes = [
  {path:'', component:StandaloneProrationComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class StandaloneProrationRoutingModule { }
