package com.sgl.smartpra.batch.amadeus.app.writer;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.amadeus.app.common.DocumentIdsWriter;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusBatchRecord;
import com.sgl.smartpra.batch.amadeus.app.domain.ProdTicketModel;
import com.sgl.smartpra.common.util.SmartPRACommonUtil;
import com.sgl.smartpra.sales.domain.TicketMain;
import com.sgl.smartpra.sales.repository.TicketMainRepository;

@Component
@Scope(value = "step")
public class StgTicketDataWriter {
	private static final Logger LOGGER = LoggerFactory.getLogger(StgTicketDataWriter.class);

	@Autowired
	private TicketMainRepository ticketMainRepository;

	public void write(List<TicketMain> ticketMainList) throws Exception {
		LOGGER.info("ProdTicketDataWriter.write -- Start");
		Boolean recSaveFlag = false;
		DocumentIdsWriter savedDocUniqueIds = DocumentIdsWriter.getInstance();
		for(TicketMain ticketMain :ticketMainList) {
			if(SmartPRACommonUtil.isNullOrTrimEmpty(savedDocUniqueIds.findDocUniqueId(ticketMain.getDocumentUniqueId()))) {
				savedDocUniqueIds.addDocUniqueId(ticketMain.getDocumentUniqueId());
				ticketMainRepository.save(ticketMain);
				recSaveFlag = true;
				LOGGER.info("Document unique id (Saved) : " + ticketMain.getDocumentUniqueId());
			}
		}
		LOGGER.info("recSaveFlag : " + recSaveFlag);
		//if(recSaveFlag) ticketMainRepository.flush();
		LOGGER.info("ProdTicketDataWriter.write -- End");
	}
}
