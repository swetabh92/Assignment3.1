import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NgxHeaderWordbreakComponent } from './ngx-header-wordbreak.component';

describe('NgxHeaderWordbreakComponent', () => {
  let component: NgxHeaderWordbreakComponent;
  let fixture: ComponentFixture<NgxHeaderWordbreakComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NgxHeaderWordbreakComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NgxHeaderWordbreakComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
