import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FlightControlMasterComponent } from './flight-control-master.component';

describe('FlightControlMasterComponent', () => {
  let component: FlightControlMasterComponent;
  let fixture: ComponentFixture<FlightControlMasterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FlightControlMasterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FlightControlMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
