import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewAirportMasterComponent } from './new-airport-master.component';

describe('NewAirportMasterComponent', () => {
  let component: NewAirportMasterComponent;
  let fixture: ComponentFixture<NewAirportMasterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewAirportMasterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewAirportMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
