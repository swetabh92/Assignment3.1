import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {path:'manage-group',loadChildren:'./management/group/group.module#GroupModule'},
  {path:'manage-module',loadChildren:'./management/modules/modules.module#ModulesModule'},
  {path:'manage-proces',loadChildren:'./management/process/process.module#ProcessModule'},
  {path:'role-profile',loadChildren:'./management/roleprofile/roleprofile.module#RoleprofileModule'},
  {path:'manage-team',loadChildren:'./management/team/team.module#TeamModule'},
  {path:'manage-user-group',loadChildren:'./management/usergroup/usergroup.module#UsergroupModule'},
  {path:'manage-user-module',loadChildren:'./management/usermodule/usermodule.module#UsermoduleModule'},
  {path:'user-profile',loadChildren:'./management/userprofile/userprofile.module#UserprofileModule'},
  {path:'manage-user-role',loadChildren:'./management/userrole/userrole.module#UserroleModule'},
  {path:'manage-user-team',loadChildren:'./management/userteam/userteam.module#UserteamModule'},
  {path:'system-parameters',loadChildren:'./systemparameters/systemparameters.module#SystemparametersModule'},

 
];
  
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule] 
})
export class AdminRoutingModule { }
