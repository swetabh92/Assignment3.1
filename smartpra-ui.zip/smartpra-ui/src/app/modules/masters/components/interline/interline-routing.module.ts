import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  { path: 'provisoMaster', loadChildren:'./proviso-master/proviso-master.module#ProvisoMasterModule'},
  { path: 'sourceCodeMaster', loadChildren:'./source-code-master/source-code-master.module#SourceCodeMasterModule'},
  { path: 'reasonCodeMaster', loadChildren:'./reason-code-master/reason-code-master.module#ReasonCodeMasterModule'}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class InterlineRoutingModule { }
