import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SectorMismatchComponent } from './sector-mismatch.component';

describe('SectorMismatchComponent', () => {
  let component: SectorMismatchComponent;
  let fixture: ComponentFixture<SectorMismatchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SectorMismatchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SectorMismatchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
