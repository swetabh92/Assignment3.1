package com.sgl.smartpra.batch.interline.configuration;

import javax.sql.DataSource;
import javax.validation.ConstraintViolationException;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemStreamException;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;

import com.sgl.smartpra.batch.interline.common.InterlineBatchConstants;
import com.sgl.smartpra.batch.interline.listener.InterlineForm3CsvStgItemReaderListener;
import com.sgl.smartpra.batch.interline.listener.InterlineForm3CsvStgItemWriterListener;
import com.sgl.smartpra.batch.interline.listener.InterlineForm3CsvStgJobListener;
import com.sgl.smartpra.batch.interline.listener.InterlineForm3CsvStgStepListener;
import com.sgl.smartpra.batch.interline.processor.InterlineForm3CsvStgProcessor;
import com.sgl.smartpra.batch.interline.service.BatchJobService;
import com.sgl.smartpra.batch.interline.tasklet.Form3FileLoggingTasklet;
import com.sgl.smartpra.batch.interline.writer.InterlineForm3CsvStgWriter;
import com.sgl.smartpra.interline.domain.entity.stg.form3.InterlineForm3CsvStg;

import lombok.extern.slf4j.Slf4j;

@Configuration
@EnableBatchProcessing
@Slf4j
public class StagForm3BatchJobConfiguration {
	@Autowired
	private JobBuilderFactory jobBuilderFactory;

	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	
	@Autowired
	private BatchJobService batchJobService;
	
	@Bean
	@StepScope
	public FlatFileItemReader<InterlineForm3CsvStg> reader(@Value("#{jobParameters[time]}") String time,@Value("#{jobParameters[fileName]}") String fileName,@Value("#{jobParameters[jobName]}") String jobName) throws Exception, ItemStreamException {
		
		log.info("time : " + time +" fileName : "+ fileName+" jobName :"+ jobName);
		
		return new FlatFileItemReaderBuilder<InterlineForm3CsvStg>().name("batchItemReader")
				.resource(batchJobService.findBatchJobResourceForForm3(fileName))
				.lineMapper(new DefaultLineMapper<InterlineForm3CsvStg>() {
					{
						setLineTokenizer(new DelimitedLineTokenizer() {
							{
								setNames(InterlineBatchConstants.FORM3_SQL_MAPPING);
							}
						});
						setFieldSetMapper(new BeanWrapperFieldSetMapper<InterlineForm3CsvStg>() {
							{
								setTargetType(InterlineForm3CsvStg.class);
							}
						});
					}
				}).linesToSkip(1).build();
	}

	@Bean
	public Job loadInterlineForm3CsvStgFileJob(@Qualifier("Form3FileLoggingStep") Step form3FileLoggingStep, 
			@Qualifier("InterlineForm3StgRecord") Step interlineForm3StgRecord, InterlineForm3CsvStgJobListener interlineForm3CsvStgJobListener) {
		 
		return jobBuilderFactory
					.get("loadInterlineForm3CsvStgFileJob")
					.listener(interlineForm3CsvStgJobListener)
					.start(form3FileLoggingStep)
					.next(interlineForm3StgRecord)
					.build();
	}

	@Bean
	protected Step Form3FileLoggingStep(Form3FileLoggingTasklet tasklet) {
		return stepBuilderFactory
				.get("Form3FileLoggingStep")
				.tasklet(tasklet)
				.build();
	}

	@Bean
	protected Step InterlineForm3StgRecord(ItemReader<InterlineForm3CsvStg> reader, ItemProcessor<InterlineForm3CsvStg, InterlineForm3CsvStg> processor,
			ItemWriter<InterlineForm3CsvStg> writer, InterlineForm3CsvStgStepListener interlineForm3CsvStgStepListener,InterlineForm3CsvStgItemWriterListener batchDataItemWriterListener,InterlineForm3CsvStgItemReaderListener interlineForm3CsvStgItemReaderListener) {
		
		return stepBuilderFactory
				.get("InterlineForm3StgRecord").<InterlineForm3CsvStg, InterlineForm3CsvStg>chunk(100)
				.reader(reader)
				.processor(processor)
				.writer(writer)
				.faultTolerant()
				.skip(ConstraintViolationException.class)
				.skipLimit(10)
				.listener(interlineForm3CsvStgStepListener)
				.listener(batchDataItemWriterListener)
				.listener(interlineForm3CsvStgItemReaderListener)
				.taskExecutor(taskExecutor())
				.throttleLimit(InterlineBatchConstants.MAX_THREADS)
				.build();
	}
	
	@Bean
	public TaskExecutor taskExecutor() {
		SimpleAsyncTaskExecutor asyncTaskExecutor = new SimpleAsyncTaskExecutor(InterlineBatchConstants.FILETYPE_FORM3);
		asyncTaskExecutor.setConcurrencyLimit(InterlineBatchConstants.MAX_THREADS);
		return asyncTaskExecutor;
	}

	@Bean
	public Form3FileLoggingTasklet tasklet() {
		return new Form3FileLoggingTasklet();
	}
	
	@Bean
	public BatchJobService batchJobService() {
		return new BatchJobService();
	}
	
	@Bean
	InterlineForm3CsvStgJobListener interlineForm3CsvStgJobListener() {
		return new InterlineForm3CsvStgJobListener();
	}

	@Bean
	public InterlineForm3CsvStgStepListener interlineForm3CsvStgStepListener() {
		return new InterlineForm3CsvStgStepListener();
	}

	@Bean
	public InterlineForm3CsvStgItemWriterListener interlineForm3CsvStgItemWriterListener() {
		return new InterlineForm3CsvStgItemWriterListener();
	}

	@Bean
	public InterlineForm3CsvStgItemReaderListener interlineForm3CsvStgItemReaderListener() {
		return new InterlineForm3CsvStgItemReaderListener();
	}

	@Bean
	public ItemProcessor<InterlineForm3CsvStg, InterlineForm3CsvStg> processor() {
		return new InterlineForm3CsvStgProcessor();
	}

	@Bean
	public ItemWriter<InterlineForm3CsvStg> writer(DataSource dataSource) {
		return new InterlineForm3CsvStgWriter();
	}

}
