import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, map, tap } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { CommonService } from 'src/app/modules/masters/services/commons/common.service';
import { Observable, of } from 'rxjs';
import { MessageBoxService } from 'src/app/modules/masters/services/commons/message-box.service';
import { StandaloneProration } from './standalone-proration';


const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
}

@Injectable({
  providedIn: 'root'
})
export class StandaloneProrationService {
  apiUrlProrationCall = environment.apiUrlProrationCall;
  apiUrlProration = environment.apiUrlProration;
  constructor(private http: HttpClient, private commonService: CommonService,private messageBoxService: MessageBoxService) { }

  searchStandaloneProration(data): Observable<StandaloneProration[]>{
    return this.http.get<StandaloneProration[]>(this.apiUrlProrationCall + 'search-document/' + data.documentNumber).pipe(
      tap(_ => this.log('fetched Standalone Details')),
      catchError(this.handleError('getAllStandalone', []))
    );
  }

  prorateStandaloneProration(request:StandaloneProration):Observable<StandaloneProration[]>{
    return this.http.post<StandaloneProration[]>(this.apiUrlProration + 'industryproration/',request,httpOptions).pipe(
      tap(_ => this.log('fetched Standalone Details')),
      catchError(this.handleError<StandaloneProration[]>('getAllStandalone', []))
    );
  }

  private handleError<T>(operation = 'operation', result?: T) {
    return (e: any): Observable<T> => {
      this.messageBoxService.getErrorMessage('ERROR', e['error']['message']);
      return of(result as T);
    };
  }

  private log(error: any) {
    if (error.message) {
      this.messageBoxService.getErrorMessage('ERROR', error.message);
    }
  }
}
