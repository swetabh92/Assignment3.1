import { Component, OnInit, Input, Output, EventEmitter, OnDestroy, ElementRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { GeneralService } from '../../../../commons/services/general.service';
import { ModulesService } from '../../services/modules.service';
import { Modules } from '../../models/modules';
import { Subject } from 'rxjs';
import swal from 'sweetalert2';

@Component({
  selector: 'app-modules',
  templateUrl: './modules.component.html',
  styleUrls: ['./modules.component.css']
})
export class ModulesComponent implements OnInit, OnDestroy {
  @ViewChild('closeModalAdd') closeModalAdd: ElementRef;
  @ViewChild('closeModalEdit') closeModalEdit: ElementRef;
  dtOptions: any = {};
  // We use this trigger because fetching the list of persons can be quite long,
  // thus we ensure the data is fetched before rendering
  dtTrigger: Subject<any> = new Subject<any>();
  public renderDT = false;
  createdBy = 'admin';
  lastUpdatedBy = 'admin';
  collapse_search_form = true;
  box_search_status = true;
  addNewForm: FormGroup;
  addNewsubmitted = false;
  editNewForm: FormGroup;
  editsubmitted = false;
  searchForm: FormGroup;
  searchsubmitted = false;
  searchresult = false;
  searchstring = '';
  checkdata: any;
  modulessList$: any;
  moduledetail: any;
  previewUrl = '';
  constructor(private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder,
    private generalService: GeneralService,
    private modulesservice: ModulesService,
  ) { }

  ngOnInit() {
    this.dtOptions = {
      searching: false, // to hide the search field in the data table top
      pagingType: 'full_numbers',
      lengthMenu: [[5, 10, 25, 50, -1], [5, 10, 25, 50, 'All']], // used to display records size( no of rows)
      language: {
        lengthMenu: 'Page size _MENU_',
        paginate: {
          next: '<i style="color:#0079c1" class="fa fa-angle-right fa-lg"></i>',
          previous: '<i style="color:#0079c1" class="fa fa-angle-left fa-lg"></i>',
          first: '<i style="color:#0079c1" class="fa fa-step-backward"></i>',
          last: '<i style="color:#0079c1" class="fa fa-step-forward"></i>'
        }
      },
      dom: 'tflrp<"datatableclass"i>',
      // used for fixed columns
      // scrollX: true,
      // scrollY: 'auto',
      // scrollCollapse: true,
      // fixedColumns:   {
      //   leftColumns: 2,
      //   rightColumns: 2
      // },
      // end of fixed columns
      // disable search and order
      // aoColumnDefs: [{ bSortable: false, aTargets: [0, 4, 5] }],
      columnDefs: [
        {
          'searchable': false,
          'orderable': false,
          'targets': [-1, -2]
        }
      ],
      // end of disable search and order
    };
    this.GetAllmoduless();
    this.addNewForm = this.formBuilder.group({
      createdBy: [''], // Validators.required],
      clientId: [''], // Validators.required],
      masModuleId: [''], // Validators.required],
      moduleManagerId: [''], // Validators.required],
      moduleName: [''], // Validators.required],
    });
    this.editNewForm = this.formBuilder.group({
      clientId: [''], // Validators.required],
      masModuleId: [''], // Validators.required],
      moduleManagerId: [''], // Validators.required],
      moduleName: [''], // Validators.required],
    });
    this.searchForm = this.formBuilder.group({
      active: ['', ],
    });
  }
  showSearchBox(e) {
    this.box_search_status = !this.box_search_status;
    this.collapse_search_form = true;
  }
  collapseSearchform(event) {
    const targetclass = event.target.className;
    // console.log(targetclass);
    // this.collapse_search_form = !this.collapse_search_form;
    if (targetclass === 'btn btn-box-tool fa fa-angle-up') {
      this.collapse_search_form = !this.collapse_search_form;
      event.target.className = 'btn btn-box-tool fa fa-angle-down';
    } else if (targetclass === 'btn btn-box-tool fa fa-angle-down') {
      this.collapse_search_form = !this.collapse_search_form;
      event.target.className = 'btn btn-box-tool fa fa-angle-up';
    }
  }
  onResetSearch() {
    this.searchForm.reset();
    this.renderDT = false;
    this.GetAllmoduless();
  }
  onSearch() {

  }
  GetAllmoduless() {
    this.modulesservice.getModulesAll().subscribe((res: any[]) => {
      this.modulessList$ = res;
      setTimeout(() => {
        this.renderDT = true;
      }, 100);
    });
  }
  get f() { return this.addNewForm.controls; }

  onResetAdd() {
    this.addNewForm.reset();
  }
  addNewmodules(): void {
    this.addNewsubmitted = true;
    // stop here if form is invalid
    if (this.addNewForm.invalid) {
      return;
    } else {
      this.modulesservice.addModules(this.addNewForm.value).subscribe(
        modulesservice => {
          // console.log(modulesservice);
          if (!!modulesservice && modulesservice.masModuleId) {
            this.modulessList$.push(modulesservice);
            this.closeModalAdd.nativeElement.click();
            swal(
              'Success',
              'New Records Addeded',
              'success'
            );
            this.onResetAdd();
          }
        });
    }
  }
  get u() { return this.editNewForm.controls; }
  showEditvalues(getId) {
    this.modulesservice.ModulesByModulesId(getId).subscribe(
      modulesservice => {
        if (!!modulesservice && modulesservice.masModuleId) {
          this.moduledetail = modulesservice;
        } else {
          swal(
            'Error',
            'Error fetching record',
            'error'
          );
        }
      });
  }
  onResetEdit() {
  }
  editNewmodules() {
    this.editsubmitted = true;
    // console.log(this.editNewForm);
    // stop here if form is invalid
    if (this.editNewForm.invalid) {
      swal(
        'Error',
        'sorry error in the form',
        'error'
      );
      return;
    } else {
      // console.log(this.editNewForm.value); return;
      this.modulesservice.updateModules(this.editNewForm.value).subscribe(
        modulesservice => {
          if (!!modulesservice && modulesservice.masModuleId) {
            const ix = modulesservice ? this.modulessList$.findIndex(h => h.masModuleId === modulesservice.masModuleId) : -1;
            if (ix > -1) { this.modulessList$[ix] = modulesservice; }
            this.closeModalEdit.nativeElement.click();
            swal(
              'Updated!',
              'Modules has been Updated.',
              'success'
            );
          }
        });
    }
  }
  removeafterDeactivate(modules: Modules): void {
    this.modulessList$ = this.modulessList$.filter(h => h !== modules);
  }
  changeStatusmodules(modules, e, Id) {
    if (e.target.checked) {
      swal({
        type: 'warning',
        title: 'Are you sure to activate this modules?',
        text: 'You will not be able to recover the data of modulessprofile',
        showCancelButton: true,
        confirmButtonColor: '#049F0C',
        cancelButtonColor: '#ff0000',
        confirmButtonText: 'Yes, activate it!',
        cancelButtonText: 'No, keep it deactivated',
        closeOnClickOutside: false,
        closeOnEsc: false,
        allowOutsideClick: false,
      } as any).then((result) => {
        if (result.value) {
          this.modulesservice.activateModules(Id).subscribe(
            data => {
              console.log('data->' + data);
            }, error => {
              console.log('error->' + error);
            });
          swal(
            'Activated!',
            'modulessprofile has been activated.',
            'success'
          );
        } else if (
          // Read more about handling dismissals
          result.dismiss === swal.DismissReason.cancel
        ) {
          e.target.checked = false;
          swal(
            'Cancelled',
            'modulessprofile is status unchanged',
            'error'
          );
        }
      });
    } else {
      swal({
        type: 'warning',
        title: 'Are you sure to deactivate this modules?',
        text: 'You will not be able to recover the data of modulessprofile',
        showCancelButton: true,
        confirmButtonColor: '#049F0C',
        cancelButtonColor: '#ff0000',
        confirmButtonText: 'Yes, deactivate it!',
        cancelButtonText: 'No, keep it as active',
        closeOnClickOutside: false,
        closeOnEsc: false,
        allowOutsideClick: false,
      } as any).then((result) => {
        if (result.value) {
          this.modulesservice.deactivateModules(Id).subscribe(
            data => {
              console.log('data->' + data);
            }, error => {
              console.log('error->' + error);
            });
          swal(
            'Deactivated!',
            'modulessprofile has been deactivated.',
            'success'
          );
          this.removeafterDeactivate(modules);
        } else if (
          // Read more about handling dismissals
          result.dismiss === swal.DismissReason.cancel
        ) {
          e.target.checked = true;
          swal(
            'Cancelled',
            'modulessprofile is status unchanged',
            'error'
          );
        }
      });
    }
  }

  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }

}

