package com.sgl.smartpra.batch.bsp.app.record;

import java.util.ArrayList;

import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;
import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;

public class NettingValues extends BSPBaseRecord {

	@Override
	public String getRecordType() {
		return BSPRecordType.NETTING_VALUES;
	}

	// Layout of Netting Values Record
	class NettingValuesLayout extends FixedLengthRecordLayout {
		public NettingValuesLayout() {
			fixedLengthFieldLayoutList = new ArrayList<FixedLengthFieldLayout>();

			// entire line
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("line", 1, 136));

			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdMessageIdentifier", 1, 3));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("seqNumber", 4, 11));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdNumericQuaifier", 12, 13));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("dateOfIssue", 14, 19));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("transactionNumber", 20, 25));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("tktDocNumber", 26, 39));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("checkDigit", 40, 40));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("nettingType1", 41, 41));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("nettingCode1", 42, 49));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("nettingAmount1", 50, 60));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("nettingType2", 61, 61));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("nettingCode2", 62, 69));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("nettingAmount2", 70, 80));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("nettingType3", 81, 81));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("nettingCode3", 82, 89));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("nettingAmount3", 90, 100));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("nettingType4", 101, 101));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("nettingCode4", 102, 109));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("nettingAmount4", 110, 120));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("filler", 121, 132));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("currencyType", 133, 136));
		}
	}

	@Override
	public LineTokenizer lineTokenizer(String handbookRevisionNumber) {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		NettingValuesLayout nettingValuesLayout = new NettingValuesLayout();
		tokenizer.setColumns(nettingValuesLayout.getColumns());
		tokenizer.setNames(nettingValuesLayout.getNames());
		return tokenizer;
	}

	@Override
	public FieldSetMapper<BSPBaseRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<BSPBaseRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<BSPBaseRecord>();
		fieldSetMapper.setTargetType(this.getClass());
		return fieldSetMapper;
	}

	// Variables to hold the record values
	private String stdMessageIdentifier;
	private String seqNumber;
	private String stdNumericQuaifier;
	private String dateOfIssue;
	private String transactionNumber;
	private String tktDocNumber;
	private String checkDigit;
	private String nettingType1;
	private String nettingCode1;
	private String nettingAmount1;
	private String nettingType2;
	private String nettingCode2;
	private String nettingAmount2;
	private String nettingType3;
	private String nettingCode3;
	private String nettingAmount3;
	private String nettingType4;
	private String nettingCode4;
	private String nettingAmount4;
	private String filler;
	private String currencyType;

	public String getStdMessageIdentifier() {
		return stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getSeqNumber() {
		return seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdNumericQuaifier() {
		return stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getDateOfIssue() {
		return dateOfIssue;
	}

	public void setDateOfIssue(String dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}

	public String getTransactionNumber() {
		return transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

	public String getTktDocNumber() {
		return tktDocNumber;
	}

	public void setTktDocNumber(String tktDocNumber) {
		this.tktDocNumber = tktDocNumber;
	}

	public String getCheckDigit() {
		return checkDigit;
	}

	public void setCheckDigit(String checkDigit) {
		this.checkDigit = checkDigit;
	}

	public String getNettingType1() {
		return nettingType1;
	}

	public void setNettingType1(String nettingType1) {
		this.nettingType1 = nettingType1;
	}

	public String getNettingCode1() {
		return nettingCode1;
	}

	public void setNettingCode1(String nettingCode1) {
		this.nettingCode1 = nettingCode1;
	}

	public String getNettingAmount1() {
		return nettingAmount1;
	}

	public void setNettingAmount1(String nettingAmount1) {
		this.nettingAmount1 = nettingAmount1;
	}

	public String getNettingType2() {
		return nettingType2;
	}

	public void setNettingType2(String nettingType2) {
		this.nettingType2 = nettingType2;
	}

	public String getNettingCode2() {
		return nettingCode2;
	}

	public void setNettingCode2(String nettingCode2) {
		this.nettingCode2 = nettingCode2;
	}

	public String getNettingAmount2() {
		return nettingAmount2;
	}

	public void setNettingAmount2(String nettingAmount2) {
		this.nettingAmount2 = nettingAmount2;
	}

	public String getNettingType3() {
		return nettingType3;
	}

	public void setNettingType3(String nettingType3) {
		this.nettingType3 = nettingType3;
	}

	public String getNettingCode3() {
		return nettingCode3;
	}

	public void setNettingCode3(String nettingCode3) {
		this.nettingCode3 = nettingCode3;
	}

	public String getNettingAmount3() {
		return nettingAmount3;
	}

	public void setNettingAmount3(String nettingAmount3) {
		this.nettingAmount3 = nettingAmount3;
	}

	public String getNettingType4() {
		return nettingType4;
	}

	public void setNettingType4(String nettingType4) {
		this.nettingType4 = nettingType4;
	}

	public String getNettingCode4() {
		return nettingCode4;
	}

	public void setNettingCode4(String nettingCode4) {
		this.nettingCode4 = nettingCode4;
	}

	public String getNettingAmount4() {
		return nettingAmount4;
	}

	public void setNettingAmount4(String nettingAmount4) {
		this.nettingAmount4 = nettingAmount4;
	}

	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}

	public String getCurrencyType() {
		return currencyType;
	}

	public void setCurrencyType(String currencyType) {
		this.currencyType = currencyType;
	}
}
