export class Modules {
  clientId: number;
  isActive: true;
  masModuleId: number;
  moduleManagerId: number;
  moduleName: string;
    constructor() { }
  }
