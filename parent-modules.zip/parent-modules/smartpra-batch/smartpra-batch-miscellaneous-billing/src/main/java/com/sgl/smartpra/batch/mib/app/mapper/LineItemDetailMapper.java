/**
 * 
 */
package com.sgl.smartpra.batch.mib.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValueCheckStrategy;

import com.sgl.smartpra.batch.mib.app.utils.QualifiedByUtil;
import com.sgl.smartpra.batch.mib.app.utils.QualifiedByUtil.BigIntegerToInteger;
import com.sgl.smartpra.batch.mib.app.utils.QualifiedByUtil.BigIntegerToString;
import com.sgl.smartpra.batch.mib.app.utils.QualifiedByUtil.ListToBigDecimal;
import com.sgl.smartpra.batch.mib.app.utils.QualifiedByUtil.ObjectToString;
import com.sgl.smartpra.batch.mib.app.utils.QualifiedByUtil.ReturnSumFromList;
import com.sgl.smartpra.batch.mib.app.utils.QualifiedByUtil.StringToBigInteger;
import com.sgl.smartpra.batch.mib.app.utils.QualifiedByUtil.StringToDate;
import com.sgl.smartpra.mib.entity.MiscBillingInvLineitemDtlEntity;
import com.sgl.smartpra.mib.jaxb.standard.LineItemDetail;

/**
 * @author kanprasa
 *
 */
@Mapper(uses = QualifiedByUtil.class, componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)
public interface LineItemDetailMapper {
	
	@Mapping(source = "detailNumber", target = "lineItemDetailNumber", qualifiedBy=BigIntegerToInteger.class)
	@Mapping(source = "productID", target = "productId")
	@Mapping(source = "startDate", target = "startDate", qualifiedBy=StringToDate.class)
	@Mapping(source = "endDate", target = "endDate", qualifiedBy=StringToDate.class)
	@Mapping(source = "minimumQuantityFlag", target = "minQtyFlag", qualifiedBy=ObjectToString.class)
	@Mapping(target = "chargeAmt", source="chargeAmount", qualifiedBy = ListToBigDecimal.class)
	@Mapping(source = "quantity.UOMCode", target = "uomCode")	
	@Mapping(source = "quantity.value", target = "quantity", defaultValue = "0")
	@Mapping(source = "unitPrice.value", target = "unitPrice", defaultValue = "0")
	@Mapping(source = "unitPrice.SF", target = "scallingFactor", qualifiedBy=BigIntegerToString.class)
	@Mapping(target = "addOnChargeAmt", source="addOnCharges", qualifiedBy = ReturnSumFromList.class)
	@Mapping(source = "totalNetAmount", target="totalNetAmt")
	public void mapLineItemDetailToEntity(LineItemDetail lineItemdetail, @MappingTarget MiscBillingInvLineitemDtlEntity lineItemDtlEntity);
	

	@Mapping(source = "lineItemDetailNumber", target = "detailNumber")
	@Mapping(source = "productId", target = "productID")
	@Mapping(source = "startDate", target = "startDate", qualifiedBy=ObjectToString.class)
	@Mapping(source = "endDate", target = "endDate", qualifiedBy=ObjectToString.class)
	@Mapping(source = "uomCode", target = "quantity.UOMCode")	
	@Mapping(source = "quantity", target = "quantity.value", defaultValue = "0")
	@Mapping(source = "unitPrice", target = "unitPrice.value", defaultValue = "0")
	@Mapping(source = "scallingFactor", target = "unitPrice.SF", qualifiedBy=StringToBigInteger.class)
	@Mapping(source = "totalNetAmt", target="totalNetAmount")
	public void mapEntityToLineItemDetail(MiscBillingInvLineitemDtlEntity lineItemDtlEntity, @MappingTarget LineItemDetail lineItemdetail);

}