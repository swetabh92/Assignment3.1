import { Directive, AfterViewInit,AfterViewChecked , ChangeDetectorRef,ElementRef} from '@angular/core';
import { DatatableComponent } from "@swimlane/ngx-datatable";

@Directive({
  selector: '[appNgxResizeWatcher]',
  
})

export class NgxResizeWatcherDirective implements AfterViewChecked,AfterViewInit {
 
  constructor(private table: DatatableComponent, public ref: ChangeDetectorRef,private el: ElementRef) {
  }
  private latestWidth: number;
  ngAfterViewChecked() {
    /*change page count text*/
    this.changeFooterText();
    if (this.table && this.table.element.clientWidth !== this.latestWidth) {
      this.latestWidth = this.table.element.clientWidth;
      this.table.recalculate();	
      this.ref.detectChanges();
    }
  }
  ngAfterViewInit() {
    this.changeFooterText();
    this.el.nativeElement.querySelectorAll("ul.pager li a[aria-label='go to first page']")[0].setAttribute("title", "First");
    this.el.nativeElement.querySelectorAll("ul.pager li a[aria-label='go to previous page']")[0].setAttribute("title", "Prev");
    this.el.nativeElement.querySelectorAll("ul.pager li a[aria-label='go to next page']")[0].setAttribute("title", "Next");
    this.el.nativeElement.querySelectorAll("ul.pager li a[aria-label='go to last page']")[0].setAttribute("title", "Last");
  }
  changeFooterText(){
    let countNode = this.el.nativeElement.querySelectorAll(".page-count")[0];
    if(countNode){
      let pageNum = this.table.bodyComponent._offset+1; 
      let pageSize = this.table.bodyComponent._pageSize;
      let visibleRow = this.table.bodyComponent.temp.length;
      let row_start = ((pageNum-1)*pageSize)+1;
      let row_end =pageNum*pageSize;
      let total = this.table.bodyComponent._rowCount;
      if(row_end>total && total) row_end = total;
      if(visibleRow == 0) {row_start = row_end = 0;}
      let text = 'Showing '+row_start+' to '+row_end+' of '+total +' entries';
      if(countNode.innerText != text){
        countNode.innerText = text;
      }
    }
  }

}
