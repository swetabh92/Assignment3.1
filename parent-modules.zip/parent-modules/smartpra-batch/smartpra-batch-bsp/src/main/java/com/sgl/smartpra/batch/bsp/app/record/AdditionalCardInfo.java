package com.sgl.smartpra.batch.bsp.app.record;

import java.util.ArrayList;

import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;
import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;

public class AdditionalCardInfo extends BSPBaseRecord {

	@Override
	public String getRecordType() {
		return BSPRecordType.ADDITIONAL_CARD_INFO;
	}

	// Layout of Additional Card Info Record
	public class AdditionalCardInfoLayout extends FixedLengthRecordLayout {
		public AdditionalCardInfoLayout() {
			fixedLengthFieldLayoutList = new ArrayList<FixedLengthFieldLayout>();

			// entire line
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("line", 1, 136));

			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdMessageIdentifier", 1, 3));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("seqNumber", 4, 11));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdNumericQuaifier", 12, 13));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("dateOfIssue", 14, 19));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("transactionNumber", 20, 25));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("fopType", 26, 35));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("fopTransactionIdentifier", 36, 60));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("filler", 61, 136));
		}
	}

	@Override
	public LineTokenizer lineTokenizer(String handbookRevisionNumber) {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		AdditionalCardInfoLayout additionalCardInfoLayout = new AdditionalCardInfoLayout();
		tokenizer.setColumns(additionalCardInfoLayout.getColumns());
		tokenizer.setNames(additionalCardInfoLayout.getNames());
		return tokenizer;
	}

	@Override
	public FieldSetMapper<BSPBaseRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<BSPBaseRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<BSPBaseRecord>();
		fieldSetMapper.setTargetType(this.getClass());
		return fieldSetMapper;
	}

	// variables to hold the record values
	private String stdMessageIdentifier;
	private String seqNumber;
	private String stdNumericQuaifier;
	private String dateOfIssue;
	private String transactionNumber;
	private String fopType;
	private String fopTransactionIdentifier;
	private String filler;

	public String getStdMessageIdentifier() {
		return stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getSeqNumber() {
		return seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdNumericQuaifier() {
		return stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getDateOfIssue() {
		return dateOfIssue;
	}

	public void setDateOfIssue(String dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}

	public String getTransactionNumber() {
		return transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

	public String getFopType() {
		return fopType;
	}

	public void setFopType(String fopType) {
		this.fopType = fopType;
	}

	public String getFopTransactionIdentifier() {
		return fopTransactionIdentifier;
	}

	public void setFopTransactionIdentifier(String fopTransactionIdentifier) {
		this.fopTransactionIdentifier = fopTransactionIdentifier;
	}

	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}
}
