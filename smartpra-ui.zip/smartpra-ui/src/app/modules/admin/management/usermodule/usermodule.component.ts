import { Component, OnInit, Input, Output, EventEmitter, OnDestroy, ElementRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { GeneralService } from '../../../../commons/services/general.service';
import { UsermoduleService } from '../../services/usermodule.service';
import { Usermodule } from '../../models/usermodule';
import { Subject } from 'rxjs';
import swal from 'sweetalert2';

@Component({
  selector: 'app-usermodule',
  templateUrl: './usermodule.component.html',
  styleUrls: ['./usermodule.component.css']
})
export class UsermoduleComponent implements OnInit, OnDestroy {
  @ViewChild('closeModalAdd') closeModalAdd: ElementRef;
  @ViewChild('closeModalEdit') closeModalEdit: ElementRef;
  dtOptions: any = {};
  // We use this trigger because fetching the list of persons can be quite long,
  // thus we ensure the data is fetched before rendering
  dtTrigger: Subject<any> = new Subject<any>();
  public renderDT = false;
  createdBy = 'admin';
  lastUpdatedBy = 'admin';
  collapse_search_form = true;
  box_search_status = true;
  addNewForm: FormGroup;
  addNewsubmitted = false;
  editNewForm: FormGroup;
  editsubmitted = false;
  searchForm: FormGroup;
  searchsubmitted = false;
  searchresult = false;
  searchstring = '';
  checkdata: any;
  usermodulesList$: any;
  usermoduledetail:any;
  previewUrl = '';
  constructor(private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder,
    private generalService: GeneralService,
    private usermoduleservice: UsermoduleService,
  ) { }

  ngOnInit() {
    this.dtOptions = {
      searching: false, // to hide the search field in the data table top
      pagingType: 'full_numbers',
      lengthMenu: [[5, 10, 25, 50, -1], [5, 10, 25, 50, 'All']], // used to display records size( no of rows)
      language: {
        lengthMenu: 'Page size _MENU_',
        paginate: {
          next: '<i style="color:#0079c1" class="fa fa-angle-right fa-lg"></i>',
          previous: '<i style="color:#0079c1" class="fa fa-angle-left fa-lg"></i>',
          first: '<i style="color:#0079c1" class="fa fa-step-backward"></i>',
          last: '<i style="color:#0079c1" class="fa fa-step-forward"></i>'
        }
      },
      dom: 'tflrp<"datatableclass"i>',
      // used for fixed columns
      // scrollX: true,
      // scrollY: 'auto',
      // scrollCollapse: true,
      // fixedColumns:   {
      //   leftColumns: 2,
      //   rightColumns: 2
      // },
      // end of fixed columns
      // disable search and order
      // aoColumnDefs: [{ bSortable: false, aTargets: [0, 4, 5] }],
      columnDefs: [
        {
          'searchable': false,
          'orderable': false,
          'targets': [-1, -2]
        }
      ],
      // end of disable search and order
    };
    this.GetAllusermodules();
    this.addNewForm = this.formBuilder.group({
      createdBy: [''], // , Validators.required],
      masModuleId: [''], // , Validators.required],
      masUserModuleId: [''], // , Validators.required],
      masUsersId: [''], // , Validators.required],
    });
    this.editNewForm = this.formBuilder.group({
      lastUpdatedBy: [''],
      masModuleId: [''], // , Validators.required],
      masUserModuleId: [''], // , Validators.required],
      masUsersId: [''], // , Validators.required],
    });
    this.searchForm = this.formBuilder.group({
      active: ['', ],
    });
  }
  showSearchBox(e) {
    this.box_search_status = !this.box_search_status;
    this.collapse_search_form = true;
  }
  collapseSearchform(event) {
    const targetclass = event.target.className;
    // console.log(targetclass);
    // this.collapse_search_form = !this.collapse_search_form;
    if (targetclass === 'btn btn-box-tool fa fa-angle-up') {
      this.collapse_search_form = !this.collapse_search_form;
      event.target.className = 'btn btn-box-tool fa fa-angle-down';
    } else if (targetclass === 'btn btn-box-tool fa fa-angle-down') {
      this.collapse_search_form = !this.collapse_search_form;
      event.target.className = 'btn btn-box-tool fa fa-angle-up';
    }
  }
  onResetSearch() {
    this.searchForm.reset();
    this.renderDT = false;
    this.GetAllusermodules();
  }
  onSearch() {

  }
  GetAllusermodules() {
    this.usermoduleservice.getUsermoduleAll().subscribe((res: any[]) => {
      this.usermodulesList$ = res;
      setTimeout(() => {
        this.renderDT = true;
      }, 100);
    });
  }
  get f() { return this.addNewForm.controls; }

  onResetAdd() {
    this.addNewForm.reset();
  }
  addNewusermodule(): void {
    this.addNewsubmitted = true;
    // stop here if form is invalid
    if (this.addNewForm.invalid) {
      return;
    } else {
      this.usermoduleservice.addUsermodule(this.addNewForm.value).subscribe(
        usermoduleservice => {
          // console.log(usermoduleservice);
          if (!!usermoduleservice && usermoduleservice.masUserModuleId) {
            this.usermodulesList$.push(usermoduleservice);
            this.closeModalAdd.nativeElement.click();
            swal(
              'Success',
              'New Records Addeded',
              'success'
            );
            this.onResetAdd();
          }
        });
    }
  }
  get u() { return this.editNewForm.controls; }
  showEditvalues(getId) {
    this.usermoduleservice.UsermoduleByUsermoduleId(getId).subscribe(
      usermoduleservice => {
        if (!!usermoduleservice && usermoduleservice.masUserModuleId) {
          this.usermoduledetail = usermoduleservice;
        } else {
          swal(
            'Error',
            'Error fetching record',
            'error'
          );
        }
      });
  }
  onResetEdit() {
  }
  editNewusermodule() {
    this.editsubmitted = true;
    // console.log(this.editNewForm);
    // stop here if form is invalid
    if (this.editNewForm.invalid) {
      swal(
        'Error',
        'sorry error in the form',
        'error'
      );
      return;
    } else {
      // console.log(this.editNewForm.value); return;
      this.usermoduleservice.updateUsermodule(this.editNewForm.value).subscribe(
        usermoduleservice => {
          if (!!usermoduleservice && usermoduleservice.masUserModuleId) {
            const ix = usermoduleservice ? this.usermodulesList$.findIndex(h => h.masUserModuleId === usermoduleservice.masUserModuleId) : -1;
            if (ix > -1) { this.usermodulesList$[ix] = usermoduleservice; }
            this.closeModalEdit.nativeElement.click();
            swal(
              'Updated!',
              'Usermodule has been Updated.',
              'success'
            );
          }
        });
    }
  }
  removeafterDeactivate(user: Usermodule): void {
    this.usermodulesList$ = this.usermodulesList$.filter(h => h !== user);
  }
  changeStatususermodule(usermodule, e, Id) {
    if (e.target.checked) {
      swal({
        type: 'warning',
        title: 'Are you sure to activate this usermodule?',
        text: 'You will not be able to recover the data of usermodulesprofile',
        showCancelButton: true,
        confirmButtonColor: '#049F0C',
        cancelButtonColor: '#ff0000',
        confirmButtonText: 'Yes, activate it!',
        cancelButtonText: 'No, keep it deactivated',
        closeOnClickOutside: false,
        closeOnEsc: false,
        allowOutsideClick: false,
      } as any).then((result) => {
        if (result.value) {
          this.usermoduleservice.activateUsermodule(Id).subscribe(
            data => {
              console.log('data->' + data);
            }, error => {
              console.log('error->' + error);
            });
          swal(
            'Activated!',
            'usermodulesprofile has been activated.',
            'success'
          );
        } else if (
          // Read more about handling dismissals
          result.dismiss === swal.DismissReason.cancel
        ) {
          e.target.checked = false;
          swal(
            'Cancelled',
            'usermodulesprofile is status unchanged',
            'error'
          );
        }
      });
    } else {
      swal({
        type: 'warning',
        title: 'Are you sure to deactivate this usermodule?',
        text: 'You will not be able to recover the data of usermodulesprofile',
        showCancelButton: true,
        confirmButtonColor: '#049F0C',
        cancelButtonColor: '#ff0000',
        confirmButtonText: 'Yes, deactivate it!',
        cancelButtonText: 'No, keep it as active',
        closeOnClickOutside: false,
        closeOnEsc: false,
        allowOutsideClick: false,
      } as any).then((result) => {
        if (result.value) {
          this.usermoduleservice.deactivateUsermodule(Id).subscribe(
            data => {
              console.log('data->' + data);
            }, error => {
              console.log('error->' + error);
            });
          swal(
            'Deactivated!',
            'usermodulesprofile has been deactivated.',
            'success'
          );
          this.removeafterDeactivate(usermodule);
        } else if (
          // Read more about handling dismissals
          result.dismiss === swal.DismissReason.cancel
        ) {
          e.target.checked = true;
          swal(
            'Cancelled',
            'usermodulesprofile is status unchanged',
            'error'
          );
        }
      });
    }
  }

  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }

}

