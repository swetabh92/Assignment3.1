import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExcpetionManagementComponent } from './excpetion-management.component';

describe('ExcpetionManagementComponent', () => {
  let component: ExcpetionManagementComponent;
  let fixture: ComponentFixture<ExcpetionManagementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExcpetionManagementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExcpetionManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
