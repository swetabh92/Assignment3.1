export class ChartConstants {
  public static DOUGHNUT = 'doughnut';
}
