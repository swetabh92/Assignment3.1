export class Process {
    isActive: true;
    masProcessDTOId: number;
    processName: string;
      constructor() { }
    }
