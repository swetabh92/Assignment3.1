import { FormGroup } from '@angular/forms';

// custom validator to check that two fields match
export function MustMatch(from: string, to: string) {
    return (formGroup: FormGroup) => {
        const control = formGroup.controls[from];
        const matchingControl = formGroup.controls[to];
        console.log("The from dt is "+ new Date(control.value) )
        console.log("The from dt is "+ matchingControl.value)
        // if (matchingControl.errors && !matchingControl.errors.mustMatch) {
        //     // return if another validator has already found an error on the matchingControl
        //     return;
        // }

        // set error on matchingControl if validation fails
        // if (control.value !== matchingControl.value) {
        //     return null;
        // } else {
        //     return true;
        // }



        if (new Date(control.value) > new Date(matchingControl.value)) {
            // swal(
            //   'From Period date should be less than To Period',
            //   'error'
            // );

            console.log("In if block ")
       
            return true;
          }
          else{
            console.log("In eelse block ")
          return true;
          }
        }

    }
