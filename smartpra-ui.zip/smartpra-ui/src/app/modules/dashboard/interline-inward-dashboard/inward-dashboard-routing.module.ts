import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { InwardDashboardComponent } from './inward-dashboard.component';

const routes: Routes = [
  {path: '', component: InwardDashboardComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class InwardDashboardRoutingModule { }
