/*package com.sgl.smartpra.allocation.master.app.dao;

import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.allocation.master.app.entity.SalesAllocationEntity;

public interface SalesAllocationMasterDao {

	public SalesAllocationEntity create(SalesAllocationEntity salesAllocationEntity);

	public SalesAllocationEntity update(SalesAllocationEntity salesAllocationEntity);

	public Optional<SalesAllocationEntity> findById(Integer allocationMasterId);

	public List<SalesAllocationEntity> findAll(List<Integer> fileMappingId);
	
	//public SalesAllocationEntity assignAllocation(AllocationMasterSearchModel allocationMasterSearchModel);

}
*/