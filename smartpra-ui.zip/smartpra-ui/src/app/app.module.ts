import {BrowserModule} from '@angular/platform-browser';
import {NgModule,APP_INITIALIZER} from '@angular/core';
import {HttpClientModule, HTTP_INTERCEPTORS} from '@angular/common/http';
import {AppRoutingModule} from './app-routing.module';
import {AppComponent} from './app.component';
import {JwtInterceptor, ErrorInterceptor} from './core/authentication/auth-gaurd-service/_helpers';
import {ApploginComponent} from './core/authentication/applogin/applogin.component';
import {NgMultiSelectDropDownModule} from 'ng-multiselect-dropdown';
import {HotkeyModule} from 'angular2-hotkeys';
import {ServiceWorkerModule} from '@angular/service-worker';
import {environment} from '../environments/environment';
import {SharedModule} from './shared/shared.module';
import {TranslateService} from "./commons/translate/transalation.service";
import {AngularSplitModule} from 'angular-split';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { ResolutionTimerComponent } from './modules/common/resolution-timer/resolution-timer.component';

export function setupTranslateFactory(
  service: TranslateService): Function {
  return () => service.use('en');
}

@NgModule({
  declarations: [
    AppComponent,
    ApploginComponent,
    ResolutionTimerComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    SharedModule,
    BsDatepickerModule.forRoot(),
    HotkeyModule.forRoot(),
    AngularSplitModule.forRoot(),
    NgMultiSelectDropDownModule.forRoot(),
    ServiceWorkerModule.register('ngsw-worker.js', {enabled: environment.production}),
  ],
  providers: [
    TranslateService,
    {
      provide: APP_INITIALIZER,
      useFactory: setupTranslateFactory,
      deps: [TranslateService],
      multi: true
    },
    {provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true},
    {provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true},
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
}
