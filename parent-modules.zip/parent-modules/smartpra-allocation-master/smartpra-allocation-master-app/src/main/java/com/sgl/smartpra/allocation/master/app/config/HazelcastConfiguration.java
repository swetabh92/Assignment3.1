package com.sgl.smartpra.allocation.master.app.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.hazelcast.config.Config;
import com.hazelcast.config.EvictionPolicy;
import com.hazelcast.config.MapConfig;
import com.hazelcast.config.MaxSizeConfig;

@Configuration
public class HazelcastConfiguration {

	@Value("${hz.cache.expiry-time}")
	private Integer cacheExpiryTime;

	@Bean
	public Config hazelCastConfig() {
		return new Config().addMapConfig(new MapConfig().setName("smartpra-allocation-master-app")
				.setMaxSizeConfig(new MaxSizeConfig(300, MaxSizeConfig.MaxSizePolicy.FREE_HEAP_SIZE))
				.setEvictionPolicy(EvictionPolicy.LRU).setTimeToLiveSeconds(cacheExpiryTime));
	}
}
