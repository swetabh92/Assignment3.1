import {Component, Input, OnInit} from '@angular/core';
import {ExceptionMasterService} from "../../../masters/components/others/exception-master/exception-master-service";
import {
  PendingApprovalModel,
  TeamModel,
  UserModel
} from "../../../masters/components/others/exception-master/exception-master-model";
import {ExceptionManagementModel} from "../models/excpetion-management-model";
import {FormBuilder} from "@angular/forms";
import {PaginationService} from "../../../../commons/services/pagination/pagination.service";
import {ExceptionManagementService} from "../../../masters/services/dashboard/exception-management.service";
import {MessageBoxService} from "../../../masters/services/commons/message-box.service";
import { ExceptionConstant } from '../constants/exception-contants';
@Component({
  selector: 'app-pending-approval',
  templateUrl: './pending-approval.component.html',
  styleUrls: ['../excpetion-management.component.css']
})

export class PendingApprovalComponent implements OnInit {

  @Input('modules') modules;
  @Input('groups') groups;
  teams: TeamModel[];
  users: UserModel[];
  model: ExceptionManagementModel = new ExceptionManagementModel(this.paginationService);
  constructor(private exceptionMasterService: ExceptionMasterService, private exceptionManagementService: ExceptionManagementService,
              private formBuilder: FormBuilder, private paginationService: PaginationService, private messageService: MessageBoxService) {
  }

  ngOnInit() {
    this.model.userForm = this.formBuilder.group(this.model.userFormObj);
  }

  onSelectGroup(groupId: string) {
    this.exceptionMasterService.getTeamsByGroupId(parseInt(groupId)).subscribe((res: TeamModel[]) => this.teams = res);
  }

  private getPendingApprovalData(data:any) {
    let params: any = {
      "approverTeamId": data.teamId,
      "approverGroupId": data.groupId,
      "approvalStatus": ExceptionConstant.PENDING_APPROVAL
    };
    this.exceptionManagementService.getAllPendingApprovalData(params).subscribe((res: PendingApprovalModel[]) => {
      this.model.pendingApprovalData = res;
    });
  }

  onSelect(selected: any) {
    if (selected && selected.length > 0)
      this.model.approvedOrRejectData = selected[0];
  }

  onApproveRejectTask(){
    this.model.approvedOrRejectData.remarks = this.model.remarks;
    this.exceptionManagementService.approveRejectPendingStatus(this.model.approvedOrRejectData).subscribe((res) => {
      if (res.approvalStatus) {
        this.messageService.getSuccessMessage("Success", "Status updated Successfully");
        this.getPendingApprovalData(this.model.userForm.value);
      } else {
        this.messageService.getWarningMessage("Error", "Status updated Failed");
      }
    });
  }


  onSearchPendingApproval(data:any) {
    this.getPendingApprovalData(data);
  }

}
