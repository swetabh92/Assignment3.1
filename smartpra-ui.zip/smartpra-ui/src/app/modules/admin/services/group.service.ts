import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { environment } from '../../../../environments/environment';
import { Group } from '../models/group';
import { MessageBoxService } from '../../masters/services/commons/message-box.service';
import {ExceptionMasterModel} from "../../masters/components/others/exception-master/exception-master-model";
const httpOptions = {};

@Injectable({
  providedIn: 'root'
})
export class GroupService {
  globalUrl = environment.apiUrlGlobal;
  masterUrl = environment.apiUrlMaster;
  authUrl = environment.apiUrlauth;
  constructor(private http: HttpClient, private messageBoxService: MessageBoxService) { }
  getGroupAll(): Observable<Group[]> {
    return this.http.get<Group[]>(this.authUrl + 'mas-groups')
      .pipe(
        tap(_ => this.log('fetched Group details')),
        catchError(this.handleError('getAllGroup', []))
      );
  }
  GroupByGroupId(groupId: string): Observable<Group> {
    return this.http.get<Group>(this.authUrl + 'mas-groups/' + groupId).pipe(
      tap(_ => this.log(`fetched Group groupId=${groupId}`)),
      catchError(this.handleError<Group>(`GroupByGroupId groupId=${groupId}`))
    );
  }
  searchGroup(parms: string): Observable<Group> {
    return this.http.get<Group>(this.authUrl + parms).pipe(
      tap(_ => this.log(`search Group groupId by ${parms}`)),
      catchError(this.handleError<Group>(`search Group groupId by ${parms}`))
    );
  }
  /** POST: add a new Group to the server */
  addGroup(formdata): Observable<Group> {
    // console.log(formdata); return;
    return this.http.post<Group>(this.authUrl + 'mas-groups/', formdata, httpOptions).pipe(
      tap(_ => this.log(`added Group groupId=`)),
      catchError(this.handleError<Group>('addGroup'))
    );
  }
  updateGroup(group: Group): Observable<any> {
   // console.log(Group.groupId);
     console.log(group);
    return this.http.put<Group>(this.authUrl + 'mas-groups/', group, httpOptions).pipe(
      tap(_ => this.log(`updated Group groupId=${group.groupId}`)),
      catchError(this.handleError<Group>('addGroup'))
    );
  }
  deleteGroup(groupId: string): Observable<Group> {
    return this.http.delete<Group>(this.authUrl + 'mas-group/' + groupId , httpOptions).pipe(
      tap(_ => this.log(`activate Group groupId=${groupId}`)),
      catchError(this.handleError<Group>('activateRoleprofile'))
    );
  }
  activateGroup(groupId: string): Observable<Group> {
    return this.http.put<Group>(this.authUrl + 'mas-groups/activateordeactivate/' + groupId , httpOptions).pipe(
      tap(_ => this.log(`activate Group groupId=${groupId}`)),
      catchError(this.handleError<Group>('activateGroup'))
    );
  }
  deactivateGroup(groupId: string): Observable<Group> {
    return this.http.put<Group>(this.authUrl + 'mas-groups/activateordeactivate/' + groupId , httpOptions).pipe(
      tap(_ => this.log(`deactivate Group groupId=${groupId}`)),
      catchError(this.handleError<Group>('deactvateGroup'))
    );
  }

  getAllModules(clientId,tableName,columnName) {
    return this.http.get<ExceptionMasterModel[]>(this.masterUrl + 'listofvalueslist/' + clientId + '/' + tableName + '/' + columnName).pipe(
      tap(_ => this.log('fetched Exception Details')),
      catchError(this.handleError('getAllException', []))
    );
  }

  private handleError<T>(operation = 'operation', result?: T) {
    return (e: any): Observable<T> => {
      console.log(e);
      const error = e.error.message || e.error.error || e.error.error_description || 'Could not connect server';
      console.log(error);
      this.messageBoxService.getErrorMessage('ERROR', error);
      return of(result as T);
    };
  }
  private log(error: any) {
    console.log(error);
    if (error.message) {
      this.messageBoxService.getErrorMessage('ERROR', error.message);
    }
  }
}


