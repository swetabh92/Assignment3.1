import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProvisoDetailsComponent } from './proviso-details.component';

describe('ProvisoDetailsComponent', () => {
  let component: ProvisoDetailsComponent;
  let fixture: ComponentFixture<ProvisoDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProvisoDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProvisoDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
