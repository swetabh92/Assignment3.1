package com.sgl.smartpra.batch.interline.processor;

import java.math.BigInteger;
import java.time.LocalDate;

import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.AfterStep;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;

import com.sgl.smartpra.batch.interline.common.InterlineBatchConstants;
import com.sgl.smartpra.batch.interline.common.InterlineUtils;
import com.sgl.smartpra.batch.interline.configuration.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.batch.interline.service.BatchJobService;
import com.sgl.smartpra.interline.domain.entity.common.Auditable;
import com.sgl.smartpra.interline.domain.entity.stg.form3.InterlineForm3CsvStg;
import com.sgl.smartpra.interline.domain.enums.Form3StgStatusEnum;

public class InterlineForm3CsvStgProcessor implements ItemProcessor<InterlineForm3CsvStg, InterlineForm3CsvStg> {
	
	private ExecutionContext executionContext;
	
	@Autowired
	BatchJobService batchJobService;
	
	@Autowired
	SmartpraMasterAppClient smartpraMasterAppClient;
	
	@BeforeStep
	public void beforeStep(StepExecution stepExecution) {
		executionContext = stepExecution.getJobExecution().getExecutionContext();
	}

	@Override
	public InterlineForm3CsvStg process(InterlineForm3CsvStg item) throws Exception {
		Auditable auditable = new Auditable();
		auditable.setCreatedBy(InterlineBatchConstants.CREATED_BY_INTERLINE);
		auditable.setCreatedDate(LocalDate.now());
		item.setStatus(Form3StgStatusEnum.READY_FOR_VALIDATION.getValue());
		item.setFileId((BigInteger) executionContext.get(InterlineBatchConstants.FILE_ID));
		item.setAuditable(auditable);
		item.setBillingMonthPeriod(executionContext.get(InterlineBatchConstants.FILE_NAME).toString().substring(8,14));
		item.setClientId(InterlineUtils.getHostCarrierDesigCode(smartpraMasterAppClient));
		item.setTransferFlag(InterlineBatchConstants.N);
		return item;
	}
	
	@AfterStep
	public void afterStep(StepExecution stepExecution) {
		executionContext = stepExecution.getJobExecution().getExecutionContext();
	}
}
