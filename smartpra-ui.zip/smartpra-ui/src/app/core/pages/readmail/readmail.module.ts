import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ReadmailRoutingModule } from './readmail-routing.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { ReadmailComponent } from './readmail.component';
import { CoreDataModule } from 'src/app/core-data/core-data.module';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    CoreDataModule,
    ReadmailRoutingModule
  ],
  declarations: [
    ReadmailComponent
  ]
})
export class ReadmailModule { }
