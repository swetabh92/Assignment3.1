import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {ExceptionManagementModel} from "../models/excpetion-management-model";
import {PaginationService} from "../../../../commons/services/pagination/pagination.service";
import {FormBuilder} from "@angular/forms";
import {ExceptionMasterService} from "../../../masters/components/others/exception-master/exception-master-service";
import {exceptionTypes, getModuleCodeMap, filterOtherModuleKeys} from "../models/excpetion-resolution-model";

@Component({
  selector: 'app-search-exception',
  templateUrl: './search-exception.component.html',
  styleUrls: ['../excpetion-management.component.css']
})
export class SearchExceptionComponent implements OnInit {

  constructor(private paginateService: PaginationService, private formBuilder: FormBuilder,
              private exceptionMasterService: ExceptionMasterService) {
  }

  model: ExceptionManagementModel = new ExceptionManagementModel(this.paginateService);
  @Output() searchParams = new EventEmitter<any>();


  ngOnInit() {
    this.model.searchForm = this.formBuilder.group(this.model.exceptionForm);
    this.getAllModules();
  }

  getAllModules() {
    this.exceptionMasterService.getAllModules().subscribe(response => {
      this.model.modulesList = response;
    });
  }

  toggleAdvanceSearch() {
    this.model.advanceSearch = !this.model.advanceSearch;
  }

  onSearchException() {
    this.model.searchSubmitted = true;
    if (this.model.searchForm.valid) {
      this.emitRequestParams();
    }
  }

  emitRequestParams() {
    let searchParam = {
      "exceptionStatus": this.model.exceptionStatus,
      "moduleName": this.model.moduleName
    };

    this.searchParams.emit(filterOtherModuleKeys(Object.assign(this.model.searchForm.value, searchParam)));
  }

  onResetSearch() {
    this.model.searchSubmitted = false;
    this.model.searchForm = this.formBuilder.group(this.model.exceptionForm);
  }

  onSelectModule($event: Event) {
    this.model.searchSubmitted = false;
    this.model.exceptionStatus = exceptionTypes()[this.model.activeTab];
    this.model.moduleName = getModuleCodeMap(this.model.modulesList, this.model.searchForm.get('moduleId').value);
  }

}
