package com.sgl.smartpra.batch.mib.app.config.batch;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.Marshaller;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.transaction.PlatformTransactionManager;

import com.sgl.smartpra.batch.mib.app.config.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.batch.mib.app.listener.OutwardJobCompletionListener;
import com.sgl.smartpra.batch.mib.app.processor.InvoiceItemReader;
import com.sgl.smartpra.batch.mib.app.processor.OutwardBillingProcessor;
import com.sgl.smartpra.batch.mib.app.service.FileLoggingService;
import com.sgl.smartpra.batch.mib.app.service.OutwardBillingPeriodTask;
import com.sgl.smartpra.batch.mib.app.service.OutwardInvoiceService;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingConstants;
import com.sgl.smartpra.batch.mib.app.validator.CommonValidator;
import com.sgl.smartpra.mib.entity.MiscBillingTrnInvoiceEntity;
import com.sgl.smartpra.mib.jaxb.standard.InvoiceTransmission;

import lombok.extern.slf4j.Slf4j;

@Configuration
@EnableBatchProcessing
@Slf4j
public class MiscBillingOutwardBatchConfiguration {

	@Autowired
	private JobBuilderFactory jobs;
	 
    @Autowired
    private StepBuilderFactory steps;
    
	@Value("${batch.directory.misc-billing.output}")
	private String xmlDir;

	@Value("${max-threads}")
	private int maxThreads;
	
	@Autowired
    private CommonValidator commonValidator;
	
	@Autowired
	private OutwardInvoiceService outwardInvoiceService;
    
	@Autowired 
    private SmartpraMasterAppClient smartpraMasterAppClient;
	
	@Autowired
	private PlatformTransactionManager transactionManager;
	
	@Autowired
	private FileLoggingService fileLoggingService;
	
	@Bean
	public TaskExecutor taskExecutor() {
		SimpleAsyncTaskExecutor taskExecutor = new SimpleAsyncTaskExecutor();
		taskExecutor.setConcurrencyLimit(maxThreads);
		return taskExecutor;
	}

    @Bean
    public Step outwardBillingPeriodsTask() {
    	return steps.get("outwardBillingPeriodsTask")
    	        	.tasklet(new OutwardBillingPeriodTask(smartpraMasterAppClient, commonValidator, fileLoggingService))
                    .build();
    }
/*    
    @Bean
    public Step outwardFileLoggingTask() {
    	return steps.get("outwardFileLoggingTask")
    	        	.tasklet(new OutwardFileLoggingTask(fileLoggingService, commonValidator, transHeaderRepository))
                    .build();
    }
*/	
	@Bean
	public Job outwardXmlJob(OutwardJobCompletionListener listener, Step outwardBillingPeriodsTask, 
			Step generateOutwardXml) {
	  	return jobs.get("outwardXmlJob")
	  			.incrementer(new RunIdIncrementer())
	  			.listener(listener)
	  			.start(outwardBillingPeriodsTask)
	  			.next(generateOutwardXml)
	    		.build();
	}
	
	@Bean 
    public Step generateOutwardXml() {
    	return steps.get("generateOutwardXml")
    			.<List<MiscBillingTrnInvoiceEntity>, InvoiceTransmission>chunk(1)
    			.reader(invoiceReader())
    			.processor(invoiceProcessor())
    			.writer(xmlItemWriter())
                .transactionManager(transactionManager)
				.taskExecutor(taskExecutor())
				.throttleLimit(maxThreads)
				.allowStartIfComplete(true)
                .build();
    }

    @Bean
    @StepScope
    public ItemReader<List<MiscBillingTrnInvoiceEntity>> invoiceReader() {
        return new InvoiceItemReader();
    }
    
    @Bean
    @StepScope
    public ItemProcessor<List<MiscBillingTrnInvoiceEntity>, InvoiceTransmission> invoiceProcessor() {
        return new OutwardBillingProcessor();
    }
    
    @Bean
    @StepScope
    public ItemWriter<InvoiceTransmission> xmlItemWriter() {
    	NoRootStaxEventItemWriter<InvoiceTransmission> xmlFileWriter = new NoRootStaxEventItemWriter<>();
        ExecutionContext executionContext = new ExecutionContext();
        String carrierCode = commonValidator.getSysParamMap().get(MiscBillingConstants.PARAM_DEFAULT_CARRIER_NUMERIC_CODE);
        String YYYYMMPP = outwardInvoiceService.generateBillingMonthAndPeriodInYYYYMMPPFormat();
        String fileName = outwardInvoiceService.generateOutwardBillingFileName(carrierCode, YYYYMMPP);
        commonValidator.setOutwardFileName(fileName);
        log.debug("carrierCode: " + carrierCode + ", YYYYMMPP: " + YYYYMMPP + ", fileName: " + fileName);
        xmlFileWriter.setResource(new FileSystemResource(xmlDir + fileName));
        xmlFileWriter.open(executionContext);
        Map<String, Object> properties = new HashMap<>();
        properties.put(Marshaller.JAXB_SCHEMA_LOCATION, MiscBillingConstants.JAXB_SCHEMA_LOCATION);
        properties.put(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
        marshaller.setClassesToBeBound(InvoiceTransmission.class);
        marshaller.setMarshallerProperties(properties);
        xmlFileWriter.setMarshaller(marshaller);
        return xmlFileWriter;
    }
}
