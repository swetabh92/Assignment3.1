package com.sgl.smartpra.allocation.master.model;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@JsonInclude(Include.NON_NULL)
public class FlownAllocation extends AllocationMaster {

	private static final long serialVersionUID = 3547491282584797842L;

	private List<String> flightStatus;

	private List<String> flightCategory;

	private Optional<String> oal;

	private List<Optional<String>> routeCode;

	private LocalDate flightFromDate;

	private LocalDate flightToDate;

}