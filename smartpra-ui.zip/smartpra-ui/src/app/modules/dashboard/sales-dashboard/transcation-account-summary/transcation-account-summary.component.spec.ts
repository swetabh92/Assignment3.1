import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TranscationAccountSummaryComponent } from './transcation-account-summary.component';

describe('TranscationAccountSummaryComponent', () => {
  let component: TranscationAccountSummaryComponent;
  let fixture: ComponentFixture<TranscationAccountSummaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TranscationAccountSummaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TranscationAccountSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
