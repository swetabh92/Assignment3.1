package com.sgl.smartpra.allocation.master.app.entity;

import java.time.LocalDateTime;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@EqualsAndHashCode(callSuper = false)
@Data
@DynamicInsert
@DynamicUpdate
@Table(schema = "SmartPRAException", name = "exception_allocation")
public class AllocationMasterEntity extends BaseEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "exception_allocation_id")
	private Integer allocationMasterId;

	@NotNull
	@Column(name = "module_lov_id")
	private Integer moduleLovId;

	@NotNull
	@Column(name = "client_id")
	private String clientId;

	@NotNull
	@Column(name = "group_id")
	private Long groupId;

	@NotNull
	@Column(name = "team_id")
	private Long teamId;

	@Column(name = "allocation_key_1")
	private String allocationKey1;

	@Column(name = "allocation_key_2")
	private String allocationKey2;

	@Column(name = "allocation_key_3")
	private String allocationKey3;

	@Column(name = "allocation_key_4")
	private String allocationKey4;

	@Column(name = "allocation_key_5")
	private String allocationKey5;

	@Column(name = "allocation_key_6")
	private String allocationKey6;

	@Column(name = "allocation_key_7")
	private String allocationKey7;

	@Column(name = "allocation_key_8")
	private String allocationKey8;

	@PrePersist
	public void prePersist() {
		setCreatedDate(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		setLastUpdatedDate(LocalDateTime.now());
	}

}
