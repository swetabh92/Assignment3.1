package com.sgl.smartpra.batch.bsp.app.processor;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.bsp.app.domain.staging.FormOfPaymentStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.RelatedTicketDocumentInfoStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TicketDocumentIdentificationStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TransactionHeaderStg;
import com.sgl.smartpra.sales.domain.TicketOrgin;
import com.sgl.smartpra.sales.repository.TicketOrginRepository;

@Component
public class TicketOriginProcessor {
	
	@Autowired
	TicketOrginRepository ticketOrginRepository;

	List<String> admAcmCheck = Arrays.asList("ADM", "ACM", "RCS", "SPD", "SSA", "TAA");

	public Map<String, List<TicketOrgin>> process(TicketDocumentIdentificationStg ticketDocumentIdentificationStg,
			TransactionHeaderStg transactionHeaderStg, Map<String, String> ticketDoc, String user,String clientId,Map<String, String> ticketOriginGMap, Integer salesKey,Integer fileId) {
		
		Map<String, List<TicketOrgin>> ticketOriginMap = new HashMap<>();
		List<TicketOrgin> ticketOrginsTicket = new ArrayList<>();
		List<TicketOrgin> ticketOrginsNonTicket = new ArrayList<>();

		if ((!"Y".equalsIgnoreCase(ticketDoc.get("conjTicketIndicator"))) || (ticketDocumentIdentificationStg
				.getTransactionCode().contentEquals("RFND")
				&& !admAcmCheck.contains(ticketDocumentIdentificationStg.getTransactionCode().substring(0, 3)))) {
			boolean setTktDocumentInfoStgs = false;
			if (!transactionHeaderStg.getFormOfPaymentStg().isEmpty()) {
				int countOfOrigin = 0;
				for (FormOfPaymentStg formOfPaymentStg : transactionHeaderStg.getFormOfPaymentStg()) {
					TicketOrgin ticketOrgin = new TicketOrgin();
					if (formOfPaymentStg.getFopType().substring(0, 2).contentEquals("EX")) {
						setTktDocumentInfoStgs = true;
						ticketOrgin.setOrigIssueAirline(formOfPaymentStg.getFopAccountNumber().substring(0, 3));
						ticketOrgin.setOrigDocument(formOfPaymentStg.getFopAccountNumber().substring(3, 13));
						if (formOfPaymentStg.getFopAccountNumber().length() >= 14) {
							int length = 0;
							length = formOfPaymentStg.getFopAccountNumber().length();
							String origCpnNoActual = formOfPaymentStg.getFopAccountNumber().substring(14, length);
							origCpnNoActual = origCpnNoActual.replaceAll(" ", "");
							StringBuilder sb = new StringBuilder();
							for (int j1 = 0; j1 < origCpnNoActual.length(); j1++) {
								if (sb.length() > 0)
									sb.append(',');
								sb.append(origCpnNoActual.charAt(j1));
							}
							ticketOrgin.setOrigCpnNo(sb.toString());
						}
						
						ticketOrgin.setSalesKey(salesKey);
						ticketOrgin.setSerialNumber(++countOfOrigin);
						ticketOrgin.setMainDocument(ticketDoc.get("mainDocument"));
						ticketOrgin.setDocumentNo(ticketDoc.get("documentNumber"));
						ticketOrgin.setIssAirline(ticketDocumentIdentificationStg.getTktDocNumber().substring(0, 3));
						ticketOrgin.setDocumentUniqueId(ticketDoc.get("documentUniqueId"));
						ticketOrgin.setCreatedBy(user);
						ticketOrgin.setCreatedDate(new Timestamp(new Date().getTime()));
						ticketOrgin.setOutwardTrnsfrFlag("N");
						if (!ticketDocumentIdentificationStg.getTransactionCode().contentEquals("RFND")) {
							ticketOrginsTicket.add(ticketOrgin);
						}
						// TODO This ticket origin objects need to persist separate
						if (ticketDocumentIdentificationStg.getTransactionCode().contentEquals("RFND")) {
							ticketOrginsNonTicket.add(ticketOrgin);
						}

					}
				}

			}
			if (!transactionHeaderStg.getRelatedTicketDocumentInfoStg().isEmpty() && !setTktDocumentInfoStgs) {
				int count2 = 0;
				for (RelatedTicketDocumentInfoStg documentInfoStg : transactionHeaderStg
						.getRelatedTicketDocumentInfoStg()) {
					TicketOrgin ticketOrgin = new TicketOrgin();
					ticketOrgin.setOrigIssueAirline(documentInfoStg.getTktDocNumber().substring(0, 3));
					ticketOrgin.setOrigDocument(documentInfoStg.getTktDocNumber().substring(3, 13));
					String origCpnNoActual1 = documentInfoStg.getRelatedTktDocCpnIdentifier();
					origCpnNoActual1 = origCpnNoActual1.replaceAll(" ", "");
					StringBuilder sb1 = new StringBuilder();
					for (int j1 = 0; j1 < origCpnNoActual1.length(); j1++) {
						if (sb1.length() > 0)
							sb1.append(',');
						sb1.append(origCpnNoActual1.charAt(j1));
					}

					ticketOrgin.setSalesKey(salesKey);
					ticketOrgin.setOrigCpnNo(sb1.toString());
					ticketOrgin.setWaiverCode(documentInfoStg.getWaiverCode());
					ticketOrgin.setReasonMemoIssuanceCode(documentInfoStg.getReasonForMemoIssuanceCode());
					if (ticketDocumentIdentificationStg.getTransactionCode().contentEquals("RFND")) {
						String rfdDate = documentInfoStg.getDateOfIssueRelatedDocument();
						
						
						ticketDoc.put("documentUniqueIdRefund", clientId + ticketDocumentIdentificationStg.getTktDocNumber().substring(0, 3)
								+"R"
								+ ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 13)
								+ rfdDate);
						
//						System.out.println("Document uinque id for refund===============================>"+ticketDoc.get("documentUniqueIdRefund"));
						
						// RFND date
						Timestamp timeStampDate = null;
						try {
							SimpleDateFormat formatter = new SimpleDateFormat("yyMMdd");
							Date date = formatter.parse(rfdDate);
							timeStampDate = new Timestamp(date.getTime());
						} catch (ParseException e) {

						}

						ticketOrgin.setRefundDate(timeStampDate);
					}
					ticketOrgin.setSerialNumber(++count2);
					ticketOrgin.setMainDocument(ticketDocumentIdentificationStg.getTktDocNumber().substring(3, 13));
					ticketOrgin.setDocumentNo(documentInfoStg.getTktDocNumber().substring(3, 13));
					ticketOrgin.setIssAirline(ticketDocumentIdentificationStg.getTktDocNumber().substring(0, 3));
					if(ticketDoc.get("documentUniqueIdRefund") != null && !ticketDoc.get("documentUniqueIdRefund").isEmpty()) {
						ticketOrgin.setDocumentUniqueId(ticketDoc.get("documentUniqueIdRefund"));
					}else {
						ticketOrgin.setDocumentUniqueId(ticketDoc.get("documentUniqueId"));
					}
					ticketOrgin.setCreatedBy(user);
					ticketOrgin.setCreatedDate(new Timestamp(new Date().getTime()));
					ticketOrgin.setFileId(fileId);
					ticketOrgin.setOutwardTrnsfrFlag("N");
					if (!ticketDocumentIdentificationStg.getTransactionCode().contentEquals("RFND")) {
						boolean isPresntsInDB = ticketOrginRepository.findOneByDocumentUniqueIdAndOrigIssueAirlineAndOrigDocumentAndOrigCpnNo(ticketOrgin.getDocumentUniqueId(), ticketOrgin.getIssAirline(), ticketOrgin.getOrigDocument(), ticketOrgin.getOrigCpnNo()).isPresent();
						String originKey = ticketOrgin.getDocumentUniqueId()+ticketOrgin.getIssAirline()+ticketOrgin.getOrigDocument()+ticketOrgin.getOrigCpnNo();
						if(!ticketOriginGMap.containsKey(originKey) && !isPresntsInDB) {
							ticketOrginsTicket.add(ticketOrgin);
							ticketOriginGMap.put(originKey, originKey);
						}
						
					}
					if (ticketDocumentIdentificationStg.getTransactionCode().contentEquals("RFND")) {
						
						boolean isPresntsInDB = ticketOrginRepository.findOneByDocumentUniqueIdAndOrigIssueAirlineAndOrigDocumentAndOrigCpnNo(ticketOrgin.getDocumentUniqueId(), ticketOrgin.getIssAirline(), ticketOrgin.getOrigDocument(), ticketOrgin.getOrigCpnNo()).isPresent();
						String originKey = ticketOrgin.getDocumentUniqueId()+ticketOrgin.getIssAirline()+ticketOrgin.getOrigDocument()+ticketOrgin.getOrigCpnNo();
						if(!ticketOriginGMap.containsKey(originKey) && !isPresntsInDB) {
							ticketOrginsNonTicket.add(ticketOrgin);
							ticketOriginGMap.put(originKey, originKey);
						}
						
					}

				}
			}
		}
		ticketOriginMap.put("ticketOrginsTicket", ticketOrginsTicket);
		ticketOriginMap.put("ticketOrginsNonTicket", ticketOrginsNonTicket);

		return ticketOriginMap;

	}


}
