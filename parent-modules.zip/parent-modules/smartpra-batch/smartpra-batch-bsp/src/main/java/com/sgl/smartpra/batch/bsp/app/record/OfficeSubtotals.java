package com.sgl.smartpra.batch.bsp.app.record;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.sgl.smartpra.batch.bsp.app.util.BSPConstants;
import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;
import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;

public class OfficeSubtotals extends BSPBaseRecord {

	@Override
	public String getRecordType() {
		return BSPRecordType.OFFICE_SUBTOTALS_PER_TRANCODE_CURRTYPE;
	}

	// Layout of Office Sub-totals Record
	public class OfficeSubtotalsLayout extends FixedLengthRecordLayout {
		public OfficeSubtotalsLayout() {
			fixedLengthFieldLayoutList = new ArrayList<FixedLengthFieldLayout>();

			// entire line
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("line", 1, 136));

			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdMessageIdentifier", 1, 3));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("seqNumber", 4, 11));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdNumericQualifier", 12, 13));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("agentNumericCode", 14, 21));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("remittancePeriodEndDate", 22, 27));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("grossValueAmt", 28, 42));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("totalRemittanceAmount", 43, 57));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("totalCommissionValueAmt", 58, 72));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("totalTaxMiscFeeAmt", 73, 87));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("transactionCode", 88, 91));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("totalTaxOnCommissionAmt", 92, 106));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("filler", 107, 132));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("currencyType", 133, 136));
		}
	}

	@Override
	public LineTokenizer lineTokenizer(String handbookRevisionNumber) {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		OfficeSubtotalsLayout officeSubtotalsLayout = new OfficeSubtotalsLayout();
		tokenizer.setColumns(officeSubtotalsLayout.getColumns());
		tokenizer.setNames(officeSubtotalsLayout.getNames());
		return tokenizer;
	}

	@Override
	public FieldSetMapper<BSPBaseRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<BSPBaseRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<BSPBaseRecord>();
		fieldSetMapper.setTargetType(this.getClass());
		return fieldSetMapper;
	}

	// Variables to hold the record values
	private String stdMessageIdentifier;
	private String seqNumber;
	private String stdNumericQualifier;
	private String agentNumericCode;
	private String remittancePeriodEndDate;
	private String grossValueAmt;
	private String totalRemittanceAmount;
	private String totalCommissionValueAmt;
	private String totalTaxMiscFeeAmt;
	private String transactionCode;
	private String totalTaxOnCommissionAmt;
	private String filler;
	private String currencyType;
	// this is a derived value based on transactionCode
	private String transactionType;

	public String getStdMessageIdentifier() {
		return stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getSeqNumber() {
		return seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdNumericQualifier() {
		return stdNumericQualifier;
	}

	public void setStdNumericQualifier(String stdNumericQualifier) {
		this.stdNumericQualifier = stdNumericQualifier;
	}

	public String getAgentNumericCode() {
		return agentNumericCode;
	}

	public void setAgentNumericCode(String agentNumericCode) {
		this.agentNumericCode = agentNumericCode;
	}

	public String getRemittancePeriodEndDate() {
		return remittancePeriodEndDate;
	}

	public void setRemittancePeriodEndDate(String remittancePeriodEndDate) {
		this.remittancePeriodEndDate = remittancePeriodEndDate;
	}

	public String getGrossValueAmt() {
		return grossValueAmt;
	}

	public void setGrossValueAmt(String grossValueAmt) {
		this.grossValueAmt = grossValueAmt;
	}

	public String getTotalRemittanceAmount() {
		return totalRemittanceAmount;
	}

	public void setTotalRemittanceAmount(String totalRemittanceAmount) {
		this.totalRemittanceAmount = totalRemittanceAmount;
	}

	public String getTotalCommissionValueAmt() {
		return totalCommissionValueAmt;
	}

	public void setTotalCommissionValueAmt(String totalCommissionValueAmt) {
		this.totalCommissionValueAmt = totalCommissionValueAmt;
	}

	public String getTotalTaxMiscFeeAmt() {
		return totalTaxMiscFeeAmt;
	}

	public void setTotalTaxMiscFeeAmt(String totalTaxMiscFeeAmt) {
		this.totalTaxMiscFeeAmt = totalTaxMiscFeeAmt;
	}

	public String getTransactionCode() {
		return transactionCode;
	}

	public void setTransactionCode(String transactionCode) {
		this.transactionCode = transactionCode;

		// set the transaction type based on transaction code
		setTransactionTypeForTransactionCode(transactionCode);
	}

	public String getTotalTaxOnCommissionAmt() {
		return totalTaxOnCommissionAmt;
	}

	public void setTotalTaxOnCommissionAmt(String totalTaxOnCommissionAmt) {
		this.totalTaxOnCommissionAmt = totalTaxOnCommissionAmt;
	}

	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}

	public String getCurrencyType() {
		return currencyType;
	}

	public void setCurrencyType(String currencyType) {
		this.currencyType = currencyType;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	private void setTransactionTypeForTransactionCode(String transactionCode) {

		List <String> acmCheck = Arrays.asList(BSPConstants.TRANSACTION_TYPE_ACM,BSPConstants.TRANSACTION_TYPE_SPC, BSPConstants.TRANSACTION_TYPE_SSAC);
		List <String> admCheck = Arrays.asList(BSPConstants.TRANSACTION_TYPE_ADM,BSPConstants.TRANSACTION_TYPE_RCS,BSPConstants.TRANSACTION_TYPE_SSAD,
				BSPConstants.TRANSACTION_TYPE_TAA);
		
		if (transactionCode.contentEquals("RFND")) {
			setTransactionType("AR");
		}else if(acmCheck.contains(transactionCode)) {
			setTransactionType("AC");
		}else if(admCheck.contains(transactionCode)) {
			setTransactionType("AD");
		}else {
			setTransactionType("AS");
		}
//		switch (transactionCode) {
//		case "TKTT":
//		case "EMDS":
//			setTransactionType("AS");
//			break;
//		case "RFND":
//			setTransactionType("AR");
//			break;
//		case "ADMA":
//		case "SPDR":
//			setTransactionType("AD");
//			break;
//		case "ACMA":
//		case "SPCR":
//			setTransactionType("AC");
//			break;
//		}
	}
}