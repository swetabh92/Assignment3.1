package com.sgl.smartpra.batch.sales.validator.app.domain;


import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the ticket_commission_stg database table.
 * 
 */
@Entity
@Table(name="ticket_commission_stg")
public class TicketCommissionStg  implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="tkt_comm_dtl_id")
	private int tktCommDtlId;

	@Column(name="created_by")
	private String createdBy;

	@Column(name="created_date")
	private Timestamp createdDate;

	@Column(name="last_updated_by")
	private String lastUpdatedBy;

	@Column(name="last_updated_date")
	private Timestamp lastUpdatedDate;

	@Column(name="serial_no")
	private int serialNo;

	@Column(name = "aeba")
	private String aeba;

	@Column(name = "apbc")
	private String apbc;

	@Column(name = "efco")
	private String efco;

	@Column(name = "efrt")
	private String efrt;

	@Column(name = "coam")
	private String coam;

	@Column(name = "cort")
	private String cort;

	@Column(name = "spam")
	private String spam;

	@Column(name = "sptp")
	private String sptp;

	@Column(name = "sprt")
	private String sprt;

	@Column(name = "ccai")
	private String ccai;

	//bi-directional many-to-one association to TicketMainStg
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="trn_tkt_id")
	private TicketMainStg ticketMainStg;

	public TicketCommissionStg() {
	}

	public int getTktCommDtlId() {
		return this.tktCommDtlId;
	}

	public void setTktCommDtlId(int tktCommDtlId) {
		this.tktCommDtlId = tktCommDtlId;
	}

	public String getAeba() {
		return this.aeba;
	}

	public void setAeba(String aeba) {
		this.aeba = aeba;
	}

	public String getApbc() {
		return this.apbc;
	}

	public void setApbc(String apbc) {
		this.apbc = apbc;
	}

	public String getCcai() {
		return this.ccai;
	}

	public void setCcai(String ccai) {
		this.ccai = ccai;
	}

	public String getCoam() {
		return this.coam;
	}

	public void setCoam(String coam) {
		this.coam = coam;
	}

	public String getCort() {
		return this.cort;
	}

	public void setCort(String cort) {
		this.cort = cort;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getEfco() {
		return this.efco;
	}

	public void setEfco(String efco) {
		this.efco = efco;
	}

	public String getEfrt() {
		return this.efrt;
	}

	public void setEfrt(String efrt) {
		this.efrt = efrt;
	}

	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getLastUpdatedDate() {
		return this.lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public int getSerialNo() {
		return this.serialNo;
	}

	public void setSerialNo(int serialNo) {
		this.serialNo = serialNo;
	}

	public String getSpam() {
		return this.spam;
	}

	public void setSpam(String spam) {
		this.spam = spam;
	}

	public String getSprt() {
		return this.sprt;
	}

	public void setSprt(String sprt) {
		this.sprt = sprt;
	}

	public String getSptp() {
		return this.sptp;
	}

	public void setSptp(String sptp) {
		this.sptp = sptp;
	}

	public TicketMainStg getTicketMainStg() {
		return this.ticketMainStg;
	}

	public void setTicketMainStg(TicketMainStg ticketMainStg) {
		this.ticketMainStg = ticketMainStg;
	}

	

}