package com.sgl.smartpra.batch.interline.listener;

import org.springframework.batch.core.ItemReadListener;

import com.sgl.smartpra.interline.domain.entity.stg.form3.InterlineForm3CsvStg;

public class InterlineForm3CsvStgItemReaderListener implements ItemReadListener<InterlineForm3CsvStg> {

	@Override
	public void beforeRead() {
		
	}

	@Override
	public void afterRead(InterlineForm3CsvStg item) {
		
	}

	@Override
	public void onReadError(Exception ex) {
		
	}

}
