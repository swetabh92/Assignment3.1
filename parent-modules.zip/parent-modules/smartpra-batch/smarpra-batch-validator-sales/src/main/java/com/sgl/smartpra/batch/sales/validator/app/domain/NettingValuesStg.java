package com.sgl.smartpra.batch.sales.validator.app.domain;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the netting_values_stg database table.
 * 
 */
@Entity
@Table(name="netting_values_stg")
public class NettingValuesStg extends BSPRecord implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="netting_value_auto_id")
	private int nettingValueAutoId;

	@Column(name="check_digit")
	private String checkDigit;

	@Column(name="created_by")
	private String createdBy;

	@Column(name="created_date")
	private Timestamp createdDate;

	@Column(name="currency_type")
	private String currencyType;

	@Column(name="date_of_issue")
	private String dateOfIssue;

	private String filler;

	@Column(name="last_updated_by")
	private String lastUpdatedBy;

	@Column(name="last_updated_date")
	private Timestamp lastUpdatedDate;

	@Column(name="netting_amount_1")
	private String nettingAmount1;

	@Column(name="netting_amount_2")
	private String nettingAmount2;

	@Column(name="netting_amount_3")
	private String nettingAmount3;

	@Column(name="netting_amount_4")
	private String nettingAmount4;

	@Column(name="netting_code_1")
	private String nettingCode1;

	@Column(name="netting_code_2")
	private String nettingCode2;

	@Column(name="netting_code_3")
	private String nettingCode3;

	@Column(name="netting_code_4")
	private String nettingCode4;

	@Column(name="netting_type_1")
	private String nettingType1;

	@Column(name="netting_type_2")
	private String nettingType2;

	@Column(name="netting_type_3")
	private String nettingType3;

	@Column(name="netting_type_4")
	private String nettingType4;

	@Column(name="seq_number")
	private String seqNumber;

	@Column(name="std_message_identifier")
	private String stdMessageIdentifier;

	@Column(name="std_numeric_quaifier")
	private String stdNumericQuaifier;

	@Column(name="tkt_doc_number")
	private String tktDocNumber;

	@Column(name="transaction_number")
	private String transactionNumber;

	//bi-directional many-to-one association to TransactionHdrStg
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.MERGE)
	@JoinColumn(name="transaction_hdr_id")
	private TransactionHdrStg transactionHdrStg;

	public NettingValuesStg() {
	}

	public int getNettingValueAutoId() {
		return this.nettingValueAutoId;
	}

	public void setNettingValueAutoId(int nettingValueAutoId) {
		this.nettingValueAutoId = nettingValueAutoId;
	}

	public String getCheckDigit() {
		return this.checkDigit;
	}

	public void setCheckDigit(String checkDigit) {
		this.checkDigit = checkDigit;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCurrencyType() {
		return this.currencyType;
	}

	public void setCurrencyType(String currencyType) {
		this.currencyType = currencyType;
	}

	public String getDateOfIssue() {
		return this.dateOfIssue;
	}

	public void setDateOfIssue(String dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}

	public String getFiller() {
		return this.filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}

	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getLastUpdatedDate() {
		return this.lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getNettingAmount1() {
		return this.nettingAmount1;
	}

	public void setNettingAmount1(String nettingAmount1) {
		this.nettingAmount1 = nettingAmount1;
	}

	public String getNettingAmount2() {
		return this.nettingAmount2;
	}

	public void setNettingAmount2(String nettingAmount2) {
		this.nettingAmount2 = nettingAmount2;
	}

	public String getNettingAmount3() {
		return this.nettingAmount3;
	}

	public void setNettingAmount3(String nettingAmount3) {
		this.nettingAmount3 = nettingAmount3;
	}

	public String getNettingAmount4() {
		return this.nettingAmount4;
	}

	public void setNettingAmount4(String nettingAmount4) {
		this.nettingAmount4 = nettingAmount4;
	}

	public String getNettingCode1() {
		return this.nettingCode1;
	}

	public void setNettingCode1(String nettingCode1) {
		this.nettingCode1 = nettingCode1;
	}

	public String getNettingCode2() {
		return this.nettingCode2;
	}

	public void setNettingCode2(String nettingCode2) {
		this.nettingCode2 = nettingCode2;
	}

	public String getNettingCode3() {
		return this.nettingCode3;
	}

	public void setNettingCode3(String nettingCode3) {
		this.nettingCode3 = nettingCode3;
	}

	public String getNettingCode4() {
		return this.nettingCode4;
	}

	public void setNettingCode4(String nettingCode4) {
		this.nettingCode4 = nettingCode4;
	}

	public String getNettingType1() {
		return this.nettingType1;
	}

	public void setNettingType1(String nettingType1) {
		this.nettingType1 = nettingType1;
	}

	public String getNettingType2() {
		return this.nettingType2;
	}

	public void setNettingType2(String nettingType2) {
		this.nettingType2 = nettingType2;
	}

	public String getNettingType3() {
		return this.nettingType3;
	}

	public void setNettingType3(String nettingType3) {
		this.nettingType3 = nettingType3;
	}

	public String getNettingType4() {
		return this.nettingType4;
	}

	public void setNettingType4(String nettingType4) {
		this.nettingType4 = nettingType4;
	}

	public String getSeqNumber() {
		return this.seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdMessageIdentifier() {
		return this.stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getStdNumericQuaifier() {
		return this.stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getTktDocNumber() {
		return this.tktDocNumber;
	}

	public void setTktDocNumber(String tktDocNumber) {
		this.tktDocNumber = tktDocNumber;
	}

	public String getTransactionNumber() {
		return this.transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

	public TransactionHdrStg getTransactionHdrStg() {
		return this.transactionHdrStg;
	}

	public void setTransactionHdrStg(TransactionHdrStg transactionHdrStg) {
		this.transactionHdrStg = transactionHdrStg;
	}
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

/*	@Override
	public LineTokenizer lineTokenizer() {

		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		NettingValuesStgLayout nettingValuesStgLayout = new NettingValuesStgLayout();
		tokenizer.setColumns(nettingValuesStgLayout.getColumns());
		tokenizer.setNames(nettingValuesStgLayout.getNames());
		return tokenizer;

	}

	@Override
	public FieldSetMapper<BSPRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<BSPRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<BSPRecord>();
		fieldSetMapper.setTargetType(NettingValuesStg.class);
		return fieldSetMapper;
	}

	@Override
	public ItemProcessor<? extends BSPRecord, ? extends BSPRecord> processor() {
		return new NettingValuesStgProcessor();
	}

	@Override
	public ItemWriter<? super BSPRecord> writer() {
		return new NettingValuesStgWriter();
	}*/

}