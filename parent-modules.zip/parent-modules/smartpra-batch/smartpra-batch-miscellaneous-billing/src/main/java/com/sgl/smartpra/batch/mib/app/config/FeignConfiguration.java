package com.sgl.smartpra.batch.mib.app.config;

import java.math.BigInteger;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.sgl.smartpra.batch.global.model.FileLogging;
import com.sgl.smartpra.currency.model.CurrencyRate;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.global.master.model.Airport;
import com.sgl.smartpra.global.master.model.Carrier;
import com.sgl.smartpra.global.master.model.ChargeCategory;
import com.sgl.smartpra.global.master.model.ChargeCode;
import com.sgl.smartpra.global.master.model.ChargeCodeType;
import com.sgl.smartpra.global.master.model.Country;
import com.sgl.smartpra.global.master.model.Dictionary;
import com.sgl.smartpra.global.master.model.Section;
import com.sgl.smartpra.global.master.model.SectionDto;
import com.sgl.smartpra.master.model.FinancialMonthModel;
import com.sgl.smartpra.master.model.ListOfValues;
import com.sgl.smartpra.master.model.OutwardBillingPeriods;
import com.sgl.smartpra.master.model.SystemParameter;

@Configuration
public class FeignConfiguration {

	@FeignClient(value = "smartpra-batch-global-app")
	public interface BatchGlobalFeignClient {

		@PostMapping("/filelog")
		public FileLogging createFileLog(@Valid @RequestBody FileLogging fileLog);

		@GetMapping("/filelogs/filename/{fileName}")
		public List<FileLogging> getFileLogByFileName(@PathVariable(value = "fileName") String fileName);

		@GetMapping("/filelog/{fileId}")
		public FileLogging getFileLogByFileId(@PathVariable(value = "fileId") BigInteger fileId);

		@PutMapping("/filelog/{fileId}")
		public FileLogging updateFileLog(@PathVariable(value = "fileId") BigInteger fileId,
				@Valid @RequestBody FileLogging fileLog);
	}
	
	@FeignClient(value = "smartpra-master-app")
	public interface SmartpraMasterAppClient {

		@GetMapping("/system-parameters-with-date/{parameterName}")
		public List<SystemParameter> getSystemParameterByparameterName(
				@PathVariable(value = "parameterName") String parameterName);
		
		@GetMapping("/system-parameters-with-date/clientId/{clientId}/parameterName/{parameterName}")
		public SystemParameter getSystemParameterByparameterNameAndClientId(
				@PathVariable(value = "parameterName") String parameterName,
				@PathVariable(value = "clientId") String clientId);
		
		@GetMapping("/listofvalues/{clientId}/{tableName}/{columnName}/{fieldValue}")
		public ListOfValues getListOfValues(@PathVariable(value = "clientId", required = true) String clientId,
				@PathVariable(value = "tableName", required = true) String tableName,
				@PathVariable(value = "columnName", required = true) String columnName,
				@PathVariable(value = "fieldValue", required = true) String fieldValue);
		
		@GetMapping("/system-parameters-with-date/clientId/parameterNames")
		public List<SystemParameter> getSystemParameterByparameterNameAndClientId(
				@RequestParam(value = "clientId", required = true) String clientId,
				@RequestParam(value = "parameterNames", required = true) List<String> parameterNames);
		
		@GetMapping("charge-categories/{chargeCategoryCode}")
		public Carrier getCarrierByCarrierCode(@PathVariable(value = "carrierCode") String carrierCode);

		@GetMapping("/billing-period/billing-month-periods/{billingMonth}/{billingPeriod}")
		public List<OutwardBillingPeriods> getOutwardBillingPeriodsUsingBillingMonthAndBillingPeriodV(
				@PathVariable(value = "billingMonth", required = true) String billingMonth,
				@PathVariable(value = "billingPeriod", required = true) Integer billingPeriod);
		
		@GetMapping("/billing-period/current-open")
		public OutwardBillingPeriods getCurrentOpenOutwardBillingPeriods(
				@RequestParam(value = "clientId", required = false) String clientId);
		
		@GetMapping("/financial-month/current-open")
		public FinancialMonthModel getCurrentOpenFinancialMonthForFinancialCalendar(
				@RequestParam(value = "clientId", required = false) String clientId);
	}

	@FeignClient(value = "smartpra-global-master-app")
	public interface SmartpraGlobalMasterAppClient {

		@GetMapping("charge-category-name/{chargeCategoryName}")
		public ChargeCategory getChargeCategoryByChargeCategoryName(@PathVariable(value = "chargeCategoryName") String chargeCategoryName);
		
		@GetMapping("/airports/{airportCode}/validate")
		public boolean isValidAirportCodeOrCityCode(@PathVariable(value = "airportCode") String airportCode);

		@GetMapping("/airports/{airportCode}")
		public Airport getAirportByAirportCode(@PathVariable(value = "airportCode") String airportCode);

		@GetMapping("/carriers/{carrierCode}")
		public Carrier getCarrierByCarrierCode(@PathVariable(value = "carrierCode") String carrierCode);

		@GetMapping("charge-categories/{chargeCategoryCode}")
		public ChargeCategory getChargeCategoryByChargeCategoryCode(
				@PathVariable(value = "chargeCategoryCode") String chargeCategoryCode) ;

		@GetMapping("/charge-categories/{chargeCategoryCode}/charge-codes/{chargeCode}")
		public ChargeCode getChargeCodeByChargeCode(
				@PathVariable(value = "chargeCategoryCode") String chargeCategoryCode,
				@PathVariable(value = "chargeCode") String chargeCode);

		@GetMapping("/chargeCodeType/{chargeCodeCategory}/{chargeCode}/{chargeCodeType}")
		public ChargeCodeType getAllChargeCodeTypeByChargeCodeType(
				@Valid @PathVariable(value = "chargeCodeCategory") String chargeCodeCategory,
				@Valid @PathVariable(value = "chargeCode") String chargeCode,
				@Valid @PathVariable(value = "chargeCodeType") String chargeType);
		
		@GetMapping("/charge-categories")
		public List<ChargeCategory> getAllChargeCategory(
				@RequestParam(value = "chargeCategoryCode", required = false) Optional<String> chargeCategoryCode,
				@RequestParam(value = "chargeCategoryName", required = false) Optional<String> chargeCategoryName,
				@RequestParam(value = "activate", required = false) Optional<Boolean> activate);
		
		@GetMapping("/charge-categories/{chargeCategoryCode}/charge-codes")
		public List<ChargeCode> getAllChargeCode(
				@PathVariable(value = "chargeCategoryCode", required = true) String chargeCategoryCode,
				@RequestParam(value = "chargeCode", required = false) Optional<String> chargeCode,
				@RequestParam(value = "chargeCodeName", required = false) Optional<String> chargeCodeName);
		
		@GetMapping("/charge-codes")
		public List<ChargeCode> getAllChargeCodesFromChargeCategory(
				@RequestParam(value = "chargeCategoryCode", required = true) String chargeCategoryCode);
		
		@GetMapping("/airports")
	    public List<Airport> getAllAirport(@RequestParam(name = "airportCode", required=false) String airportCode,
	    		@RequestParam(name = "airportName", required=false) String airportName,
				@RequestParam(name = "cityCode", required=false) String cityCode,
				@RequestParam(name = "cityName", required=false) String cityName,
				@RequestParam(name = "countryCode", required=false) String countryCode);
		
		@GetMapping("/dictionary")
		public List<Dictionary> getDictionaryByElementdefine(
				@RequestParam(value = "elementName" , required = false) String elementName,
				@RequestParam(value = "dictionaryDefine" , required = false) String dictionarydefine);
		
		@GetMapping("/charge-codes/sections")
		public List<Section> getSectionByChargeCode(@RequestParam(value = "chargeCode", required = true) String chargeCode);

		@GetMapping("/section/details")
		public List<SectionDto> fetchSectionByChargeCode(@RequestParam(value = "chargeCode", required = true) String chargeCode);
		
		@GetMapping("/chargeCodeType")
		public List<ChargeCodeType> getAllChargeCodeTypeByCodeandCat(
				@RequestParam(value = "chargeCode" , required = false) Optional<String> chargeCode,
				@RequestParam(value = "chargeCatCode" , required = false) Optional<String> chargeCatCode);
		
		@GetMapping("/countries")
		public List<Country> getListOfCountries(@RequestParam(value = "countryCode", required = false) String countryCode,
				@RequestParam(value = "countryName", required = false) String countryName);

	}

	@FeignClient(value = "smartpra-exception-transaction-integration")
	public interface SmartpraExceptionTransIntgAppClient {
		@PostMapping("/api/init-exceptionmessage")
		public void initExceptionTrasaction(@RequestBody ExceptionTransactionModel exceptionTransactionModel);
		
	}
	
	@FeignClient(value = "smartpra-currency-master-app")
	public interface SmartpraCurrencyMasterAppClient {

		@GetMapping("/currency/{currencyRateType}/{currencyFromCode}/{currencyToCode}/{effectiveDate}")
		public CurrencyRate getEffectiveCurrencyRate(
				@PathVariable(value = "currencyRateType", required = true) String currencyRateType,
				@PathVariable(value = "currencyFromCode", required = true) String currencyFromCode,
				@PathVariable(value = "currencyToCode", required = true) String currencyToCode,
				@PathVariable(value = "effectiveDate", required = true) String effectiveDate); // "yyyy-MM-dd"
	}
}
