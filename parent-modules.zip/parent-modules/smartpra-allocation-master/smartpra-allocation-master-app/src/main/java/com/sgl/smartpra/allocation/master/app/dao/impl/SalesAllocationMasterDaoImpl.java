/*package com.sgl.smartpra.allocation.master.app.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.sgl.smartpra.allocation.master.app.dao.SalesAllocationMasterDao;
import com.sgl.smartpra.allocation.master.app.entity.SalesAllocationEntity;
import com.sgl.smartpra.allocation.master.app.dao.repository.SalesAllocationRepository;

public class SalesAllocationMasterDaoImpl implements SalesAllocationMasterDao {

	@Autowired
	SalesAllocationRepository salesAllocationRepository;
	
	@Override
	public SalesAllocationEntity create(SalesAllocationEntity salesAllocationEntity) {
		return salesAllocationRepository.save(salesAllocationEntity);
	}

	@Override
	public SalesAllocationEntity update(SalesAllocationEntity salesAllocationEntity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<SalesAllocationEntity> findById(Integer allocationMasterId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<SalesAllocationEntity> findAll(List<Integer> fileMappingId) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public SalesAllocationEntity assignAllocation(AllocationMasterSearchModel allocationMasterSearchModel){
		
		return salesAllocationRepository.findAll(SalesAllocationSpecification.search(allocationMasterSearchModel));
		
	}

}
*/