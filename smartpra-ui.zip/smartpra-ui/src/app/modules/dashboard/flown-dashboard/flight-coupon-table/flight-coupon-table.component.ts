import { Component, OnInit,OnDestroy,ElementRef,ViewChild,HostListener,Input,Output,EventEmitter } from '@angular/core';
import { FormBuilder,FormGroup, Validators } from '@angular/forms';
import {PaginationService} from '../../../../commons/services/pagination/pagination.service';
import {couponStatusList,CouponListModel,paxType,cabin} from '../model/flown-model';
import {FlownService} from '../services/flown.service';
import { DatatableComponent } from "@swimlane/ngx-datatable";
import { MessageBoxService} from '../../../masters/services/commons/message-box.service'
import {timer} from 'rxjs';
import { Subscription } from 'rxjs/Subscription';
import { HotkeyService ,Command} from '../services/hotkey.service';
import swal from 'sweetalert2';
import { DateFormatService } from '../../../../commons/services/date-format/date-format.service';
@Component({
  selector: 'app-flight-coupon-table',
  templateUrl: './flight-coupon-table.component.html',
  styleUrls: ['./flight-coupon-table.component.css']
})
export class FlightCouponTableComponent implements OnInit,OnDestroy  {
  subscription: Subscription;
  editRow:boolean = false;
  viewticketQuery:boolean = false; 
  cpnStatus = couponStatusList;
  paxType = paxType;
  flownCabin = cabin;
  selectedCouponList:CouponListModel[] = [];  
  selectedCoupon:CouponListModel;
  editing = {};
  couponList:CouponListModel[] = [];
  selectionRadio = false;
  couponModeltype:string;
  focusElement:boolean = true;
  systemDateFormat = this.dateFormatService.getAngularPipeDateFormat();
  currencyCode = this.flownService.currencyCode;
  /*flowncoupon add */
  submitted:boolean = false;
  addEditForm:FormGroup;
  flownRBD:any = [] ;
  scrollDocumentQuery:boolean = false;
  @ViewChild('statusPopup') statusPopup: ElementRef;
  @ViewChild('statusParent') statusParent: ElementRef;
  @ViewChild('closeModal') closeModal: ElementRef;

  @ViewChild('couponTable') couponTable: DatatableComponent;
  @Output() update = new EventEmitter();
  @Input('values')
  set values(values:CouponListModel){
    if(Array.isArray(values)) {
      this.selectedCouponList = [];
      this.couponList = this.mappingStatus(this.trimKeys(values));
      // console.log(this.couponList)
      
    }   
  }
  @HostListener('document:click', ['$event.target'])
  public outsideClick(targetElement) {
    if(!(targetElement.classList.contains("status-indicator-icon") || this.statusPopup.nativeElement.contains(targetElement))){
      this.statusPopup.nativeElement.style.display ='none';
    }
  }
  page: any = this.paginateService.getPageinateConfig();
  constructor(private dateFormatService:DateFormatService,private hotkeyService:HotkeyService,private messageBoxService:MessageBoxService,private flownService:FlownService,private paginateService: PaginationService,private formBuilder:FormBuilder) { }
  ngOnInit() {
    this.addEditForm = this.createForm();
    this.subscription = this.hotkeyService.commands.subscribe(c => {
      this.handleCommand(c)
    });
  }
  handleCommand(command: Command) {
    if(command.module != 'FlightCouponTableComponent') return false;
    console.log(command.module)
    switch (command.name) {
      case 'FlightCouponTableComponent.save': {
        this.formAction('submit');
         break;
      } 
      case 'FlightCouponTableComponent.clear': {
        this.formReset();
        break;
      }  
      case 'FlightCouponTableComponent.cancel': {
        this.closeModal.nativeElement.click();
        this.resetHotKeyModule();
        break;
      }
    }
  }
  
 resetHotKeyModule(){
  this.hotkeyService.resetHotKeyModule(); 
 }
 getEditRbdList(){
  this.editing["reportedFlownRbd"]="";
  let val = this.editing["reportedFlownCabin"]?this.editing["reportedFlownCabin"]:this.selectedCouponList[0].reportedFlownCabin;
  this.flownRBD = this.flownService.cabinRbdList[val]; 
 }
 getRbdList($event){
      let cabinVal = $event.target.value;
      this.flownRBD = this.flownService.cabinRbdList[cabinVal]; 
      const ctrl = this.addEditForm.get('reportedFlownRbd');
      ctrl.setValue("");
      if(this.addEditForm.value.reportedFlownCabin == "") ctrl.disable();
      else  ctrl.enable();
 }
  generateRBD(){
    let rbd:any = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
     return rbd.split("").map((val)=>{
        return {
          key:val,
          value:val
        }
    });
  }

  nullToString(val){
    if(val == null) return "";
    else return val;
  }
  trimKeys(arr){
    arr.map((item)=>{
      item['reportedFlownRbd'] = this.nullToString(item['reportedFlownRbd']); 
      item['reportedFlownCabin'] = this.nullToString(item['reportedFlownCabin']);
      item['passengerType'] = this.nullToString(item['passengerType']);
      item['etktIndicator'] = this.nullToString(item['etktIndicator']);
      item['etktIndicator'] = item['etktIndicator'].trim();
      item['etktIndicator'] = item['etktIndicator'] == "E"?"Y":item['etktIndicator'];
      item['reportedFlownRbd'] = item['reportedFlownRbd'].trim();
      return item;
    })
    return arr;
  }
  get cf(){
    return this.addEditForm.controls;
  }
  onSelect(event,type?:string,inputevent?:any){
    if(type =='all' && event.selected) {
      this.selectedCouponList = event.selected;
    }
    else {
      if(this.selectionRadio) {
        this.editing = {};
        this.getEditRbdList();
        if(inputevent && inputevent.target.checked) { this.selectedCouponList = [event];this.selectedCoupon = event; if(this.viewticketQuery) this.triggerScroll();}
        else { this.selectedCouponList = [];this.selectedCoupon = undefined;}
      }
      else {
        let ind = this.selectedCouponList.findIndex(item => item['flownCpnId'] == event['flownCpnId']);
        if(ind === -1) this.selectedCouponList.push(event);else this.selectedCouponList.splice(ind,1);
      }
    }
  }
  iconErrAlert(){
    let title  = "Please select any coupon to proceed!"
    this.messageBoxService.getWarningMessage(title,"");
  }
  /*edit coupon */
  updateValue(event,name) {
    this.editing[name] = event.target.value;
  }
  editCoupon(){
    if((this.selectedCouponList.length == 0  || this.selectedCouponList.length>1) && !this.editRow){
      this.iconErrAlert();
      return false;
    } 
    this.editRow = !this.editRow;
    if(!this.viewticketQuery) this.selectionRadio = !this.selectionRadio;
    if(this.editRow) {
      this.viewticketQuery = false;
      this.selectedCoupon = this.selectedCouponList[0];
      this.flownRBD = [];
      this.getEditRbdList();
    }   
  }
  deleteCoupon(){
    if(this.selectedCouponList.length == 0){
      this.iconErrAlert();
      return false;
    } 
    let deleteList = this.selectedCouponList.map((item)=>{
      return {
        "documentUniqueId"  : item['documentUniqueId'],
        "couponNumber"      : item['couponNumber'],
        "couponStatus"      : item['couponStatus'],
        "flownCpnId"        : item['flownCpnId'],
        "outwardTrnsfrFlag": item['outwardTrnsfrFlag'],
        "glExtractDate"    : item['glExtractDate'],
        "reversalIndicator": item['reversalIndicator'],
        "prorationSourceInd": item['prorationSource'],
        "flightKey"   : item['flightKey']
      } 
    })
    this.messageBoxService.deleteRecordMessage(deleteList.length).then((result) => {
			if (result.value) {
        this.flownService.deleteCoupon(deleteList).subscribe((res:any)=>{
          if(res > 0){
             let success = {
               isSuccess: true,
               successMessage: "Coupons has been successfully deleted.",
               action:"delete",
               count:deleteList.length
             }
             this.update.emit(success);
          }
        })
			}
		});
  }
  couponReopen(){
    if(this.selectedCouponList.length == 0){
      this.iconErrAlert();
      return false;
    } 
    let repenList = this.selectedCouponList.map((item)=>{
      return {
        "documentUniqueId"  : item['documentUniqueId'],
        "couponNumber"      : item['couponNumber'],
        "couponStatus"      : item['couponStatus'],
        "flownCpnId"        : item['flownCpnId'],
        "outwardTrnsfrFlag": item['outwardTrnsfrFlag'],
        "glExtractDate"    : item['glExtractDate'],
        "reversalIndicator": item['reversalIndicator'],
        "prorationSourceInd": item['prorationSource'],
        "flightKey"   : item['flightKey']
      } 
   })
    swal({
      type: 'warning',
      title: "Are you sure you want to reopen this coupons?",
      text: repenList.length+" item selected!",
      showCancelButton: true,
      confirmButtonColor: '#ff0000',
      cancelButtonColor: '#049F0C',
      confirmButtonText: "Yes, process it",
      cancelButtonText: 'No, keep it!',
      closeOnClickOutside: false,
      closeOnEsc: false,
      allowOutsideClick: false,
      customClass: 'Custom_Cancel',
    } as any).then((result)=>{
      if (result.value) {
        this.flownService.couponReopen(repenList).subscribe((res:any)=>{
          if(res > 0){
            let success = {
              isSuccess:true,
              successMessage: "Coupons has been reopened successfully.",
              action:"refresh",
            }
            this.update.emit(success); 
          }
        })
      }
    });
  }
  holdOnCoupons(){
    if(this.selectedCouponList.length == 0){
      this.iconErrAlert();
      return false;
    } 
    let holdOnList = this.selectedCouponList.map((item)=>{
      return {
        "documentUniqueId"  : item['documentUniqueId'],
        "couponNumber"      : item['couponNumber'],
        "couponStatus"      : item['couponStatus'],
        "flownCpnId"        : item['flownCpnId'],
        "outwardTrnsfrFlag": item['outwardTrnsfrFlag'],
        "glExtractDate"    : item['glExtractDate'],
        "reversalIndicator": item['reversalIndicator'],
        "prorationSourceInd": item['prorationSource'],
        "flightKey"   : item['flightKey']
      }
   })
    swal({
      type: 'warning',
      title: "Are you sure you want to hold on this coupons?",
      text: holdOnList.length+" item selected!",
      showCancelButton: true,
      confirmButtonColor: '#ff0000',
      cancelButtonColor: '#049F0C',
      confirmButtonText: "Yes, process it",
      cancelButtonText: 'No, keep it!',
      closeOnClickOutside: false,
      closeOnEsc: false,
      allowOutsideClick: false,
      customClass: 'Custom_Cancel',
    } as any).then((result)=>{
      if (result.value) {
        this.flownService.holdOnCoupons(holdOnList).subscribe((res:any)=>{
          if(res > 0){
            let success = {
              isSuccess:true,
              successMessage: "Successfully coupons on hold.",
              action:"refresh",
            }
            this.update.emit(success); 
          }
        })
      }
    });
  }
  openTicketQuery(){
    if((this.selectedCouponList.length == 0  || this.selectedCouponList.length>1) && !this.viewticketQuery){
      this.iconErrAlert();
      return false;
    } 
    if(!this.editRow) this.selectionRadio = !this.selectionRadio;
    this.viewticketQuery = !this.viewticketQuery;
    if(this.viewticketQuery){
      this.editRow = false;
      this.triggerScroll();
      this.selectedCoupon = this.selectedCouponList[0]
    } 
    //window.open("http://localhost:4200/#/ticketquery", "myWindow", "width=1200,height=600");
  //myWindow.document.write("<p>This is 'myWindow'</p>");
  }
  updateCoupon(){
    let ind = this.couponList.findIndex(item => item['flownCpnId'] == this.selectedCoupon['flownCpnId']);
    let editing = Object.assign({},this.couponList[ind],this.editing);
    editing["eTktIndicator"] = editing["etktIndicator"];
    this.flownService.editCoupon(editing).subscribe((res:any)=>{
      if(res == 1){
         let success = {
           isSuccess: true,
           successMessage: "Record has been successfully saved",
           action:"update",
         }
         Object.assign(this.couponList[ind],this.editing);
        this.update.emit(success);
       }
       this.resetEdit();
    })
  }
 
  isEdit(row){
    return this.editRow && this.selectedCoupon && (this.selectedCoupon['flownCpnId'] ==row['flownCpnId']);
  }
  
  onSort(){
    //this.resetEdit();
  }
 
  resetEdit(){
    this.selectionRadio = this.editRow = false;this.editing = {};
  }

  
  /*add coupon */
  createForm(){
    return this.formBuilder.group({
      flightNumber     : [''],
      flightDate       : [''],
      toAirport         : [''], 
      fromAirport      : [''],
      issueAirline	   : ['',[Validators.required]],
      documentNumber	 : ['',[Validators.required, Validators.minLength(10)]],
      couponNumber	   : ['',[Validators.required]],
      reportedFlownCabin : ['',[Validators.required]],
      reportedFlownRbd	 : [''],
      passengerType    : [''],
      issueDate        : ['',[Validators.required]] ,
      flightKey        :[''],
      eTktIndicator   : [''],
      createdBy       :['Manual']
    });
  }
  formAction(type){
    if(type=='submit') {
      this.submitted = true;
      if(this.addEditForm.valid) {
        this.flownService.addCoupon(this.addEditForm.value).subscribe((res:any)=>{
           if(res && res.flownCpnId){
              this.closeModal.nativeElement.click(); 
              this.resetHotKeyModule();
              let success = {
                isSuccess: true,
                successMessage: "Record has been successfully saved",
                action:"add",
              }

              this.update.emit(success);
            }
         })
      
      }
    }
    else if(type == 'clear') this.formReset();
  }
  setHotKeyModule(){
    this.hotkeyService.hotKeyModule = 'FlightCouponTableComponent';
  }
  formReset(){
    this.flownRBD = [];
    this.focusElement = this.submitted = false;
    this.addEditForm = this.createForm();
    this.flownService.viewFlown["fromAirport"] = this.flownService.viewFlown["departure"];
    this.flownService.viewFlown["toAirport"] = this.flownService.viewFlown["arrival"];
    delete this.flownService.viewFlown["issueDate"];
    this.addEditForm.patchValue(this.flownService.viewFlown);
    setTimeout(()=>{
      this.focusElement = true;
    },200)
  }

  statusOpen(e){
    this.statusPopup.nativeElement.style.display ='block';
     let parent = this.statusParent.nativeElement.getBoundingClientRect();
     let child = e.target.getBoundingClientRect();
     let popup = this.statusPopup.nativeElement.getBoundingClientRect();
     let pos = { top: (child.top-parent.top-136) , left: (child.left-parent.left-popup.width+15)};
     this.statusPopup.nativeElement.style.left = pos.left+'px';
     this.statusPopup.nativeElement.style.top = pos.top+'px';
  }
  resetSelection(){
    this.editing={};this.selectedCouponList = [];this.selectedCoupon = undefined;    
  }
  triggerScroll(){
    this.scrollDocumentQuery = true;
    timer(10).subscribe(()=>{
      this.scrollDocumentQuery = false;
    })
  }
  convertDecimal(val){
    if(val == null) val = 0;
    return val.toFixed(this.flownService.currencyDecimalPression);
  }
  ngOnDestroy() { 
    this.subscription.unsubscribe();
  }
  developmentProgressIcon(){
    let title  = "Development in Progress . . ."
    this.messageBoxService.getWarningMessage(title,"");
  }

  mappingStatus(arr) {
    arr.forEach((couponList) => {
      couponList["statusIndicators"].forEach((item) => {
        couponList[item["statusName"]] = item["value"];
      });
      return couponList;
    })
    return arr;
  }
  
  
}
