import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MiscellaneousBillingComponent } from './miscellaneous-billing/miscellaneous-billing.component';

const routes: Routes = [
  {path:'',component:MiscellaneousBillingComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MiscellaneousBillingRoutingModule { }
