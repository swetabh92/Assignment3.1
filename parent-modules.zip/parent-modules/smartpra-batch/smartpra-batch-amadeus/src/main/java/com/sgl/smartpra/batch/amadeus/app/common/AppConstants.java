package com.sgl.smartpra.batch.amadeus.app.common;

public class AppConstants {

	public static final String FILETYPE_IDENTIFICATION_STRING_ETL = "E_TKT_LIFT";

	public static final String FILETYPE_IDENTIFICATION_STRING_EMD = "EMD_LIFT";

	public static final String CREATED_BY = "Amadeus";

	public static final String FILE_SOURCE_EMD = "EMD";

	public static final String FILE_SOURCE_ETL = "ETL";

	public static final String STATUS_PRODUCTION = "RV";

	public static final String STATUS_PRODUCTION_ERROR = "EV";

	public static final String STG_STATUS_LOADED = "N";

	public static final String STG_STATUS_ERROR = "E";

	public static final String STG_STATUS_TRANSFERRED = "Y";

	public static final String EMD_Version_01_01 = "EMD_LIFT  V01.01";

	public static final String EMD_Version_01_00 = "EMD_LIFT  V01.00";

	public static final String EMD_Version_01_03 = "EMD_LIFT  V01.03";

	public static final String ETL_Version_2_20 = "E_TKT_LIFTV02.20";

	public static final String ANCILLARY_SERVICE = "R";

	public static final String MULTI_UPLIFT_FLAG = "N";

	public static final String PASSENGER_TYPE = "C";

	public static final String COUPON_STATUS = "RV";

	public static final String USAGE_TYPE_P = "P";

	public static final String ETICKET_INDICATOR_DEFAULT = "E";

	public static final String DOCUMENT_TYPE_EMD = "EMD";

	public static final String EMD_INDICATOR_DEFAULT = "Y";

	public static final String DDMMYY_FORMAT = "ddMMyy";

	public static final String YYYYMMDD_FORMAT = "yyyyMMdd";

	public static final String CONJ_TICKET_INDICATOR_YES = "Y";

	public static final String CONJ_TICKET_INDICATOR_NO = "N";

	public static final String MIGRATED_TICKET_DEFAULT = "N";

	public static final String REPORTED_FARE_IT = "IT";

	public static final String REPORTED_FARE_BT = "BT";

	public static final String REPORTED_FARE_BL = "BL";

	public static final String MARKETING_FLIGHT_NUMBER_DEFAULT = "0";

	public static final String COUPON_USE_IND = "F";

	public static final String PRIME_REISSUE_R = "R";

	public static final String PRIME_REISSUE_P = "P";

	public static final String DD_MM_YY_FORMAT = "ddMMyy";

	public static final String YYYY_MM_DD_FORMAT = "yyyyMMdd";

	public static final String INVALIDATE_DATE_FORMAT = "Invalid date Format";

	public static final String PARAM_DEFAULT_CARRIER_NUMERIC_CODE = "DEFAULT_CARRIER_NUMERIC_CODE";
	
	

	public static final String PARAM_DEFAULT_CARRIER_ALPHA_CODE = "DEFAULT_CARRIER_ALPHA_CODE";

	public static final String PARAM_FLIGHT_NUMBER_OPTION = "FLIGHT_NUMBER_OPTION";

	public static final String USAGE_TYPE_F = "F";

	public static final String FLOWN_COUPON_F = "F";
	
	public static final String FLOWN_COUPON_U = "U";

	public static final String IS_VALIDATED = "N";

	public static final Integer COUPON_NUMBER = 4;

	public static final Integer COUPON_LENGTH = 62;

	public static final Integer COUPON_LENGTH_EMD = 95;

	public static final String SURSECTOR_MARKETTING_CARRIER = "/-";

	public static final String EMD_INDICATOR = "Y";

	public static final String FF_INDICATOR_DEFAULT = "N";

	public static final String CODE_SHARE_INDICATOR_DEFAULT = "N";

	public static final String FIRST_TIME_PROCESSED_DEFAULT = "Y";

	public static final String REVENUE_FLAG_DEFAULT = "N";

	public static final String OPEN = "OPEN";

	public static final String FLIGHT_DATE_OPEN = "OPEN";

	public static final String REPORTED_FARE_NO_FARE = "NOFARE";

	public static final String REPORTED_FARE_BULK = "BULK";
	
	public static final String COUPON_NUMBER_01 = "01";
	
	public static final String REPORTING_TYPE_AGENCY = "9999999";
	
	public static final String REPORTING_TYPE_AGENCY_TYPE = "G";
	
	public static final String DEFAULTY_CITY_CODE = "111";
	
	public static final String ONEWORLD_MIGRATION_PERIOD="ONEWORLD_MIGRATION_PERIOD";
	
	public static final String DOCUMENT_TYPE_PAX="PAX";
	
	public static final String PROCESSED_REQUEST_FLAG="Y";
	
	public static final String COUPON_TYPE="U";
	
	public static final String REQUEST_TYPE_OUT="O";
	
	public static final String DATA_SOURCE_AUTOMATED="A";
	
	public static final String MULTI_COUPON_ID = "0";
	
	public static final String ALLIANCE_NAME_OWC = "OWC";
	
	public static final String FLAG_Y="Y";
	
	public static final String FLAG_N="N";
	
	public static final String PRORATION_METHOD_DEFAULT="N";
	
	public static final String SALES_PROCESS_INDICATOR_N="N";
	
}
