import { Component, OnInit, ViewChild, ElementRef, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { RouteCodeMasterService } from '../../../services/flown/route-code-master/route-code-master.service';
import { GeneralService } from '../../../../../commons/services/general.service';
import { RouteCode } from '../../../models/flown/route-code';
import { MessageBoxService } from '../../../services/commons/message-box.service';
import { PaginationService } from '../../../../../commons/services/pagination/pagination.service';
import { HotkeysService } from 'angular2-hotkeys/src/hotkeys.service';
import { Hotkey } from 'angular2-hotkeys/src/hotkey.model';
import { MasterHotkeys } from '../../../../../commons/properties/master/master-hotkeys.enum'
import { AlertMessageConstants } from '../../../../../commons/properties/alert-message-constants.properties';
import { CommonService } from '../../../services/commons/common.service';
import { DateConstant } from '../../../../../commons/properties/date-constant.properties';
@Component({
  selector: 'app-route-code-master',
  templateUrl: './route-code-master.component.html',
  styleUrls: ['./route-code-master.component.css']
})
export class RouteCodeMasterComponent implements OnInit{
  @ViewChild('closeModalAdd') closeModalAdd: ElementRef;
  @ViewChild('closeModalEdit') closeModalEdit: ElementRef;
  @ViewChild('closeModalSearch') closeModalSearch: ElementRef;
  routeCodeList: RouteCode[] =[];
  addNewRouteCodeForm: FormGroup;
  addNewsubmitted = false;
  editsubmittedForm: FormGroup;
  editsubmitted = false;
  searchForm: FormGroup;
  searchsubmitted = false;
  setFormCodeObj:any;
  success:string= '';
  message: string;
  showMessage:boolean =false;
  formFlag: string="";
  toMinDate:any;
	fromMaxDate:any;
	currentDate : Date = new Date();
	DATE_FORMAT = DateConstant.DATE;
  formObj={
    clientId: [''],
    routeCode: [,[Validators.required,Validators.minLength(1),Validators.maxLength(4)]],
    routing: ['', [Validators.required,Validators.minLength(1),Validators.maxLength(40)]],
    effectiveFromDate: ['', [Validators.required]],
    effectiveToDate: ['', [Validators.required]],
    accountCode: ['',[Validators.minLength(1),Validators.maxLength(50)]],
    responsibilityCentre: ['',[Validators.minLength(1),Validators.maxLength(20)]],
    costCenter: ['',[Validators.minLength(1),Validators.maxLength(20)]],
    attribute1: ['',[Validators.minLength(1),Validators.maxLength(20)]],
    attribute2: ['',[Validators.minLength(1),Validators.maxLength(20)]],
	}
  page: any = this.PaginateService.getPageinateConfig();	
  constructor(private PaginateService: PaginationService,private generalService: GeneralService, private routeCodeService: RouteCodeMasterService, private formBuilder: FormBuilder, private router: Router, private messageBoxService: MessageBoxService,private hotkeysService: HotkeysService, private commonService:CommonService) {

    this.hotkeysService.add(new Hotkey(MasterHotkeys.save, (event: KeyboardEvent): boolean => {
      if (this.formFlag == 'addRouteCode') {
      this.addNewRouteCode();
      }else if(this.formFlag == 'editRouteCode'){
      this.onUpdate();
      }
      return false; 
  }));

  this.hotkeysService.add(new Hotkey(MasterHotkeys.clear, (event: KeyboardEvent): boolean => {
    if (this.formFlag == 'addRouteCode'){
      this.resetForm('add');
   }else if(this.formFlag =='searchRouteCode'){
      this.resetForm('search');
			this.getAllRouteCode();
   }
  return false; 
  }));

  this.hotkeysService.add(new Hotkey(MasterHotkeys.cancel, (event: KeyboardEvent): boolean => {
  if (this.formFlag == 'addRouteCode') {
  this.onCancelChange('add')
  }else if (this.formFlag == 'editRouteCode'){
    this.onCancelChange('edit')
  }
  else if(this.formFlag == 'searchRouteCode'){
    document.getElementById("closeSearch").click();
  }
  return false; 
  }));
   }

  ngOnInit() {
    this.getAllRouteCode();
    let addForm = Object.assign({}, this.formObj);
    addForm['createdBy'] = this.commonService.getUser();
    this.addNewRouteCodeForm = this.formBuilder.group(addForm);
		let editForm = Object.assign({}, this.formObj);
		editForm['routeCodeId'] = '';
		editForm['lastUpdatedBy'] = this.commonService.getUser();
		this.editsubmittedForm = this.formBuilder.group(editForm);
    this.searchForm = this.formBuilder.group({
      routeCode: ['',[Validators.maxLength(4)]],
      routing: ['',[Validators.maxLength(40)]],
      effectiveFromDate: [''],
      effectiveToDate: [''],
    });
    this.getEffectiveFromDate(this.addNewRouteCodeForm,'effectiveFromDate');
		this.getEffectiveToDate(this.addNewRouteCodeForm,'effectiveToDate');
		this.getEffectiveFromDate(this.editsubmittedForm,'effectiveFromDate');
    this.getEffectiveToDate(this.editsubmittedForm,'effectiveToDate');
    this.getEffectiveFromDate(this.searchForm,'effectiveFromDate');
		this.getEffectiveToDate(this.searchForm,'effectiveToDate');
  }

  // closeAlertValidation() {
  //   var tempThis = this;
  //   window.setTimeout(function () {
  //     tempThis.success = { isSuccess: false, successMessage: '' };
  //   }, AlertMessageConstants.CLOSE_ALERT_TIME);
  // }

  getAllRouteCode(): void {
    this.routeCodeService.getAllRouteCode().subscribe((res: RouteCode[]) => {
      this.routeCodeList = res;
    });
  }
  editForm(id, type) {
    this.editsubmittedForm.disable();
		this.editsubmittedForm.get("effectiveToDate").enable();
    if(type == 'update')this.resetForm('edit');else if(type=='add')this.resetForm('add');
		this.routeCodeService.getRouteCodeById(id).subscribe((res:any) => {
			if (type == 'update') {
        let result = Object.assign({}, res);
				result.effectiveFromDate = new Date(result.effectiveFromDate);
				result.effectiveToDate = new Date(result.effectiveToDate);
				result.effectiveFromDate > new Date() ? this.editsubmittedForm.get('effectiveFromDate').enable() : this.editsubmittedForm.get('effectiveFromDate').disable();
				this.editsubmittedForm.patchValue(result);
			}
			else {
				let result = Object.assign({}, res);
				result.effectiveFromDate = new Date(result.effectiveFromDate);
				result.effectiveToDate = new Date(result.effectiveToDate);
        this.addNewRouteCodeForm.patchValue(result);
			}
		})
	}

  get f() { return this.addNewRouteCodeForm.controls; }
  get u() { return this.editsubmittedForm.controls; }
  get s() { return this.searchForm.controls; }

  resetForm(type) {
		if (type == 'add') {
      this.addNewsubmitted = false;
      this.addNewRouteCodeForm.reset();
		}else if (type == 'edit') {
			this.editsubmitted = false;
			this.editsubmittedForm.reset();
		}
		else if (type == 'search') {
			this.searchsubmitted = false;
			this.searchForm.reset();
		}
  }
  
  onSearch() {
		this.searchsubmitted = true;
		if (this.searchForm.invalid) return false;
		this.routeCodeService.searchRouteCode(this.searchForm.value).subscribe((res) => {
			this.routeCodeList = res;
		})
	}

  updateDataTable(data,type){
		if(type == 'add') this.routeCodeList.unshift(data);	
		else{
			const ind = this.routeCodeList.findIndex((item) => { return data.routeCodeId == item.routeCodeId;});
			if(ind == -1) return false;if(type =='update')  this.routeCodeList[ind] = data;else if(type == 'remove') this.routeCodeList.splice(ind, 1);
		}
		this.routeCodeList = [...this.routeCodeList];
  }
  
  addNewRouteCode(){
    this.addNewsubmitted = true;
    if (this.addNewRouteCodeForm.invalid) {
      return false;
    } else {
      this.addNewRouteCodeForm.value.effectiveFromDate = this.generalService.splitDate(this.addNewRouteCodeForm.value.effectiveFromDate);
		  this.addNewRouteCodeForm.value.effectiveToDate = this.generalService.splitDate(this.addNewRouteCodeForm.value.effectiveToDate);
      this.addNewRouteCodeForm.value.clientId = this.commonService.getClientId();
			this.addNewRouteCodeForm.value.createdBy= this.commonService.getUser();
      this.routeCodeService.addRouteCode(this.addNewRouteCodeForm.value).subscribe(
        (res:any) => {
          if (res && res.routeCodeId) {
            this.updateDataTable(res,'add');
            // this.success = { isSuccess: true, successMessage: "Record has been successfully saved" };
            this.message = "Record has been successfully saved";
            this.showMessage = true;
            this.closeModalAdd.nativeElement.click();
					  // this.closeAlertValidation();
          }
        });
    }
  }
	
  onUpdate(){
    this.editsubmitted = true;
    if (this.editsubmittedForm.invalid) {
      return false;
    } else {
      let data = Object.assign({}, this.editsubmittedForm.getRawValue());
      data.effectiveFromDate = this.generalService.splitDate( data.effectiveFromDate);
      data.effectiveToDate = this.generalService.splitDate( data.effectiveToDate);
      data.clientId = data.clientId.trim();
      data.lastUpdatedBy= this.commonService.getUser();
      const routeCode = Object.assign({}, data);
      delete(routeCode.routeCodeId);
      this.routeCodeService.updateRouteCode(data, routeCode).subscribe(
        (response:any) => {
          if (response && response.routeCodeId) {
		      	this.updateDataTable(response,'update');
            // this.success = { isSuccess: true, successMessage: "Record has been successfully saved" };
            this.message = "Record has been successfully saved";
            this.showMessage = true;
					  this.closeModalEdit.nativeElement.click();
					  // this.closeAlertValidation();
          }
        });
    }
  }

  onCancelChange(type){
    this.resetForm(type);
    this.closeModalAdd.nativeElement.click();
    this.closeModalEdit.nativeElement.click();
  }

  getEffectiveFromDate(formName:any,obj:string){
		formName.controls[obj].valueChanges.subscribe((minDate) => {
			return this.toMinDate = minDate;
		});
	}
	getEffectiveToDate(formName:any,obj:string){
		formName.controls[obj].valueChanges.subscribe((maxDate) => {
			return this.fromMaxDate = maxDate;
		});
	}
	validateEffectiveToDate(date) {
		return !(new Date(date) > new Date());
	}
	disableCalendarDatesOnFromDateSelction(){
		let getFromDate = this.editsubmittedForm.get("effectiveFromDate").value;
		if(new Date(getFromDate) < this.currentDate){
			return this.toMinDate = this.currentDate;
		}
		else{
			return this.toMinDate = this.toMinDate;
		}
	}

}

