package com.sgl.smartpra.batch.amadeus.app.domain;

import java.io.Serializable;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.commons.lang.StringUtils;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.LineTokenizer;

@Entity
@Table(name = "oneworld_request_file", schema="smartPRAoneworld")
public class RequestFileDetail extends BatchRecord implements Serializable {

	private static final long serialVersionUID = -8909773393155806814L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "request_dtl_id")
	private BigInteger requestId;

	@Column(name = "request_airline_code")
	private String requestAirLineCode;

	@Column(name = "respond_airline_code")
	private String responseAirLineCode;

	@Column(name = "ticket_number")
	private BigInteger ticketNumber;
	
	@Transient
	private String ticketNumberStr;

	@Column(name = "coupon_number")
	private Integer couponNumber;

	@Transient
	private String couponNumberStr;
	
	@Column(name = "coupon_type")
	private String couponType;

	@Column(name = "request_date")
	private Date requestDate;

	@Column(name = "request_type")
	private String requestType;

	@Column(name = "ticket_issuing_airline_code")
	private String ticketIssuingAirLineCode;

	@Column(name = "multi_coupon_id")
	private String multiCouponId;

	@Column(name = "data_source")
	private String dataSource;

	@Column(name = "request_seq_number")
	private Integer requestSeqNumber;

	@Column(name = "last_response_date")
	private Date lastResponseDate;
	
	@Column(name = "process_required_flag")
	private String processRequiredFlag ;

	@Column(name = "file_id")
	private Integer fileId;
	
	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_date")
	private Timestamp createdDate;

	@Column(name = "last_updated_by")
	private String lastUpdatedBy;

	@Column(name = "last_updated_date")
	private Timestamp lastUpdatedDate;

	
	public BigInteger getRequestId() {
		return requestId;
	}

	public void setRequestId(BigInteger requestId) {
		this.requestId = requestId;
	}

	public String getRequestAirLineCode() {
		return requestAirLineCode;
	}

	public void setRequestAirLineCode(String requestAirLineCode) {
		this.requestAirLineCode = requestAirLineCode;
	}

	public String getResponseAirLineCode() {
		return responseAirLineCode;
	}

	public void setResponseAirLineCode(String responseAirLineCode) {
		this.responseAirLineCode = responseAirLineCode;
	}

	public BigInteger getTicketNumber() {
		return ticketNumber;
	}

	public void setTicketNumber(BigInteger ticketNumber) {
		this.ticketNumber = ticketNumber;
	}

	public Integer getCouponNumber() {
		return couponNumber;
	}

	public void setCouponNumber(Integer couponNumber) {
		this.couponNumber = couponNumber;
	}

	public String getCouponType() {
		return couponType;
	}

	public void setCouponType(String couponType) {
		this.couponType = couponType;
	}

	public Date getRequestDate() {
		return requestDate;
	}

	public void setRequestDate(Date requestDate) {
		this.requestDate = requestDate;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public String getTicketIssuingAirLineCode() {
		return ticketIssuingAirLineCode;
	}

	public void setTicketIssuingAirLineCode(String ticketIssuingAirLineCode) {
		this.ticketIssuingAirLineCode = ticketIssuingAirLineCode;
	}

	public String getMultiCouponId() {
		if(StringUtils.isEmpty(multiCouponId)) {
			return multiCouponId = "000000000";
		}
		return multiCouponId.trim();
	}

	public void setMultiCouponId(String multiCouponId) {
		this.multiCouponId = multiCouponId.trim();
	}

	public String getDataSource() {
		return dataSource;
	}

	public void setDataSource(String dataSource) {
		this.dataSource = dataSource;
	}

	public Integer getRequestSeqNumber() {
		return requestSeqNumber;
	}

	public void setRequestSeqNumber(Integer requestSeqNumber) {
		this.requestSeqNumber = requestSeqNumber;
	}

	public Date getLastResponseDate() {
		return lastResponseDate;
	}

	public void setLastResponseDate(Date lastResponseDate) {
		this.lastResponseDate = lastResponseDate;
	}
	
	
	public String getProcessRequiredFlag() {
		return processRequiredFlag;
	}

	public void setProcessRequiredFlag(String processRequiredFlag) {
		this.processRequiredFlag = processRequiredFlag;
	}

	public Integer getFileId() {
		return fileId;
	}

	public void setFileId(Integer fileId) {
		this.fileId = fileId;
	}

	@Override
	public String getCreatedBy() {
		return createdBy;
	}
	
	@Override
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	@Override
	public Timestamp getCreatedDate() {
		return createdDate;
	}

	@Override
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	@Override
	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}
	
	@Override
	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	@Override
	public Timestamp getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	@Override
	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getTicketNumberStr() {
		return ticketNumberStr;
	}

	@Override
	public LineTokenizer lineTokenizer() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public FieldSetMapper<BatchRecord> fieldSetMapper() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ItemProcessor<? extends BatchRecord, ? extends BatchRecord> processor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ItemWriter<? super BatchRecord> writer() {
		// TODO Auto-generated method stub
		return null;
	}

	/*public void setTicketNumberStr(String ticketNumberStr) {
		//String str = ticketNumberStr.substring(5, ticketNumberStr.length()-1);
		BigInteger ticketNumber = new BigInteger(ticketNumberStr);
		this.setTicketNumber(ticketNumber);
		this.ticketNumberStr = ticketNumberStr;
	}

	public String getCouponNumberStr() {
		return couponNumberStr;
	}

	public void setCouponNumberStr(String couponNumberStr) {
		Integer couponNumber = new Integer(couponNumberStr);
		this.setCouponNumber(couponNumber);
		this.couponNumberStr = couponNumberStr;
	}

	@Override
	public LineTokenizer lineTokenizer() {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		RequestFileDetailLayout requestLayout = new RequestFileDetailLayout();
		tokenizer.setColumns(requestLayout.getColumns());
		tokenizer.setNames(requestLayout.getNames());
		return tokenizer;
	}

	@Override
	public FieldSetMapper<BatchRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<BatchRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<>();
		fieldSetMapper.setTargetType(RequestFileDetail.class);
		return fieldSetMapper;
	}

	@Override
	public ItemProcessor<? extends BatchRecord, ? extends BatchRecord> processor() {
		return new RequestFileProcessor();
	}
	
	@Override
	public ItemWriter<? super BatchRecord> writer() {
		return new RequestFileDetailWriter();
	}
*/
}
