import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AircraftMasterComponent } from './aircraft-master.component';

describe('AircraftMasterComponent', () => {
  let component: AircraftMasterComponent;
  let fixture: ComponentFixture<AircraftMasterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AircraftMasterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AircraftMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
