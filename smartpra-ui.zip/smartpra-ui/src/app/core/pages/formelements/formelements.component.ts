import { Component, OnInit} from '@angular/core';
import {GeneralService} from '../../../commons/services/general.service';
declare var $;
import swal from 'sweetalert2';
@Component({
  selector: 'app-formelements',
  templateUrl: './formelements.component.html',
  styleUrls: ['./formelements.component.css']
})
export class FormelementsComponent implements OnInit {

  constructor(private Gservice: GeneralService) { }

  ngOnInit() {
    this.Gservice.LoadTreeViewJs();
    this.Gservice.LoadProfileSettingJs();
    this.Gservice.LoadFormSettingJs();
  }

}
