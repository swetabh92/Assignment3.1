package com.sgl.smartpra.batch.sales.validator.app.domain;


import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;



/**
 * The persistent class for the ticket_orgin_stg database table.
 * 
 */
@Entity
@Table(name="ticket_orgin_stg")
public class TicketOrginStg implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="tkt_orgin_id")
	private int tktOrginId;

	@Column(name="created_by")
	private String createdBy;

	@Column(name="created_date")
	private Timestamp createdDate;

	@Column(name="disrupt_cpn1")
	private int disruptCpn1;

	@Column(name="disrupt_cpn2")
	private int disruptCpn2;

	@Column(name="disrupt_cpn3")
	private int disruptCpn3;

	@Column(name="disrupt_cpn4")
	private int disruptCpn4;

	@Column(name="last_updated_by")
	private String lastUpdatedBy;

	@Column(name="last_updated_date")
	private Timestamp lastUpdatedDate;

	@Column(name="orig_cpn_no")
	private String origCpnNo;

	@Column(name="orig_doc_type")
	private String origDocType;

	@Column(name="orig_document")
	private String origDocument;

	@Column(name="orig_document_unique_id")
	private String origDocumentUniqueId;

	@Column(name="orig_issue_airline")
	private String origIssueAirline;

	@Column(name="orig_main_doc_no")
	private String origMainDocNo;

	@Column(name="reason_memo_issuance_code")
	private String reasonMemoIssuanceCode;

	@Column(name="sales_key")
	private int salesKey;

	@Column(name="serial_number")
	private int serialNumber;

	@Column(name="waiver_code")
	private String waiverCode;

	//bi-directional many-to-one association to TicketMainStg

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="trn_tkt_id")
	private TicketMainStg ticketMainStg;

	public TicketOrginStg() {
	}

	public int getTktOrginId() {
		return this.tktOrginId;
	}

	public void setTktOrginId(int tktOrginId) {
		this.tktOrginId = tktOrginId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public int getDisruptCpn1() {
		return this.disruptCpn1;
	}

	public void setDisruptCpn1(int disruptCpn1) {
		this.disruptCpn1 = disruptCpn1;
	}

	public int getDisruptCpn2() {
		return this.disruptCpn2;
	}

	public void setDisruptCpn2(int disruptCpn2) {
		this.disruptCpn2 = disruptCpn2;
	}

	public int getDisruptCpn3() {
		return this.disruptCpn3;
	}

	public void setDisruptCpn3(int disruptCpn3) {
		this.disruptCpn3 = disruptCpn3;
	}

	public int getDisruptCpn4() {
		return this.disruptCpn4;
	}

	public void setDisruptCpn4(int disruptCpn4) {
		this.disruptCpn4 = disruptCpn4;
	}

	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getLastUpdatedDate() {
		return this.lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getOrigCpnNo() {
		return this.origCpnNo;
	}

	public void setOrigCpnNo(String origCpnNo) {
		this.origCpnNo = origCpnNo;
	}

	public String getOrigDocType() {
		return this.origDocType;
	}

	public void setOrigDocType(String origDocType) {
		this.origDocType = origDocType;
	}

	public String getOrigDocument() {
		return this.origDocument;
	}

	public void setOrigDocument(String origDocument) {
		this.origDocument = origDocument;
	}

	public String getOrigDocumentUniqueId() {
		return this.origDocumentUniqueId;
	}

	public void setOrigDocumentUniqueId(String origDocumentUniqueId) {
		this.origDocumentUniqueId = origDocumentUniqueId;
	}

	public String getOrigIssueAirline() {
		return this.origIssueAirline;
	}

	public void setOrigIssueAirline(String origIssueAirline) {
		this.origIssueAirline = origIssueAirline;
	}

	public String getOrigMainDocNo() {
		return this.origMainDocNo;
	}

	public void setOrigMainDocNo(String origMainDocNo) {
		this.origMainDocNo = origMainDocNo;
	}

	public String getReasonMemoIssuanceCode() {
		return this.reasonMemoIssuanceCode;
	}

	public void setReasonMemoIssuanceCode(String reasonMemoIssuanceCode) {
		this.reasonMemoIssuanceCode = reasonMemoIssuanceCode;
	}

	public int getSalesKey() {
		return this.salesKey;
	}

	public void setSalesKey(int salesKey) {
		this.salesKey = salesKey;
	}

	public int getSerialNumber() {
		return this.serialNumber;
	}

	public void setSerialNumber(int serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getWaiverCode() {
		return this.waiverCode;
	}

	public void setWaiverCode(String waiverCode) {
		this.waiverCode = waiverCode;
	}

	public TicketMainStg getTicketMainStg() {
		return this.ticketMainStg;
	}

	public void setTicketMainStg(TicketMainStg ticketMainStg) {
		this.ticketMainStg = ticketMainStg;
	}
}