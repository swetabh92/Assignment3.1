package com.sgl.smartpra.batch.mib.app.processor;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.service.spi.ServiceException;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.google.gson.Gson;
import com.sgl.smartpra.batch.mib.app.config.FeignConfiguration.SmartpraCurrencyMasterAppClient;
import com.sgl.smartpra.batch.mib.app.config.FeignConfiguration.SmartpraGlobalMasterAppClient;
import com.sgl.smartpra.batch.mib.app.config.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.batch.mib.app.mapper.AddOnChargeDtlMapper;
import com.sgl.smartpra.batch.mib.app.mapper.InvoiceHeaderMapper;
import com.sgl.smartpra.batch.mib.app.mapper.InvoiceSummaryMapper;
import com.sgl.smartpra.batch.mib.app.mapper.LineItemDetailMapper;
import com.sgl.smartpra.batch.mib.app.mapper.LineItemMapper;
import com.sgl.smartpra.batch.mib.app.mapper.TaxDetailsMapper;
import com.sgl.smartpra.batch.mib.app.mapper.TransmissionHeaderMapper;
import com.sgl.smartpra.batch.mib.app.mapper.TransmissionSummaryMapper;
import com.sgl.smartpra.batch.mib.app.service.OutwardInvoiceService;
import com.sgl.smartpra.batch.mib.app.service.SupportingDetailService;
import com.sgl.smartpra.batch.mib.app.service.TransmissionService;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingConstants;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingUtil;
import com.sgl.smartpra.currency.model.CurrencyRate;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;
import com.sgl.smartpra.global.master.model.Carrier;
import com.sgl.smartpra.global.master.model.ChargeCategory;
import com.sgl.smartpra.global.master.model.ChargeCode;
import com.sgl.smartpra.global.master.model.Section;
import com.sgl.smartpra.mib.entity.MiscBillInvTransTotalAmtEntity;
import com.sgl.smartpra.mib.entity.MiscBillingAddOnChargeDtlEntity;
import com.sgl.smartpra.mib.entity.MiscBillingInvLineitemDtlEntity;
import com.sgl.smartpra.mib.entity.MiscBillingInvLineitemEntity;
import com.sgl.smartpra.mib.entity.MiscBillingInvTransHeaderEntity;
import com.sgl.smartpra.mib.entity.MiscBillingSupportingDetailEntity;
import com.sgl.smartpra.mib.entity.MiscBillingTaxDetailsEntity;
import com.sgl.smartpra.mib.entity.MiscBillingTrnInvoiceEntity;
import com.sgl.smartpra.mib.jaxb.dictionary.TaxType;
import com.sgl.smartpra.mib.jaxb.standard.AddOnCharges;
import com.sgl.smartpra.mib.jaxb.standard.ISDetails;
import com.sgl.smartpra.mib.jaxb.standard.Invoice;
import com.sgl.smartpra.mib.jaxb.standard.InvoiceHeader;
import com.sgl.smartpra.mib.jaxb.standard.InvoiceSummary;
import com.sgl.smartpra.mib.jaxb.standard.InvoiceTransmission;
import com.sgl.smartpra.mib.jaxb.standard.InvoiceTransmissionModel;
import com.sgl.smartpra.mib.jaxb.standard.LineItem;
import com.sgl.smartpra.mib.jaxb.standard.LineItemDetail;
import com.sgl.smartpra.mib.jaxb.standard.Tax;
import com.sgl.smartpra.mib.jaxb.standard.TaxAmount;
import com.sgl.smartpra.mib.jaxb.standard.TransmissionHeader;
import com.sgl.smartpra.mib.jaxb.standard.TransmissionSummary;

import lombok.extern.slf4j.Slf4j;

@Component
@Scope(value = "step")
@Slf4j
public class MiscBillingFileProcessor implements ItemProcessor<InvoiceTransmission, InvoiceTransmissionModel> {
	
	@Value("#{stepExecution}")
	private StepExecution stepExecution;
	
	@Autowired
	private TransmissionHeaderMapper transmissionHeaderMapper;
	
	@Autowired
	private TransmissionSummaryMapper transmissionSummaryMapper;

	@Autowired
	private InvoiceHeaderMapper invoiceHeaderMapper;
	
	@Autowired
	private InvoiceSummaryMapper invoiceSummaryMapper;

	@Autowired
	private LineItemMapper lineItemMapper;
	
	@Autowired
	private LineItemDetailMapper lineItemDetailMapper;

	@Autowired
	private AddOnChargeDtlMapper addOnChargeDtlMapper;
	
	@Autowired
	private TaxDetailsMapper taxDetailsMapper;

	@Autowired
	private SmartpraGlobalMasterAppClient smartpraGlobalMasterAppClient;
	
	@Autowired
	private SmartpraMasterAppClient smartpraMasterAppClient;
	
	@Autowired
	private SmartpraCurrencyMasterAppClient smartpraCurrencyMasterAppClient;

	@Autowired
	private OutwardInvoiceService outwardInvoiceService;
	
	@Autowired
	private SupportingDetailService supportingDetailService;
	
	@Autowired
	private TransmissionService transmissionService;
	
	private Map<String, String> chargeCategoryMap = new HashMap<>();
	
	private Map<String, List<ChargeCode>> chargeCodeMap = new HashMap<>();
	
	private static Integer chargeCodeCount = 0;
	private static String clientId;
	private static Integer fileId;
	private static String fileName;
	private static DecimalFormat df2 = new DecimalFormat("#.##");
	
	@Override
	public InvoiceTransmissionModel process(InvoiceTransmission invoiceTransmission) throws Exception {
		log.debug("#################### Entering InvoiceTransmissionProcessor ####################");
		log.debug("$$$$$$$$$$ Entering InvoiceTransmissionProcessor $$$$$$$$$$$$$");
		InvoiceTransmissionModel invoiceTransmissionModel = new InvoiceTransmissionModel();
		populateMaster();
		MiscBillingInvTransHeaderEntity miscBillingInvTransHeaderEntity = processTransmisionHeader(invoiceTransmission.getTransmissionHeader(), invoiceTransmission.getTransmissionSummary());
		
		List<MiscBillingTrnInvoiceEntity> invoiceEntityList = new ArrayList<>();
		processInvoice(invoiceTransmission.getInvoice(), invoiceEntityList, miscBillingInvTransHeaderEntity);
		outwardInvoiceService.populateBatchNoInInvoices(clientId, MiscBillingConstants.INWARD, invoiceEntityList);
		miscBillingInvTransHeaderEntity.setMiscBillingTrnInvoices(invoiceEntityList);

		List<MiscBillInvTransTotalAmtEntity> miscBillInvTransTotalAmtEntityList = transmissionService.processTransmissionSummary(invoiceTransmission.getTransmissionSummary(), miscBillingInvTransHeaderEntity);
		invoiceTransmissionModel.setMiscBillingInvTransHeaderEntity(miscBillingInvTransHeaderEntity);
		invoiceTransmissionModel.setMiscBillInvTransTotalAmtEntityList(miscBillInvTransTotalAmtEntityList);
		invoiceTransmissionModel.setMiscBillingTrnInvoiceEntityListList(invoiceEntityList);

		return invoiceTransmissionModel;
	}

	public void populateMaster() {
		log.debug("$$$$$$$$$$ Entering populateMaster $$$$$$$$$$$$$");
		List<ChargeCategory> chargeCategoryList = smartpraGlobalMasterAppClient.getAllChargeCategory(null, null, null);
		for (ChargeCategory chargeCategory : chargeCategoryList) {
			List<ChargeCode> chargeCodeList = smartpraGlobalMasterAppClient.getAllChargeCodesFromChargeCategory(chargeCategory.getChargeCategoryCode().get());
			chargeCodeMap.put(chargeCategory.getChargeCategoryCode().get(), chargeCodeList);
			chargeCategoryMap.put(chargeCategory.getChargeCategoryName().get(), chargeCategory.getChargeCategoryCode().get());
		}
		JobParameters jobParameters = this.stepExecution.getJobExecution().getJobParameters();
		fileId = Integer.valueOf(jobParameters.getLong("fileId").intValue());
		fileName = jobParameters.getString("fileName");
		clientId = jobParameters.getString("clientId");
		
		log.debug("$$$$$$$$$$ Exiting populateMaster $$$$$$$$$$$$$");
	}
	
	public MiscBillingInvTransHeaderEntity processTransmisionHeader(TransmissionHeader transmissionHeader, TransmissionSummary transmissionSummary) throws Exception {
		log.debug("Entering processTransmisionHeader()");
		
		MiscBillingInvTransHeaderEntity invTransHeaderEntity = new MiscBillingInvTransHeaderEntity();
		log.debug("fileId: " + fileId + ", fileName: " + fileName + ", clientId: " + clientId);
		String year = fileName.substring(11, 13);
		String month = fileName.substring(13, 15);
		String billingPeriod= fileName.substring(15, 17);
		log.debug("year: " + year + ", month: " + month);
		
		invTransHeaderEntity.setBillingMonth(MiscBillingUtil.getMonth(month) + "-" + year);
		invTransHeaderEntity.setBillingPeriod(Integer.parseInt(billingPeriod));
		
		// carrier designator code. it should be the value as mapped in the system parameter DEFAUT_CARRIER_DESIGNATOR_CODE...
		invTransHeaderEntity.setClientId(clientId); 
		invTransHeaderEntity.setFileId(fileId);
		invTransHeaderEntity.setInwardOutwardFlag(MiscBillingConstants.INWARD);

		transmissionHeaderMapper.mapTransmissionHeaderToEntity(transmissionHeader, invTransHeaderEntity);
		transmissionSummaryMapper.mapTransmissionSummaryToEntity(transmissionSummary, invTransHeaderEntity);
		
		log.debug("Exiting processTransmisionHeader()");
		return invTransHeaderEntity;
	}

	public void processInvoice(List<Invoice> invoiceList, List<MiscBillingTrnInvoiceEntity> invoiceEntityList
			, MiscBillingInvTransHeaderEntity miscBillingInvTransHeaderEntity) throws Exception {
		log.debug("Entering processInvoice()");
		if(invoiceList != null && invoiceList.size() > 0) {
			stepExecution.getExecutionContext().put("invoiceCount", invoiceList.size());
		}
		for (Invoice invoice : invoiceList) {
			MiscBillingTrnInvoiceEntity invoiceEntity = new MiscBillingTrnInvoiceEntity();
			try {
				InvoiceSummary invoiceSummary = invoice.getInvoiceSummary();
				processInvoiceHeader(invoice, invoiceEntity, miscBillingInvTransHeaderEntity);
				processInvoiceSummary(invoiceSummary, invoiceEntity, miscBillingInvTransHeaderEntity);
				List<LineItem> lineItemList = invoice.getLineItem();
				List<LineItemDetail> lineItemDetailList = invoice.getLineItemDetail();
				
				List<MiscBillingInvLineitemEntity> lineItemEntityList = new ArrayList<>();
				processLineItem(lineItemList, lineItemEntityList, invoiceEntity);
				invoiceEntity.setMiscBillingInvLineitem(lineItemEntityList);
				chargeCodeCount += invoiceSummary.getLineItemCount().intValue();

				List<MiscBillingInvLineitemDtlEntity> lineItemDtlEntityList = new ArrayList<>();
				processLineItemDetail(lineItemDetailList, lineItemDtlEntityList, lineItemEntityList, invoiceEntity);
				
				for (MiscBillingInvLineitemEntity lineItemEntity : lineItemEntityList) {
					populateLineItemDetailListInLineItem(lineItemEntity, lineItemDtlEntityList);
				}
				String baseCurrency = MiscBillingUtil.getBaseCurrency(smartpraMasterAppClient, invoiceEntity.getClientId());
				invoiceEntity.setBaseCurrency(baseCurrency);
				String invoiceDate = new SimpleDateFormat("yyyy-MM-dd").format(invoiceEntity.getInvoiceDate());
				CurrencyRate currencyRate = null;
				try {
					currencyRate = smartpraCurrencyMasterAppClient.getEffectiveCurrencyRate(MiscBillingConstants.BKR, 
							invoiceEntity.getCurrencyCode(), baseCurrency, invoiceDate);
				} catch (ServiceException se) {
					log.debug("Record not found for BKR " + invoiceEntity.getCurrencyCode() + " - BaseCurrency: " + baseCurrency + " and invoiceDate: " + invoiceDate);
				} catch (Exception e) {
					log.debug("Exception thrown while getting data for BKR currency.");
					e.printStackTrace();
				}
				BigDecimal exchangeRate = null;
				if(currencyRate != null) {
					if(currencyRate.getExchangeRate().isPresent()) {
						exchangeRate = new BigDecimal(currencyRate.getExchangeRate().get());
						Double amtBaseCurrency = invoiceEntity.getTotalAmount().doubleValue() / exchangeRate.doubleValue();
						invoiceEntity.setAmountBaseCurrency(new BigDecimal(df2.format(amtBaseCurrency)));
					}
				}
			} catch (Exception e) {
				log.debug("Error while processing method processInvoice():- ");
				e.printStackTrace();
			}
			invoiceEntityList.add(invoiceEntity);
		}
		stepExecution.getExecutionContext().put("chargeCodeCount", chargeCodeCount);
		log.debug("Exiting processInvoice()");
	}
	
	public void processInvoiceHeader(Invoice invoice, MiscBillingTrnInvoiceEntity invoiceEntity
			, MiscBillingInvTransHeaderEntity miscBillingInvTransHeaderEntity) throws Exception {
		InvoiceHeader invoiceHeader = invoice.getInvoiceHeader();
		log.debug("Entering processInvoiceHeader(): " + invoiceHeader.getInvoiceNumber());
		invoiceHeaderMapper.mapInvoiceHeaderToEntity(invoiceHeader, invoiceEntity);
	   	if(StringUtils.isEmpty(invoiceEntity.getDigitalSignatureFlag())){
	   		invoiceEntity.setDigitalSignatureFlag(MiscBillingConstants.DIGITAL_SIGNATURE_DEFAULT);
	   	}
	   	invoiceEntity.setClientId(clientId);
	   	invoiceEntity.setInvoiceStatus(MiscBillingConstants.STATUS_OPEN);
	   	invoiceEntity.setInwardOutwardFlag(MiscBillingConstants.I);
	   	
	   	if(MiscBillingConstants.INVOICE.equalsIgnoreCase(invoiceEntity.getInvoiceType())) {
	   		invoiceEntity.setInvoiceType(MiscBillingConstants.I);
	   	} else if(MiscBillingConstants.CREDIT_NOTE.equalsIgnoreCase(invoiceEntity.getInvoiceType())) {
	   		invoiceEntity.setInvoiceType(MiscBillingConstants.C);
	   	}
	   	String chargeCategoryName = invoiceEntity.getChargeCategoryCode();
	   	if(!StringUtils.isEmpty(chargeCategoryName)) {
	   		invoiceEntity.setChargeCategoryCode(chargeCategoryMap.get(chargeCategoryName));
		} 
	   	
	   	String sellerOrganizationId = invoiceEntity.getSellerOrganizationId();
	   	if(!StringUtils.isEmpty(sellerOrganizationId)) {
	   		try {
	   			Carrier carrier = null;
				try {
					carrier = smartpraGlobalMasterAppClient.getCarrierByCarrierCode(sellerOrganizationId);
				} catch (RecordNotFoundException e) {
					log.debug("Record not found for carrier code " + sellerOrganizationId + " in carrier master");
				} catch (Exception e) {
					log.debug("Exception thrown while getting carrier code " + sellerOrganizationId + " from carrier master");
					e.printStackTrace();
				}
	   			if(carrier != null && carrier.getCarrierCode().get().equalsIgnoreCase(sellerOrganizationId)) {
	   				invoiceEntity.setSupplierType(MiscBillingConstants.C);
	   			} else {
	   				invoiceEntity.setSupplierType(MiscBillingConstants.NO);
	   			}
	   		} catch (RecordNotFoundException e) {
	   			log.debug("getCarrierByCarrierCode(): " + e.getMessage());
	   			invoiceEntity.setSupplierType(MiscBillingConstants.NO);
	   		} catch (Exception e) {
	   			log.debug("getCarrierByCarrierCode(): While setting SettlementType: Feign client throws an error while getting carrier master.");
	   			e.printStackTrace();
	   		}
	   	}
	   	
	   	String correspondenceInvoiceNo = MiscBillingConstants.EMPTY_STRING;
	   	String rejectionInvoiceNo = MiscBillingConstants.EMPTY_STRING;
	   	ISDetails isDetails = invoiceHeader.getISDetails();
	   	if(isDetails.getCorrespondenceDetails() != null) {
	   		correspondenceInvoiceNo = isDetails.getCorrespondenceDetails().getInvoiceNumber();
	   		if(!StringUtils.isEmpty(correspondenceInvoiceNo)) {
	   			invoiceEntity.setOriginalInvoiceNumber(correspondenceInvoiceNo);
	   		}
	   		BigInteger corRefNo = isDetails.getCorrespondenceDetails().getCorrespondenceRefNumber();
	   		if(corRefNo != null) {
		   		invoiceEntity.setCorrespondanceRefNo(corRefNo.intValue());
		   	}
	   	}
	   	if(isDetails.getRejectedInvoiceDetails() != null) {
	   		rejectionInvoiceNo = isDetails.getRejectedInvoiceDetails().getInvoiceNumber();
	   		if(!StringUtils.isEmpty(rejectionInvoiceNo)) {
	   			invoiceEntity.setOriginalInvoiceNumber(rejectionInvoiceNo);
	   		}
	   	}
	   	
	   	if(!StringUtils.isEmpty(invoiceHeader.getPONumber())) {
	   		invoiceEntity.setPoNumber(invoiceHeader.getPONumber());
	   	}
		invoiceEntity.setMiscBillingInvTransHeader(miscBillingInvTransHeaderEntity);
		List<MiscBillingInvLineitemEntity> lineItemEntityList = new ArrayList<>();
		invoiceEntity.setMiscBillingInvLineitem(lineItemEntityList);
		log.debug("Exiting processInvoiceHeader(): " + invoiceHeader.getInvoiceNumber());
	}
	
	public void processLineItem(List<LineItem> lineItemList, List<MiscBillingInvLineitemEntity> lineItemEntityList, MiscBillingTrnInvoiceEntity invoiceEntity) {
		log.debug("Entering processLineItem(): ");
		
		for (LineItem lineItem : lineItemList) {
			MiscBillingInvLineitemEntity lineItemEntity = new MiscBillingInvLineitemEntity();
			lineItemMapper.mapLineItemToEntity(lineItem, lineItemEntity);
			if(StringUtils.isEmpty(lineItemEntity.getLocationCode())) {
		   		if(!StringUtils.isEmpty(lineItem.getLocationCodeICAO())){
		   			lineItemEntity.setLocationCode(lineItem.getLocationCodeICAO());
		   		}
		   	}
			lineItemEntity.setMiscBillingTrnInvoice(invoiceEntity);
			lineItemEntity.setChargeCatCode(invoiceEntity.getChargeCategoryCode());
			lineItemEntity.setChargeCode(getChargeCode(invoiceEntity.getChargeCategoryCode(), lineItemEntity.getChargeCode()));
			lineItemEntity.setMiscBillingTaxDetails(populateTaxVatDetails(lineItem.getTax(), invoiceEntity, lineItemEntity, null, MiscBillingConstants.LINE_ITEM));
			lineItemEntity.setMiscBillingAddOnChargeDtl(populateAddOnChargeDtl(lineItem.getAddOnCharges(), invoiceEntity, lineItemEntity, null, MiscBillingConstants.LINE_ITEM));
			lineItemEntityList.add(lineItemEntity);
		}
		log.debug("Exiting processLineItem()");
	}
	
	public void processLineItemDetail(List<LineItemDetail> lineItemDetailList, List<MiscBillingInvLineitemDtlEntity> lineItemDtlEntityList
			, List<MiscBillingInvLineitemEntity> lineItemEntityList, MiscBillingTrnInvoiceEntity invoiceEntity) {
		log.debug("Entering processLineItemDetail()");
		for (LineItemDetail lineItemDtl : lineItemDetailList) {
			MiscBillingInvLineitemDtlEntity lineItemDtlEntity = new MiscBillingInvLineitemDtlEntity();
			lineItemDetailMapper.mapLineItemDetailToEntity(lineItemDtl, lineItemDtlEntity);
			populateLineItemInLineItemDetail(lineItemDtlEntity, lineItemEntityList);
			lineItemDtlEntity.setMiscBillingTaxDetails(populateTaxVatDetails(lineItemDtl.getTax(), invoiceEntity, null, lineItemDtlEntity, MiscBillingConstants.LINE_ITEM_DETAIL));
			lineItemDtlEntity.setMiscBillingAddOnChargeDtl(populateAddOnChargeDtl(lineItemDtl.getAddOnCharges(), invoiceEntity, null, lineItemDtlEntity, MiscBillingConstants.LINE_ITEM_DETAIL));
			lineItemDtlEntity.setMiscBillingSupportingDetail(populateSupportingDetail(lineItemDtl, lineItemDtlEntity, lineItemDtlEntity.getMiscBillingInvLineitem().getChargeCode()));
			lineItemDtlEntityList.add(lineItemDtlEntity);
		}
		log.debug("Exiting processLineItemDetail()");
	}
	
	public List<MiscBillingSupportingDetailEntity> populateSupportingDetail(LineItemDetail lineItemDetail, 
			MiscBillingInvLineitemDtlEntity lineItemDtlEntity, String chargeCode) {
		
		List<MiscBillingSupportingDetailEntity> suppDetailList = new ArrayList<>();
		List<Section> sectionList = smartpraGlobalMasterAppClient.getSectionByChargeCode(chargeCode);
		Map<String, Object> sectionMap = supportingDetailService.getSectionDetails(sectionList, lineItemDetail);
		Map<String, List<Object>> sectionListMap = supportingDetailService.getSectionDetailsList(sectionList, lineItemDetail);
		
		for (Map.Entry<String,Object> section : sectionMap.entrySet()) {
			String sectionName = section.getKey();
			Object obj = section.getValue();
			
			MiscBillingSupportingDetailEntity supDetEntity = new MiscBillingSupportingDetailEntity();
			supDetEntity.setMiscBillingInvLineitemDtl(lineItemDtlEntity);
			supDetEntity.setSectionName(sectionName);
			supDetEntity.setJsonValue(new Gson().toJson(obj));
			suppDetailList.add(supDetEntity);
		}
		
		for (Map.Entry<String,List<Object>> section : sectionListMap.entrySet()) {
			String sectionName = section.getKey();
			List<Object> objList = section.getValue();
			if(objList != null && objList.size() > 0) {
				MiscBillingSupportingDetailEntity supDetEntity = new MiscBillingSupportingDetailEntity();
				supDetEntity.setMiscBillingInvLineitemDtl(lineItemDtlEntity);
				supDetEntity.setSectionName(sectionName);
				supDetEntity.setJsonValue(new Gson().toJson(objList));
				suppDetailList.add(supDetEntity);
			}
		}
		return suppDetailList;
	}
	
	public void populateLineItemInLineItemDetail(MiscBillingInvLineitemDtlEntity lineItemDtlEntity
			, List<MiscBillingInvLineitemEntity> lineItemEntityList) {
		
		BigInteger lineItemNumber = lineItemDtlEntity.getLineItemNumber(); 
		for (MiscBillingInvLineitemEntity lineItemEntity : lineItemEntityList) {
			if(lineItemNumber != null){
				if(lineItemNumber.intValue() == lineItemEntity.getLineItemNumber()) {
					lineItemDtlEntity.setMiscBillingInvLineitem(lineItemEntity);
					break;
				}
			}
		}
	}
	
	public void processInvoiceSummary(InvoiceSummary invoiceSummary, MiscBillingTrnInvoiceEntity invoiceEntity
			, MiscBillingInvTransHeaderEntity miscBillingInvTransHeaderEntity) throws Exception {
		log.debug("Entering processInvoiceSummary()");
		
		invoiceSummaryMapper.mapInvoiceSummaryToEntity(invoiceSummary, invoiceEntity);
		
		List<Tax> taxList = invoiceSummary.getTax();
		invoiceEntity.setMiscBillingTaxDetails(populateTaxVatDetails(taxList, invoiceEntity, null, null, MiscBillingConstants.INVOICE));
		invoiceEntity.setMiscBillingAddOnChargeDtl(populateAddOnChargeDtlinInvoiceSummary(invoiceSummary.getAddOnCharges(), invoiceEntity));
		
		BigInteger attachmentCount = invoiceSummary.getAttachmentCount();
		if(attachmentCount != null) {
			invoiceEntity.setNoOfAttachments(attachmentCount.intValue());
		}
		log.debug("Exiting processInvoiceSummary()");
	}
	
	public List<MiscBillingTaxDetailsEntity> populateTaxVatDetails(List<Tax> taxList, MiscBillingTrnInvoiceEntity invoiceEntity,
			MiscBillingInvLineitemEntity lineItemEntity, MiscBillingInvLineitemDtlEntity lineItemDtlEntity, String type) {
		
		int invoiceSeqNo = 1;
		int lineItemSeqNo = 1;
		int lineItemDtlSeqNo = 1;
		List<MiscBillingTaxDetailsEntity> taxDtlEntityList = new ArrayList<>();
		for (Tax tax : taxList) {
			MiscBillingTaxDetailsEntity taxDtlEntity = taxDetailsMapper.mapToEntity(tax);
			if(!StringUtils.isEmpty(tax.getTaxType())) {
				taxDtlEntity.setTaxType(tax.getTaxType().value());
			}
			if(!StringUtils.isEmpty(tax.getTaxCategory())) {
				taxDtlEntity.setTaxCategory(tax.getTaxCategory().value());
			}
			
			if(MiscBillingConstants.INVOICE.equalsIgnoreCase(type)) {
				taxDtlEntity.setRecordSeqNumber(invoiceSeqNo++);
				taxDtlEntity.setMiscBillingTrnInvoice(invoiceEntity);
				taxDtlEntity.setTaxLevel(MiscBillingConstants.INVOICE);
			} else if(MiscBillingConstants.LINE_ITEM.equalsIgnoreCase(type)) {
				taxDtlEntity.setMiscBillingTrnInvoice(invoiceEntity);
				taxDtlEntity.setRecordSeqNumber(lineItemSeqNo++);
				taxDtlEntity.setMiscBillingInvLineitem(lineItemEntity);
				taxDtlEntity.setTaxLevel(MiscBillingConstants.LINE_ITEM);
			} else if(MiscBillingConstants.LINE_ITEM_DETAIL.equalsIgnoreCase(type)) {
				taxDtlEntity.setMiscBillingTrnInvoice(invoiceEntity);
				taxDtlEntity.setRecordSeqNumber(lineItemDtlSeqNo++);
				taxDtlEntity.setMiscBillingInvLineitemDtl(lineItemDtlEntity);
				taxDtlEntity.setTaxLevel(MiscBillingConstants.DETAIL);
			}
			populateTaxVatAmount(tax, invoiceEntity, lineItemEntity, lineItemDtlEntity, type);
			taxDtlEntityList.add(taxDtlEntity);
		}
		return taxDtlEntityList;
	}
	
	public void populateTaxVatAmount(Tax tax, MiscBillingTrnInvoiceEntity invoiceEntity,
			MiscBillingInvLineitemEntity lineItemEntity, MiscBillingInvLineitemDtlEntity lineItemDtlEntity, String type) { 
		BigDecimal taxAmount = new BigDecimal(0);
		BigDecimal vatAmount = new BigDecimal(0);
		
		if(tax != null) {
			List<TaxAmount> taxAmountList = tax.getTaxAmount();
			for (TaxAmount taxAmt : taxAmountList) {
				TaxType taxType = tax.getTaxType();
				if(!StringUtils.isEmpty(taxType)) {
					String taxTypeValue = taxType.value();
					BigDecimal taxAmtValue = taxAmt.getValue();
					if(MiscBillingConstants.TAX.equalsIgnoreCase(taxTypeValue)) {
						if(taxAmt.getName() != null && !StringUtils.isEmpty(taxAmt.getName().name())){
							if(MiscBillingConstants.DIFFERENCE.equalsIgnoreCase(taxAmt.getName().name())) {
								taxAmount = taxAmtValue;
							}
						} else {
							taxAmount = taxAmtValue;
						}
					} else if(MiscBillingConstants.VAT.equalsIgnoreCase(taxTypeValue)) {
						if(taxAmt.getName() != null && !StringUtils.isEmpty(taxAmt.getName().name())){
							if(MiscBillingConstants.DIFFERENCE.equalsIgnoreCase(taxAmt.getName().name())) {
								vatAmount = taxAmtValue;
							}
						} else {
							vatAmount = taxAmtValue;
						}
					}
				}
			}	 
		}
		
		if(MiscBillingConstants.INVOICE.equalsIgnoreCase(type)) {
			if(invoiceEntity.getTaxAmount() != null) {
				invoiceEntity.setTaxAmount(invoiceEntity.getTaxAmount().add(taxAmount));
			} else {
				invoiceEntity.setTaxAmount(taxAmount);
			}
			if(invoiceEntity.getVatAmount() != null) {
				invoiceEntity.setVatAmount(invoiceEntity.getVatAmount().add(vatAmount));
			} else {
				invoiceEntity.setVatAmount(vatAmount);
			}
		} else if(MiscBillingConstants.LINE_ITEM.equalsIgnoreCase(type)) {
			if(lineItemEntity.getTaxAmount() != null) {
				lineItemEntity.setTaxAmount(lineItemEntity.getTaxAmount().add(taxAmount));
			} else {
				lineItemEntity.setTaxAmount(taxAmount);
			}
			if(lineItemEntity.getVatAmount() != null) {
				lineItemEntity.setVatAmount(lineItemEntity.getVatAmount().add(vatAmount));
			} else {
				lineItemEntity.setVatAmount(vatAmount);
			}
		} else if(MiscBillingConstants.LINE_ITEM_DETAIL.equalsIgnoreCase(type)) {
			if(lineItemDtlEntity.getTaxAmt() != null) {
				lineItemDtlEntity.setTaxAmt(lineItemDtlEntity.getTaxAmt().add(taxAmount));;
			} else {
				lineItemDtlEntity.setTaxAmt(taxAmount);
			}
			if(lineItemDtlEntity.getVatAmt() != null) {
				lineItemDtlEntity.setVatAmt(lineItemDtlEntity.getVatAmt().add(vatAmount));
			} else {
				lineItemDtlEntity.setVatAmt(vatAmount);
			}
		}
	}
	
	public List<MiscBillingAddOnChargeDtlEntity> populateAddOnChargeDtlinInvoiceSummary(List<InvoiceSummary.AddOnCharges> addOnCharges
			, MiscBillingTrnInvoiceEntity invoiceEntity) {
		
		int invoiceSeqNo = 1;
		List<MiscBillingAddOnChargeDtlEntity> addOnchargeDtlEntityList = new ArrayList<>();
		for (InvoiceSummary.AddOnCharges addOnCharge : addOnCharges) {
			MiscBillingAddOnChargeDtlEntity addOnChargeDtlEntity = addOnChargeDtlMapper.mapForInvSummaryToEntity(addOnCharge);
			addOnChargeDtlEntity.setAddOnLevel(MiscBillingConstants.INVOICE);
			addOnChargeDtlEntity.setRecordSeqNumber(invoiceSeqNo++);
			if(!StringUtils.isEmpty(addOnCharge.getAddOnChargePercentage())) {
				addOnChargeDtlEntity.setAddOnChargePercentage(new BigDecimal(addOnCharge.getAddOnChargePercentage()));
			}
			addOnChargeDtlEntity.setMiscBillingTrnInvoice(invoiceEntity);
			addOnchargeDtlEntityList.add(addOnChargeDtlEntity);
		}
		return addOnchargeDtlEntityList;
	}
	
	public List<MiscBillingAddOnChargeDtlEntity> populateAddOnChargeDtl(List<AddOnCharges> addOnCharges, MiscBillingTrnInvoiceEntity invoiceEntity, 
			MiscBillingInvLineitemEntity lineItemEntity, MiscBillingInvLineitemDtlEntity lineItemDtlEntity, String type) {

		int lineItemSeqNo = 1;
		int lineItemDtlSeqNo = 1;
		List<MiscBillingAddOnChargeDtlEntity> addOnchargeDtlEntityList = new ArrayList<>();
		for (AddOnCharges addOnCharge : addOnCharges) {
			MiscBillingAddOnChargeDtlEntity addOnChargeDtlEntity = addOnChargeDtlMapper.mapToEntity(addOnCharge);
			if(!StringUtils.isEmpty(addOnCharge.getAddOnChargePercentage())){
				addOnChargeDtlEntity.setAddOnChargePercentage(new BigDecimal(addOnCharge.getAddOnChargePercentage()));
			}
			if(MiscBillingConstants.LINE_ITEM.equalsIgnoreCase(type)) {	
				addOnChargeDtlEntity.setRecordSeqNumber(lineItemSeqNo++);
				addOnChargeDtlEntity.setAddOnLevel(MiscBillingConstants.LINE_ITEM);
				addOnChargeDtlEntity.setMiscBillingInvLineitem(lineItemEntity);
			} else if(MiscBillingConstants.LINE_ITEM_DETAIL.equalsIgnoreCase(type)) {
				addOnChargeDtlEntity.setRecordSeqNumber(lineItemDtlSeqNo++);
				addOnChargeDtlEntity.setAddOnLevel(MiscBillingConstants.DETAIL);
				addOnChargeDtlEntity.setMiscBillingInvLineitemDtl(lineItemDtlEntity);
			}
			addOnChargeDtlEntity.setMiscBillingTrnInvoice(invoiceEntity);
			addOnchargeDtlEntityList.add(addOnChargeDtlEntity);
		}
		return addOnchargeDtlEntityList;
	}

	public void populateLineItemDetailListInLineItem(MiscBillingInvLineitemEntity lineItemEntity, 
			List<MiscBillingInvLineitemDtlEntity> lineItemDtlEntityList) {

		List<MiscBillingInvLineitemDtlEntity> newlineItemDtlEntityList = new ArrayList<>();
		for (MiscBillingInvLineitemDtlEntity lineItemDtlEntity : lineItemDtlEntityList) {
			BigInteger lineItemNumber = lineItemDtlEntity.getLineItemNumber();
			if(lineItemNumber != null && lineItemEntity.getLineItemNumber() != null){
				if(lineItemNumber.intValue() == lineItemEntity.getLineItemNumber()) {
					newlineItemDtlEntityList.add(lineItemDtlEntity);
				}
			}
		}
		lineItemEntity.setMiscBillingLineitemDetails(newlineItemDtlEntityList);
	}
	
	public String getChargeCode(String chargeCategoryCode, String chargeCodeName) {
		
		String chargeCode = MiscBillingConstants.EMPTY_STRING;
		List<ChargeCode> chargeCodeList = chargeCodeMap.get(chargeCategoryCode);
		for (ChargeCode cc : chargeCodeList) {
			if(chargeCodeName.equalsIgnoreCase(cc.getChargeCodeName().get())){
				chargeCode = cc.getChargeCode().get();
			}
		}
		return chargeCode;
	}	
}