/**
 * 
 */
package com.sgl.smartpra.batch.mib.app.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingConstants;
import com.sgl.smartpra.global.master.model.Carrier;
import com.sgl.smartpra.global.master.model.Section;
import com.sgl.smartpra.mib.entity.MiscBillingSupportingDetailEntity;
import com.sgl.smartpra.mib.jaxb.dictionary.ContactType;
import com.sgl.smartpra.mib.jaxb.standard.AccommodationDetails;
import com.sgl.smartpra.mib.jaxb.standard.AircraftDetails;
import com.sgl.smartpra.mib.jaxb.standard.AreaDetails;
import com.sgl.smartpra.mib.jaxb.standard.CarDetails;
import com.sgl.smartpra.mib.jaxb.standard.CateringDetails;
import com.sgl.smartpra.mib.jaxb.standard.ConsumptionDetails;
import com.sgl.smartpra.mib.jaxb.standard.ContactDetails;
import com.sgl.smartpra.mib.jaxb.standard.DeskGateDetails;
import com.sgl.smartpra.mib.jaxb.standard.EmployeeDetails;
import com.sgl.smartpra.mib.jaxb.standard.FlightDetails;
import com.sgl.smartpra.mib.jaxb.standard.LineItemDetail;
import com.sgl.smartpra.mib.jaxb.standard.MailDetails;
import com.sgl.smartpra.mib.jaxb.standard.MiscData;
import com.sgl.smartpra.mib.jaxb.standard.MiscDetails;
import com.sgl.smartpra.mib.jaxb.standard.ParkingDetails;
import com.sgl.smartpra.mib.jaxb.standard.PassengerDetails;
import com.sgl.smartpra.mib.jaxb.standard.ReferenceNo;
import com.sgl.smartpra.mib.jaxb.standard.RouteDetails;
import com.sgl.smartpra.mib.jaxb.standard.ServiceProviderDetails;
import com.sgl.smartpra.mib.jaxb.standard.SettlementDetails;
import com.sgl.smartpra.mib.jaxb.standard.UATPDetails;

import lombok.extern.slf4j.Slf4j;

/**
 * @author kanprasa
 *
 */
@Service
@Slf4j
public class SupportingDetailService {

	public Map<String, List<Object>> getSectionDetailsList(List<Section> sectionList, LineItemDetail lineItemDetail) {
		
		Map<String, List<Object>> sectionMap = new HashMap<>();
		for (Section section : sectionList) {
			String sectionName = section.getSectionNameActual().get();
		
			if(MiscBillingConstants.ROUTE_DETAILS.equalsIgnoreCase(sectionName)) {
				if(lineItemDetail.getRouteDetails() != null) {
					List<Object> routeList = new ArrayList<>();
					for (RouteDetails routeDetail : lineItemDetail.getRouteDetails()) {
						routeList.add(routeDetail);
					}
					sectionMap.put(sectionName, routeList);
				}
			} else if(MiscBillingConstants.SETTLEMENT_DETAILS.equalsIgnoreCase(sectionName)) {
				if(lineItemDetail.getSettlementDetails() != null) {
					List<Object> settleList = new ArrayList<>();
					for (SettlementDetails settlementDetail : lineItemDetail.getSettlementDetails()) {
						settleList.add(settlementDetail);
					}
					sectionMap.put(sectionName, settleList);
				}
			} else if(MiscBillingConstants.PASSENGER_DETAILS.equalsIgnoreCase(sectionName)) {
				if(lineItemDetail.getPassengerDetails() != null) {
					List<Object> passList = new ArrayList<>();
					for (PassengerDetails passengerDetail : lineItemDetail.getPassengerDetails()) {
						passList.add(passengerDetail);
					}
					sectionMap.put(sectionName, passList);
				}
			} else if(MiscBillingConstants.CATERING_DETAILS.equalsIgnoreCase(sectionName)) {
				if(lineItemDetail.getCateringDetails() != null) {
					List<Object> catList = new ArrayList<>();
					for (CateringDetails cateringDetail : lineItemDetail.getCateringDetails()) {
						catList.add(cateringDetail);
					}
					sectionMap.put(sectionName, catList);
				}
			} else if(MiscBillingConstants.EMPLOYEE_DETAILS.equalsIgnoreCase(sectionName)) {
				if(lineItemDetail.getEmployeeDetails() != null) {
					List<Object> empList = new ArrayList<>();
					for (EmployeeDetails employeeDetail : lineItemDetail.getEmployeeDetails()) {
						empList.add(employeeDetail);
					}
					sectionMap.put(sectionName, empList);
				}
			} else if(MiscBillingConstants.MISC_DETAILS.equalsIgnoreCase(sectionName)) {
				MiscDetails miscDetails = lineItemDetail.getMiscDetails();
				if(miscDetails != null) {
					List<MiscData> miscDataList = miscDetails.getMiscData();
					if(miscDataList != null && miscDataList.size() > 0) {
						List<Object> miscList = new ArrayList<>();
						for (MiscData miscData : miscDataList) {
							miscList.add(miscData);
						}
						sectionMap.put(sectionName, miscList);
					}
				}
			} else if(MiscBillingConstants.REFERENCE_NO.equalsIgnoreCase(sectionName)) {
				if(lineItemDetail.getReferenceNo() != null) {
					List<Object> refList = new ArrayList<>();
					for (ReferenceNo referenceNo : lineItemDetail.getReferenceNo()) {
						refList.add(referenceNo);
					}
					sectionMap.put(sectionName, refList);
				}
			}
		}
		
		return sectionMap;
	}
	
	public Map<String, Object> getSectionDetails(List<Section> sectionList, LineItemDetail lineItemDetail) {
		
		Map<String, Object> sectionMap = new HashMap<>();
		for (Section section : sectionList) {
			String sectionName = section.getSectionNameActual().get();
		
			if(MiscBillingConstants.MAIL_DETAILS.equalsIgnoreCase(sectionName)) {
				if(lineItemDetail.getMailDetails() != null)	sectionMap.put(sectionName, lineItemDetail.getMailDetails());
			} else if(MiscBillingConstants.AIRCRAFT_DETAILS.equalsIgnoreCase(sectionName)) {
				if(lineItemDetail.getAircraftDetails() != null) sectionMap.put(sectionName, lineItemDetail.getAircraftDetails());
			} else if(MiscBillingConstants.FLIGHT_DETAILS.equalsIgnoreCase(sectionName)) {
				if(lineItemDetail.getFlightDetails() != null) sectionMap.put(sectionName, lineItemDetail.getFlightDetails());
			} else if(MiscBillingConstants.PARKING_DETAILS.equalsIgnoreCase(sectionName)) {
				if(lineItemDetail.getParkingDetails() != null) sectionMap.put(sectionName, lineItemDetail.getParkingDetails());
			} else if(MiscBillingConstants.AREA_DETAILS.equalsIgnoreCase(sectionName)) {
				if(lineItemDetail.getAreaDetails() != null) sectionMap.put(sectionName, lineItemDetail.getAreaDetails());
			} else if(MiscBillingConstants.DESKGATES_DETAILS.equalsIgnoreCase(sectionName)) {
				if(lineItemDetail.getDeskGateDetails() != null) sectionMap.put(sectionName, lineItemDetail.getDeskGateDetails());
			} else if(MiscBillingConstants.CONSUMPTION_DETAILS.equalsIgnoreCase(sectionName)) {
				if(lineItemDetail.getConsumptionDetails() != null) sectionMap.put(sectionName, lineItemDetail.getConsumptionDetails());
			} else if(MiscBillingConstants.SERVICE_PROVIDER_DETAILS.equalsIgnoreCase(sectionName)) {
				if(lineItemDetail.getServiceProviderDetails() != null) sectionMap.put(sectionName, lineItemDetail.getServiceProviderDetails());
			} else if(MiscBillingConstants.ACCOMODATION_DETAILS.equalsIgnoreCase(sectionName)) {
				if(lineItemDetail.getAccommodationDetails() != null) sectionMap.put(sectionName, lineItemDetail.getAccommodationDetails());	
			} else if(MiscBillingConstants.CAR_DETAILS.equalsIgnoreCase(sectionName)) {
				if(lineItemDetail.getCarDetails() != null) sectionMap.put(sectionName, lineItemDetail.getCarDetails());
			} else if(MiscBillingConstants.UATP_DETAILS.equalsIgnoreCase(sectionName)) {
				if(lineItemDetail.getUATPDetails() != null) sectionMap.put(sectionName, lineItemDetail.getUATPDetails());
			} else if(MiscBillingConstants.CONTRACT_NO.equalsIgnoreCase(sectionName)) {
				if(StringUtils.isNotBlank(lineItemDetail.getContractNo())) sectionMap.put(sectionName, lineItemDetail.getContractNo());
			} else if(MiscBillingConstants.POOL_NO.equalsIgnoreCase(sectionName)) {
				if(StringUtils.isNotBlank(lineItemDetail.getPoolNo())) sectionMap.put(sectionName, lineItemDetail.getPoolNo());
				if(lineItemDetail.getPoolNo() != null) sectionMap.put(sectionName, lineItemDetail.getPoolNo());
			} else if(MiscBillingConstants.RECEIPT_NO.equalsIgnoreCase(sectionName)) {
				if(StringUtils.isNotBlank(lineItemDetail.getReceiptNo())) sectionMap.put(sectionName, lineItemDetail.getReceiptNo());
			} else if(MiscBillingConstants.RECIPIENT.equalsIgnoreCase(sectionName)) {
				if(StringUtils.isNotBlank(lineItemDetail.getRecipient())) sectionMap.put(sectionName, lineItemDetail.getRecipient());
			} else if(MiscBillingConstants.MISHANDLING_TYPE.equalsIgnoreCase(sectionName)) {
				if(StringUtils.isNotBlank(lineItemDetail.getMishandlingType())) sectionMap.put(sectionName, lineItemDetail.getMishandlingType());
			}
		}
		
		return sectionMap;
	}
	
	public void populateSectionDetails(LineItemDetail lineItemDetail, MiscBillingSupportingDetailEntity suppDtlEntity) {
		
		String sectionName = suppDtlEntity.getSectionName();
		String json = suppDtlEntity.getJsonValue();
		if(StringUtils.isBlank(sectionName) || StringUtils.isBlank(json)) return;
		
		Gson gson = new Gson();
		if(MiscBillingConstants.MAIL_DETAILS.equalsIgnoreCase(sectionName)) {
			lineItemDetail.setMailDetails(gson.fromJson(json, MailDetails.class));
		} else if(MiscBillingConstants.AIRCRAFT_DETAILS.equalsIgnoreCase(sectionName)) {
			lineItemDetail.setAircraftDetails(gson.fromJson(json, AircraftDetails.class));
		} else if(MiscBillingConstants.FLIGHT_DETAILS.equalsIgnoreCase(sectionName)) {
			lineItemDetail.setFlightDetails(gson.fromJson(json, FlightDetails.class));
		} else if(MiscBillingConstants.PARKING_DETAILS.equalsIgnoreCase(sectionName)) {
			lineItemDetail.setParkingDetails(gson.fromJson(json, ParkingDetails.class));
		} else if(MiscBillingConstants.AREA_DETAILS.equalsIgnoreCase(sectionName)) {
			lineItemDetail.setAreaDetails(gson.fromJson(json, AreaDetails.class));
		} else if(MiscBillingConstants.DESKGATES_DETAILS.equalsIgnoreCase(sectionName)) {
			lineItemDetail.setDeskGateDetails(gson.fromJson(json, DeskGateDetails.class));
		} else if(MiscBillingConstants.CONSUMPTION_DETAILS.equalsIgnoreCase(sectionName)) {
			lineItemDetail.setConsumptionDetails(gson.fromJson(json, ConsumptionDetails.class));
		} else if(MiscBillingConstants.SERVICE_PROVIDER_DETAILS.equalsIgnoreCase(sectionName)) {
			lineItemDetail.setServiceProviderDetails(gson.fromJson(json, ServiceProviderDetails.class));
		} else if(MiscBillingConstants.ACCOMODATION_DETAILS.equalsIgnoreCase(sectionName)) {
			lineItemDetail.setAccommodationDetails(gson.fromJson(json, AccommodationDetails.class));
		} else if(MiscBillingConstants.CAR_DETAILS.equalsIgnoreCase(sectionName)) {
			lineItemDetail.setCarDetails(gson.fromJson(json, CarDetails.class));
		} else if(MiscBillingConstants.UATP_DETAILS.equalsIgnoreCase(sectionName)) {
			lineItemDetail.setUATPDetails(gson.fromJson(json, UATPDetails.class));
		} else if(MiscBillingConstants.ROUTE_DETAILS.equalsIgnoreCase(sectionName)) {
			try {
				List<RouteDetails> routeDetails = Arrays.asList(gson.fromJson(json, RouteDetails[].class));
				lineItemDetail.getRouteDetails().addAll(routeDetails);
			} catch (JsonSyntaxException e) {
				log.error("Exception thrown while converting json to List<RouteDetails>: " + json);
				e.printStackTrace();
			}
		} else if(MiscBillingConstants.SETTLEMENT_DETAILS.equalsIgnoreCase(sectionName)) {
			try {
				List<SettlementDetails> settlementDetails = Arrays.asList(gson.fromJson(json, SettlementDetails[].class));
				lineItemDetail.getSettlementDetails().addAll(settlementDetails);
			} catch (JsonSyntaxException e) {
				log.error("Exception thrown while converting json to List<SettlementDetails>: " + json);
				e.printStackTrace();
			}
		} else if(MiscBillingConstants.PASSENGER_DETAILS.equalsIgnoreCase(sectionName)) {
			try {
				List<PassengerDetails> passengerDetails = Arrays.asList(gson.fromJson(json, PassengerDetails[].class));
				lineItemDetail.getPassengerDetails().addAll(passengerDetails);
			} catch (JsonSyntaxException e) {
				log.error("Exception thrown while converting json to List<PassengerDetails>: " + json);
				e.printStackTrace();
			}
		} else if(MiscBillingConstants.CATERING_DETAILS.equalsIgnoreCase(sectionName)) {
			try {
				List<CateringDetails> cateringDetails = Arrays.asList(gson.fromJson(json, CateringDetails[].class));
				lineItemDetail.getCateringDetails().addAll(cateringDetails);
			} catch (JsonSyntaxException e) {
				log.error("Exception thrown while converting json to List<CateringDetails>: " + json);
				e.printStackTrace();
			}
		} else if(MiscBillingConstants.EMPLOYEE_DETAILS.equalsIgnoreCase(sectionName)) {
			try {
				List<EmployeeDetails> employeeDetails = Arrays.asList(gson.fromJson(json, EmployeeDetails[].class));
				lineItemDetail.getEmployeeDetails().addAll(employeeDetails);
			} catch (JsonSyntaxException e) {
				log.error("Exception thrown while converting json to List<EmployeeDetails>: " + json);
				e.printStackTrace();
			}
		} else if(MiscBillingConstants.MISC_DETAILS.equalsIgnoreCase(sectionName)) {
			lineItemDetail.setMiscDetails(gson.fromJson(json, MiscDetails.class));
		} else if(MiscBillingConstants.CONTRACT_NO.equalsIgnoreCase(sectionName)) {
			lineItemDetail.setContractNo(gson.fromJson(json, String.class));
		} else if(MiscBillingConstants.POOL_NO.equalsIgnoreCase(sectionName)) {
			lineItemDetail.setPoolNo(gson.fromJson(json, String.class));
		} else if(MiscBillingConstants.RECEIPT_NO.equalsIgnoreCase(sectionName)) {
			lineItemDetail.setReceiptNo(gson.fromJson(json, String.class));
		} else if(MiscBillingConstants.REFERENCE_NO.equalsIgnoreCase(sectionName)) {
			try {
				List<ReferenceNo> referenceNo = Arrays.asList(gson.fromJson(json, ReferenceNo[].class));
				lineItemDetail.getReferenceNo().addAll(referenceNo);
			} catch (JsonSyntaxException e) {
				log.error("Exception thrown while converting json to List<ReferenceNo>: " + json);
				e.printStackTrace();
			}
		} else if(MiscBillingConstants.RECIPIENT.equalsIgnoreCase(sectionName)) {
			lineItemDetail.setRecipient(gson.fromJson(json, String.class));
		} else if(MiscBillingConstants.MISHANDLING_TYPE.equalsIgnoreCase(sectionName)) {
			lineItemDetail.setMishandlingType(gson.fromJson(json, String.class));
		}
	}
	
	public List<ContactDetails> getContactDetails(Carrier carrier) {
		List<ContactDetails> cdList = new ArrayList<>();
		if(carrier.getTelephoneNumber().isPresent()) {
			cdList.add(getContactDetails(MiscBillingConstants.TELEPHONE, carrier.getTelephoneNumber().get()));
		}
		if(carrier.getEmail().isPresent()) {
			cdList.add(getContactDetails(MiscBillingConstants.EMAIL, carrier.getEmail().get()));
		}
		if(carrier.getFaxNumber().isPresent()) {
			cdList.add(getContactDetails(MiscBillingConstants.FAX, carrier.getFaxNumber().get()));
		}
		if(carrier.getTelex().isPresent()) {
			cdList.add(getContactDetails(MiscBillingConstants.TELEX, carrier.getTelex().get()));
		}
		if(carrier.getAftn().isPresent()) {
			cdList.add(getContactDetails(MiscBillingConstants.AFTN, carrier.getAftn().get()));
		}
		if(carrier.getSita().isPresent()) {
			cdList.add(getContactDetails(MiscBillingConstants.SITA, carrier.getSita().get()));
		}
		if(carrier.getWebsite().isPresent()) {
			cdList.add(getContactDetails(MiscBillingConstants.WEBSITE, carrier.getWebsite().get()));
		}
		return cdList;		
	}
	
	public ContactDetails getContactDetails(String contactType, String contactValue) {
		ContactDetails cd = new ContactDetails();
		cd.setContactType(ContactType.fromValue(contactType));
		cd.setContactValue(contactValue);
		return cd;		
	}
}
