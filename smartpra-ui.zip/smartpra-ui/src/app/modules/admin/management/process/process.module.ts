import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProcessRoutingModule } from './process-routing.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { ProcessComponent } from './process.component';
import { CoreDataModule } from 'src/app/core-data/core-data.module';

@NgModule({
  imports: [
    CommonModule,
    CoreDataModule,
    SharedModule,
    ProcessRoutingModule
  ],
  declarations: [
    ProcessComponent
  ]
})
export class ProcessModule { }
