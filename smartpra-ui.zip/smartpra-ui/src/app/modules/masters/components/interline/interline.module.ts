import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { InterlineRoutingModule } from './interline-routing.module';

@NgModule({
  imports: [
    CommonModule,    
    InterlineRoutingModule
  ],
  declarations: []
})
export class InterlineModule { }
