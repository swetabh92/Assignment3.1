package com.sgl.smartpra.batch.sales.validator.app.domain;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.fasterxml.jackson.annotation.JsonIgnore;



/**
 * The persistent class for the standared_amount_stg database table.
 * 
 */
@Entity
@Table(name="standared_amount_stg")
public class StandaredAmountStg extends BSPRecord implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="std_amount_auto_id")
	private int stdAmountAutoId;

	@Column(name="check_digit")
	private String checkDigit;

	@Column(name="commissionable_amount")
	private String commissionableAmount;

	@Column(name="created_by")
	private String createdBy;

	@Column(name="created_date")
	private Timestamp createdDate;

	@Column(name="currency_type")
	private String currencyType;

	@Column(name="date_of_issue")
	private String dateOfIssue;

	private String filler;

	@Column(name="last_updated_by")
	private String lastUpdatedBy;

	@Column(name="last_updated_date")
	private Timestamp lastUpdatedDate;

	@Column(name="net_fare_amount")
	private String netFareAmount;

	@Column(name="seq_number")
	private String seqNumber;

	@Column(name="std_message_identifier")
	private String stdMessageIdentifier;

	@Column(name="std_numeric_quaifier")
	private String stdNumericQuaifier;

	@Column(name="tax_misc_fee_amount_1")
	private String taxMiscFeeAmount1;

	@Column(name="tax_misc_fee_amount_2")
	private String taxMiscFeeAmount2;

	@Column(name="tax_misc_fee_amount_3")
	private String taxMiscFeeAmount3;

	@Column(name="tax_misc_fee_type_1")
	private String taxMiscFeeType1;

	@Column(name="tax_misc_fee_type_2")
	private String taxMiscFeeType2;

	@Column(name="tax_misc_fee_type_3")
	private String taxMiscFeeType3;

	@Column(name="tkt_doc_amount")
	private String tktDocAmount;

	@Column(name="tkt_doc_number")
	private String tktDocNumber;

	@Column(name="transaction_number")
	private String transactionNumber;

	//bi-directional many-to-one association to TransactionHdrStg
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.MERGE)
	@JoinColumn(name="transaction_hdr_id")
	private TransactionHdrStg transactionHdrStg;

	public StandaredAmountStg() {
	}

	public int getStdAmountAutoId() {
		return this.stdAmountAutoId;
	}

	public void setStdAmountAutoId(int stdAmountAutoId) {
		this.stdAmountAutoId = stdAmountAutoId;
	}

	public String getCheckDigit() {
		return this.checkDigit;
	}

	public void setCheckDigit(String checkDigit) {
		this.checkDigit = checkDigit;
	}

	public String getCommissionableAmount() {
		return this.commissionableAmount;
	}

	public void setCommissionableAmount(String commissionableAmount) {
		this.commissionableAmount = commissionableAmount;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCurrencyType() {
		return this.currencyType;
	}

	public void setCurrencyType(String currencyType) {
		this.currencyType = currencyType;
	}

	public String getDateOfIssue() {
		return this.dateOfIssue;
	}

	public void setDateOfIssue(String dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}

	public String getFiller() {
		return this.filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}

	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getLastUpdatedDate() {
		return this.lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getNetFareAmount() {
		return this.netFareAmount;
	}

	public void setNetFareAmount(String netFareAmount) {
		this.netFareAmount = netFareAmount;
	}

	public String getSeqNumber() {
		return this.seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdMessageIdentifier() {
		return this.stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getStdNumericQuaifier() {
		return this.stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getTaxMiscFeeAmount1() {
		return this.taxMiscFeeAmount1;
	}

	public void setTaxMiscFeeAmount1(String taxMiscFeeAmount1) {
		this.taxMiscFeeAmount1 = taxMiscFeeAmount1;
	}

	public String getTaxMiscFeeAmount2() {
		return this.taxMiscFeeAmount2;
	}

	public void setTaxMiscFeeAmount2(String taxMiscFeeAmount2) {
		this.taxMiscFeeAmount2 = taxMiscFeeAmount2;
	}

	public String getTaxMiscFeeAmount3() {
		return this.taxMiscFeeAmount3;
	}

	public void setTaxMiscFeeAmount3(String taxMiscFeeAmount3) {
		this.taxMiscFeeAmount3 = taxMiscFeeAmount3;
	}

	public String getTaxMiscFeeType1() {
		return this.taxMiscFeeType1;
	}

	public void setTaxMiscFeeType1(String taxMiscFeeType1) {
		this.taxMiscFeeType1 = taxMiscFeeType1;
	}

	public String getTaxMiscFeeType2() {
		return this.taxMiscFeeType2;
	}

	public void setTaxMiscFeeType2(String taxMiscFeeType2) {
		this.taxMiscFeeType2 = taxMiscFeeType2;
	}

	public String getTaxMiscFeeType3() {
		return this.taxMiscFeeType3;
	}

	public void setTaxMiscFeeType3(String taxMiscFeeType3) {
		this.taxMiscFeeType3 = taxMiscFeeType3;
	}

	public String getTktDocAmount() {
		return this.tktDocAmount;
	}

	public void setTktDocAmount(String tktDocAmount) {
		this.tktDocAmount = tktDocAmount;
	}

	public String getTktDocNumber() {
		return this.tktDocNumber;
	}

	public void setTktDocNumber(String tktDocNumber) {
		this.tktDocNumber = tktDocNumber;
	}

	public String getTransactionNumber() {
		return this.transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

	public TransactionHdrStg getTransactionHdrStg() {
		return this.transactionHdrStg;
	}

	public void setTransactionHdrStg(TransactionHdrStg transactionHdrStg) {
		this.transactionHdrStg = transactionHdrStg;
	}
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	

}