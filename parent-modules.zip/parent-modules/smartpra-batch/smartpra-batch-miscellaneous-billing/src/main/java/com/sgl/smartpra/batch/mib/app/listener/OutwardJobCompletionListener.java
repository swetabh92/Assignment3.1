/**
 * 
 */
package com.sgl.smartpra.batch.mib.app.listener;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;

import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.global.model.FileErrorLog;
import com.sgl.smartpra.batch.global.model.FileLogging;
import com.sgl.smartpra.batch.mib.app.config.FeignConfiguration.BatchGlobalFeignClient;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingConstants;
import com.sgl.smartpra.batch.mib.app.validator.CommonValidator;
import com.sgl.smartpra.common.util.FileLoggingConstants;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class OutwardJobCompletionListener extends JobExecutionListenerSupport {
	
	@Value("${batch.directory.misc-billing.input}")
	private String miscBillingBatchOutputDir;
	
	@Autowired
	private BatchGlobalFeignClient batchGlobalFeignClient;
	
	@Autowired
	private CommonValidator commonValidator; 
	
	@Override
	public void afterJob(JobExecution jobExecution) {
		String message = MiscBillingConstants.EMPTY_STRING;
		FileLogging fileLogging = batchGlobalFeignClient.getFileLogByFileId(BigInteger.valueOf(commonValidator.getFileId()));
		if (jobExecution.getStatus() == BatchStatus.COMPLETED) {
			fileLogging.setEndDateTime(new Timestamp(new Date().getTime()));
			fileLogging.setTotalCounts(commonValidator.getOutwardInvoiceCount());
			fileLogging.setHeaderCounts(commonValidator.getOutwardInvoiceCount());
			fileLogging.setDetailCounts(commonValidator.getOutwardChargeCodeCount());
			fileLogging.setErrorCounts(0);
			fileLogging.setTransferredCounts(0);
			fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_CREATED);
			fileLogging.setFileName(commonValidator.getOutwardFileName());
			message = "!!! JOB FINISHED! Time to verify the results";
		} else {
			fileLogging.setTotalCounts(0);
			fileLogging.setHeaderCounts(0);
			fileLogging.setDetailCounts(0);
			fileLogging.setErrorCounts(0);
			fileLogging.setTransferredCounts(0);
			fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_ERRONEOUS);
			fileLogging.setRemarks(FileLoggingConstants.FILELOGGING_FAILED_REMARK);
			fileLogging.setFileName(commonValidator.getOutwardFileName());
			FileErrorLog fileErrorLog = new FileErrorLog();
			fileErrorLog.setFileId(fileLogging.getFileId());
			fileErrorLog.setErrorDetail(jobExecution.getStatus().toString());
			fileErrorLog.setErrorDescription(jobExecution.getFailureExceptions().toString());
			ArrayList<FileErrorLog> fileErrorLogList = new ArrayList<>();
			fileErrorLogList.add(fileErrorLog);
			fileLogging.setFileErrorLog(fileErrorLogList);
			message = "!!! JOB FINISHED -FAILED ! Time to verify the results"; 
		}
		fileLogging = batchGlobalFeignClient.updateFileLog(fileLogging.getFileId(), fileLogging);
		commonValidator.resetMasters();
		log.info(message);
	}
}