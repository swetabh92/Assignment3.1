package com.sgl.smartpra.batch.amadeus.app.writer;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.amadeus.app.domain.ProdCouponModel;
import com.sgl.smartpra.batch.amadeus.app.common.AppConstants;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusBatchRecord;
import com.sgl.smartpra.flown.domain.FlownCoupon;
import com.sgl.smartpra.flown.repository.BsaCouponDetailRepository;
import com.sgl.smartpra.flown.repository.FlownCouponRepository;
import com.sgl.smartpra.flown.repository.FlownEsacRepository;
import com.sgl.smartpra.sales.domain.TicketCoupon;
import com.sgl.smartpra.sales.domain.TicketMain;
import com.sgl.smartpra.sales.repository.TicketMainRepository;

@Component
@Scope(value = "step")
public class ProdCouponDataWriter<T extends AmadeusBatchRecord> implements ItemWriter<ProdCouponModel> {

	private static final Logger LOGGER = LoggerFactory.getLogger(ProdCouponDataWriter.class);

	@Value("#{stepExecution}")
	private StepExecution stepExecution;

	@Value("#{jobParameters['carrieNumericCode']}")
	public Integer hostCarrNumericCode;

	@Value("#{jobParameters['careerDesignatorCode']}")
	public String hostCarrDesigCode;

	@Autowired
	private BsaCouponDetailRepository amadeusBsaCouponRepository;

	@Autowired
	private FlownCouponRepository amadeusETlFlownCouponRepository;

	@Autowired
	private FlownEsacRepository amadeusETlEsacCouponRepository;

	@Autowired
	private TicketMainRepository ticketMainRepository;

	@Override
	public void write(List<? extends ProdCouponModel> items) throws Exception {
		FlownCoupon flowncoupon = null;
		Optional<TicketMain> ticketMainOpt = null;
		TicketMain ticketMain = null;
		List<TicketCoupon> ticketCouponList = null;
		Boolean updateFlag = null;
		for (ProdCouponModel prodCouponModel : items) {
			LOGGER.info("Adding Flown Values" + prodCouponModel.getFlownEsac());
			//amadeusBsaCouponRepository.saveAndFlush(prodCouponModel.getBsaCouponDetail());
			if (prodCouponModel.getFlownCoupon() != null) {
				flowncoupon = prodCouponModel.getFlownCoupon();
				ticketMainOpt = ticketMainRepository.findByDocumentUniqueId(flowncoupon.getDocumentUniqueId());
				updateFlag = false;
				if (ticketMainOpt.isPresent()) {
					LOGGER.info("Dociment unique id is present in ticket main-->"
							+ ticketMainOpt.get().getDocumentUniqueId());
					ticketMain = ticketMainOpt.get();

					ticketCouponList = ticketMain.getTicketCoupons();
					for (TicketCoupon ticketCoupon : ticketCouponList) {
						if (ticketCoupon.getCouponNumber() == flowncoupon.getCouponNumber()) {
							flowncoupon.setDeriveFlownRbd(ticketCoupon.getTicketedRbd());
							flowncoupon.setDeriveFlownCabin(ticketCoupon.getTicketedCabin());
							if (ticketCoupon.getUtilType() == null) {
								LOGGER.info("Updating util_type for utilizing coupon");
								ticketCoupon.setUtilType(AppConstants.FLOWN_COUPON_U);
								ticketCoupon.setOperatingCarrierAlphaCode(hostCarrDesigCode);
								ticketCoupon.setOperatingCarrierNumCode(String.valueOf(hostCarrNumericCode));
								ticketCoupon.setOperatingFlightDeptDate(flowncoupon.getFlightDate());
								ticketCoupon.setOperatingFlightNumber(flowncoupon.getFlightNumber());
								updateFlag = true;
							}

							break;
						}
					}
				}
				if (updateFlag) {
					ticketMainRepository.saveAndFlush(ticketMain);
				}
				amadeusETlFlownCouponRepository.save(flowncoupon);
			}
			amadeusETlEsacCouponRepository.saveAndFlush(prodCouponModel.getFlownEsac());
		}
	}

	public StepExecution getStepExecution() {
		return stepExecution;
	}

	public void setStepExecution(StepExecution stepExecution) {
		this.stepExecution = stepExecution;
	}

}
