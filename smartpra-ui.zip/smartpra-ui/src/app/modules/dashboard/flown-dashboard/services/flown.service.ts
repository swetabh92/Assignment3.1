import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, map, tap } from 'rxjs/operators';
import { environment } from '../../../../../environments/environment';
import {CommonService} from '../../../masters/services/commons/common.service';
import {FlownListModel,CouponListModel,flownKey} from '../model/flown-model';
import { Observable } from 'rxjs';
const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
}
@Injectable({
  providedIn: 'root'
})
export class FlownService {
    viewFlown:FlownListModel;
    currencyDecimalPression:number=2;
    currencyCode:string = '';
    cabinRbdList:any;
    //apiUrlFlown = 'http://10.100.27.106:8060/smartpra/flown/flown-dashboard/';
    apiUrlFlown = environment.apiUrlFlown;
    //apiUrlFlown = 'http://10.245.240.63:8060/smartpra/flown/flown-dashboard/';
    constructor(private commonService: CommonService,private http: HttpClient) { }
    getSearchDet(data):Observable<FlownListModel[]>{
      return this.http.post<FlownListModel[]>(this.apiUrlFlown + 'search',this.commonService.convertApiObj(data),httpOptions).pipe(
        tap(_ => this.commonService.log('fetched flown Details')),
        catchError(this.commonService.handleError('getAllPos', []))
      );;
    }
    getCouponDet(data):Observable<CouponListModel[]>{
      return this.http.get<CouponListModel[]>(this.apiUrlFlown+data[flownKey]+'/searchCoupon',httpOptions)
      .pipe(
        tap(_ => this.commonService.log('fetched flown Details')),
        catchError(this.commonService.handleError('getAllPos', []))
      );
    }
    addCoupon(data):Observable<CouponListModel[]>{
      return this.http.post<CouponListModel[]>(this.apiUrlFlown+'coupon/add',data,httpOptions)
      .pipe(
        tap(_ => this.commonService.log('fetched flown Details')),
        catchError(this.commonService.handleError('getAllPos', []))
      );
    }
    editCoupon(data):Observable<CouponListModel[]>{
      return this.http.post<CouponListModel[]>(this.apiUrlFlown+'coupon/edit',data,httpOptions)
      .pipe(
        tap(_ => this.commonService.log('fetched flown Details')),
        catchError(this.commonService.handleError('getAllPos', []))
      );
    }
    deleteCoupon(data):Observable<CouponListModel[]>{
      return this.http.post<CouponListModel[]>(this.apiUrlFlown+'coupon/delete',data,httpOptions)
      .pipe(
        tap(_ => this.commonService.log('fetched flown Details')),
        catchError(this.commonService.handleError('getAllPos', []))
      );
    }
    getFlightInfo(flight){
     return this.http.get(this.apiUrlFlown+flight[flownKey]+'/searchFlightInfo',httpOptions)
      .pipe(
        tap(_ => this.commonService.log('fetched flown Details')),
        catchError(this.commonService.handleError('getAllPos', []))
      );
    }
    deleteFlight(flight){
      return this.http.get(this.apiUrlFlown+'flight/delete/'+flight[flownKey],httpOptions)
       .pipe(
         tap(_ => this.commonService.log('fetched flown Details')),
         catchError(this.commonService.handleError('getAllPos', []))
       );
    } 
    cancelFlight(flightKeys){
      return this.http.get(this.apiUrlFlown+'flight/cancel/'+flightKeys,httpOptions)
       .pipe(
         tap(_ => this.commonService.log('fetched flown Details')),
         catchError(this.commonService.handleError('getAllPos', []))
       );
    } 
    getCurrencyDP(){
      let url = environment.apiUrlSystemParameter+"DECIMAL_PRECISION";
      return this.http.get(url,httpOptions)
       .pipe(
         tap(_ => this.commonService.log('fetched flown Details')),
         catchError(this.commonService.handleError('getAllPos', []))
       );
    }
    getCurrencyCode(){
      let url = environment.apiUrlSystemParameter+"DEFAULT_CURRENCY_CODE";
      return this.http.get(url,httpOptions)
       .pipe(
         tap(_ => this.commonService.log('fetched flown Details')),
         catchError(this.commonService.handleError('getAllPos', []))
       );
    }
    getFlightLength(){
      let url = environment.apiUrlSystemParameter+"FLIGHT_NUMBER_OPTION";
      return this.http.get(url,httpOptions)
       .pipe(
         tap(_ => this.commonService.log('fetched flown Details')),
         catchError(this.commonService.handleError('getAllPos', []))
       );
    }
    couponReopen(data){
      return this.http.post(this.apiUrlFlown+'coupon/reopen/',data,httpOptions)
      .pipe(
         tap(_ => this.commonService.log('fetched flown Details')),
         catchError(this.commonService.handleError('getAllPos', []))
      );
    }
    holdOnCoupons(data){
      return this.http.post(this.apiUrlFlown+'coupon/holdon',data,httpOptions)
      .pipe(
         tap(_ => this.commonService.log('fetched flown Details')),
         catchError(this.commonService.handleError('getAllPos', []))
      );
    }
    flightReopen(flightKeys){
      return this.http.get(this.apiUrlFlown+'flight/cancel/'+flightKeys,httpOptions)
      .pipe(
         tap(_ => this.commonService.log('fetched flown Details')),
         catchError(this.commonService.handleError('getAllPos', []))
      );
    }
    flightInfoUpdate(data){
      return this.http.post(this.apiUrlFlown+'searchFlightInfo/edit',data,httpOptions)
      .pipe(
         tap(_ => this.commonService.log('fetched flown Details')),
         catchError(this.commonService.handleError('getAllPos', []))
      );
    }
    getCabinRbdList() {
      //let url="http://10.245.240.63:8060/smartpra/master/booking-class/cabin-rbd-list?clientId=QR&salesDate=2019-01-01&utilDate=2019-01-01";
      let url = environment.apiUrlMaster+"booking-class/cabin-rbd-list?clientId=QR&salesDate=2019-01-01&utilDate=2019-01-01";
      return this.http.get(url,httpOptions)
      .pipe(
         tap(_ => this.commonService.log('fetched flown Details')),
         catchError(this.commonService.handleError('getAllPos', []))
      );
    }
    
}
