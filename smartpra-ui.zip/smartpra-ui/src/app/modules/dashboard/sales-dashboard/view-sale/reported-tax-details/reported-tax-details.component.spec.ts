import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportedTaxDetailsComponent } from './reported-tax-details.component';

describe('ReportedTaxDetailsComponent', () => {
  let component: ReportedTaxDetailsComponent;
  let fixture: ComponentFixture<ReportedTaxDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportedTaxDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportedTaxDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
