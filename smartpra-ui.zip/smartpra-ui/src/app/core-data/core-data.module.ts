import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BsDatepickerCustomizeDirective } from '../modules/dashboard/flown-dashboard/model/bs-datepicker-customize.directive';
import { AutoScrollDirective } from '../commons/directivies/auto-scroll.directive';
import { NgxHeaderWordbreakComponent } from '../commons/components/ngx-header-wordbreak/ngx-header-wordbreak.component';
import { NgxGroupHeaderComponent } from '../commons/components/ngx-group-header/ngx-group-header.component';
import { NgxGroupCellComponent } from '../commons/components/ngx-group-cell/ngx-group-cell.component';
import { HeaderComponent } from '../core/layout/header/header.component';
import { LeftsidebarComponent } from '../core/layout/leftsidebar/leftsidebar.component';
import { RightsidebarComponent } from '../core/layout/rightsidebar/rightsidebar.component';
import { TaskMenuComponent } from '../core/layout/task-menu/task-menu.component';
import { FooterComponent } from '../core/layout/footer/footer.component';
import { NgxHeadercolComponent } from '../commons/components/ngx-headercol/ngx-headercol.component';
import { NgxSelectComponent } from '../commons/components/ngx-select/ngx-select.component';
import { UpperCaseDirective } from '../commons/directivies/upper-case.directive';
import { NumberOnlyDirective } from '../commons/directivies/number-only.directive';
import { NgxResizeWatcherDirective } from '../commons/directivies/ngx-resize-watcher.directive';
import { UpperalphaDirective } from '../commons/directivies/upperalpha.directive';
import { PercentageDirective } from '../commons/directivies/percentage.directive';
import { AlphabeatDirective } from '../commons/directivies/alphabeat.directive';
import { AlphanumericDirective } from '../commons/directivies/alphanumeric.directive';
import { ExceptionMasterPipe } from '../modules/masters/components/others/exception-master/exception-master-pipe';
import { InInterfaceLogstatusPipe } from '../modules/dashboard/custom-pipe/in-interface-logstatus.pipe';
import { FieldErrorMessageComponent } from '../commons/components/field-error-message/field-error-message.component';
import { TranslatePipe } from '../commons/translate/translate.pipe';
import { ToastAlertMessageComponent } from '../commons/components/toast-alert-message/toast-alert-message.component';
import { AutoFocusDirective } from '../commons/directivies/auto-focus.directive';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forChild([]),
  ],
  declarations: [
    BsDatepickerCustomizeDirective,
    AutoScrollDirective,
    NgxHeaderWordbreakComponent,
    NgxGroupHeaderComponent,
    NgxGroupCellComponent,
    HeaderComponent,
    LeftsidebarComponent,
    RightsidebarComponent,
    TaskMenuComponent,
    FooterComponent,
    NgxHeadercolComponent,
    NgxSelectComponent,
    UpperCaseDirective,
    NumberOnlyDirective,    
    NgxResizeWatcherDirective,
    UpperalphaDirective,
    PercentageDirective,
    AlphabeatDirective,
    AlphanumericDirective,
    ExceptionMasterPipe,
    InInterfaceLogstatusPipe,
    FieldErrorMessageComponent,
    TranslatePipe,
    ToastAlertMessageComponent,
    AutoFocusDirective
  ],
  exports:[
    BsDatepickerCustomizeDirective,
    AutoScrollDirective,
    NgxHeaderWordbreakComponent,
    NgxGroupHeaderComponent,
    NgxGroupCellComponent,
    HeaderComponent,
    LeftsidebarComponent,
    RightsidebarComponent,
    TaskMenuComponent,
    FooterComponent,
    NgxHeadercolComponent,
    NgxSelectComponent,
    UpperCaseDirective,
    NumberOnlyDirective,    
    NgxResizeWatcherDirective,
    UpperalphaDirective,
    PercentageDirective,
    AlphabeatDirective,
    AlphanumericDirective,
    ExceptionMasterPipe,
    InInterfaceLogstatusPipe,
    FieldErrorMessageComponent,
    TranslatePipe,
    ToastAlertMessageComponent,
    AutoFocusDirective,
    RouterModule
  ]
})
export class CoreDataModule { }
