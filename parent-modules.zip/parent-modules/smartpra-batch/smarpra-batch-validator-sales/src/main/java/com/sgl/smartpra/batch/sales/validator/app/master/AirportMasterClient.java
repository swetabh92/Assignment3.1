package com.sgl.smartpra.batch.sales.validator.app.master;

import java.util.List;

import com.sgl.smartpra.global.master.model.Airport;

public  interface AirportMasterClient {
	
	public  Airport getAirportByAirportCode(String airportCode);
	public  List<Airport> getAllAirport(String airportCode,String airportName, String cityCode,String cityName,String countryCode);
	
}