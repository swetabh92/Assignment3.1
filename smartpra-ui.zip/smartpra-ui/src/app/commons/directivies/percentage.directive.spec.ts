import { PercentageDirective } from './percentage.directive';

describe('PercentageDirective', () => {
  it('should create an instance', () => {
    const directive = new PercentageDirective();
    expect(directive).toBeTruthy();
  });
});
