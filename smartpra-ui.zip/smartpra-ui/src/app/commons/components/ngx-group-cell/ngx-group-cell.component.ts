import { Component, OnInit,Input,ElementRef,ViewChild,Output,EventEmitter  } from '@angular/core';

@Component({
  selector: 'app-ngx-group-cell',
  templateUrl: './ngx-group-cell.component.html',
  styleUrls: ['./ngx-group-cell.component.css']
})
export class NgxGroupCellComponent implements OnInit {
  @Input() groupValues:any[];
  @Input() row:any;
  constructor() { }

  ngOnInit() {
  }
 
}
