import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import swal from 'sweetalert2';

import { environment } from '../../../../environments/environment';
import { Userrole } from '../models/userrole';
import { MessageBoxService } from '../../masters/services/commons/message-box.service';
const httpOptions = {
  // headers: new HttpHeaders({ 'Content-Type': 'multipart/form-data' })
};
const httpOptions1 = {
  headers: new HttpHeaders({ 'Content-Type': 'multipart/form-data' })
};
@Injectable({
  providedIn: 'root'
})
export class UserroleService {
  globalUrl = environment.apiUrlGlobal;
  masterUrl = environment.apiUrlMaster;
  authUrl = environment.apiUrlauth;
  constructor(private http: HttpClient, private messageBoxService: MessageBoxService) { }
  getUserroleAll(): Observable<Userrole[]> {
    return this.http.get<Userrole[]>(this.authUrl + 'mas-user-roles')
      .pipe(
        tap(_ => this.log('fetched Userrole details')),
        catchError(this.handleError('getAllUserrole', []))
      );
  }
  UserroleByUserroleId(masUserRoleId: string): Observable<Userrole> {
    return this.http.get<Userrole>(this.authUrl + 'mas-user-roles/' + masUserRoleId).pipe(
      tap(_ => this.log(`fetched Userrole masUserRoleId=${masUserRoleId}`)),
      catchError(this.handleError<Userrole>(`UserroleByUserroleId masUserRoleId=${masUserRoleId}`))
    );
  }
  searchUserrole(parms: string): Observable<Userrole> {
    return this.http.get<Userrole>(this.authUrl + parms).pipe(
      tap(_ => this.log(`search Userrole masUserRoleId by ${parms}`)),
      catchError(this.handleError<Userrole>(`search Userrole masUserRoleId by ${parms}`))
    );
  }
  /** POST: add a new Userrole to the server */
  addUserrole(formdata): Observable<Userrole> {
    // console.log(formdata); return;
    return this.http.post<Userrole>(this.authUrl + 'mas-user-roles/', formdata, httpOptions).pipe(
      tap(_ => this.log(`added Userrole masUserRoleId=`)),
      catchError(this.handleError<Userrole>('addUserrole'))
    );
  }
  updateUserrole(userrole: Userrole): Observable<any> {
   // console.log(Userrole.masUserRoleId);
    // console.log(Userrole);
    return this.http.put<Userrole>(this.authUrl + 'mas-user-roles/' + userrole.masUserRoleId, Userrole, httpOptions).pipe(
      tap(_ => this.log(`updated Userrole masUserRoleId=${userrole.masUserRoleId}`)),
      catchError(this.handleError<Userrole>('addUserrole'))
    );
  }
  activateUserrole(masUserRoleId: string): Observable<Userrole> {
    return this.http.put<Userrole>(this.authUrl + 'mas-user-roles/activateordeactivate/' + masUserRoleId , httpOptions).pipe(
      tap(_ => this.log(`activate Userrole masUserRoleId=${masUserRoleId}`)),
      catchError(this.handleError<Userrole>('activateUserrole'))
    );
  }
  deactivateUserrole(masUserRoleId: string): Observable<Userrole> {
    return this.http.put<Userrole>(this.authUrl + 'mas-user-roles/activateordeactivate/' + masUserRoleId , httpOptions).pipe(
      tap(_ => this.log(`deactivate Userrole masUserRoleId=${masUserRoleId}`)),
      catchError(this.handleError<Userrole>('deactvateUserrole'))
    );
  }

  private handleError<T>(operation = 'operation', result?: T) {
    return (e: any): Observable<T> => {
      console.log(e);
      const error = e.error.message || e.error.error || e.error.error_description || 'Could not connect server';
      console.log(error);
      this.messageBoxService.getErrorMessage('ERROR', error);
      return of(result as T);
    };
  }
  private log(error: any) {
    console.log(error);
    if (error.message) {
      this.messageBoxService.getErrorMessage('ERROR', error.message);
    }
  }
}

