package com.sgl.smartpra.batch.bsp.app.listener;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.bsp.app.config.FeignConfiguration.BatchGlobalFeignClient;
import com.sgl.smartpra.batch.bsp.app.domain.staging.FileHeaderStg;
import com.sgl.smartpra.batch.bsp.app.repository.staging.FileHeaderStgRepository;
import com.sgl.smartpra.batch.global.model.FileErrorLog;
import com.sgl.smartpra.batch.global.model.FileLogging;
import com.sgl.smartpra.common.util.FileLoggingConstants;
import com.sgl.smartpra.common.util.SmartpraFileUtility;
import com.sgl.smartpra.sales.domain.TicketMain;
import com.sgl.smartpra.sales.domain.spec.TicketMainDomainSpecification;
import com.sgl.smartpra.sales.repository.TicketMainRepository;

@Component
public class BSPProdLoadJobExecutionListener extends JobExecutionListenerSupport {
	
	@Value("${batch.directory.bsp.processed}")
	private String processedDir;
	
	@Value("${batch.directory.bsp.input}")
	private String inputDir;
	
	@Value("${batch.directory.bsp.failed}")
	private String failedDir;
	
	@Autowired
	BatchGlobalFeignClient batchGlobalFeignClient;
	
	@Autowired
	TicketMainRepository ticketMainRepository; 
	
	@Autowired
	private FileHeaderStgRepository fileHeaderStgRepository;
	

	private static final Logger log = LoggerFactory.getLogger(BSPStagingLoadJobExecutionListener.class);
	
	
	
	

	@Override
	public void beforeJob(JobExecution jobExecution) {
		Map<String, String> ticketPaymentGMap = new Hashtable<>();
		Map<String, String> ticketSalesGMap = new Hashtable<>();
		Map<String, String> ticketTaxGMap = new Hashtable<>();
		Map<String, String> ticketOriginGMap = new Hashtable<>();
		Map<String, String> reportedTaxGMap = new Hashtable<>();
		Map<String, String> ticktCommisionGMap = new Hashtable<>();
		
		jobExecution.getExecutionContext().put("ticketPaymentGMap", ticketPaymentGMap);
		jobExecution.getExecutionContext().put("ticketSalesGMap", ticketSalesGMap);
		jobExecution.getExecutionContext().put("ticketTaxGMap", ticketTaxGMap);
		jobExecution.getExecutionContext().put("ticketOriginGMap", ticketOriginGMap);
		jobExecution.getExecutionContext().put("reportedTaxGMap", reportedTaxGMap);
		jobExecution.getExecutionContext().put("ticktCommisionGMap", ticktCommisionGMap);
		
	}

	@Override
	public void afterJob(JobExecution jobExecution) {
		
		JobParameters jobParameters = jobExecution.getJobParameters();
		
		long fileId = jobParameters.getLong("fileId");
		
		FileLogging fileLogging = batchGlobalFeignClient.getFileLogByFileId(BigInteger.valueOf(fileId));
		
		String fileName = fileLogging.getFileName();
		
		if (jobExecution.getStatus() == BatchStatus.COMPLETED) {
			
			Specification<TicketMain> spec = TicketMainDomainSpecification.countOfTicketMainByFileId((int) (long) fileId);

			long totalTicketCount = ticketMainRepository.count(spec);
			
			StepExecution stepExecution = jobExecution.getStepExecutions().stream().findAny().get();
			
			String duplicateRecord = (String) stepExecution.getExecutionContext().get("duplicateRecord");

			Integer headerCount = fileLogging.getHeaderCounts();
			Integer totalCount = headerCount + fileLogging.getDetailCounts();
			Integer errorCount = fileLogging.getDetailCounts() - (int)totalTicketCount;
			Integer detailCount = fileLogging.getDetailCounts();

			List<FileHeaderStg> fileHeader = fileHeaderStgRepository.findAllByFileId((int) (long) fileId);

			String ISOCityCode = "";
			if(fileHeader != null && !fileHeader.isEmpty() ) {
				
				ISOCityCode = fileHeader.get(0).getIsoCityCode();
			}
			
			
			if (jobExecution.getStatus() == BatchStatus.COMPLETED ) {
				fileLogging.setEndDateTime(new Timestamp(new Date().getTime()));
				fileLogging.setDetailCounts(detailCount);
				fileLogging.setTotalCounts(totalCount);
				fileLogging.setHeaderCounts(headerCount);
				fileLogging.setErrorCounts(errorCount);
				fileLogging.setTransferredCounts((int)totalTicketCount);
				fileLogging.setJobName(stepExecution.getStepName());
				fileLogging.setCityCode(ISOCityCode);
				if((StringUtils.isNotEmpty(duplicateRecord) && duplicateRecord.equals("Yes")) 
						&& (fileLogging.getErrorCounts()>0 && fileLogging.getTransferredCounts()>0)) {
					fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_PARTTRANSFERRED);
				}else if(fileLogging.getErrorCounts()>0 && fileLogging.getTransferredCounts()==0) {
					fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_ERRONEOUS);
				}
				else if(fileLogging.getErrorCounts()==0 && fileLogging.getTransferredCounts()>0 ){
				fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_TRANSFERRED);
				}else if(fileLogging.getErrorCounts()==0 && fileLogging.getTransferredCounts()==0) {
					fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_TECHFAILED);
					
				}
				fileLogging.setFileSize(StringUtils.isEmpty(fileLogging.getFileSize()) ? SmartpraFileUtility.getFileSize(inputDir + fileName) : fileLogging.getFileSize());
				
				
				if(stepExecution.getStepName().equalsIgnoreCase("fileLoggingDetailTasklet")) {
					try {
						SmartpraFileUtility.moveFile(inputDir + fileName, processedDir +fileName);
						fileLogging.setIsMovedToRelevantFolder("Y");
					} catch (Exception e) {
					
					}
				}
				
				log.info("!!! JOB FINISHED SUCCESSFULLY!");
				log.info("!!! START TIME = " + jobExecution.getStartTime());
				log.info("!!! END TIME = " + jobExecution.getEndTime());
				log.info("!!! TOTAL TICKET COUNT - "  + detailCount);
				log.info("!!! TOTAL TRANSFERED TICKET COUNT - "  + totalTicketCount);
				log.info("!!! TOTAL ERRONEOUS TICKET COUNT - "  + fileLogging.getErrorCounts());
				log.info("!!! Time taken = "
						+ ((jobExecution.getEndTime().getTime() - jobExecution.getStartTime().getTime()) / 1000.0)
						+ " seconds");
				
				
			} else {
				fileLogging.setTotalCounts(0);
				fileLogging.setHeaderCounts(0);
				fileLogging.setDetailCounts(0);
				fileLogging.setErrorCounts(0);
				fileLogging.setTransferredCounts(0);
				fileLogging.setJobName(stepExecution.getStepName());
				fileLogging.setFileSize(StringUtils.isEmpty(fileLogging.getFileSize()) ? SmartpraFileUtility.getFileSize(inputDir + fileName) : fileLogging.getFileSize());
				fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_ERRONEOUS);
				fileLogging.setRemarks(FileLoggingConstants.FILELOGGING_FAILED_REMARK);
				fileLogging.setCityCode(ISOCityCode);
				FileErrorLog fileErrorLog = new FileErrorLog();
				fileErrorLog.setFileId(fileLogging.getFileId());
				fileErrorLog.setErrorDetail(jobExecution.getStatus().toString());
				fileErrorLog.setErrorDescription(jobExecution.getFailureExceptions().toString());
				ArrayList<FileErrorLog> fileErrorLogList = new ArrayList<>();
				fileErrorLogList.add(fileErrorLog);
				fileLogging.setFileErrorLog(fileErrorLogList);
				String dtStr = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
				SmartpraFileUtility.moveFile(inputDir + fileName, failedDir +fileName+dtStr);
				fileLogging.setIsMovedToRelevantFolder("Y");
				log.info("!!! JOB FINISHED -FAILED ! Time to verify the results");
			}
			fileLogging = batchGlobalFeignClient.updateFileLog(BigInteger.valueOf(fileId), fileLogging);
		
		}
	}

}
