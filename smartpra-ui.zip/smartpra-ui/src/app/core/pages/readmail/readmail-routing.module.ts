import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ReadmailComponent } from './readmail.component';

const routes: Routes = [
  {path:'',component:ReadmailComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReadmailRoutingModule { }
