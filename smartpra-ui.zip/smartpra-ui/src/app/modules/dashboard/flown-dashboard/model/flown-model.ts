export interface FlownListModel {
	flightKey:number;
	flightNumber:number;
	flightStatus:string;
	flightDate:Date;
	departure:string;
	arrival:string;
	paxCntsAct:number;
	paxCntsRepd:number;
	paxCntsMissmatch:number;
	grossFareRevenue:number;
	actualPaxCount:number;
	estimatedRevenue:number;
	estimatedPaxCount:number;
	yq:string;
	yr:string;
	tax:number;
	discount:number;
	commision:number;
	orc:number;
	ancilaryRevenue:number;
	netRevenue:number;
}

export interface CouponListModel {
	flightKey:number;
	flownCpnId:number;
	acDate:Date; 
	ancillaryService:string;
	couponNumber:number;
	couponStatus:string;
	dataSource:string
	dateOfIssue:Date;
	deriveFlownCabin:string;
	deriveFlownRbd:string;
	documentClass:string;
	documentNumber:number;
	documentUniqueId:string;
	etktIndicator:string;
	fareBasis:string;
	issueAirline:number;
	kg:string;
	monthCloseDate:Date;
	multiUplifted:string;
	passengerType:string;
	pcs:string;
	pnr:string;
	reportedFlownCabin:string;
	reportedFlownRbd:string;
	saleCommission:number;
	saleDiscount:number;
	saleFare:number;
	saleOrc:number;
	surcharge:number;
	tax:number;
}

export interface FlightInfoModel {
	aircraftRegistration:string;
	ccabinBlockCapacity:number;
	ccabinCapacityAct:number;
	ccabinCapacityRepd:number;
	ccabinDiff:number;
	deadLoadCapacity:number;
	ebtAct:number;
	emdAct:number;
	fcabinBlockCapacity:number;
	fcabinCapacityAct:number;
	fcabinCapacityRepd:number;
	fcabinDiff:number;
	flightCatagory:string;
	flightKey:number;
	flightStatus:string;
	flyingDistance:number;
	flyingHours:number;
	mcoAct:number;
	oalPAXCountAct:number;
	oalPAXCountRepd:number;
	paxAct:number;
	paxDiff:number;
	payloadCapacity:number;
	routeCode:string;
	selfPAXCountAct:number;
	selfPAXCountRepd:number;
	totalPaxRepd:number;
	wcabinBlockCapacity:number;
	wcabinCapacityAct:number;
	wcabinCapacityRepd:number;
	wcabinDiff:number;
	ycabinBlockCapacity:number;
	ycabinCapacityAct:number;
	ycabinCapacityRepd:number;
	ycabinDiff:number;
}
export const couponStatusList = {
	"RV" : "Ready for validation",
	"EV" : "Error in validation",
	"VV" : "Validated successfully",
	"RS" : "Revenue Estimated",
	"AR" : "Awaiting for the Response",
	"EP" : "Error in proration",
	"PP" : "Prorated successfully",
	"EC" : "Error in Discount - commission Derivation",
	"CC" : "Discount - Commission derived successfully",
	"ER" : "Error in revenue processing",
	"RR" : "Revenue processed",
	"EQ" : "Error in QC",
	"QQ" : "QC processed",
	"EA" : "Error in accounting",
	"AA" : "Accounted successfully",
	"EM" : "Error in GL Extraction",
	"MC" : "GL Extraction",
	"OH" : "On Hold",
	"EO" : "Error while Transferring to billing",
	"OW" : "Transferred for billing",
	"EF" : "Error while File generation",
	"FG" : "File Generated",
	"EI" : "Error In IS Validation",
	"IV" : "IS Validated"
}
export const paxType = {
	"A" :"Adult",
	"C" :"Child",
	"I" :"Infant",
}
export const cabin = {
	"F" :"First",
	"C" :"Business",
	"W" :"Premium Economy",
	"Y" :"Economy",
}
export const flownKey = 'flightKey';
//export const flownKey = 'flightNo';
export const flownStatusList={
	"Z":"outstanding",
	"O":"open",
	"B":"balanced",
	"U":"unbalanced",
	"E":"erroneous",
	"C":"cancelled",
	"X":"onhold"
}
export const flownIconStatusList = {
	"default": {
		"graph": "enable",
		"delete": "enable",
		"close": "enable",
		"reopen": "enable",
		"view": "enable",
		"batch_header": "enable",
		"ldm_reco": "enable",
		"hold_on_flights": "enable",
		"cancel_flights": "enable",
		"import_export": "enable",
		"exceptions": "enable",
		"remarks": "enable"
	},
	"outstanding": {
		"graph": "enable",
		"delete": "disable",
		"close": "disable",
		"reopen": "disable",
		"view": "disable",
		"batch_header": "disable",
		"ldm_reco": "disable",
		"hold_on_flights": "disable",
		"cancel_flights": "enable",
		"import_export": "disable",
		"exceptions": "disable",
		"remarks": "enable"
	},
	"open": {
		"graph": "enable",
		"delete": "enable",
		"close": "enable",
		"reopen": "disable",
		"view": "enable",
		"batch_header": "enable",
		"ldm_reco": "enable",
		"hold_on_flights": "enable",
		"cancel_flights": "disable",
		"import_export": "enable",
		"exceptions": "disable",
		"remarks": "enable"
	},
	"balanced": {
		"graph": "enable",
		"delete": "enable",
		"close": "enable",
		"reopen": "enable",
		"view": "enable",
		"batch_header": "enable",
		"ldm_reco": "enable",
		"hold_on_flights": "enable",
		"cancel_flights": "disable",
		"import_export": "enable",
		"exceptions": "enable",
		"remarks": "enable"
	},
	"unbalanced": {
		"graph": "enable",
		"delete": "enable",
		"close": "enable",
		"reopen": "enable",
		"view": "enable",
		"batch_header": "enable",
		"ldm_reco": "enable",
		"hold_on_flights": "enable",
		"cancel_flights": "disable",
		"import_export": "enable",
		"exceptions": "enable",
		"remarks": "enable"
	},
	"erroneous": {
		"graph": "enable",
		"delete": "enable",
		"close": "enable",
		"reopen": "enable",
		"view": "enable",
		"batch_header": "enable",
		"ldm_reco": "enable",
		"hold_on_flights": "enable",
		"cancel_flights": "disable",
		"import_export": "enable",
		"exceptions": "enable",
		"remarks": "enable"
	},
	"cancelled": {
		"graph": "enable",
		"delete": "disable",
		"close": "disable",
		"reopen": "disable",
		"view": "disable",
		"batch_header": "disable",
		"ldm_reco": "disable",
		"hold_on_flights": "disable",
		"cancel_flights": "toggle",
		"import_export": "disable",
		"exceptions": "disable",
		"remarks": "enable"
	},
	"onhold": {
		"graph": "enable",
		"delete": "disable",
		"close": "disable",
		"reopen": "disable",
		"view": "enable",
		"batch_header": "enable",
		"ldm_reco": "enable",
		"hold_on_flights": "toggle",
		"cancel_flights": "disable",
		"import_export": "enable",
		"exceptions": "disable",
		"remarks": "enable"
	}

}

