package com.sgl.smartpra.batch.sales.validator.app.domain;


import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * The persistent class for the stg_reported_tax_details database table.
 * 
 */
@Entity
@Table(name="stg_reported_tax_details")
public class StgReportedTaxDetail  implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="stg_reported_tax_dtl_id")
	private int stgReportedTaxDtlId;

	@Column(name="coupon_number")
	private int couponNumber;

	@Column(name="created_by")
	private String createdBy;

	@Column(name="created_date")
	private Timestamp createdDate;

	@Column(name="date_of_issue")
	private String dateOfIssue;

	@Column(name="document_no")
	private String documentNo;

	@Column(name="iss_airline")
	private String issAirline;

	@Column(name="last_updated_by")
	private String lastUpdatedBy;

	@Column(name="last_updated_date")
	private Timestamp lastUpdatedDate;

	private String pnr;

	@Column(name="serial_no")
	private int serialNo;

	@Column(name="source_data")
	private String sourceData;

	@Column(name="tax_amount")
	private BigDecimal taxAmount;

	@Column(name="tax_code")
	private String taxCode;

	@Column(name="transaction_return_key")
	private String transactionReturnKey;

	@Column(name="transaction_type")
	private String transactionType;
	
	@Column(name="tax_currency")
	private String taxCurrency;

	//bi-directional many-to-one association to TicketMainStg
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="trn_tkt_id")
	private TicketMainStg ticketMainStg;

	public StgReportedTaxDetail() {
	}

	public String getTaxCurrency() {
		return taxCurrency;
	}

	public void setTaxCurrency(String taxCurrency) {
		this.taxCurrency = taxCurrency;
	}

	public int getStgReportedTaxDtlId() {
		return this.stgReportedTaxDtlId;
	}

	public void setStgReportedTaxDtlId(int stgReportedTaxDtlId) {
		this.stgReportedTaxDtlId = stgReportedTaxDtlId;
	}

	public int getCouponNumber() {
		return this.couponNumber;
	}

	public void setCouponNumber(int couponNumber) {
		this.couponNumber = couponNumber;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDateOfIssue() {
		return this.dateOfIssue;
	}

	public void setDateOfIssue(String dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}

	public String getDocumentNo() {
		return this.documentNo;
	}

	public void setDocumentNo(String documentNo) {
		this.documentNo = documentNo;
	}

	public String getIssAirline() {
		return this.issAirline;
	}

	public void setIssAirline(String issAirline) {
		this.issAirline = issAirline;
	}

	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getLastUpdatedDate() {
		return this.lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getPnr() {
		return this.pnr;
	}

	public void setPnr(String pnr) {
		this.pnr = pnr;
	}

	public int getSerialNo() {
		return this.serialNo;
	}

	public void setSerialNo(int serialNo) {
		this.serialNo = serialNo;
	}

	public String getSourceData() {
		return this.sourceData;
	}

	public void setSourceData(String sourceData) {
		this.sourceData = sourceData;
	}

	public BigDecimal getTaxAmount() {
		return this.taxAmount;
	}

	public void setTaxAmount(BigDecimal taxAmount) {
		this.taxAmount = taxAmount;
	}

	public String getTaxCode() {
		return this.taxCode;
	}

	public void setTaxCode(String taxCode) {
		this.taxCode = taxCode;
	}

	public String getTransactionReturnKey() {
		return this.transactionReturnKey;
	}

	public void setTransactionReturnKey(String transactionReturnKey) {
		this.transactionReturnKey = transactionReturnKey;
	}

	public String getTransactionType() {
		return this.transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public TicketMainStg getTicketMainStg() {
		return this.ticketMainStg;
	}

	public void setTicketMainStg(TicketMainStg ticketMainStg) {
		this.ticketMainStg = ticketMainStg;
	}

	
}

