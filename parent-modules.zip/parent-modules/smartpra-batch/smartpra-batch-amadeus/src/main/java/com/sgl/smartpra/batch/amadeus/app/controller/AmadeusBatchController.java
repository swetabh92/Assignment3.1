package com.sgl.smartpra.batch.amadeus.app.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.batch.amadeus.app.service.AmadeusBatchJobService;
import com.sgl.smartpra.common.util.FileLoggingConstants;

@RestController
public class AmadeusBatchController {

	private static final Logger LOGGER = LoggerFactory.getLogger(AmadeusBatchController.class);

	@Autowired
	AmadeusBatchJobService amadeusBatchJobService;

	/**
	 * This method is used to invoke the batch job to parse the input flat file and store it into Staging DB and later to production database.
	 * (Common file load for ETL and EMD flat files).
	 * 
	 * @param inboundFileName
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping("/invokejob")
	public String handleIn(@RequestParam("inboundFileName") String inboundFileName) throws Exception {
		LOGGER.info("Invoke Job action called with file name : " + inboundFileName);
		return amadeusBatchJobService.executeAmadeusBatchLoad(inboundFileName, FileLoggingConstants.FILELOGGING_PROCESSEDBY_MANUAL);
	}
}
