package com.sgl.smartpra.allocation.master.app.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.sgl.smartpra.allocation.master.app.entity.AllocationMasterEntity;

import java.util.List;

public interface AllocationMasterRepository
		extends JpaRepository<AllocationMasterEntity, Integer>, JpaSpecificationExecutor<AllocationMasterEntity> {

	List<AllocationMasterEntity> findByModuleLovId(Integer moduleLovId);
}
