import {CommonService} from '../../../masters/services/commons/common.service';
import {ExceptionConstant} from './../constants/exception-contants';
import {Injectable} from '@angular/core';
import * as _ from 'underscore';
import {ExceptionTransactionTableComponent} from "../exception-transaction-table/exception-transaction-table.component";
import {MessageBoxService} from "../../../masters/services/commons/message-box.service";
import {ExceptionManagementModel} from "../models/excpetion-management-model";
import {StorageService} from "../../../../commons/services/storage/storage.service";
import { TaskStatusEnumModel } from '../models/task-status-model';

declare var moment: any;


@Injectable({
  providedIn: 'root'
})
export class ExceptionManagementUtil {

  constructor(private messageService: MessageBoxService, private commonService: CommonService,
              private storageService: StorageService) {
  }

  assignException(model, tableComponent: ExceptionTransactionTableComponent) {
    let exceptionTransIds = _.pluck(tableComponent.model.selected, "exceptionTransId");

    return {
      "groupId": parseInt(model.userForm.value.groupId),
      "teamId": parseInt(model.userForm.value.teamId),
      "userId": parseInt(model.userForm.value.userId),
      "exceptionStatus": ExceptionConstant.ASSIGNED,
      "assignedType": ExceptionConstant.MANUAL,
      "transactionIds": exceptionTransIds,
      "assignedBy": this.commonService.getUser()
    };
  }

  isAssignFormValid(tableModel, txnModel): boolean {
    if (tableModel.model.selected.length <= 0) {
      this.messageService.showGeneralErrorMessage("Error", "Please select a transaction to assign");
      return false;
    }
    if (txnModel.userArr && txnModel.userArr.length > 0) {
      txnModel.selectUsersFlag = false;
      return true;
    }
    txnModel.selectUsersFlag = true;
    return false;
  }

  isReleaseAndAssignFormValid(tableModel, txnModel: ExceptionManagementModel): boolean {
    if (!txnModel.userForm.valid) {
      return false;
    }

    if (tableModel.model.selected.length <= 0) {
      this.messageService.showGeneralErrorMessage("Error", "Please select a transaction to assign");
      return false;
    }
    if (txnModel.userArr && txnModel.userArr.length > 0) {
      txnModel.selectUsersFlag = false;
      return true;
    }
    txnModel.selectUsersFlag = true;
    return false;
  }

  parseReleaseAndReassignObject(model, tableComponent: ExceptionTransactionTableComponent) {
    let exceptionTransIds = [];
    tableComponent.model.selected.forEach(function (value) {
      let taskObj = {
        "transactionId": value.exceptionTransId,
        "aggregationId": value.aggregationId
      };
      exceptionTransIds.push(taskObj);
    });
    return {
      "assignedGroupId": parseInt(model.userForm.value.groupId),
      "assignedTeamId": parseInt(model.userForm.value.teamId),
      "assignedUserId": parseInt(model.userForm.value.userId),
      "assignerId": 1,
      "taskStatus": ExceptionConstant.TRANSFERRED,
      "assignedType": ExceptionConstant.MANUAL,
      "taskVOList": exceptionTransIds,
      "assignedBy": this.commonService.getUser()
    };
  }


  parseTeamExceptionStatus(userData: any, parseMode: any) {
    let chartData = [];
    let availTaskStatusCount : TaskStatusEnumModel = new TaskStatusEnumModel;
    _.each(userData, function (singleTeamData: any) {
      availTaskStatusCount =  new TaskStatusEnumModel;
      _.each(singleTeamData.taskStatusList, function (taskStatus: any) {
        let taskStatusENUm = taskStatus.status.toString();
        availTaskStatusCount[taskStatusENUm] = taskStatus.count;
      });

      let taskStatusCount: any = {
        "WORK_IN_PROGRESS": availTaskStatusCount.WORK_IN_PROGRESS || 0,
        "PENDING_APPROVAL": availTaskStatusCount.PENDING_APPROVAL || 0,
        "RESOLVED": availTaskStatusCount.RESOLVED || 0,
        "CLOSED": availTaskStatusCount.CLOSED || 0,
        "ASSIGNED": availTaskStatusCount.ASSIGNED || 0
      };
      let chartObj = {};
      if (parseMode == "T") {
        chartObj = {
          "name": singleTeamData.teamName,
          "id": singleTeamData.teamId,
          "taskStatusCount": taskStatusCount,
          "chartValue": _.values(taskStatusCount)
        };
      } else if (parseMode == "U") {
        chartObj = {
          "name": singleTeamData.userName,
          "id": singleTeamData.userId,
          "taskStatusCount": taskStatusCount,
          "chartValue": _.values(taskStatusCount)
        };
      }
      chartData.push(chartObj);
    });
    return chartData;
  }

  /*
  * TODO CHANGE THE START TIME VALUE TO BE DYNAMIC
  *  THE CHANGE IS DEMO PURPOSE ONLY
  * */
  parseValidateForm(selected: any[]) {
    if (!_.isEmpty(selected)) {
      let model = StorageService.getResolutionTimerInstance();
      selected.forEach(selectedItem => {
        selectedItem["startTime"] = moment().format(ExceptionConstant.RESOLUTION_DATE_TIME_FORMAT);
        selectedItem["endTime"] = moment().format(ExceptionConstant.RESOLUTION_DATE_TIME_FORMAT);
        selectedItem["lastUpdatedBy"] = this.commonService.getUser();
        selectedItem["clientId"] = this.commonService.getClientId();
      })
    }
    return selected;
  }
}

