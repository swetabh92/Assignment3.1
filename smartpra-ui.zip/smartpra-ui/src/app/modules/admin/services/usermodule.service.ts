import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import swal from 'sweetalert2';

import { environment } from '../../../../environments/environment';
import { Usermodule } from '../models/usermodule';
import { MessageBoxService } from '../../masters/services/commons/message-box.service';
const httpOptions = {
  // headers: new HttpHeaders({ 'Content-Type': 'multipart/form-data' })
};
const httpOptions1 = {
  headers: new HttpHeaders({ 'Content-Type': 'multipart/form-data' })
};
@Injectable({
  providedIn: 'root'
})
export class UsermoduleService {
  globalUrl = environment.apiUrlGlobal;
  masterUrl = environment.apiUrlMaster;
  authUrl = environment.apiUrlauth;
  constructor(private http: HttpClient, private messageBoxService: MessageBoxService) { }
  getUsermoduleAll(): Observable<Usermodule[]> {
    return this.http.get<Usermodule[]>(this.authUrl + 'mas-user-modules')
      .pipe(
        tap(_ => this.log('fetched Usermodule details')),
        catchError(this.handleError('getAllUsermodule', []))
      );
  }
  UsermoduleByUsermoduleId(masUserModuleId: string): Observable<Usermodule> {
    return this.http.get<Usermodule>(this.authUrl + 'mas-user-modules/' + masUserModuleId).pipe(
      tap(_ => this.log(`fetched Usermodule masUserModuleId=${masUserModuleId}`)),
      catchError(this.handleError<Usermodule>(`UsermoduleByUsermoduleId masUserModuleId=${masUserModuleId}`))
    );
  }
  searchUsermodule(parms: string): Observable<Usermodule> {
    return this.http.get<Usermodule>(this.authUrl + parms).pipe(
      tap(_ => this.log(`search Usermodule masUserModuleId by ${parms}`)),
      catchError(this.handleError<Usermodule>(`search Usermodule masUserModuleId by ${parms}`))
    );
  }
  /** POST: add a new Usermodule to the server */
  addUsermodule(formdata): Observable<Usermodule> {
    // console.log(formdata); return;
    return this.http.post<Usermodule>(this.authUrl + 'mas-user-modules/', formdata, httpOptions).pipe(
      tap(_ => this.log(`added Usermodule masUserModuleId=`)),
      catchError(this.handleError<Usermodule>('addUsermodule'))
    );
  }
  updateUsermodule(usermodule: Usermodule): Observable<any> {
   // console.log(Usermodule.masUserModuleId);
    // console.log(Usermodule);
    return this.http.put<Usermodule>(this.authUrl + 'mas-user-modules/' + usermodule.masUserModuleId, Usermodule, httpOptions).pipe(
      tap(_ => this.log(`updated Usermodule masUserModuleId=${usermodule.masUserModuleId}`)),
      catchError(this.handleError<Usermodule>('addUsermodule'))
    );
  }
  activateUsermodule(masUserModuleId: string): Observable<Usermodule> {
    return this.http.put<Usermodule>(this.authUrl + 'mas-user-modules/activateordeactivate/' + masUserModuleId , httpOptions).pipe(
      tap(_ => this.log(`activate Usermodule masUserModuleId=${masUserModuleId}`)),
      catchError(this.handleError<Usermodule>('activateUsermodule'))
    );
  }
  deactivateUsermodule(masUserModuleId: string): Observable<Usermodule> {
    return this.http.put<Usermodule>(this.authUrl + 'mas-user-modules/activateordeactivate/' + masUserModuleId , httpOptions).pipe(
      tap(_ => this.log(`deactivate Usermodule masUserModuleId=${masUserModuleId}`)),
      catchError(this.handleError<Usermodule>('deactvateUsermodule'))
    );
  }
  private handleError<T>(operation = 'operation', result?: T) {
    return (e: any): Observable<T> => {
      console.log(e);
      const error = e.error.message || e.error.error || e.error.error_description || 'Could not connect server';
      console.log(error);
      this.messageBoxService.getErrorMessage('ERROR', error);
      return of(result as T);
    };
  }
  private log(error: any) {
    console.log(error);
    if (error.message) {
      this.messageBoxService.getErrorMessage('ERROR', error.message);
    }
  }
}

