package com.sgl.smartpra.batch.bsp.app.config;

import org.springframework.context.annotation.Bean;

public class FeignDecoderConfiguration {

	@Bean
	public FeignErrorDecoder feignErrorDecoder() {
		return new FeignErrorDecoder();
	}
}
