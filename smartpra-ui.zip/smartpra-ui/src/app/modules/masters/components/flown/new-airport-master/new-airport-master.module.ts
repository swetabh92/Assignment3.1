import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NewAirportMasterRoutingModule } from './new-airport-master-routing.module';
import { NewAirportMasterComponent } from './new-airport-master.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { CoreDataModule } from 'src/app/core-data/core-data.module';

@NgModule({
  imports: [
    CommonModule, 
    SharedModule,
    CoreDataModule,
    NewAirportMasterRoutingModule
  ],
  declarations: [
    NewAirportMasterComponent
  ]
})
export class NewAirportMasterModule { }
