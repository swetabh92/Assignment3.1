package com.sgl.smartpra.batch.sales.validator.app.writer;

public class TicketMainStgWriter {

}
