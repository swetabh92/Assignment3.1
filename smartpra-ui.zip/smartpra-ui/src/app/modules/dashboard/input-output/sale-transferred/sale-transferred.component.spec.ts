import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SaleTransferredComponent } from './sale-transferred.component';

describe('SaleTransferredComponent', () => {
  let component: SaleTransferredComponent;
  let fixture: ComponentFixture<SaleTransferredComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SaleTransferredComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SaleTransferredComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
