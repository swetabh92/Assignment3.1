package com.sgl.smartpra.batch.global.app.entity;

import java.io.Serializable;
import java.math.BigInteger;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;

import com.sgl.smartpra.batch.global.app.dao.result.ExpectedFrequencyResult;
import com.sgl.smartpra.batch.global.app.dao.result.FileStatusResult;
import com.sgl.smartpra.batch.global.app.dao.result.MultiRecordExceptionsResult;

@Entity
@Table(name = "file_logging", schema = "smartpraglobalbatch")
@NamedNativeQueries({
		@NamedNativeQuery(name = "getFileStatus", resultSetMapping = "FileStatusResult", query = "select count(1) as status_count, fl.lov_module_id, lov.field_short_desc ,file_status from SmartPRAGlobalBatch.file_logging fl, SmartPRAMaster.mas_list_of_values lov  where lov.lov_id = fl.lov_module_id  and fl.file_status in ('ER','TF','TR', 'PT')  and fl.created_date between ?1 and ?2  group by fl.lov_module_id,  lov.field_short_desc, fl.file_status order by lov.field_short_desc"),
		@NamedNativeQuery(name = "getExpectedFrequencyAndModuleName", resultSetMapping = "ExpectedFrequencyAndModuleNameResult", query = "select distinct gmft.frequency_type_name, lov.field_short_desc from SmartPRAInterface.interface_info ii, SmartPRAGlobal.global_mas_frequency_type gmft, smartpramaster.mas_list_of_values lov where ii.frequency_type_id = gmft.frequency_type_id and ii.lov_module_id = lov.lov_id and ii.file_type = ?1 and   lov.lov_id = ?2"),
		@NamedNativeQuery(name = "getMultiRecordExceptions", resultSetMapping = "MultiRecordExceptionsResult", query = "select fel.file_id, 0 as record_number, me.exception_cause, fel.error_description, me.exception_action, me.exception_severity, me.exp_resolution_time from smartpramaster.mas_exception me, SmartPRAGlobalBatch.file_error_log fel where  fel.file_id=? union all select rel.file_id, rel.record_number, me.exception_cause, rel.error_description, me.exception_action, me.exception_severity, me.exp_resolution_time from  smartpramaster.mas_exception me, SmartPRAGlobalBatch.record_error_log rel where  rel.file_id=?") })
@SqlResultSetMappings({
		@SqlResultSetMapping(name = "ExpectedFrequencyAndModuleNameResult", classes = {
				@ConstructorResult(targetClass = ExpectedFrequencyResult.class, columns = {
						@ColumnResult(name = "frequency_type_name", type = String.class),
						@ColumnResult(name = "field_short_desc", type = String.class) }) }),
		@SqlResultSetMapping(name = "FileStatusResult", classes = {
				@ConstructorResult(targetClass = FileStatusResult.class, columns = {
						@ColumnResult(name = "status_count", type = Integer.class),
						@ColumnResult(name = "lov_module_id", type = Integer.class),
						@ColumnResult(name = "field_short_desc", type = String.class),
						@ColumnResult(name = "file_status", type = String.class) }) }),
		@SqlResultSetMapping(name = "MultiRecordExceptionsResult", classes = {
				@ConstructorResult(targetClass = MultiRecordExceptionsResult.class, columns = {
						@ColumnResult(name = "file_id", type = Integer.class),
						@ColumnResult(name = "record_number", type = Integer.class),
						@ColumnResult(name = "exception_cause", type = String.class),
						@ColumnResult(name = "error_description", type = String.class),
						@ColumnResult(name = "exception_action", type = String.class),
						@ColumnResult(name = "exception_severity", type = String.class),
						@ColumnResult(name = "exp_resolution_time", type = Integer.class) }) }),

})
public class FileLoggingEntity extends BaseEntity implements Serializable {

	private static final long serialVersionUID = -225927476427328129L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "file_id", unique = true, nullable = false)
	private BigInteger fileId;

	@Column(name = "client_id")
	private String clientId;

	@Column(name = "skipped_record_count")
	private Integer skippedRecordCount;

	@Column(name = "interface_type")
	private String interfaceType;

	@Column(name = "file_category")
	private String fileCategory;

	@Column(name = "file_name")
	private String fileName;

	@Column(name = "processed_by")
	private String processedBy;

	@Column(name = "file_status")
	private String fileStatus;

	@Column(name = "schedule_date_time")
	private Timestamp scheduleDateTime;

	@Column(name = "start_date_time")
	private Timestamp startDateTime;

	@Column(name = "end_date_time")
	private Timestamp endDateTime;

	@Column(name = "total_counts")
	private Integer totalCounts;

	@Column(name = "header_counts")
	private Integer headerCounts;

	@Column(name = "detail_counts")
	private Integer detailCounts;

	@Column(name = "error_counts")
	private Integer errorCounts;

	@Column(name = "transferred_counts")
	private Integer transferredCounts;

	@Column(name = "file_size")
	private String fileSize;

	@Column(name = "lov_module_id")
	private Integer moduleId;

	@Column(name = "module_name")
	private String moduleName;

	@Column(name = "file_type")
	private String fileType;

	@Column(name = "city_code")
	private String cityCode;

	@Column(name = "source")
	private String source;

	@Column(name = "is_encrypted_post_success")
	private String isEncryptedPostSuccess;

	@Column(name = "is_encrypted_prior_loading")
	private String isEncryptedPriorLoading;

	@Column(name = "is_renamed_post_success")
	private String isRenamedPostSuccess;

	@Column(name = "is_moved_to_relevant_folder")
	private String isMovedToRelevantFolder;

	@Column(name = "is_notification_sent")
	private String isNotificationSent;

	@Column(name = "remarks")
	private String remarks;

	@Column(name = "job_name")
	private String jobName;

	public BigInteger getFileId() {
		return fileId;
	}

	public void setFileId(BigInteger fileId) {
		this.fileId = fileId;
	}

	public Integer getSkippedRecordCount() {
		return skippedRecordCount;
	}

	public void setSkippedRecordCount(Integer skippedRecordCount) {
		this.skippedRecordCount = skippedRecordCount;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getInterfaceType() {
		return interfaceType;
	}

	public void setInterfaceType(String interfaceType) {
		this.interfaceType = interfaceType;
	}

	public String getFileCategory() {
		return fileCategory;
	}

	public void setFileCategory(String fileCategory) {
		this.fileCategory = fileCategory;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getProcessedBy() {
		return processedBy;
	}

	public void setProcessedBy(String processedBy) {
		this.processedBy = processedBy;
	}

	public String getFileStatus() {
		return fileStatus;
	}

	public void setFileStatus(String fileStatus) {
		this.fileStatus = fileStatus;
	}

	public Timestamp getScheduleDateTime() {
		return scheduleDateTime;
	}

	public void setScheduleDateTime(Timestamp scheduleDateTime) {
		this.scheduleDateTime = scheduleDateTime;
	}

	public Timestamp getStartDateTime() {
		return startDateTime;
	}

	public void setStartDateTime(Timestamp startDateTime) {
		this.startDateTime = startDateTime;
	}

	public Timestamp getEndDateTime() {
		return endDateTime;
	}

	public void setEndDateTime(Timestamp endDateTime) {
		this.endDateTime = endDateTime;
	}

	public Integer getTotalCounts() {
		return totalCounts;
	}

	public void setTotalCounts(Integer totalCounts) {
		this.totalCounts = totalCounts;
	}

	public Integer getHeaderCounts() {
		return headerCounts;
	}

	public void setHeaderCounts(Integer headerCounts) {
		this.headerCounts = headerCounts;
	}

	public Integer getDetailCounts() {
		return detailCounts;
	}

	public void setDetailCounts(Integer detailCounts) {
		this.detailCounts = detailCounts;
	}

	public Integer getErrorCounts() {
		return errorCounts;
	}

	public void setErrorCounts(Integer errorCounts) {
		this.errorCounts = errorCounts;
	}

	public Integer getTransferredCounts() {
		return transferredCounts;
	}

	public void setTransferredCounts(Integer transferredCounts) {
		this.transferredCounts = transferredCounts;
	}

	public String getFileSize() {
		return fileSize;
	}

	public void setFileSize(String fileSize) {
		this.fileSize = fileSize;
	}

	public Integer getModuleId() {
		return moduleId;
	}

	public void setModuleId(Integer moduleId) {
		this.moduleId = moduleId;
	}

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public String getCityCode() {
		return cityCode;
	}

	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getIsEncryptedPostSuccess() {
		return isEncryptedPostSuccess;
	}

	public void setIsEncryptedPostSuccess(String isEncryptedPostSuccess) {
		this.isEncryptedPostSuccess = isEncryptedPostSuccess;
	}

	public String getIsEncryptedPriorLoading() {
		return isEncryptedPriorLoading;
	}

	public void setIsEncryptedPriorLoading(String isEncryptedPriorLoading) {
		this.isEncryptedPriorLoading = isEncryptedPriorLoading;
	}

	public String getIsRenamedPostSuccess() {
		return isRenamedPostSuccess;
	}

	public void setIsRenamedPostSuccess(String isRenamedPostSuccess) {
		this.isRenamedPostSuccess = isRenamedPostSuccess;
	}

	public String getIsMovedToRelevantFolder() {
		return isMovedToRelevantFolder;
	}

	public void setIsMovedToRelevantFolder(String isMovedToRelevantFolder) {
		this.isMovedToRelevantFolder = isMovedToRelevantFolder;
	}

	public String getIsNotificationSent() {
		return isNotificationSent;
	}

	public void setIsNotificationSent(String isNotificationSent) {
		this.isNotificationSent = isNotificationSent;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

}
