export const StorageConstants = {
  USER_NAME_EMAIL: "user_name_email",
  CURRENT_LANG: "current_lang",
  RESOLUTION_MODEL: "RESOLUTION_MODEL",
  CURRENT_TASK_ID: "CURRENT_TASK_ID",
};
