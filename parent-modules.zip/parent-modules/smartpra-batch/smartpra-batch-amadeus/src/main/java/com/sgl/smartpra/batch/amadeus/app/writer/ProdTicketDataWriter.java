package com.sgl.smartpra.batch.amadeus.app.writer;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusBatchRecord;
import com.sgl.smartpra.batch.amadeus.app.domain.ProdTicketModel;
import com.sgl.smartpra.sales.domain.TicketMain;
import com.sgl.smartpra.sales.repository.TicketMainRepository;

@Component
@Scope(value = "step")
public class ProdTicketDataWriter<T extends AmadeusBatchRecord> implements ItemWriter<ProdTicketModel> {
	private static final Logger LOGGER = LoggerFactory.getLogger(ProdTicketDataWriter.class);

	@Autowired
	private TicketMainRepository ticketMainRepository;

	@Override
	public void write(List<? extends ProdTicketModel> items) throws Exception {
		LOGGER.info("ProdTicketDataWriter.write -- Start");
		List<TicketMain> ticketMainList;
		TicketMain ticketMain = null;
		for (ProdTicketModel prodTicketModel : items) {
			ticketMainList =  (List<TicketMain>) prodTicketModel.getTicketMain();
			//LOGGER.info("TicketMain.DocumentUniqueID:{} "+ ticketMain.getDocumentUniqueId());
			System.out.println("ticket   list--->"+ticketMainList.toString());
			ticketMainRepository.saveAll(ticketMainList);
			ticketMainRepository.flush();
		}
		LOGGER.info("ProdTicketDataWriter.write -- End");
	}
}
