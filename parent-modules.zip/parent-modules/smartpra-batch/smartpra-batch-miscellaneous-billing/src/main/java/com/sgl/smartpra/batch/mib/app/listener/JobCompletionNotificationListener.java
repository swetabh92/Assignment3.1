package com.sgl.smartpra.batch.mib.app.listener;


import java.math.BigInteger;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.global.model.FileErrorLog;
import com.sgl.smartpra.batch.global.model.FileLogging;
import com.sgl.smartpra.batch.mib.app.config.FeignConfiguration.BatchGlobalFeignClient;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingConstants;
import com.sgl.smartpra.batch.mib.app.validator.CommonValidator;
import com.sgl.smartpra.common.util.FileLoggingConstants;
import com.sgl.smartpra.common.util.SmartpraFileUtility;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class JobCompletionNotificationListener extends JobExecutionListenerSupport {
	
	@Value("${batch.directory.misc-billing.input}")
	private String miscBillingBatchInputDir;
	
	@Value("${batch.directory.misc-billing.duplicate}")
	private String miscBillingBatchDuplicateDir;
	
	@Value("${batch.directory.misc-billing.failed}")
	private String miscBillingBatchFailedDir;
	
	@Value("${batch.directory.misc-billing.processed}")
	private String miscBillingBatchProcessedDir;
	
	@Value("${env-prod}")
	private String isProd;
	
	@Autowired
	private BatchGlobalFeignClient batchGlobalFeignClient;
	
	@Autowired
	private CommonValidator commonValidator;
	
	@Override
	public void afterJob(JobExecution jobExecution) {
		StepExecution stepExecution = jobExecution.getStepExecutions().stream()
				.filter(x -> "extractFileDataToStaging".equalsIgnoreCase(x.getStepName()))
				.findAny().get();
		JobParameters jobParameters = jobExecution.getJobParameters();
		long fileId = jobParameters.getLong("fileId");
		String fileName = jobParameters.getString("fileName");
		Integer invoiceCount = stepExecution.getExecutionContext().getInt("invoiceCount");
		Integer chargeCodeCount = stepExecution.getExecutionContext().getInt("chargeCodeCount");
		FileLogging fileLogging = batchGlobalFeignClient.getFileLogByFileId(BigInteger.valueOf(fileId));
		if (jobExecution.getStatus() == BatchStatus.COMPLETED) {
			fileLogging.setEndDateTime(new Timestamp(new Date().getTime()));
			fileLogging.setTotalCounts(invoiceCount);
			fileLogging.setHeaderCounts(invoiceCount);
			fileLogging.setDetailCounts(chargeCodeCount);
			fileLogging.setErrorCounts(0);
			fileLogging.setTransferredCounts(invoiceCount);
			fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_TRANSFERRED);
			if(MiscBillingConstants.YES.equals(isProd)) {
				boolean flag = SmartpraFileUtility.moveFile(miscBillingBatchInputDir + fileName, miscBillingBatchProcessedDir +fileName);
				fileLogging.setIsMovedToRelevantFolder(flag?"Y":"N");
			}
			log.info("!!! JOB FINISHED! Time to verify the results");
		} else {
			fileLogging.setTotalCounts(0);
			fileLogging.setHeaderCounts(0);
			fileLogging.setDetailCounts(0);
			fileLogging.setErrorCounts(0);
			fileLogging.setTransferredCounts(0);
			fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_ERRONEOUS);
			fileLogging.setRemarks(FileLoggingConstants.FILELOGGING_FAILED_REMARK);
			FileErrorLog fileErrorLog = new FileErrorLog();
			fileErrorLog.setFileId(fileLogging.getFileId());
			fileErrorLog.setErrorDetail(jobExecution.getStatus().toString());
			fileErrorLog.setErrorDescription(jobExecution.getFailureExceptions().toString());
			ArrayList<FileErrorLog> fileErrorLogList = new ArrayList<>();
			fileErrorLogList.add(fileErrorLog);
			fileLogging.setFileErrorLog(fileErrorLogList);
			
			String dtStr = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
			if(MiscBillingConstants.YES.equals(isProd)) {
				boolean flag = SmartpraFileUtility.moveFile(miscBillingBatchInputDir + fileName, miscBillingBatchFailedDir + fileName + dtStr);
				fileLogging.setIsMovedToRelevantFolder(flag?"Y":"N");
			}
			log.info("!!! JOB FINISHED -FAILED ! Time to verify the results");
		}
		fileLogging = batchGlobalFeignClient.updateFileLog(BigInteger.valueOf(fileId), fileLogging);
		commonValidator.resetMasters();
	}

}