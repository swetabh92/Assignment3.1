package com.sgl.smartpra.batch.bsp.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.batch.bsp.app.service.BSPJobLauncher;

@RestController
public class BSPBatchController {

	@Autowired
	BSPJobLauncher bspJobLauncher;

	@RequestMapping("/bsp/processFile")
	public void processFile(@RequestParam("inboundFileName") String inboundFileName, @RequestParam("user") String user,
			@RequestParam("clientId") String clientId) throws Exception {
		bspJobLauncher.launchBSPStagingLoadJob(inboundFileName, user, clientId);
	}

	@RequestMapping("/bsp/moveStagingToProd")
	public void moveStagingToProd(@RequestParam("fileId") Long fileId, @RequestParam("user") String user)
			throws Exception {
		bspJobLauncher.launchBSPProdLoadJob(fileId, user);
	}
	
	@RequestMapping("/bsp/businessValidations")
	public void executeSalesBusinessValidation(@RequestParam("fileId") Long fileId) {
		
	}

}
