import { TestBed } from '@angular/core/testing';

import { SalesdashboardserviceService } from './salesdashboardservice.service';

describe('SalesdashboardserviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SalesdashboardserviceService = TestBed.get(SalesdashboardserviceService);
    expect(service).toBeTruthy();
  });
});
