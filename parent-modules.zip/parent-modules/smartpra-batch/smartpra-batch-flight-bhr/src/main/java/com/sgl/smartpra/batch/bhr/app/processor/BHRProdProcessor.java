package com.sgl.smartpra.batch.bhr.app.processor;

import static com.sgl.smartpra.batch.bhr.app.util.BHRConstants.BALANCE_FLAG_DEFAULT;
import static com.sgl.smartpra.batch.bhr.app.util.BHRConstants.CABIN;
import static com.sgl.smartpra.batch.bhr.app.util.BHRConstants.CONTROL_CAL;
import static com.sgl.smartpra.batch.bhr.app.util.BHRConstants.CONTROL_VALUE;
import static com.sgl.smartpra.batch.bhr.app.util.BHRConstants.DOC_TYPE;
import static com.sgl.smartpra.batch.bhr.app.util.BHRConstants.DOC_TYPE_EBT;
import static com.sgl.smartpra.batch.bhr.app.util.BHRConstants.DOC_TYPE_EMD;
import static com.sgl.smartpra.batch.bhr.app.util.BHRConstants.DOC_TYPE_MCO;
import static com.sgl.smartpra.batch.bhr.app.util.BHRConstants.ESTIMATION_FLAG_DEFAULT;
import static com.sgl.smartpra.batch.bhr.app.util.BHRConstants.FLIGHT_TYPE_DEFAULT;
import static com.sgl.smartpra.batch.bhr.app.util.BHRConstants.NON_REVENUE_IND;
import static com.sgl.smartpra.batch.bhr.app.util.BHRConstants.NON_REVENUE_IND_Y;
import static com.sgl.smartpra.batch.bhr.app.util.BHRConstants.SERVICE_TYPE_SCHEDULE;
import static com.sgl.smartpra.batch.bhr.app.util.BHRConstants.SSIM_IND_N;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.bhr.app.config.FeignConfiguration.BatchGlobalFeignClient;
import com.sgl.smartpra.batch.bhr.app.config.FeignConfiguration.ExceptionTransIntgAppClient;
import com.sgl.smartpra.batch.bhr.app.config.FeignConfiguration.GlobalMasterFeignClient;
import com.sgl.smartpra.batch.bhr.app.config.FeignConfiguration.SmartpraFlownClient;
import com.sgl.smartpra.batch.bhr.app.config.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.batch.bhr.app.domain.FlightBatchHeaderStg;
import com.sgl.smartpra.batch.bhr.app.util.BHRCommonUtil;
import com.sgl.smartpra.batch.bhr.app.util.BHRConstants;
import com.sgl.smartpra.batch.bhr.app.util.BHRCountReader;
import com.sgl.smartpra.batch.global.model.FileLogging;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.exception.txn.model.ExceptionParametersValueModel;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.flown.model.FlightControlDetails;
import com.sgl.smartpra.flown.model.FlightDataDetails;
import com.sgl.smartpra.flown.model.FlightFutureSchedule;
import com.sgl.smartpra.global.master.model.Airport;
import com.sgl.smartpra.master.model.Aircraft;
import com.sgl.smartpra.master.model.FlightControl;

import feign.FeignException;

@Component
@Scope(value = "step")
public class BHRProdProcessor extends RecordProcessor
		implements ItemProcessor<FlightBatchHeaderStg, FlightBatchHeaderStg> {

	private static Logger LOGGER = LoggerFactory.getLogger(BHRProdProcessor.class);

	@Autowired
	SmartpraMasterAppClient smartpraMasterAppClient;

	@Autowired
	SmartpraFlownClient smartpraFlownClient;

	@Autowired
	BatchGlobalFeignClient batchGlobalFeignClient;

	@Autowired
	ExceptionTransIntgAppClient exceptionTransIntgAppClient;

	@Autowired
	GlobalMasterFeignClient globalMasterFeignClient;

	@Value("#{stepExecution}")
	private StepExecution stepExecution;

	ExceptionTransactionModel exceptionTransactionModel;
	List<ExceptionParametersValueModel> parametersValueModelList;
	ExceptionParametersValueModel parametersValueModel;
	FileLogging fileLogging;


	@Override
	public FlightBatchHeaderStg process(FlightBatchHeaderStg fileDetail) throws Exception {
		LOGGER.info("BHRProdProcessor.process() - start with flightNumber:" + fileDetail.getFlightNumber());
		super.process(fileDetail);
		BHRCountReader.incTotalCount();
		ExceptionTransactionModel exceptionTransactionModel;
		List<ExceptionParametersValueModel> parametersValueModelList;
		ExceptionParametersValueModel parametersValueModel;
		FileLogging fileLogging;
		String flightDate = BHRCommonUtil.getDate(fileDetail.getFlightDate())
				.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
		FlightDataDetails flightDataDetails = new FlightDataDetails();
		String clientId = stepExecution.getJobExecution().getJobParameters().getString("clientId");

		String flightNumberOption = stepExecution.getJobExecution().getJobParameters().getString("flightNumberOption");

		flightDataDetails = new FlightDataDetails();
		flightDataDetails.setClientId(clientId);

		if (StringUtils.isNotEmpty(flightNumberOption)) {
			flightDataDetails.setFlightNumber(
					BHRCommonUtil.derivedFlightNumber(fileDetail.getFlightNumber(), flightNumberOption));
		} else {
			flightDataDetails.setFlightNumber(fileDetail.getFlightNumber());
		}
		Airport airport = null;
		// checking from airport code
		try {
			airport = globalMasterFeignClient.getAirportByAirportCode(fileDetail.getFromAirport());
		} catch (FeignException fex) {
			LOGGER.error(" From Airpot Code is not in Airport Master:" + fileDetail.getFromAirport());
		}
		if (airport != null) {
			flightDataDetails.setFromAirport(OptionalUtil.getValue(airport.getAirportCode()));
		} else {
			BHRCountReader.incErrorCount();
			exceptionTransactionModel = prepareExceptionTransactionModel(fileDetail);
			exceptionTransactionModel.setExceptionCode(BHRConstants.BHR_FILE_INCORRECT_AIRPORTCODE);
			parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();

			fileLogging = batchGlobalFeignClient.getFileLogByFileId(BigInteger.valueOf(fileDetail.getFileId()));

			parametersValueModel = new ExceptionParametersValueModel();
			parametersValueModel.setParameterName("File Name");
			parametersValueModel.setParameterValue(fileLogging.getFileName());
			parametersValueModelList.add(parametersValueModel);

			parametersValueModel = new ExceptionParametersValueModel();
			parametersValueModel.setParameterName("Airport Code");
			parametersValueModel.setParameterValue(fileDetail.getFromAirport());
			parametersValueModelList.add(parametersValueModel);

			exceptionTransactionModel.setParametersValueList(parametersValueModelList);
			exceptionTransIntgAppClient.initExceptionTrasaction(exceptionTransactionModel);
			return null;
		}

		// checking to airport code
		Airport toAirport = null;
		try {
			toAirport = globalMasterFeignClient.getAirportByAirportCode(fileDetail.getToAirport());
		} catch (FeignException fex) {
			LOGGER.error(" To Airpot Code is not in Airport Master:" + fileDetail.getToAirport());
		}

		if (toAirport != null) {
			LOGGER.info("Setting toairport to flidata Details - start");
			flightDataDetails.setToAirport(OptionalUtil.getValue(toAirport.getAirportCode()));
			LOGGER.info("Setting toairport to flidata Details - start");
		} else {
			BHRCountReader.incErrorCount();
			exceptionTransactionModel = prepareExceptionTransactionModel(fileDetail);
			exceptionTransactionModel.setExceptionCode(BHRConstants.BHR_FILE_INCORRECT_AIRPORTCODE);
			parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();

			fileLogging = batchGlobalFeignClient.getFileLogByFileId(BigInteger.valueOf(fileDetail.getFileId()));

			parametersValueModel = new ExceptionParametersValueModel();
			parametersValueModel.setParameterName("File Name");
			parametersValueModel.setParameterValue(fileLogging.getFileName());
			parametersValueModelList.add(parametersValueModel);

			parametersValueModel = new ExceptionParametersValueModel();
			parametersValueModel.setParameterName("Airport Code");
			parametersValueModel.setParameterValue(fileDetail.getToAirport());
			parametersValueModelList.add(parametersValueModel);

			exceptionTransactionModel.setParametersValueList(parametersValueModelList);
			exceptionTransIntgAppClient.initExceptionTrasaction(exceptionTransactionModel);
			return null;
		}

		flightDataDetails.setFlightDate(BHRCommonUtil.getDate(fileDetail.getFlightDate()));
		LOGGER.info("smartpraMasterAppClient.getAllAircraft(getAircraftRegistration) - start");
		List<Aircraft> aircrafts = null;
		Aircraft aircraft = null;
		try {
			aircrafts = smartpraMasterAppClient.getAllAircraft(fileDetail.getAircraftRegistration(), null, null);

		} catch (FeignException fex) {
			LOGGER.error(" getAircraftRegistration is not in Aircraft Master:" + fileDetail.getAircraftRegistration());
		}
		// Setting Aircraft Registration
		if (aircrafts != null && aircrafts.size() > 0) {
			LOGGER.info("Aircraft Registration to flidata Details - start");
			aircraft = aircrafts.get(0);
			flightDataDetails.setAircraftRegistration(aircraft.getAircraftRegistration().get());
			flightDataDetails.setAircraftType(aircraft.getAircraftType().get());
			LOGGER.info("Aircraft Registration to flidata Details - End");
		} else {
			exceptionTransactionModel = prepareExceptionTransactionModel(fileDetail);
			exceptionTransactionModel.setExceptionCode(BHRConstants.BHR_FILE_INCORRECT_AIRCRAFT_REGISTRATION);
			parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();

			fileLogging = batchGlobalFeignClient.getFileLogByFileId(BigInteger.valueOf(fileDetail.getFileId()));

			parametersValueModel = new ExceptionParametersValueModel();
			parametersValueModel.setParameterName("Aircraft registration");
			parametersValueModel.setParameterValue(fileDetail.getAircraftRegistration());
			parametersValueModelList.add(parametersValueModel);

			parametersValueModel = new ExceptionParametersValueModel();
			parametersValueModel.setParameterName("File Name");
			parametersValueModel.setParameterValue(fileLogging.getFileName());
			parametersValueModelList.add(parametersValueModel);

			exceptionTransactionModel.setParametersValueList(parametersValueModelList);
			exceptionTransIntgAppClient.initExceptionTrasaction(exceptionTransactionModel);
		}
		if (StringUtils.isNotEmpty(fileDetail.getPayload())) {
			flightDataDetails.setPayloadCapacity(Long.valueOf(fileDetail.getPayload()));
		} else if (aircraft != null) {
			flightDataDetails.setPayloadCapacity(Long.parseLong(aircraft.getPayload().get()));
		}

		LOGGER.info("smartpraMasterAppClient.getAllAircraft(getAircraftRegistration) - End");
		flightDataDetails.setFileId(fileDetail.getFileId());
		// Flight master reference
		LOGGER.info("smartpraMasterAppClient.getFlightSchedule() - start");
		FlightFutureSchedule flightSchedule = smartpraFlownClient.getFlightSchedule(clientId,
				fileDetail.getFlightNumber(), fileDetail.getFromAirport(), fileDetail.getToAirport(),
				BHRCommonUtil.convertDate(fileDetail.getFlightDate()));
		LOGGER.info("smartpraMasterAppClient.getFlightSchedule() - End");
		flightDataDetails.setServiceType(SERVICE_TYPE_SCHEDULE);

		flightDataDetails.setArrivalTime(flightSchedule.getArrivalTime());
		flightDataDetails.setDepartureTime(flightSchedule.getDepartureTime());
		flightDataDetails.setFromLeg(flightSchedule.getFromLeg());
		flightDataDetails.setToLeg(flightSchedule.getToLeg());
		flightDataDetails.setFlightType(flightSchedule != null && StringUtils.isNotEmpty(flightSchedule.getFlightType())
				? flightSchedule.getFlightType()
				: FLIGHT_TYPE_DEFAULT);
		flightDataDetails.setEstimationFlag(ESTIMATION_FLAG_DEFAULT);
		flightDataDetails.setFlightIndicator(BHRConstants.FLIGHT_INDICATOR);
		flightDataDetails.setAircraftRegistration(fileDetail.getAircraftRegistration());
		flightDataDetails.setfCabinCapacity(Integer.valueOf(fileDetail.getFirstClassCabinControl()));
		flightDataDetails.setcCabinCapacity(Integer.valueOf(fileDetail.getBusinessCabinControl()));
		flightDataDetails.setwCabinCapacity(Integer.valueOf(fileDetail.getPremiumEconomyCabinControl()));
		flightDataDetails.setyCabinCapacity(Integer.valueOf(fileDetail.getEconomyCabinControl()));

		flightDataDetails.setfCabinBlockCapacity(Integer.valueOf(fileDetail.getFirstClassCapacity()));
		flightDataDetails.setcCabinBlockCapacity(Integer.valueOf(fileDetail.getBusinessClassCapacity()));
		flightDataDetails.setwCabinBlockCapacity(Integer.valueOf(fileDetail.getPremiumEcoClassCapacity()));
		flightDataDetails.setyCabinBlockCapacity(Integer.valueOf(fileDetail.getEconomyClassCapacity()));

		flightDataDetails.setReceivedPaxCount(Integer.valueOf(fileDetail.getFirstClassCabinControl())
				+ Integer.valueOf(fileDetail.getBusinessCabinControl())
				+ Integer.valueOf(fileDetail.getPremiumEconomyCabinControl())
				+ Integer.valueOf(fileDetail.getEconomyCabinControl()));

		flightDataDetails.setActualPaxCount(0);
		flightDataDetails
				.setMismatchPaxCount(flightDataDetails.getReceivedPaxCount() - flightDataDetails.getActualPaxCount());

		/*
		 * flightDataDetails.setBalanceFlag(BALANCE_FLAG_DEFAULT);
		 * if(flightDataDetails.getSsimInd().equals(null)) {
		 * flightDataDetails.setSsimInd(SSIM_IND_N); }else {
		 * flightDataDetails.setSsimInd(SSIM_IND_Y); }
		 */
		flightDataDetails.setBalanceFlag(BALANCE_FLAG_DEFAULT);
		flightDataDetails.setDeadLoadCapacity(Long.valueOf(fileDetail.getDeadload()));
		LOGGER.info("smartpraFlownClient.getFlightDataDetails() - start with flight Numebr::"
				+ fileDetail.getFlightNumber());
		FlightDataDetails flightDataDetailsDB = smartpraFlownClient.getFlightDataDetails(fileDetail.getFlightNumber(),
				fileDetail.getFromAirport(), fileDetail.getToAirport(),
				BHRCommonUtil.getDate(fileDetail.getFlightDate()), null);
		LOGGER.info("smartpraFlownClient.getFlightDataDetails() - End");
		if (flightDataDetailsDB != null) {
			if (!flightDataDetailsDB.getFlightStatus().equals(BHRConstants.FLIGHT_STATUS_OUTSTANDING)) {
				BHRCountReader.incErrorCount();
				exceptionTransactionModel = prepareExceptionTransactionModel(fileDetail);
				exceptionTransactionModel.setExceptionCode(BHRConstants.BHR_FILE_FLIGHT_ALREADY_UPDATED);
				parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();

				fileLogging = batchGlobalFeignClient.getFileLogByFileId(BigInteger.valueOf(fileDetail.getFileId()));

				/*
				 * parametersValueModel = new ExceptionParametersValueModel();
				 * parametersValueModel.setParameterName("File name");
				 * parametersValueModel.setParameterValue(fileLogging.getFileName());
				 * parametersValueModelList.add(parametersValueModel);
				 */

				parametersValueModel = new ExceptionParametersValueModel();
				parametersValueModel.setParameterName("Flight no");
				parametersValueModel.setParameterValue(fileDetail.getFlightNumber());
				parametersValueModelList.add(parametersValueModel);

				parametersValueModel = new ExceptionParametersValueModel();
				parametersValueModel.setParameterName("From sector");
				parametersValueModel.setParameterValue(fileDetail.getFromAirport());
				parametersValueModelList.add(parametersValueModel);

				parametersValueModel = new ExceptionParametersValueModel();
				parametersValueModel.setParameterName("To sector");
				parametersValueModel.setParameterValue(fileDetail.getToAirport());
				parametersValueModelList.add(parametersValueModel);

				parametersValueModel = new ExceptionParametersValueModel();
				parametersValueModel.setParameterName("Depart date");
				parametersValueModel.setParameterValue(flightDate);
				parametersValueModelList.add(parametersValueModel);

				exceptionTransactionModel.setParametersValueList(parametersValueModelList);
				exceptionTransIntgAppClient.initExceptionTrasaction(exceptionTransactionModel);
				return null;
			} else {
				flightDataDetails.setFlightStatus(BHRConstants.FLIGHT_STATUS_OPEN);
				flightDataDetails.setLastUpdatedBy(BHRConstants.BHR_LAST_UPDATEDBY);
				flightDataDetails.setSsimInd(flightDataDetailsDB.getSsimInd());
				flightDataDetails.setDataSource(flightDataDetailsDB.getDataSource());
				flightDataDetails.setFileId(flightDataDetailsDB.getFileId());
				LOGGER.info(
						"smartpraFlownClient.updateFlightDataDetails(flightKey, flightDataDetails) - start with flight Key::"
								+ flightDataDetailsDB.getFlightKey());
				flightDataDetails = smartpraFlownClient.updateFlightDataDetails(flightDataDetailsDB.getFlightKey(),
						flightDataDetails);
				createFlightControlDetails(fileDetail, flightDataDetails);
				LOGGER.info(
						"smartpraFlownClient.updateFlightDataDetails(flightKey, flightDataDetails) - ends with flight Key::"
								+ flightDataDetailsDB.getFlightKey());
			}
		} else {

			flightDataDetails.setSsimInd(SSIM_IND_N);
			flightDataDetails.setDataSource(BHRConstants.BHR_DATA_SOURCE_STATUS);
			flightDataDetails.setFlightStatus(BHRConstants.FLIGHT_STATUS_OPEN);
			flightDataDetails.setCreatedBy(fileDetail.getCreatedBy());
			flightDataDetails.setCreatedDate(new Timestamp(new Date().getTime()));
			try {
				LOGGER.info("smartpraFlownClient.createFlightDataDetails(flightDataDetails) - start with flightNumber::"
						+ flightDataDetails.getFlightNumber());
				flightDataDetails = smartpraFlownClient.createFlightDataDetails(flightDataDetails);
				createFlightControlDetails(fileDetail, flightDataDetails);

				LOGGER.info("smartpraFlownClient.createFlightDataDetails(flightDataDetails) - End with flightNumber::"
						+ flightDataDetails.getFlightNumber());
			} catch (FeignException fex) {
				BHRCountReader.incErrorCount();
				exceptionTransactionModel = prepareExceptionTransactionModel(fileDetail);
				exceptionTransactionModel.setExceptionCode(BHRConstants.BHR_FILE_ERROR_IN_CREATING_FLIFGHT);
				parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();

				fileLogging = batchGlobalFeignClient.getFileLogByFileId(BigInteger.valueOf(fileDetail.getFileId()));

				/*
				 * parametersValueModel = new ExceptionParametersValueModel();
				 * parametersValueModel.setParameterName("File name");
				 * parametersValueModel.setParameterValue(fileLogging.getFileName());
				 * parametersValueModelList.add(parametersValueModel);
				 */

				parametersValueModel = new ExceptionParametersValueModel();
				parametersValueModel.setParameterName("Flight no");
				parametersValueModel.setParameterValue(fileDetail.getFlightNumber());
				parametersValueModelList.add(parametersValueModel);

				parametersValueModel = new ExceptionParametersValueModel();
				parametersValueModel.setParameterName("From sector");
				parametersValueModel.setParameterValue(fileDetail.getFromAirport());
				parametersValueModelList.add(parametersValueModel);

				parametersValueModel = new ExceptionParametersValueModel();
				parametersValueModel.setParameterName("To sector");
				parametersValueModel.setParameterValue(fileDetail.getToAirport());
				parametersValueModelList.add(parametersValueModel);

				parametersValueModel = new ExceptionParametersValueModel();
				parametersValueModel.setParameterName("Depart date");
				parametersValueModel.setParameterValue(flightDate);
				parametersValueModelList.add(parametersValueModel);

				exceptionTransactionModel.setParametersValueList(parametersValueModelList);
				exceptionTransIntgAppClient.initExceptionTrasaction(exceptionTransactionModel);
				return null;
			}
		}
		LOGGER.info("BHRProdProcessor.process() - end");
		BHRCountReader.incTransferCount();
		return fileDetail;
	}

	private void createFlightControlDetails(FlightBatchHeaderStg fileDetail, FlightDataDetails flightDataDetails) {
		Integer receivedCount = null;
		BHRCommonUtil commonUtil = new BHRCommonUtil();
		LOGGER.info("smartpraMasterAppClient.getFlightControls(clientId) - start");
		List<FlightControl> flightControls = smartpraMasterAppClient.getFlightControls(fileDetail.getClientId());
		LOGGER.info("smartpraMasterAppClient.getFlightControls(clientId) - End");
		flightControls.sort(Comparator.comparing((FlightControl fc) -> fc.getControlType().get()).reversed());
		String flightDate = BHRCommonUtil.getDate(fileDetail.getFlightDate())
				.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
		Map<String, Object> controlMap = new HashMap<>();
		if (CollectionUtils.isNotEmpty(flightControls)) {
			for (FlightControl flightControl : flightControls) {
				FlightControlDetails flightControlDetails = new FlightControlDetails();
				flightControlDetails.setClientId(fileDetail.getClientId());
				flightControlDetails.setFlightKey(flightDataDetails.getFlightKey());
				flightControlDetails.setFlightNumber(fileDetail.getFlightNumber());
				flightControlDetails.setFromAirport(fileDetail.getFromAirport());
				flightControlDetails.setToAirport(fileDetail.getToAirport());
				flightControlDetails.setFlightDate(BHRCommonUtil.getDate(fileDetail.getFlightDate()));
				flightControlDetails.setControlId(flightControl.getFlightControlId().get());

				String ctrlInd1 = null;
				String ctrlVal1 = null;
				String ctrlInd2 = null;
				String ctrlVal2 = null;
				String ctrlInd3 = null;
				String ctrlVal3 = null;
				String ctrlInd4 = null;
				String ctrlVal4 = null;
				String selfOalInd = null;

				if (flightControl.getControlIndicator1().isPresent()) {
					ctrlInd1 = flightControl.getControlIndicator1().get();
				}

				if (flightControl.getControlValue1().isPresent()) {
					ctrlVal1 = flightControl.getControlValue1().get();
				}

				if (flightControl.getControlIndicator2().isPresent()) {
					ctrlInd2 = flightControl.getControlIndicator2().get();
				}
				if (flightControl.getControlValue2().isPresent()) {
					ctrlVal2 = flightControl.getControlValue2().get();
				}

				if (flightControl.getControlIndicator3().isPresent()) {
					ctrlInd3 = flightControl.getControlIndicator3().get();
				}
				if (flightControl.getControlValue3().isPresent()) {
					ctrlVal3 = flightControl.getControlValue3().get();
				}
				if (flightControl.getControlIndicator4().isPresent()) {
					ctrlInd4 = flightControl.getControlIndicator4().get();
				}
				if (flightControl.getControlValue4().isPresent()) {
					ctrlVal4 = flightControl.getControlValue4().get();
				}
				if (flightControl.getSelfOalIndicator().isPresent()) {
					selfOalInd = flightControl.getSelfOalIndicator().get();
				}

				if (flightControl.getControlType().get().equalsIgnoreCase(CONTROL_VALUE)) {

					if (StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(CABIN)) {
						receivedCount = commonUtil.receivedCountCalculationCabin1(fileDetail, ctrlInd1, ctrlVal1,
								ctrlInd2, ctrlVal2, ctrlInd3, ctrlVal3, ctrlInd4, ctrlVal4);
					} else if (StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(CABIN)) {
						receivedCount = commonUtil.receivedCountCalculationCabin2(fileDetail, ctrlInd1, ctrlVal1,
								ctrlInd2, ctrlVal2, ctrlInd3, ctrlVal3, ctrlInd4, ctrlVal4);
					} else if (StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(CABIN)) {
						receivedCount = commonUtil.receivedCountCalculationCabin3(fileDetail, ctrlInd1, ctrlVal1,
								ctrlInd2, ctrlVal2, ctrlInd3, ctrlVal3, ctrlInd4, ctrlVal4);
					} else if (StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(CABIN)) {
						receivedCount = commonUtil.receivedCountCalculationCabin4(fileDetail, ctrlInd1, ctrlVal1,
								ctrlInd2, ctrlVal2, ctrlInd3, ctrlVal3, ctrlInd4, ctrlVal4);
					}

					// Handling Non Revenue Indicator-for infant
					if (StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(NON_REVENUE_IND)
							&& ctrlVal1.equalsIgnoreCase(NON_REVENUE_IND_Y)) {
						receivedCount = commonUtil.infantCount1(fileDetail, ctrlInd2, ctrlVal2, ctrlInd3, ctrlVal3,
								ctrlInd4, ctrlVal4);
					} else if (StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(NON_REVENUE_IND)
							&& ctrlVal2.equalsIgnoreCase(NON_REVENUE_IND_Y)) {
						receivedCount = commonUtil.infantCount2(fileDetail, ctrlInd1, ctrlVal1, ctrlInd3, ctrlVal3,
								ctrlInd4, ctrlVal4);
					} else if (StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(NON_REVENUE_IND)
							&& ctrlVal3.equalsIgnoreCase(NON_REVENUE_IND_Y)) {
						receivedCount = commonUtil.infantCount3(fileDetail, ctrlInd1, ctrlVal1, ctrlInd2, ctrlVal2,
								ctrlInd4, ctrlVal4);
					} else if (StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(NON_REVENUE_IND)
							&& ctrlVal4.equalsIgnoreCase(NON_REVENUE_IND_Y)) {
						receivedCount = commonUtil.infantCount4(fileDetail, ctrlInd1, ctrlVal1, ctrlInd2, ctrlVal2,
								ctrlInd3, ctrlVal3);
					}

					// Handling MCO/EMD/FIN
					if (StringUtils.isNotEmpty(ctrlInd1) && ctrlInd1.equalsIgnoreCase(DOC_TYPE)
							&& (ctrlVal1.equalsIgnoreCase(DOC_TYPE_EMD) || ctrlVal1.equalsIgnoreCase(DOC_TYPE_MCO)
									|| ctrlVal1.equalsIgnoreCase(DOC_TYPE_EBT))) {
						receivedCount = commonUtil.emdMcoEbtCount1(fileDetail, selfOalInd, ctrlInd1, ctrlVal1, ctrlInd2,
								ctrlVal2, ctrlInd3, ctrlVal3, ctrlInd4, ctrlVal4);
					} else if (StringUtils.isNotEmpty(ctrlInd2) && ctrlInd2.equalsIgnoreCase(DOC_TYPE)
							&& (ctrlVal2.equalsIgnoreCase(DOC_TYPE_EMD) || ctrlVal2.equalsIgnoreCase(DOC_TYPE_MCO)
									|| ctrlVal2.equalsIgnoreCase(DOC_TYPE_EBT))) {
						receivedCount = commonUtil.emdMcoEbtCount2(fileDetail, selfOalInd, ctrlInd1, ctrlVal1, ctrlInd2,
								ctrlVal2, ctrlInd3, ctrlVal3, ctrlInd4, ctrlVal4);
					} else if (StringUtils.isNotEmpty(ctrlInd3) && ctrlInd3.equalsIgnoreCase(NON_REVENUE_IND)
							&& ctrlVal3.equalsIgnoreCase(NON_REVENUE_IND_Y)) {
						receivedCount = commonUtil.emdMcoEbtCount3(fileDetail, selfOalInd, ctrlInd1, ctrlVal1, ctrlInd2,
								ctrlVal2, ctrlInd3, ctrlVal3, ctrlInd4, ctrlVal4);
					} else if (StringUtils.isNotEmpty(ctrlInd4) && ctrlInd4.equalsIgnoreCase(NON_REVENUE_IND)
							&& ctrlVal4.equalsIgnoreCase(NON_REVENUE_IND_Y)) {
						receivedCount = commonUtil.emdMcoEbtCount4(fileDetail, selfOalInd, ctrlInd1, ctrlVal1, ctrlInd2,
								ctrlVal2, ctrlInd3, ctrlVal3, ctrlInd4, ctrlVal4);
					}

					flightControlDetails.setReceivedCount(receivedCount != null ? receivedCount : 0);
					controlMap.put(flightControl.getFlightControlId().get(), receivedCount);
				} // END V

				if (flightControl.getControlType().get().equalsIgnoreCase(CONTROL_CAL)) {
					// formula evaluation
					receivedCount = commonUtil.parseControlFormula(flightControl.getControlFormula().get(), controlMap);
					flightControlDetails.setReceivedCount(receivedCount != null ? receivedCount : 0);
					controlMap.put(flightControl.getFlightControlId().get(), receivedCount);
				}
				flightControlDetails.setActualCount(0);
				flightControlDetails.setMismatchCount(0);
				flightControlDetails.setCreatedBy(fileDetail.getCreatedBy());
				flightControlDetails.setCreatedDate(new Timestamp(new Date().getTime()));

				try {
					smartpraFlownClient.createFlightControlDetails(flightDataDetails.getFlightKey(),
							flightControlDetails);
				} catch (FeignException fex) {
					LOGGER.error(fex.getMessage());
					exceptionTransactionModel = prepareExceptionTransactionModel(fileDetail);
					exceptionTransactionModel.setExceptionCode(BHRConstants.BHR_FILE_ERROR_IN_POPULATE_FLOIGHT_CONTROL);
					parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();

					fileLogging = batchGlobalFeignClient.getFileLogByFileId(BigInteger.valueOf(fileDetail.getFileId()));

					/*
					 * parametersValueModel = new ExceptionParametersValueModel();
					 * parametersValueModel.setParameterName("File name");
					 * parametersValueModel.setParameterValue(fileLogging.getFileName());
					 * parametersValueModelList.add(parametersValueModel);
					 */

					parametersValueModel = new ExceptionParametersValueModel();
					parametersValueModel.setParameterName("Flight no");
					parametersValueModel.setParameterValue(fileDetail.getFlightNumber());
					parametersValueModelList.add(parametersValueModel);

					parametersValueModel = new ExceptionParametersValueModel();
					parametersValueModel.setParameterName("From sector");
					parametersValueModel.setParameterValue(fileDetail.getFromAirport());
					parametersValueModelList.add(parametersValueModel);

					parametersValueModel = new ExceptionParametersValueModel();
					parametersValueModel.setParameterName("To sector");
					parametersValueModel.setParameterValue(fileDetail.getToAirport());
					parametersValueModelList.add(parametersValueModel);

					parametersValueModel = new ExceptionParametersValueModel();
					parametersValueModel.setParameterName("Depart date");
					parametersValueModel.setParameterValue(flightDate);
					parametersValueModelList.add(parametersValueModel);

					exceptionTransactionModel.setParametersValueList(parametersValueModelList);
					exceptionTransIntgAppClient.initExceptionTrasaction(exceptionTransactionModel);
				}
			}
		}
	}

	private ExceptionTransactionModel prepareExceptionTransactionModel(FlightBatchHeaderStg fileDetail) {
		ExceptionTransactionModel exceptionTransactionModel = new ExceptionTransactionModel();
		String issueCxr = BHRCommonUtil.getHostCarrierNumericCode(smartpraMasterAppClient);
		String clientId = BHRCommonUtil.getHostCarrierDesigCode(smartpraMasterAppClient);
		exceptionTransactionModel.setClientId(clientId);
		exceptionTransactionModel.setIssuedCarrier(issueCxr);
		exceptionTransactionModel.setOrderId(2);// for future use
		exceptionTransactionModel.setCreatedBy(BHRConstants.BHR_EXCEP_CREATEDBY);
		exceptionTransactionModel.setEnvironment(BHRConstants.BHR_EXCEP_ENVIRONMENT_P);
		exceptionTransactionModel.setFileId((long) fileDetail.getFileId());
		exceptionTransactionModel.setExceptionDate(LocalDateTime.now());

		exceptionTransactionModel.setBatchKey1(fileDetail.getFlightNumber());
		exceptionTransactionModel.setBatchKey2(fileDetail.getFromAirport());
		exceptionTransactionModel.setBatchKey3(fileDetail.getToAirport());
		exceptionTransactionModel.setBatchKey4(BHRConstants.FLIGHT_INDICATOR.toString());
		Date date = Date.from(
				BHRCommonUtil.getDate(fileDetail.getFlightDate()).atStartOfDay(ZoneId.systemDefault()).toInstant());
		exceptionTransactionModel.setBatchKey5(asLocalDateTime(date));
		exceptionTransactionModel.setBatchKey6(LocalDateTime.now());

		return exceptionTransactionModel;
	}

	public static LocalDateTime asLocalDateTime(Date date) {
		return Instant.ofEpochMilli(date.getTime()).atZone(ZoneId.systemDefault()).toLocalDateTime();
	}

}
