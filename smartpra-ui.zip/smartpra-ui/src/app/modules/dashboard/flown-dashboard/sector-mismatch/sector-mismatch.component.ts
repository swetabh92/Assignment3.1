import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sector-mismatch',
  templateUrl: './sector-mismatch.component.html',
  styleUrls: ['./sector-mismatch.component.css']
})
export class SectorMismatchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
