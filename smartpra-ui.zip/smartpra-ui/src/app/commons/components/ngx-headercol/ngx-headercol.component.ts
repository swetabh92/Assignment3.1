import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-ngx-headercol',
  templateUrl: './ngx-headercol.component.html',
  styleUrls: ['./ngx-headercol.component.css']
})
export class NgxHeadercolComponent implements OnInit {

  constructor() { }
	@Input() sortDir:string;
	@Input() sortable:boolean;
	@Input() name:boolean;
  ngOnInit() {
  }

}
