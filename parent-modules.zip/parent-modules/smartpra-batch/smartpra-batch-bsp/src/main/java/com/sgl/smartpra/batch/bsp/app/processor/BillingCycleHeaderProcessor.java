package com.sgl.smartpra.batch.bsp.app.processor;

import com.sgl.smartpra.batch.bsp.app.domain.staging.BSPStagingDomainObject;
import com.sgl.smartpra.batch.bsp.app.domain.staging.BillingCycleHeaderStg;
import com.sgl.smartpra.batch.bsp.app.mapper.BSPRecordMapper;
import com.sgl.smartpra.batch.bsp.app.record.BSPBaseRecord;
import com.sgl.smartpra.batch.bsp.app.record.BillingCycleHeader;

public class BillingCycleHeaderProcessor extends BSPBaseItemProcessor {
	@Override
	public BSPStagingDomainObject process(BSPBaseRecord bspBaseRecord) throws Exception {

		BillingCycleHeaderStg billingCycleHeaderStg = BSPRecordMapper.INSTANCE
				.mapBillingCycleHeaderRecord((BillingCycleHeader) bspBaseRecord);
		return billingCycleHeaderStg;

	}
}
