package com.sgl.smartpra.batch.amadeus.app.listener;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.amadeus.app.config.FeignConfiguration.BatchGlobalFeignClient;
import com.sgl.smartpra.batch.global.model.FileErrorLog;
import com.sgl.smartpra.batch.global.model.FileLogging;
import com.sgl.smartpra.common.util.FileLoggingConstants;
import com.sgl.smartpra.common.util.SmartpraFileUtility;

@Component
public class ProdJobsNotificationListener extends JobExecutionListenerSupport {

	private static final Logger LOGGER = LoggerFactory.getLogger(StgJobNotificationListener.class);

	@Autowired
	BatchGlobalFeignClient batchGlobalFeignClient;

	private StepExecution stepExecution;

	@Value("${batch.directory.amadeus.input}")
	private String batchInputDir;

	@Value("${batch.directory.amadeus.processed}")
	private String batchProcessedDir;

	@Value("${batch.directory.amadeus.failed}")
	private String batchFailedDir;

	@Override
	public void afterJob(JobExecution jobExecution) {
		long fileId = jobExecution.getJobParameters().getLong("inboundFileId");
		String fileName = jobExecution.getJobParameters().getString("inboundFileName");
		FileLogging  fileLogging = batchGlobalFeignClient.getFileLogByFileId(BigInteger.valueOf(fileId));
		fileLogging.setEndDateTime(new Timestamp(new Date().getTime()));
		Integer errorCount = (Integer) jobExecution.getExecutionContext().get("errorCount");
		if(errorCount == null) errorCount = 0;
		Integer transferredCount = (Integer) jobExecution.getExecutionContext().get("transferredCount");
		if(transferredCount == null) transferredCount = 0;
		if (jobExecution.getStatus() == BatchStatus.COMPLETED) {
			if(errorCount == 0) {
				fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_TRANSFERRED);
			} else {
				fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_PARTTRANSFERRED);
				fileLogging.setRemarks("Due to errors in the file only partial records transferred.");
			}
			SmartpraFileUtility.moveFile(batchInputDir + fileName, batchProcessedDir + fileName);
			fileLogging.setIsMovedToRelevantFolder("Y");
			LOGGER.info("!!! JOB FINISHED! Time to verify the results");
		} else  {
			String dtStr = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
			fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_TECHFAILED);
			String remarks = (String) jobExecution.getExecutionContext().get("errorRemarks");
			if(remarks != null && remarks.length()>0) {
				fileLogging.setRemarks(remarks); 
			} 
			else {
				fileLogging.setRemarks(FileLoggingConstants.FILELOGGING_FAILED_REMARK); 
			}
			FileErrorLog fileErrorLog = new FileErrorLog();
			fileErrorLog.setFileId(fileLogging.getFileId());
			fileErrorLog.setErrorDetail(jobExecution.getStatus().toString());
			fileErrorLog.setErrorDescription(jobExecution.getStepExecutions().toString().substring(0,1000));
			ArrayList<FileErrorLog> fileErrorLogList = new ArrayList<FileErrorLog>();
			fileErrorLogList.add(fileErrorLog);
			fileLogging.setFileErrorLog(fileErrorLogList);
			SmartpraFileUtility.moveFile(batchInputDir + fileName, batchFailedDir + fileName + dtStr);
			fileLogging.setIsMovedToRelevantFolder("Y");
			LOGGER.info("!!! JOB FINISHED -FAILED ! Time to verify the results");
		}
		fileLogging.setErrorCounts(errorCount);
		fileLogging.setTransferredCounts(transferredCount);
		fileLogging = batchGlobalFeignClient.updateFileLog(BigInteger.valueOf(fileId), fileLogging);
	}
}