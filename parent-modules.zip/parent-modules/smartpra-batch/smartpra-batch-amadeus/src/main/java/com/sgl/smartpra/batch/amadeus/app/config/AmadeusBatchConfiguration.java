package com.sgl.smartpra.batch.amadeus.app.config;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManagerFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.data.RepositoryItemReader;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.mapping.PatternMatchingCompositeLineMapper;
import org.springframework.batch.item.file.transform.LineTokenizer;
import org.springframework.beans.factory.BeanInitializationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.transaction.PlatformTransactionManager;

import com.sgl.smartpra.batch.amadeus.app.common.AppConstants;
import com.sgl.smartpra.batch.amadeus.app.domain.ProdCouponModel;
import com.sgl.smartpra.batch.amadeus.app.domain.ProdTicketModel;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusBatchRecord;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusRecordStaging;
import com.sgl.smartpra.batch.amadeus.app.listener.ProdJobsNotificationListener;
import com.sgl.smartpra.batch.amadeus.app.listener.StgJobNotificationListener;
import com.sgl.smartpra.batch.amadeus.app.repository.AmadeusRecordStagingRepository;

@Configuration
@EnableBatchProcessing
public class AmadeusBatchConfiguration {

	private static final Logger LOGGER = LoggerFactory.getLogger(AmadeusBatchConfiguration.class);
	@Autowired
	public JobBuilderFactory jobBuilderFactory;

	@Autowired
	public StepBuilderFactory stepBuilderFactory;

	@Autowired
	EntityManagerFactory emf;

	@Value("${batch.directory.amadeus.input}")
	private String batchInputDir;

	@Autowired
	private AmadeusRecordStagingRepository amadeusRecordStagingRepository;

	@Autowired
	private PlatformTransactionManager transactionManager;

	@Bean
	public TaskExecutor taskExecutor() {
		SimpleAsyncTaskExecutor taskExecutor = new SimpleAsyncTaskExecutor();
		taskExecutor.setConcurrencyLimit(10);
		return taskExecutor;
	}

	@Bean
	public Job importAmadeusStgJob(StgJobNotificationListener listener, Step importAmadeusStgData) 
			throws IOException {
		// @formatter:off
		return jobBuilderFactory
				.get("importAmadeusStgJob")
				.incrementer(new RunIdIncrementer())
				.listener(listener)
				.flow(importAmadeusStgData)
				.end()
				.build();
		// @formatter:on

	}

	@Bean
	public Job importAmadeusETLProdJob(ProdJobsNotificationListener listener, Step importAmadeusETLTicketData, 
			Step importAmadeusETLCouponData) throws IOException {
		// @formatter:off
		return jobBuilderFactory
				.get("importAmadeusETLProdJob")
				.incrementer(new RunIdIncrementer())
				.listener(listener)
				.flow(importAmadeusETLTicketData)
				.next(importAmadeusETLCouponData)
				.end()
				.build();
		// @formatter:on
	}

	@Bean
	public Job importAmadeusEMDProdJob(ProdJobsNotificationListener listener, Step importAmadeusEMDTicketData,
			Step importAmadeusEMDCouponData) throws IOException {
		// @formatter:off
		return jobBuilderFactory.get("importAmadeusEMDProdJob")
				.incrementer(new RunIdIncrementer())
				.listener(listener)
				.flow(importAmadeusEMDTicketData)
				.next(importAmadeusEMDCouponData)
				.end()
				.build();
		// @formatter:on
	}

	@SuppressWarnings("unchecked")
	@Bean
	@Scope
	public Step importAmadeusStgData() throws IOException {
		// @formatter:off
		return stepBuilderFactory
				.get("AmadeusStgRecord").<AmadeusBatchRecord, AmadeusBatchRecord>chunk(1)
				.reader(stagingCommonItemReader(null, null))
				.processor(
						(ItemProcessor<? super AmadeusBatchRecord, ? extends AmadeusBatchRecord>) stagingCommonProcessor())
				.writer((ItemWriter<? super AmadeusBatchRecord>) stagingCommonItemWriter(null, null))
				.faultTolerant()
				.skip(DataIntegrityViolationException.class)
                .noRetry(DataIntegrityViolationException.class)
                //.noRollback(DataIntegrityViolationException.class)
				.transactionManager(transactionManager)
				.taskExecutor(taskExecutor())
				.build();
		// @formatter:on
	}

	@SuppressWarnings("unchecked")
	@Bean
	@Scope
	public Step importAmadeusEMDCouponData() throws IOException {
		// @formatter:off
		return stepBuilderFactory.get("AmadeusEMDCouponRecord").<AmadeusBatchRecord, AmadeusBatchRecord>chunk(1)
				.reader((ItemReader<? extends AmadeusBatchRecord>) prodRepositoryItemReader(null))
				.processor(
						(ItemProcessor<? super AmadeusBatchRecord, ? extends AmadeusBatchRecord>) prodEMDCouponProcessor())

				.writer((ItemWriter<? super AmadeusBatchRecord>) couponRepositoryItemWriter())
				.transactionManager(transactionManager)
				//.taskExecutor(taskExecutor())
				.build();
		// @formatter:on

	}

	@SuppressWarnings("unchecked")
	@Bean
	@Scope
	public Step importAmadeusETLCouponData() throws IOException {
		// @formatter:off
		return stepBuilderFactory.get("AmadeusETLCouponRecord").<AmadeusBatchRecord, AmadeusBatchRecord>chunk(1)
				.reader((ItemReader<? extends AmadeusBatchRecord>) prodRepositoryItemReader(null))
				.processor(
						(ItemProcessor<? super AmadeusBatchRecord, ? extends AmadeusBatchRecord>) prodETLCouponProcessor())

				.writer((ItemWriter<? super AmadeusBatchRecord>) couponRepositoryItemWriter())
				.transactionManager(transactionManager)
				//.taskExecutor(taskExecutor())
				.build();
		// @formatter:on
	}

	@SuppressWarnings("unchecked")
	@Bean
	@Scope
	public Step importAmadeusETLTicketData() throws IOException {
		// @formatter:off
		return stepBuilderFactory.get("AmadeusEtlTicketRecord").<AmadeusBatchRecord, AmadeusBatchRecord>chunk(1)
				.reader((ItemReader<? extends AmadeusBatchRecord>) prodTicketRepositoryItemReader(null))
				.processor(
						(ItemProcessor<? super AmadeusBatchRecord, ? extends AmadeusBatchRecord>) prodETLTicketProcessor())

				.writer((ItemWriter<? super AmadeusBatchRecord>) ticketRepositoryItemWriter())
				.transactionManager(transactionManager)
				//.taskExecutor(taskExecutor())
				.build();
		// @formatter:on
	}
	
	@SuppressWarnings("unchecked")
	@Bean
	@Scope
	public Step importAmadeusEMDTicketData() throws IOException {
		// @formatter:off
		return stepBuilderFactory.get("AmadeusEmdTicketRecord").<AmadeusBatchRecord, AmadeusBatchRecord>chunk(1)
				.reader((ItemReader<? extends AmadeusBatchRecord>) prodTicketRepositoryItemReader(null))
				.processor(
						(ItemProcessor<? super AmadeusBatchRecord, ? extends AmadeusBatchRecord>) prodEMDTicketProcessor())

				.writer((ItemWriter<? super AmadeusBatchRecord>) ticketRepositoryItemWriter())
				.transactionManager(transactionManager)
				//.taskExecutor(taskExecutor())
				.build();
		// @formatter:on
	}
	
	
	

	@SuppressWarnings("resource")
	@Bean
	@StepScope
	public FlatFileItemReader<AmadeusBatchRecord> stagingCommonItemReader(
			@Value("#{jobParameters[inboundFileName]}") String fileName,
			@Value("#{jobParameters[amadeusVersion]}") String amadeusVersion) throws IOException {
		LOGGER.info("Build Amadeus Item Reader File Name : {}", fileName);
		FlatFileItemReader<AmadeusBatchRecord> reader = new FlatFileItemReader<AmadeusBatchRecord>();
		List<String> linesList = new ArrayList<String>();
		reader.setResource(new FileSystemResource(batchInputDir + "/" + fileName));
		//reader.setSaveState(false);
		LineTokenizer lineTokenizer = null;
		if (amadeusVersion.contains(AppConstants.EMD_Version_01_01)) {
			LOGGER.info("Config Using Tokenizer for EMD Version 1.01 Tokenzier");
			lineTokenizer = (new AmadeusRecordStaging()).emdV1_01Tokenizer();
		} else if (amadeusVersion.contains(AppConstants.ETL_Version_2_20)) {
			LOGGER.info("Config Using Tokenizer for ETL Version 2.20 Tokenzier");
			lineTokenizer = (new AmadeusRecordStaging()).lineTokenizer();
		} else if (amadeusVersion.contains(AppConstants.EMD_Version_01_03)) {
			LOGGER.info("Config Using Tokenizer for EMD Version 1.03 Tokenzier");
			lineTokenizer = (new AmadeusRecordStaging()).emdV1_03Tokenizer();
		} else if (amadeusVersion.contains(AppConstants.EMD_Version_01_00)) {
			LOGGER.info("Config Using Tokenizer for EMD Version 1.00 Tokenzier");
			lineTokenizer = (new AmadeusRecordStaging()).emdV1_00Tokenizer();
		} else {
			throw new BeanInitializationException("Unsupported File");
		}
		//reader.setLinesToSkip(1);
		reader.setLineMapper(amadeusLineMapper(lineTokenizer));
		//reader.setRecordSeparatorPolicy(new IgnoreBlankLinePolicy(linesList));
		return reader;
	}

	@Bean
	@StepScope
	public ItemReader<? extends AmadeusBatchRecord> prodTicketRepositoryItemReader(
			@Value("#{jobParameters[inboundFileId]}") Integer fileId) throws IOException {
		RepositoryItemReader<AmadeusRecordStaging> reader = new RepositoryItemReader<AmadeusRecordStaging>();
		ArrayList<Integer> arguments = new ArrayList<Integer>();
		arguments.add(fileId);
		reader.setRepository(amadeusRecordStagingRepository);
		reader.setMethodName("findByFileId");
		reader.setArguments(arguments);
		Map<String, Direction> map = new HashMap<String, Direction>();
		map.put("documentNumber", Direction.ASC);
		reader.setSort(map);
		return reader;
	}

	
	@Bean
	@StepScope
	public ItemReader<? extends AmadeusBatchRecord> prodRepositoryItemReader(
			@Value("#{jobParameters[inboundFileId]}") Integer fileId) throws IOException {
		RepositoryItemReader<AmadeusRecordStaging> reader = new RepositoryItemReader<AmadeusRecordStaging>();
		ArrayList<Integer> arguments = new ArrayList<Integer>();
		arguments.add(fileId);
		reader.setRepository(amadeusRecordStagingRepository);
		reader.setMethodName("findByFileIdAndStatus");
		reader.setArguments(arguments);
		Map<String, Direction> map = new HashMap<String, Direction>();
		map.put("documentNumber", Direction.ASC);
		reader.setSort(map);
		return reader;
	}
	@Bean
	@StepScope
	public ItemProcessor<? extends AmadeusBatchRecord, ? extends AmadeusBatchRecord> prodETLTicketProcessor() {
		return new ProdTicketModel().prodProcessor();
	}
	
	@Bean
	@StepScope
	public ItemProcessor<? extends AmadeusBatchRecord, ? extends AmadeusBatchRecord> prodEMDTicketProcessor() {
		return new ProdTicketModel().prodEmdTicketProcessor();
	}

	@Bean
	@StepScope
	public ItemProcessor<? extends AmadeusBatchRecord, ? extends AmadeusBatchRecord> prodETLCouponProcessor() {
		return new ProdCouponModel().prodETLCouponProcessor();
	}

	@Bean
	@StepScope
	public ItemProcessor<? extends AmadeusBatchRecord, ? extends AmadeusBatchRecord> prodEMDCouponProcessor() {
		return new ProdCouponModel().prodEMDCouponProcessor();
	}

	@Bean
	@StepScope
	ItemWriter<? super AmadeusBatchRecord> ticketRepositoryItemWriter() {
		return new ProdTicketModel().writer();
	}

	@Bean
	@StepScope
	ItemWriter<? super AmadeusBatchRecord> couponRepositoryItemWriter() {
		return new ProdCouponModel().prodETLCouponWriter();
	}

	public LineMapper<AmadeusBatchRecord> amadeusLineMapper(LineTokenizer lineTokenizer) {
		LOGGER.info("Build amadeusLineMapper");
		PatternMatchingCompositeLineMapper<AmadeusBatchRecord> mapper = new PatternMatchingCompositeLineMapper<>();

		Map<String, LineTokenizer> tokenizers = new HashMap<>();
		tokenizers.put("1*", lineTokenizer);
		tokenizers.put("2*", lineTokenizer);
		tokenizers.put("9*", lineTokenizer);
		mapper.setTokenizers(tokenizers);

		Map<String, FieldSetMapper<AmadeusBatchRecord>> mappers = new HashMap<>();
		mappers.put("1*", (new AmadeusRecordStaging()).fieldSetMapper());
		mappers.put("2*", (new AmadeusRecordStaging()).fieldSetMapper());
		mappers.put("9*", (new AmadeusRecordStaging()).fieldSetMapper());

		mapper.setFieldSetMappers(mappers);
		return mapper;
	}

	@SuppressWarnings("unused")
	@Bean
	@StepScope
	public ItemWriter<? super AmadeusBatchRecord> stagingCommonItemWriter(
			@Value("#{jobParameters[inboundFileName]}") String fileName,
			@Value("#{jobParameters[amadeusVersion]}") String amadeusVersion) throws IOException {
		LOGGER.info("Build Item Writer File Name : {}", fileName);
		if (amadeusVersion.contains(AppConstants.EMD_Version_01_01)) {
			LOGGER.info("Config EMD Writer: {}", amadeusVersion);
			return new AmadeusRecordStaging().amadeusEmdV1_01writer();
		} else if (amadeusVersion.contains(AppConstants.ETL_Version_2_20)) {
			LOGGER.info("Config ETL Writer: {}", amadeusVersion);
			return new AmadeusRecordStaging().amadeusEtlV2_20writer();
		} else if (amadeusVersion.contains(AppConstants.EMD_Version_01_03)) {
			LOGGER.info("Config ETL Writer: {}", amadeusVersion);
			return new AmadeusRecordStaging().amadeusEmdV1_03writer();
		} else if (amadeusVersion.contains(AppConstants.EMD_Version_01_00)) {
			LOGGER.info("Config ETL Writer: {}", amadeusVersion);
			return new AmadeusRecordStaging().amadeusEmdV1_00writer();
		}
		return null;
	}
	@Bean
	@StepScope
	public ItemProcessor<? extends AmadeusBatchRecord, ? extends AmadeusBatchRecord> stagingCommonProcessor() {
		return new AmadeusRecordStaging().processor();
	}
}
