import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UsermoduleRoutingModule } from './usermodule-routing.module';
import { UsermoduleComponent } from './usermodule.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { CoreDataModule } from 'src/app/core-data/core-data.module';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    CoreDataModule,
    UsermoduleRoutingModule
  ],
  declarations: [
    UsermoduleComponent
  ]
})
export class UsermoduleModule { }
