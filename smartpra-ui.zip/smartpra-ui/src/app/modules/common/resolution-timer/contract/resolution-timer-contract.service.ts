import {Injectable} from '@angular/core';
import {BehaviorSubject} from "rxjs";
import {ResolutionTimerModel} from "../model/resolution-timer.model";

@Injectable({
  providedIn: 'root'
})
export class ResolutionTimerContractService {

  /*Initialize the model to set the default as false*/
  resolutionTimerModel: ResolutionTimerModel;

  private messageSource = new BehaviorSubject(this.resolutionTimerModel);
  instance = this.messageSource.asObservable();

  constructor() {
  }

  changeMessage(model: ResolutionTimerModel) {
    this.messageSource.next(model)
  }

  getResolutionTimerModel() {
    return this.resolutionTimerModel;
  }

  setResolutionTimerModel(resolutionTimerModel: ResolutionTimerModel) {
    return this.resolutionTimerModel = resolutionTimerModel;
  }




}
