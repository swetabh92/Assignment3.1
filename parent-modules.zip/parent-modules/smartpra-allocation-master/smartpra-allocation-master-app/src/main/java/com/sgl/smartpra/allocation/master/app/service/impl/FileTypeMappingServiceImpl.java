package com.sgl.smartpra.allocation.master.app.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.sgl.smartpra.allocation.master.app.mapper.FileTypeMapper;
import com.sgl.smartpra.allocation.master.app.mapper.FileTypeMappingMapper;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.allocation.master.app.entity.FileTypeMappingEntity;
import com.sgl.smartpra.allocation.master.app.dao.repository.FileTypeMappingRepository;
import com.sgl.smartpra.allocation.master.app.dao.repository.FileTypeRepository;
import com.sgl.smartpra.allocation.master.app.dao.spec.FileTypeMappingSpecification;
import com.sgl.smartpra.allocation.master.app.service.FileTypeMappingService;
import com.sgl.smartpra.allocation.master.model.FileType;
import com.sgl.smartpra.allocation.master.model.FileTypeMapping;
import com.sgl.smartpra.exceptions.exception.RecordNotFoundException;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class FileTypeMappingServiceImpl implements FileTypeMappingService {

    @Autowired
    private FileTypeMapper fileTypeMapper;

    @Autowired
    private FileTypeMappingMapper fileTypeMappingMapper;

    @Autowired
    FileTypeMappingRepository fileTypeMappingRepository;

    @Autowired
    FileTypeRepository fileTypeRepository;

    @Override
    public List<FileTypeMapping> findAll() {

        List<FileTypeMapping> fileTypeMappingList = new ArrayList<>();
        Optional.ofNullable(fileTypeMappingRepository.findAll()).ifPresent(fileTypeMappingEntityList -> {
            fileTypeMappingEntityList.forEach(entity -> fileTypeMappingList.add(fileTypeMappingMapper.mapToModel(entity)));
        });
        return fileTypeMappingList;
    }

    @Override
    public FileTypeMapping findByFileTypeMappingId(Integer fileTypeMappingId) {
        FileTypeMappingEntity fileTypeMappingEntity = fileTypeMappingRepository.findById(fileTypeMappingId)
                .orElseThrow(() -> new RecordNotFoundException(String.valueOf(fileTypeMappingId)));
        return fileTypeMappingMapper.mapToModel(fileTypeMappingEntity);
    }

    @Override
    public FileTypeMapping findFileTypeMappingByFileTypeId(Integer fileTypeId, Integer moduleLovId) {

        FileTypeMappingEntity fileTypeMappingEntity = fileTypeMappingRepository
                .findOne(Specification.where(FileTypeMappingSpecification.fileTypeIdEquals(fileTypeId))
                        .and(FileTypeMappingSpecification.moduleIdEquals(moduleLovId))).orElseThrow(() -> new RecordNotFoundException(String.valueOf(fileTypeId)));
        return fileTypeMappingMapper.mapToModel(fileTypeMappingEntity);
    }

    @Override
    public List<FileType> getFileTypeByModuleId(Integer moduleLovId, String clientId) {

        List<FileTypeMappingEntity> fileTypeMappingEntity = fileTypeMappingRepository
                .findAll(Specification.where(FileTypeMappingSpecification.moduleIdEquals(moduleLovId)));
        List<Integer> fileTypeIds = new ArrayList<Integer>();

        fileTypeMappingEntity.forEach(entity -> fileTypeIds.add(entity.getFileTypeId()));

        List<FileType> fileTypeList = new ArrayList<>();

        if (CollectionUtils.isNotEmpty(fileTypeIds)) {

            fileTypeList = fileTypeMapper.mapToModel(fileTypeRepository.findByFileTypeId(fileTypeIds, clientId));
        }
        return fileTypeList;
    }

    @Override
    public List<FileType> findAllFileType() {
        List<FileType> fileTypeList = new ArrayList<>();
        Optional.of(fileTypeRepository.findAll()).ifPresent(fileTypeEntityList -> {
            fileTypeEntityList.forEach(entity -> fileTypeList.add(fileTypeMapper.mapToModel(entity)));
        });
        return fileTypeList;
    }

}
