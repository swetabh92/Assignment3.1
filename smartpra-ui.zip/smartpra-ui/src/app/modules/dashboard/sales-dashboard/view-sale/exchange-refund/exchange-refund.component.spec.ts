import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExchangeRefundComponent } from './exchange-refund.component';

describe('ExchangeRefundComponent', () => {
  let component: ExchangeRefundComponent;
  let fixture: ComponentFixture<ExchangeRefundComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExchangeRefundComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExchangeRefundComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
