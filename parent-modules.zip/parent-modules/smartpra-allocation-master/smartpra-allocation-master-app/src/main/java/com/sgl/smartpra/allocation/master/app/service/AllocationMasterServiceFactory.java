package com.sgl.smartpra.allocation.master.app.service;

import org.springframework.stereotype.Component;

@Component
public class AllocationMasterServiceFactory {

	/*@Autowired
	FlownAllocationServiceImpl flownAllocationService;

	@Autowired
	SalesAllocationServiceImpl salesAllocationService;

	@Autowired
	InterlineAllocationServiceImpl interlineAllocationService;

	public AllocationMasterService getAllocationMasterService(ModuleNameEnum moduleName) {
		AllocationMasterService allocationMasterService = null;
		if (moduleName.equals(ModuleNameEnum.FLOWN)) {
			allocationMasterService = flownAllocationService;
		} else if (moduleName.equals(ModuleNameEnum.SALES)) {
			allocationMasterService = salesAllocationService;
		} else if (moduleName.equals(ModuleNameEnum.INTERLINE)) {
			allocationMasterService = interlineAllocationService;
		}
		return allocationMasterService;

	}*/
}
