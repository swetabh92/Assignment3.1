import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AppfirsttimepasswordComponent } from './appfirsttimepassword.component';

describe('AppfirsttimepasswordComponent', () => {
  let component: AppfirsttimepasswordComponent;
  let fixture: ComponentFixture<AppfirsttimepasswordComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppfirsttimepasswordComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppfirsttimepasswordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
