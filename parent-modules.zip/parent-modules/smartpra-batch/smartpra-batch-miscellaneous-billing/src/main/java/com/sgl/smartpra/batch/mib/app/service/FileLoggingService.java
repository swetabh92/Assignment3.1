/**
 * 
 */
package com.sgl.smartpra.batch.mib.app.service;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.batch.global.model.FileErrorLog;
import com.sgl.smartpra.batch.global.model.FileLogging;
import com.sgl.smartpra.batch.mib.app.config.FeignConfiguration.BatchGlobalFeignClient;
import com.sgl.smartpra.batch.mib.app.config.FeignConfiguration.SmartpraExceptionTransIntgAppClient;
import com.sgl.smartpra.batch.mib.app.config.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingConstants;
import com.sgl.smartpra.batch.mib.app.utils.MiscBillingUtil;
import com.sgl.smartpra.common.util.FileLoggingConstants;
import com.sgl.smartpra.common.util.SmartpraFileUtility;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;

import lombok.extern.slf4j.Slf4j;

/**
 * @author kanprasa
 *
 */
@Service
@Slf4j
public class FileLoggingService {

	@Value("${batch.directory.misc-billing.output}")
	private String miscBillingBatchOutputDir;

	@Autowired
	private BatchGlobalFeignClient batchGlobalFeignClient;
	
	public FileLogging createFileLogging(String clientId, String hostCarrDesigCode, String carrierNumericCode, String jobName, 
			String fileName, String processedBy) {
		FileLogging fileLogging = MiscBillingUtil.initFileLogging();
		fileLogging.setClientId(hostCarrDesigCode);
		fileLogging.setInterfaceType(FileLoggingConstants.FILELOGGING_INTERFACE_OUTPUT);
		fileLogging.setFileName(fileName);
		fileLogging.setProcessedBy(processedBy);
		fileLogging.setFileType(FileLoggingConstants.FILELOGGING_FILETYPE_MISC_BILLING_OUT);
		fileLogging.setJobName(jobName);
		fileLogging.setFileSize(SmartpraFileUtility.getFileSize(miscBillingBatchOutputDir + fileName));
		return batchGlobalFeignClient.createFileLog(fileLogging);
	}
}
