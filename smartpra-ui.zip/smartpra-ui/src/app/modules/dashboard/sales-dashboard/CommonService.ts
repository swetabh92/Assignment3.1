import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import {HttpParams  } from '@angular/common/http';
import { MessageBoxService } from './MessageBoxService';
@Injectable({
  providedIn: 'root'
})
export class CommonService {
	constructor(private messageBoxService: MessageBoxService) { }
   handleError<T>(operation = 'operation', result?: T) {
    return (e: any): Observable<T> => {
      // this.messageBoxService.getErrorMessage('ERROR', e['error']['message'] ? e['error']['message'] : e['error']['errorMessageList'][0]);
      this.messageBoxService.getErrorMessage('ERROR', e['error']['message']);
      return of(result as T);
    };
  }
  
   log(error: any) {
    if (error.message) {
      // this.messageBoxService.getErrorMessage('ERROR', error.message ? ['error']['message'] : ['error']['errorMessageList'][0] );
      this.messageBoxService.getErrorMessage('ERROR', error.message  );
    }
  }
   SearchParams(Obj){
	let params = new HttpParams();
	Object.keys(Obj).forEach((key)=>{
		if(!this.isEmpty(Obj[key])){
			if(Obj[key] instanceof Date) Obj[key]= this.covertDate(Obj[key]);
			params = params.set(key,Obj[key])
		}
	}) 
	return params;
  }
   isEmpty(val){
	if((val =="" || val == null || val == undefined) && (typeof val != 'boolean') && (typeof val != 'number')) return true;
	else return false;
  }
   convertApiObj(Obj){
	  let tempObj={}
	  Object.keys(Obj).forEach((key)=>{
		  if(!this.isEmpty(Obj[key])){
			  if(Obj[key] instanceof Date) Obj[key]= this.covertDate(Obj[key]);		
			  else if(Obj[key] == 'false') Obj[key] = false;
			  else if(Obj[key] == 'true') Obj[key] = true;
			 tempObj[key] = Obj[key];
		  }
	  })
	  return tempObj;
   }
    covertDate(dt){
	   let date = new Date(dt);
	   let day:any = date.getDate();
	   day = day>9?day:"0"+day
	   let month:any = date.getMonth()+1;
	   month = month>9?month:"0"+month;
	   let year:any = date.getFullYear();
	   return year+"-"+month+"-"+day;
   }
}