package com.sgl.smartpra.batch.interline.writer;

import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;

import com.sgl.smartpra.interline.domain.entity.stg.form3.InterlineForm3CsvStg;
import com.sgl.smartpra.interline.domain.repository.stg.form3.InterlineForm3CsvStgRepository;

public class InterlineForm3CsvStgWriter implements ItemWriter<InterlineForm3CsvStg> {

	@Autowired
	InterlineForm3CsvStgRepository interlineForm3CsvStgRepository;
	
	@Override
	public void write(List<? extends InterlineForm3CsvStg> items) throws Exception {
		interlineForm3CsvStgRepository.saveAll(items);
	}

}
