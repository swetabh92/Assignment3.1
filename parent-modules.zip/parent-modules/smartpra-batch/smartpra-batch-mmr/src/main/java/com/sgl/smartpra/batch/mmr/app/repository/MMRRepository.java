package com.sgl.smartpra.batch.mmr.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.batch.mmr.app.domain.CurrencyRate;

@Repository
public interface MMRRepository extends JpaRepository<CurrencyRate, Integer> {

	
}
