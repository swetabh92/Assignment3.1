export enum MasterHotkeys {

    save   = 'alt+s',
    clear  = 'alt+c',
    cancel = 'alt+n',
}
