package com.sgl.smartpra.batch.interline.listener;

import java.util.List;

import org.springframework.batch.core.ItemWriteListener;

import com.sgl.smartpra.interline.domain.entity.stg.form3.InterlineForm3CsvStg;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class InterlineForm3CsvStgItemWriterListener implements ItemWriteListener<InterlineForm3CsvStg> {

	@Override
	public void beforeWrite(List<? extends InterlineForm3CsvStg> items) {
		log.info("ItemWriteListener - beforeWrite");
	}

	@Override
	public void afterWrite(List<? extends InterlineForm3CsvStg> items) {
		log.info("ItemWriteListener - afterWrite");
	}

	@Override
	public void onWriteError(Exception exception, List<? extends InterlineForm3CsvStg> items) {
		log.info("ItemWriteListener - onWriteError");
	}

}