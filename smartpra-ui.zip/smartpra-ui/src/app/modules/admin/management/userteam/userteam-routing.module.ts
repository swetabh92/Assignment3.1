import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserteamComponent } from './userteam.component';

const routes: Routes = [
  {path:'',component:UserteamComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserteamRoutingModule { }
