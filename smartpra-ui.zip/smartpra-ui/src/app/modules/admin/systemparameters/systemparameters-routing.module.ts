import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SystemparametersComponent } from './systemparameters.component';

const routes: Routes = [
  {path:'',component:SystemparametersComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SystemparametersRoutingModule { }
