export class Roleprofile {
    isActive: true;
    roleId: number;
    roleName: number;
      constructor() { }
    }
