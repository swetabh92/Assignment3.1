/**
 * 
 */
package com.sgl.smartpra.batch.mib.app.validator;

import java.util.function.Predicate;

import org.apache.commons.lang3.StringUtils;

import com.sgl.smartpra.global.master.model.ChargeCategory;
import com.sgl.smartpra.global.master.model.ChargeCode;

/**
 * @author kanprasa
 *
 */
public class MiscBillingPredicates {

    public static Predicate<Object> isEmptyObject(){
    	return (w) -> w == null || StringUtils.isBlank(String.valueOf(w));
    }
    
    public static Predicate<Object> isChargeCodeTypeRequired(){
    	return (cct) -> cct != null && ((ChargeCode) cct).getChargeCodeTypeRequiredIndicator().get().booleanValue();
    }
    
    public static Predicate<Object> isPoLineItemRequired(){
    	return (cct) -> cct != null && ((ChargeCode) cct).getPoLineItemRequiredIndicator().get().booleanValue();
    }
    
    public static Predicate<Object> isProductIdRequired(){
    	return (cct) -> cct != null && ((ChargeCode) cct).getProductIdRequiredIndicator().get().booleanValue();
    }
    
    public static Predicate<Object> isLocationCodeRequiredForChargeCode(){
    	return (cct) -> cct != null && ((ChargeCode) cct).getLocationCodeRequiredIndicator().get().booleanValue();
    }
    
    public static Predicate<Object> isLocationCodeRequired(){
    	return (cct) -> cct != null && ((ChargeCategory) cct).getLocationRequiredIndicator().get().booleanValue();
    }
    
    public static Predicate<Object> isPoNumberRequired(){
    	return (cct) -> cct != null && ((ChargeCategory) cct).getPoNumberRequiredIndicator().get().booleanValue();
    }
}
