package com.sgl.smartpra.batch.amadeus.app.processor;

import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.sgl.smartpra.batch.amadeus.app.common.AppConstants;
import com.sgl.smartpra.batch.amadeus.app.config.FeignConfiguration.CarrierMasterFeignClient;
import com.sgl.smartpra.batch.amadeus.app.config.FeignConfiguration.ExceptionTxnFeignClient;
import com.sgl.smartpra.batch.amadeus.app.config.FeignConfiguration.FlownFeignClient;
import com.sgl.smartpra.batch.amadeus.app.config.FeignConfiguration.MasterFeignClient;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusNewTaxStaging;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusRecordDetailStaging;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusRecordStaging;
import com.sgl.smartpra.batch.amadeus.app.domain.ProdTicketModel;
import com.sgl.smartpra.batch.amadeus.app.repository.AmadeusRecordStagingRepository;
import com.sgl.smartpra.batch.amadeus.app.utils.AmadeusCommonUtils;
import com.sgl.smartpra.common.model.ValidatorResponse;
import com.sgl.smartpra.common.util.ExceptionCodeConstants;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.common.util.SmartPRACommonUtil;
import com.sgl.smartpra.common.validator.EntityValidator;
import com.sgl.smartpra.exception.txn.model.ExceptionParametersValueModel;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.global.master.model.Carrier;
import com.sgl.smartpra.master.model.AgencyMaster;
import com.sgl.smartpra.master.model.BookingClassModel;
import com.sgl.smartpra.master.model.FormCode;
import com.sgl.smartpra.sales.domain.TicketCoupon;
import com.sgl.smartpra.sales.domain.TicketMain;
import com.sgl.smartpra.sales.domain.TicketTax;
import com.sgl.smartpra.sales.repository.TicketMainRepository;

@SuppressWarnings("serial")
public class ProdEMDTicketProcessor extends AmadeusProcessor
		implements ItemProcessor<AmadeusRecordStaging, ProdTicketModel> {

	private static final Logger LOGGER = LoggerFactory.getLogger(ProdEMDTicketProcessor.class);

	@Autowired
	MasterFeignClient masterFeignClient;

	@Autowired
	FlownFeignClient flownFeignClient;

	@Autowired
	private TicketMainRepository ticketMainRepository;

	@Autowired
	private AmadeusRecordStagingRepository amadeusRecordStagingRepository;

	@Autowired
	private ExceptionTxnFeignClient exceptionTxnFeignClient;

	@Autowired
	CarrierMasterFeignClient carrierMasterFeignClient;

	@Value("#{jobParameters['careerDesignatorCode']}")
	public String hostCarrDesigCode;

	@Value("#{jobParameters['carrieNumericCode']}")
	public Integer hostCarrNumericCode;

	@Value("#{jobParameters['flightNoLen']}")
	public String sysParamFlightLen;

	@Value("#{stepExecution}")
	private StepExecution stepExecution;

	private Integer errorCount;

	private Integer transferredCount;

	private List<ValidatorResponse> failedPropertyList;

	private EntityValidator entityValidator;

	@Override
	public ProdTicketModel process(AmadeusRecordStaging amadeusRecordStaging) throws Exception {

		JobExecution jobExecution = this.stepExecution.getJobExecution();
		ExecutionContext jobExecutionContext = jobExecution.getExecutionContext();

		LOGGER.info("ProdEMDTicketProcessor.process -- Start");
		Class<?> classVar = Class.forName("com.sgl.smartpra.batch.amadeus.app.domain.AmadeusRecordStaging");
		Method method;
		String errMsg;
		String[] errMsgArr;
		ExceptionTransactionModel exceptionTransactionModel;
		List<ExceptionParametersValueModel> parametersValueModelList;
		ExceptionParametersValueModel paramValueModel;
		ProdTicketModel prodTicketModel = new ProdTicketModel();
		DateTimeFormatter dtFormatter = DateTimeFormatter.ofPattern("ddMMyy");

		SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
		SimpleDateFormat format1 = new SimpleDateFormat("ddMMMyy");
		String reportingAgency = null;
		String agencyType = null;
		String areaOfOperation = null;
		String reportingAgencyType = null;
		String carrierCode = null;
		String carrierName1 = null;
		String carrierName2 = null;
		List<FormCode> formcodeList = null;
		List<AgencyMaster> agencyMasterList = null;
		List<AgencyMaster> agencyMasterListForOriginalissue = null;
		List<Carrier> carrierMasterList = null;
		List<TicketMain> ticketMainList = new ArrayList<TicketMain>();
		// Unique columns for all ticket / coupon tables
		String issueAirline = amadeusRecordStaging.getIssAirline();
		String mainDocumentNo = amadeusRecordStaging.getDocumentNumber();
		String documentNumberstr = amadeusRecordStaging.getDocumentNumber();
		String documentUniqueidString = null;
		String documentUniqueid = null;
		String updatedDocNumber = null;
		String originalDocumentUniqueid = null;
		Date originalIssueDate = null;
		String numberOfCoupon = null;
		TicketMain ticketMain = null;
		documentUniqueid = hostCarrDesigCode + issueAirline + documentNumberstr
				+ amadeusRecordStaging.getIssueDate().substring(2);

		try {

			int i = 0;
			int j = 0;
			int sector = 0;
			Integer count = (Integer) jobExecutionContext.get("errorCount");

			if (count != null) {
				errorCount = count;
			} else {
				jobExecutionContext.put("errorCount", 0);
				errorCount = 0;
			}

			count = (Integer) jobExecutionContext.get("transferredCount");
			LOGGER.info("Transfered Count --->" + jobExecutionContext.get("transferredCount"));

			if (count != null) {
				transferredCount = count;
			} else {
				LOGGER.info("Transfered Count status--->" + jobExecutionContext.get("transferredCount"));
				jobExecutionContext.put("transferredCount", 0);
				transferredCount = 0;
			}

			// Duplicate record check
			Optional<TicketMain> ticketMainOpt = ticketMainRepository.findByDocumentUniqueId(documentUniqueid);
			if (ticketMainOpt.isPresent()) {
				LOGGER.debug("DocumentUniqueId " + documentUniqueid
						+ " already exists in ticketMain table or multiple flown coupon's found in the current file");
				amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_ERROR);
				amadeusRecordStagingRepository.saveAndFlush(amadeusRecordStaging);
				return null;
			} else {
				// Reference data check - start
				// 1. formCodeList

				formcodeList = masterFeignClient.getAllFormCode(
						amadeusRecordStaging.getDocumentNumber().substring(0, 3), null, numberOfCoupon, null, null);

				if (formcodeList.isEmpty()) {
					LOGGER.info("Error Count in formcode  master list---------->" + errorCount);
					errorCount++;
					jobExecutionContext.put("errorCount", errorCount);
					LOGGER.info("Error Count after in formcode master list----------->"
							+ jobExecution.getExecutionContext().get("errorCount"));

					// Exception logic - start
					exceptionTransactionModel = AmadeusCommonUtils.initExceptionTransactionModel(amadeusRecordStaging,
							documentUniqueid);
					exceptionTransactionModel.setClientId(hostCarrDesigCode);
					exceptionTransactionModel.setExceptionCode(ExceptionCodeConstants.ERRORCODE_DOCTYPE);
					// exceptionTransactionModel.setResolutionRemarks("Form code details need to be
					// added in formcode master");
					/*
					 * exceptionTransactionModel.
					 * setExceptionDetails("Formcode details not found for formCode : " +
					 * amadeusRecordStaging.getDocumentNumber().substring(0, 3));
					 */
					parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();

					paramValueModel = new ExceptionParametersValueModel();
					paramValueModel.setParameterName("Document No.");
					paramValueModel.setParameterValue(amadeusRecordStaging.getDocumentNumber());
					parametersValueModelList.add(paramValueModel);

					paramValueModel = new ExceptionParametersValueModel();
					paramValueModel.setParameterName("Carrier Numeric Code");
					paramValueModel.setParameterValue(issueAirline);
					parametersValueModelList.add(paramValueModel);

					paramValueModel = new ExceptionParametersValueModel();
					paramValueModel.setParameterName("Doc Type");
					paramValueModel.setParameterValue(amadeusRecordStaging.getDocumentNumber().substring(0, 3));
					parametersValueModelList.add(paramValueModel);

					exceptionTransactionModel.setParametersValueList(parametersValueModelList);

					exceptionTxnFeignClient.initExceptionTrasaction(exceptionTransactionModel);
					// Exception logic - end
					amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_ERROR);
					amadeusRecordStagingRepository.saveAndFlush(amadeusRecordStaging);
					return null;
				}

				// 2. agencyMasterList
				agencyMasterList = masterFeignClient.getAllAgency(amadeusRecordStaging.getAgencyNumber(),
						reportingAgency, agencyType, areaOfOperation, reportingAgencyType, null);

				// 3. flightKeyList - Require for Flown Coupon (ProdETLCouponProcessor) \
				String derivedFlightNo = SmartPRACommonUtil
						.deriveFlightNo(amadeusRecordStaging.getUsageOperatingFlightNumber(), sysParamFlightLen);

				/*
				 * flightDataDetails = flownFeignClient.getFlightDataDetails(derivedFlightNo,
				 * amadeusRecordStaging.getUsageOriginCodeEmd(),
				 * amadeusRecordStaging.getUsageDestinationCodeEmd(), localDate, null);
				 */
				/*
				 * if (flightKeyList == null || flightKeyList.size() == 0) { errorCount++;
				 * jobExecutionContext.put("errorCount", errorCount);
				 * LOGGER.info("flightKeyList is empty....");
				 * LOGGER.info("Actual Operating flight number" +
				 * amadeusRecordStaging.getUsageOperatingFlightNumber());
				 * LOGGER.info("Derived Operating flight number" + derivedFlightNo); //
				 * Exception logic - start exceptionTransactionModel =
				 * AmadeusCommonUtils.initExceptionTransactionModel(amadeusRecordStaging,
				 * documentUniqueid); exceptionTransactionModel.setClientId(hostCarrDesigCode);
				 * exceptionTransactionModel.setExceptionCode(ExceptionCodeConstants.
				 * ERRORCODE_FLIGHTKEYNOTFOUND); exceptionTransactionModel.
				 * setResolutionRemarks("Flight data details need to be updated..");
				 * exceptionTransactionModel.
				 * setExceptionDetails("Flight data details not found for flight number : " +
				 * derivedFlightNo + ", usage orgincode: " +
				 * amadeusRecordStaging.getUsageOriginCodeEmd() + ", usage desgination code: " +
				 * amadeusRecordStaging.getUsageOriginCodeEmd()); parametersValueModelList = new
				 * ArrayList<ExceptionParametersValueModel>();
				 * 
				 * paramValueModel = new ExceptionParametersValueModel();
				 * paramValueModel.setParameterName("Document No");
				 * paramValueModel.setParameterValue(amadeusRecordStaging.getDocumentNumber());
				 * parametersValueModelList.add(paramValueModel);
				 * 
				 * paramValueModel = new ExceptionParametersValueModel();
				 * paramValueModel.setParameterName("Coupon No.");
				 * paramValueModel.setParameterValue("");
				 * parametersValueModelList.add(paramValueModel);
				 * 
				 * paramValueModel = new ExceptionParametersValueModel();
				 * paramValueModel.setParameterName("Line No.");
				 * paramValueModel.setParameterValue(derivedFlightNo);
				 * parametersValueModelList.add(paramValueModel);
				 * 
				 * exceptionTransactionModel.setParametersValueList(parametersValueModelList);
				 * 
				 * exceptionTxnFeignClient.initExceptionTrasaction(exceptionTransactionModel) ;
				 * // Exception logic - end
				 * 
				 * amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_ERROR);
				 * amadeusRecordStagingRepository.saveAndFlush(amadeusRecordStaging); return
				 * null; }
				 */
				// 4. Booking class master check - Require for Flown Coupon
				// (ProdETLCouponProcessor)
				List<BookingClassModel> bookingClassModelList = masterFeignClient
						.getListOfBookingClassByUtilizationEffectiveDate(null, amadeusRecordStaging.getSellingClass(),
								null, null, null, null, null);
				if (bookingClassModelList.isEmpty()) {
					LOGGER.info("Error Count before---------->" + errorCount);
					errorCount++;
					jobExecutionContext.put("errorCount", errorCount);
					LOGGER.info("Error Count after----------->" + jobExecution.getExecutionContext().get("errorCount"));
					// Exception logic - start
					exceptionTransactionModel = AmadeusCommonUtils.initExceptionTransactionModel(amadeusRecordStaging,
							documentUniqueid);
					exceptionTransactionModel.setClientId(hostCarrDesigCode);
					exceptionTransactionModel.setExceptionCode(ExceptionCodeConstants.ERRORCODE_DOCCLASS);
					/*
					 * exceptionTransactionModel
					 * .setResolutionRemarks("Cabin details need to be added in Booking Class Master"
					 * ); exceptionTransactionModel.setExceptionDetails(
					 * "BookingClass details not found for rbd : " +
					 * amadeusRecordStaging.getSellingClass());
					 */
					if (amadeusRecordStaging.getCouponNumber() != null)
						exceptionTransactionModel
								.setCouponNumber(Integer.parseInt(amadeusRecordStaging.getCouponNumber()));
					parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();

					paramValueModel = new ExceptionParametersValueModel();
					paramValueModel.setParameterName("Document No.");
					paramValueModel.setParameterValue(amadeusRecordStaging.getDocumentNumber());
					parametersValueModelList.add(paramValueModel);

					paramValueModel = new ExceptionParametersValueModel();
					paramValueModel.setParameterName("Carrier Numeric Code");
					paramValueModel.setParameterValue(issueAirline);
					parametersValueModelList.add(paramValueModel);

					paramValueModel = new ExceptionParametersValueModel();
					paramValueModel.setParameterName("Doc Class");
					paramValueModel.setParameterValue(amadeusRecordStaging.getSellingClass());
					parametersValueModelList.add(paramValueModel);

					exceptionTransactionModel.setParametersValueList(parametersValueModelList);

					exceptionTxnFeignClient.initExceptionTrasaction(exceptionTransactionModel);
					// Exception logic - end
					amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_ERROR);
					amadeusRecordStagingRepository.saveAndFlush(amadeusRecordStaging);
					return null;
				}

				// Reference data check - end

				// Data type validation login - begin
				/*
				 * failedPropertyList = new ArrayList<ValidatorResponse>(); entityValidator =
				 * new EntityValidator(); failedPropertyList =
				 * entityValidator.validateEntity(amadeusRecordStaging); if
				 * (!failedPropertyList.isEmpty()) {
				 * prodTicketModel.getTicketMain().get(0).setStatus(AppConstants.
				 * STATUS_PRODUCTION_ERROR); for (ValidatorResponse validatorResponse :
				 * failedPropertyList) { errMsg = validatorResponse.getFieldErrorMessage(); if
				 * (errMsg != null && errMsg.length() > 0) { errMsgArr = errMsg.split("#"); if
				 * (errMsgArr.length > 1) { // Exception logic - start exceptionTransactionModel
				 * = AmadeusCommonUtils .initExceptionTransactionModel(amadeusRecordStaging,
				 * documentUniqueid); exceptionTransactionModel.setClientId(hostCarrDesigCode);
				 * exceptionTransactionModel
				 * .setExceptionCode(ExceptionCodeConstants.ERRORCODE_INCORRECTDATA);
				 * exceptionTransactionModel.setResolutionRemarks(
				 * "Data error need to be corrected in the production tables..");
				 * exceptionTransactionModel.
				 * setExceptionDetails("errMsgArr[0] [DocumentuniqueID : " + documentUniqueid +
				 * ", Invalid Field : " + errMsgArr[0] + "]");
				 * 
				 * parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();
				 * paramValueModel = new ExceptionParametersValueModel();
				 * paramValueModel.setParameterName("Check Digit");
				 * paramValueModel.setParameterValue("0");
				 * parametersValueModelList.add(paramValueModel);
				 * 
				 * paramValueModel = new ExceptionParametersValueModel();
				 * paramValueModel.setParameterName("Line No.");
				 * paramValueModel.setParameterValue(errMsgArr[0]);
				 * parametersValueModelList.add(paramValueModel);
				 * 
				 * paramValueModel = new ExceptionParametersValueModel();
				 * paramValueModel.setParameterName("Start Position");
				 * paramValueModel.setParameterValue("0");
				 * parametersValueModelList.add(paramValueModel);
				 * 
				 * paramValueModel = new ExceptionParametersValueModel();
				 * paramValueModel.setParameterName("End Position");
				 * paramValueModel.setParameterValue("0");
				 * parametersValueModelList.add(paramValueModel);
				 * 
				 * exceptionTransactionModel.setParametersValueList(parametersValueModelList);
				 * exceptionTxnFeignClient.initExceptionTrasaction(exceptionTransactionModel) ;
				 * // Exception logic - end
				 * 
				 * method = classVar.getDeclaredMethod(errMsgArr[0], String.class); if
				 * (errMsgArr[1].equalsIgnoreCase("SYSDATE")) {
				 * method.invoke(amadeusRecordStaging, LocalDateTime.now().toString()); } else
				 * if (errMsgArr[1].equalsIgnoreCase("EMPTY")) {
				 * method.invoke(amadeusRecordStaging, ""); } else {
				 * method.invoke(amadeusRecordStaging, errMsgArr[1]); } }
				 * 
				 * } } }
				 */
				// Data type validation login - end

				ticketMain = new TicketMain();

				// Original document unique id
				String OriginalIssueAirline = null;
				String originalDocumentNumber = null;
				SimpleDateFormat formatter = new SimpleDateFormat("dd/MMM/yyyy");

				ticketMain.setIssueAirline(amadeusRecordStaging.getIssAirline());
				ticketMain.setDocumentNumber(amadeusRecordStaging.getDocumentNumber());
				ticketMain.setEmdIndicator(AppConstants.EMD_INDICATOR);

				LOGGER.info("Reported Fare   :{}", amadeusRecordStaging.getReportedFare());
				if (amadeusRecordStaging.getReportedFare().equals(AppConstants.REPORTED_FARE_BL)) {
					ticketMain.setGrossFare(new BigDecimal(0));
				} else if (amadeusRecordStaging.getReportedFare().equals(AppConstants.REPORTED_FARE_BT)) {
					ticketMain.setGrossFare(new BigDecimal(0));
				} else if (amadeusRecordStaging.getReportedFare().equals(AppConstants.REPORTED_FARE_IT)) {
					ticketMain.setGrossFare(new BigDecimal(0));
				} else {
					ticketMain.setGrossFare(new BigDecimal(amadeusRecordStaging.getReportedFare()));
				}
				ticketMain.setCurrencyOfSale(amadeusRecordStaging.getCurrencyOfReportedFare());
				ticketMain.setTicketingModeIndicator(amadeusRecordStaging.getTicketingModeIndicator());
				ticketMain.setIsValidated(AppConstants.IS_VALIDATED);
				ticketMain.setFareCalcModeIndicator(amadeusRecordStaging.getFareCalcModeIndicator());
				if (amadeusRecordStaging.getEquivalentFare().matches("\\d*\\.?\\d+")) {
					ticketMain.setEquivalentFare(new BigDecimal(amadeusRecordStaging.getEquivalentFare()));
				} else if (amadeusRecordStaging.getEquivalentFare() == null
						|| amadeusRecordStaging.getEquivalentFare().length() == 0) {
					amadeusRecordStaging.setEquivalentFare("0");
				} else {
					amadeusRecordStaging.setEquivalentFare("0");
				}
				ticketMain.setEquivalentCurrencyOfSale(amadeusRecordStaging.getPaymentCurrency());
				if (agencyMasterList.isEmpty()) {
					LOGGER.info("Agency is not available in Agency Master");
					AgencyMaster agencyMaster = new AgencyMaster();
					agencyMaster.setAgencyCode(Optional.of(amadeusRecordStaging.getAgencyNumber()));
					agencyMaster.setClientId(Optional.of(hostCarrDesigCode));
					agencyMaster.setAreaOfOperation(Optional.of(amadeusRecordStaging.getIssuingOfficeLocation()));
					agencyMaster.setReportingAgency(Optional.of(AppConstants.REPORTING_TYPE_AGENCY));
					agencyMaster.setReportingAgencyType(Optional.of(AppConstants.REPORTING_TYPE_AGENCY_TYPE));
					agencyMaster.setCityCode(Optional.of(amadeusRecordStaging.getIssuingOfficeLocation()));
					agencyMaster.setCreatedBy(Optional.of(amadeusRecordStaging.getCreatedBy()));

					AgencyMaster agencyMasterCreate = masterFeignClient.createAgencyMaster(agencyMaster);
					LOGGER.info("Agency Creation Details " + agencyMasterCreate.toString());
					if (agencyMasterCreate != null) {
						LOGGER.info("Agency is Created in Agency Master :{}");
						ticketMain.setReportingAgentCode(agencyMasterCreate.getReportingAgency().get());
						ticketMain.setPlaceOfIssue(agencyMasterCreate.getCityCode().get());
						ticketMain.setPlaceOfSale(agencyMasterCreate.getCityCode().get());
						LOGGER.info("Reporting Agency type" + ticketMain.getReportingAgentCode());
					}

					/*
					 * LOGGER.info("Error Count in agency master list---------->" + errorCount);
					 * errorCount++; jobExecutionContext.put("errorCount", errorCount);
					 * LOGGER.info("Error Count after in agency master list----------->" +
					 * jobExecution.getExecutionContext().get("errorCount"));
					 * amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_ERROR);
					 * amadeusRecordStagingRepository.saveAndFlush(amadeusRecordStaging); //
					 * Exception logic - start exceptionTransactionModel =
					 * AmadeusCommonUtils.initExceptionTransactionModel(amadeusRecordStaging,
					 * documentUniqueid); exceptionTransactionModel.setClientId(hostCarrDesigCode);
					 * exceptionTransactionModel.setExceptionCode(ExceptionCodeConstants.
					 * ERRORCODE_AGENCYMASTER); exceptionTransactionModel.
					 * setResolutionRemarks("Agency details need to be added in agency master");
					 * exceptionTransactionModel.setExceptionDetails(
					 * "Agench details not found for agency number : " +
					 * amadeusRecordStaging.getAgencyNumber()); parametersValueModelList = new
					 * ArrayList<ExceptionParametersValueModel>();
					 * 
					 * paramValueModel = new ExceptionParametersValueModel();
					 * paramValueModel.setParameterName("Agency Code");
					 * paramValueModel.setParameterValue(amadeusRecordStaging.getAgencyNumber());
					 * parametersValueModelList.add(paramValueModel);
					 * 
					 * paramValueModel = new ExceptionParametersValueModel();
					 * paramValueModel.setParameterName("Effective Date");
					 * paramValueModel.setParameterValue(LocalDateTime.now().toString());
					 * parametersValueModelList.add(paramValueModel);
					 * 
					 * exceptionTransactionModel.setParametersValueList(parametersValueModelList);
					 * 
					 * exceptionTxnFeignClient.initExceptionTrasaction(exceptionTransactionModel);
					 * // Exception logic - end
					 * amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_ERROR);
					 * amadeusRecordStagingRepository.saveAndFlush(amadeusRecordStaging); return
					 * null;
					 */
				}
				if (amadeusRecordStaging.getIssueDate() != null && !amadeusRecordStaging.getIssueDate().isEmpty()) {
					LOGGER.info("Issue Date   :{}", amadeusRecordStaging.getIssueDate());
					ticketMain.setDateOfIssue(format.parse(amadeusRecordStaging.getIssueDate()));
					System.out.println("issue date" + ticketMain.getDateOfIssue());
				}
				if (amadeusRecordStaging.getBookingReference() != null
						&& !amadeusRecordStaging.getIssueDate().isEmpty()) {
					ticketMain.setPnr(amadeusRecordStaging.getBookingReference());
				}
				LOGGER.info("TourCode :{}" + amadeusRecordStaging.getTourCode());
				if (amadeusRecordStaging.getTourCode() != null && !amadeusRecordStaging.getTourCode().isEmpty()) {
					ticketMain.setTourCode(amadeusRecordStaging.getTourCode());
				}
				ticketMain.setFca(amadeusRecordStaging.getFareConstruction());
				ticketMain.setPassengerName(amadeusRecordStaging.getPassengerName());
				ticketMain.setNetRemitIndicator(amadeusRecordStaging.getNetReportingIndicator());
				ticketMain.setCreatedBy(amadeusRecordStaging.getCreatedBy());
				ticketMain.setCreatedDate(new Timestamp(new Date().getTime()));
				ticketMain.setClientId(hostCarrDesigCode);
				ticketMain.setFileId(amadeusRecordStaging.getFileId());
				ticketMain.setFfyIndicator(AppConstants.FF_INDICATOR_DEFAULT);
				ticketMain.setCodeShareIndicator(AppConstants.CODE_SHARE_INDICATOR_DEFAULT);
				ticketMain.setReportedDate(new Timestamp(new Date().getTime()));
				ticketMain.setFirstTimeProcessed(AppConstants.FIRST_TIME_PROCESSED_DEFAULT);
				ticketMain.setRevenueFlag(AppConstants.REVENUE_FLAG_DEFAULT);
				ticketMain.setProrationMethod(AppConstants.PRORATION_METHOD_DEFAULT);
				if (formcodeList != null && !formcodeList.isEmpty()) {
					ticketMain.setDocType(OptionalUtil.getValue(formcodeList.get(0).getDocumentType()));
				}
				if (formcodeList.get(0).getNumberOfCoupon().get() != "0") {
					ticketMain.setDocClass(formcodeList.get(0).getDocumentType().get().substring(0, 2)
							+ formcodeList.get(0).getNumberOfCoupon().get());
				} else {
					ticketMain.setDocClass(formcodeList.get(0).getDocumentType().get().substring(0, 2));
				}

				if (agencyMasterList != null && !agencyMasterList.isEmpty()) {
					LOGGER.info("Agency is Available in Agency Master :{}");
					ticketMain.setReportingAgentCode(agencyMasterList.get(0).getReportingAgency().get());
					ticketMain.setPlaceOfIssue(amadeusRecordStaging.getIssuingOfficeLocation());
					ticketMain.setPlaceOfSale(amadeusRecordStaging.getIssuingOfficeLocation());
				}

				ticketMain.setMainDocument(mainDocumentNo);

				LOGGER.info("Document Number Derived from Original Issue Information   :{}",
						amadeusRecordStaging.getOriginalIssueInformation());
				if (amadeusRecordStaging.getOriginalIssueInformation() != null
						&& !amadeusRecordStaging.getOriginalIssueInformation().isEmpty()) {
					String originalIssueInformation = amadeusRecordStaging.getOriginalIssueInformation()
							.replaceAll("\\s+", "");
					if (originalIssueInformation.length() == 31 || originalIssueInformation.length() == 30) {
						LOGGER.info("Original Issue Information having length 30 / 31 :{}");
						OriginalIssueAirline = originalIssueInformation.substring(0, 3);
						originalDocumentNumber = originalIssueInformation.substring(3, 13);
						ticketMain.setOriginalIssueAirline(OriginalIssueAirline);
						ticketMain.setOriginalDocumentNumber(originalDocumentNumber);
						ticketMain.setOriginalPlaceOfIssue(originalIssueInformation.substring(13, 16));
						ticketMain.setOriginalDateOfIssue(format1.parse(originalIssueInformation.substring(16, 23)));
						ticketMain.setOriginalAgentCode(originalIssueInformation.substring(23, 30));
						originalIssueDate = format1.parse(originalIssueInformation.substring(16, 23));
						originalDocumentUniqueid = hostCarrDesigCode + OriginalIssueAirline + originalDocumentNumber
								+ originalIssueInformation.substring(16, 23);
						ticketMain.setOriginalDocumentUniqueId(originalDocumentUniqueid);
						LOGGER.info("original Document Id" + originalDocumentUniqueid);

					} else if (originalIssueInformation.length() == 28) {

						// agencyMasterList for originalIssueInformation
						agencyMasterListForOriginalissue = masterFeignClient.getAllAgency(
								originalIssueInformation.substring(20, 27), reportingAgency, agencyType,
								areaOfOperation, reportingAgencyType, null);

						if (agencyMasterListForOriginalissue.isEmpty()) {
							LOGGER.info("Error Count in agency master list---------->" + errorCount);
							errorCount++;
							jobExecutionContext.put("errorCount", errorCount);
							LOGGER.info(
									"Error Count after in agency master list for original issuer information----------->"
											+ jobExecution.getExecutionContext().get("errorCount"));
							amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_ERROR);
							amadeusRecordStagingRepository.saveAndFlush(amadeusRecordStaging);
							// Exception logic - start
							exceptionTransactionModel = AmadeusCommonUtils
									.initExceptionTransactionModel(amadeusRecordStaging, documentUniqueid);
							exceptionTransactionModel.setClientId(hostCarrDesigCode);
							exceptionTransactionModel.setExceptionCode(ExceptionCodeConstants.ERRORCODE_AGENCYMASTER);
							/*
							 * exceptionTransactionModel.
							 * setResolutionRemarks("Agency details need to be added in agency master");
							 * exceptionTransactionModel.setExceptionDetails(
							 * "Agench details not found for agency number : " +
							 * amadeusRecordStaging.getAgencyNumber());
							 */
							parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();

							paramValueModel = new ExceptionParametersValueModel();
							paramValueModel.setParameterName("Agency Code");
							paramValueModel.setParameterValue(amadeusRecordStaging.getAgencyNumber());
							parametersValueModelList.add(paramValueModel);

							paramValueModel = new ExceptionParametersValueModel();
							paramValueModel.setParameterName("Effective Date");
							paramValueModel.setParameterValue(LocalDateTime.now().toString());
							parametersValueModelList.add(paramValueModel);

							exceptionTransactionModel.setParametersValueList(parametersValueModelList);

							exceptionTxnFeignClient.initExceptionTrasaction(exceptionTransactionModel);
							// Exception logic - end
							amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_ERROR);
							amadeusRecordStagingRepository.saveAndFlush(amadeusRecordStaging);
							return null;
						}

						LOGGER.info("Original Issue Information having length 28 :{}");
						OriginalIssueAirline = originalIssueInformation.substring(0, 3);
						originalDocumentNumber = originalIssueInformation.substring(3, 13);
						originalIssueDate = format1.parse(originalIssueInformation.substring(13, 20));
						ticketMain.setOriginalIssueAirline(OriginalIssueAirline);
						ticketMain.setOriginalDocumentNumber(originalDocumentNumber);
						ticketMain.setOriginalPlaceOfIssue(agencyMasterListForOriginalissue.get(0).getCityCode().get());
						ticketMain.setOriginalDateOfIssue(originalIssueDate);
						LOGGER.info("Original Agent Code to derive original place of issue from  Agency Master -->"
								+ originalIssueInformation.substring(20, 27));
						ticketMain.setOriginalAgentCode(originalIssueInformation.substring(20, 27));
						originalDocumentUniqueid = hostCarrDesigCode + OriginalIssueAirline + originalDocumentNumber
								+ originalIssueInformation.substring(13, 20);
						ticketMain.setOriginalDocumentUniqueId(originalDocumentUniqueid);
						LOGGER.info("original Document Id" + originalDocumentUniqueid);
					} else if (originalIssueInformation.length() == 22 && originalIssueInformation.contains("XX")) {

						LOGGER.info("Original Issue Information having length 22 :{}");
						OriginalIssueAirline = originalIssueInformation.substring(0, 3);
						originalIssueDate = format1.parse(originalIssueInformation.substring(8, 15));
						ticketMain.setOriginalIssueAirline(OriginalIssueAirline);
						ticketMain.setOriginalDocumentNumber(originalDocumentNumber);
						ticketMain.setOriginalPlaceOfIssue(originalIssueInformation.substring(5, 8));
						ticketMain.setOriginalDateOfIssue(originalIssueDate);
						ticketMain.setOriginalAgentCode(originalIssueInformation.substring(15, 22));
						ticketMain.setOriginalDocumentUniqueId(originalDocumentUniqueid);

					} else {
						LOGGER.info("Error in Original Issue Information having length greater than 31 :{}");
					}

					ticketMain.setPrimeReissue(AppConstants.PRIME_REISSUE_R);
				} else {
					ticketMain.setPrimeReissue(AppConstants.PRIME_REISSUE_P);
				}
				if (amadeusRecordStaging.getEndorsementRestrictionText() != null
						&& !amadeusRecordStaging.getEndorsementRestrictionText().isEmpty()) {
					if (amadeusRecordStaging.getEndorsementRestrictionText().length() <= 200) {
						LOGGER.info("Endorsenment Text Lenght less than 200 ---->"
								+ amadeusRecordStaging.getEndorsementRestrictionText().length());
						ticketMain.setEndorsements(amadeusRecordStaging.getEndorsementRestrictionText());
					} else if (amadeusRecordStaging.getEndorsementRestrictionText().length() > 200) {
						LOGGER.info("Endorsenment Text Lenght having more than 200---->"
								+ amadeusRecordStaging.getEndorsementRestrictionText().length());
						ticketMain.setEndorsements(
								amadeusRecordStaging.getEndorsementRestrictionText().substring(0, 199));
					}

				}
				ticketMain.setEticketInd(AppConstants.ETICKET_INDICATOR_DEFAULT);
				ticketMain.setNetFareCurrency(amadeusRecordStaging.getCurrencyOfNetFare());
				if (amadeusRecordStaging.getNetFare() != null && !amadeusRecordStaging.getNetFare().isEmpty()) {
					ticketMain.setNetFareAmount(new BigDecimal(amadeusRecordStaging.getNetFare()));
				}
				ticketMain.setRfic(amadeusRecordStaging.getReasonForIssuanceCode());
				ticketMain.setRfisc(amadeusRecordStaging.getReasonForIssuanceSubCode()); 
				ticketMain.setAirlineIssuingAgent(amadeusRecordStaging.getAgencyNumber());

				ticketMain.setMigratedTicket(AppConstants.MIGRATED_TICKET_DEFAULT);
				if (amadeusRecordStaging.getReportedFare().equals(AppConstants.REPORTED_FARE_BL)) {
					ticketMain.setBtItIndicator(amadeusRecordStaging.getReportedFare());
				} else if (amadeusRecordStaging.getReportedFare().equals(AppConstants.REPORTED_FARE_BT)) {
					ticketMain.setBtItIndicator(amadeusRecordStaging.getReportedFare());
				} else if (amadeusRecordStaging.getReportedFare().equals(AppConstants.REPORTED_FARE_IT)) {
					ticketMain.setBtItIndicator(amadeusRecordStaging.getReportedFare());
				}
				ticketMain.setCouponUseIndicator(amadeusRecordStaging.getUsageType());
				ticketMain.setFileSource(amadeusRecordStaging.getFileSource());
				ticketMain.setDataSource(amadeusRecordStaging.getFileSource());
				ticketMain.setStatus(AppConstants.STATUS_PRODUCTION);

				if (amadeusRecordStaging.getAmadeusRecordDetailStgs().get(0) != null) {
					if (amadeusRecordStaging.getAmadeusRecordDetailStgs().get(0).getInvoluntaryIndicator() != null) {
						ticketMain.setInvolIndicator(
								amadeusRecordStaging.getAmadeusRecordDetailStgs().get(0).getInvoluntaryIndicator());
					}

				}

				ticketMain.setAgentCode(amadeusRecordStaging.getAgencyNumber());
				ticketMain.setDocumentUniqueId(documentUniqueid);
				ticketMainList.add(ticketMain);

				List<TicketCoupon> ticketCouponList = new ArrayList<TicketCoupon>();
				TicketCoupon ticketCoupon;

				for (AmadeusRecordDetailStaging recordDetailStaging : amadeusRecordStaging
						.getAmadeusRecordDetailStgs()) {
					Integer saleCoupon = Integer.parseInt(recordDetailStaging.getSaleCouponNumber());

					bookingClassModelList = masterFeignClient.getListOfBookingClassByUtilizationEffectiveDate(null,
							recordDetailStaging.getSellingClass(), null, null, null, null, null);
					LOGGER.info("bookingClassModelList  Lists are:{}" + bookingClassModelList);
					ticketCoupon = new TicketCoupon();
					ticketCoupon.setDocumentUniqueId(documentUniqueid);
					ticketCoupon.setIssueAirline(issueAirline);
					ticketCoupon.setDocumentNumber(mainDocumentNo);
					ticketCoupon.setMainDocument(mainDocumentNo);
					ticketCoupon.setEmdConsumedAtIssuanceInd(recordDetailStaging.getConsumedAtIssuanceIndicator());
					BigDecimal couponValue = new BigDecimal(0);
					if (recordDetailStaging.getCouponValue() != null && !recordDetailStaging.getCouponValue().isEmpty())
						if (couponValue.compareTo(BigDecimal.ZERO) != 0)
							couponValue = new BigDecimal(recordDetailStaging.getCouponValue());
					ticketCoupon.setEmdCouponValue(couponValue);
					ticketCoupon.setMcoCouponValue(couponValue);

					ticketCoupon.setEmdCurrencyType(amadeusRecordStaging.getCurrencyOfReportedFare());
					ticketCoupon.setEmdExcessBaggCurrencyCode(recordDetailStaging.getEbtChargeCurrency());
					ticketCoupon.setEmdExcessBaggRatePerUnit(recordDetailStaging.getEbtRatePerUnit());
					ticketCoupon.setEmdFeeOwnerAirlineDesign(recordDetailStaging.getFeeOwner());
					if (amadeusRecordStaging.getInConnectionCouponNo() != null
							&& !amadeusRecordStaging.getInConnectionCouponNo().isEmpty()) {
						ticketCoupon.setEmdRelatedCouponNumber(
								Integer.parseInt(amadeusRecordStaging.getInConnectionCouponNo()));
					}
					ticketCoupon.setEmdRelatedTicketNumber(amadeusRecordStaging.getInConnectionDocNo());
					ticketCoupon.setEmdReasonForIssuanceSubcde(recordDetailStaging.getReasonForIssuanceSubCode());
					ticketCoupon.setEmdOperatingCarrier(amadeusRecordStaging.getSoldOperatingCarrier());
					if (recordDetailStaging.getSaleCouponNumber() != null
							&& !recordDetailStaging.getSaleCouponNumber().isEmpty()) {
						ticketCoupon.setCouponNumber(Integer.parseInt(recordDetailStaging.getSaleCouponNumber()));
					}
					if (recordDetailStaging.getOrigin() != null && !recordDetailStaging.getOrigin().isEmpty()) {
						ticketCoupon.setFromAirport(recordDetailStaging.getOrigin());
					}

					if (recordDetailStaging.getDestination() != null
							&& !recordDetailStaging.getDestination().isEmpty()) {
						ticketCoupon.setToAirport(recordDetailStaging.getDestination());
					}

					String airlineCodeOpt = (recordDetailStaging.getAirlineCode().trim());

					carrierMasterList = carrierMasterFeignClient.getAllCarrier(null, airlineCodeOpt, null, null, null);

					if (carrierMasterList.isEmpty()) {
						LOGGER.info("Carrier Code Not Available for the Career Designator Code" + airlineCodeOpt);
						LOGGER.info("Error Count before---------->" + errorCount);
						errorCount++;
						jobExecutionContext.put("errorCount", errorCount);
						LOGGER.info(
								"Error Count after----------->" + jobExecution.getExecutionContext().get("errorCount"));
						// Exception logic - start
						exceptionTransactionModel = AmadeusCommonUtils
								.initExceptionTransactionModel(amadeusRecordStaging, documentUniqueid);
						exceptionTransactionModel.setClientId(hostCarrDesigCode);
						exceptionTransactionModel.setExceptionCode(ExceptionCodeConstants.ERRORCODE_INVALIDCARRIERCODE);
						/*
						 * exceptionTransactionModel.
						 * setResolutionRemarks("Airline Code need to be added in Carrier  Master");
						 * exceptionTransactionModel.setExceptionDetails(
						 * "Carrier  details not found for airline code : " +
						 * recordDetailStaging.getAirlineCode());
						 */
						if (amadeusRecordStaging.getCouponNumber() != null)
							exceptionTransactionModel
									.setCouponNumber(Integer.parseInt(amadeusRecordStaging.getCouponNumber()));
						parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();

						paramValueModel = new ExceptionParametersValueModel();
						paramValueModel.setParameterName("Document No.");
						paramValueModel.setParameterValue(amadeusRecordStaging.getDocumentNumber());
						parametersValueModelList.add(paramValueModel);

						paramValueModel = new ExceptionParametersValueModel();
						paramValueModel.setParameterName("Carrier Code");
						paramValueModel.setParameterValue(recordDetailStaging.getAirlineCode());
						parametersValueModelList.add(paramValueModel);

						paramValueModel = new ExceptionParametersValueModel();
						paramValueModel.setParameterName("Carrier Numeric Code");
						paramValueModel.setParameterValue("Exception");
						parametersValueModelList.add(paramValueModel);

						exceptionTransactionModel.setParametersValueList(parametersValueModelList);

						exceptionTxnFeignClient.initExceptionTrasaction(exceptionTransactionModel);
						// Exception logic - end
						amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_ERROR);
						amadeusRecordStagingRepository.saveAndFlush(amadeusRecordStaging);
						return null;
					}

					ticketCoupon.setMarketingCarrierAlphaCode(recordDetailStaging.getAirlineCode());
					LOGGER.info("Marketing Numeric Code" + carrierMasterList.get(0).getCarrierCode());
					ticketCoupon.setMarketingCarrierNumCode(
							OptionalUtil.getValue(carrierMasterList.get(0).getCarrierCode()));

					if (recordDetailStaging.getSaleLocalFlightDate() != null
							&& !recordDetailStaging.getSaleLocalFlightDate().isEmpty()) {
						if (recordDetailStaging.getSaleLocalFlightDate().trim().equals(AppConstants.FLIGHT_DATE_OPEN)) {
							ticketCoupon.setMarketingFlightDate(null);
						} else {
							ticketCoupon.setMarketingFlightDate(
									LocalDate.parse(recordDetailStaging.getSaleLocalFlightDate(), dtFormatter));
						}

					}

					ticketCoupon.setFareBasis(recordDetailStaging.getFareBasis());
					ticketCoupon.setSectorNumber(String.valueOf(++sector));
					LOGGER.info("Sector Number-->" + sector);
					ticketCoupon.setNotValidBefore(AmadeusCommonUtils
							.convDateFormat(recordDetailStaging.getNotValidBeforeDate(), "yyyyMMdd", "ddMMM"));
					LOGGER.info("Not valid Before Date-->" + ticketCoupon.getNotValidBefore());
					ticketCoupon.setNotValidAfter(AmadeusCommonUtils
							.convDateFormat(recordDetailStaging.getNotValidAfterDate(), "yyyyMMdd", "ddMMM"));
					ticketCoupon.setCreatedBy(recordDetailStaging.getCreatedBy());
					ticketCoupon.setCreatedDate(new Timestamp(new Date().getTime()));

					ticketCoupon.setTicketMain(ticketMain);
					ticketCouponList.add(ticketCoupon);
					LOGGER.info("ProdETLTicketProcessor.process -- End");

				}

				ticketMain.setTicketCoupons(ticketCouponList);

				List<TicketTax> ticketTaxList = new ArrayList<TicketTax>();
				TicketTax ticketTax;
				for (AmadeusNewTaxStaging newTaxStaging : amadeusRecordStaging.getAmadeusNewTaxStgs()) {
					ticketTax = new TicketTax();
					ticketTax.setDocumentUniqueId(documentUniqueid);
					ticketTax.setIssueAirline(issueAirline);
					ticketTax.setDocumentNumber(documentNumberstr);
					ticketTax.setMainDocument(mainDocumentNo);

					ticketTax.setTaxCode(newTaxStaging.getNewTaxCode());
					BigDecimal taxAmt = new BigDecimal(0);
					if (newTaxStaging.getNewTaxValue() != null && !newTaxStaging.getNewTaxValue().isEmpty()) {
						String newTax = newTaxStaging.getNewTaxValue().trim();
						try {
							taxAmt = new BigDecimal(newTax);
							ticketTax.setTaxAmount(taxAmt);
						} catch (NumberFormatException e) {

						}
					}

					ticketTax.setSerialNo(++j);
					LOGGER.info("Serial Number fox Tax-->" + j);

					ticketTax.setTaxCurrency(amadeusRecordStaging.getCurrencyOfReportedFare());
					ticketTax.setCreatedBy(amadeusRecordStaging.getCreatedBy());
					ticketTax.setCreatedDate(new Timestamp(new Date().getTime()));
					ticketTax.setTicketMain(ticketMain);
					ticketTaxList.add(ticketTax);
				}
				ticketMain.setTicketTaxs(ticketTaxList);

				prodTicketModel.setTicketMain(ticketMainList);

			}

			transferredCount++;
			jobExecutionContext.put("transferredCount", transferredCount);
			LOGGER.info("Transfered Count-----------" + transferredCount);
			return prodTicketModel;
		} catch (Exception e) {
			LOGGER.error("Exception Thrown for the amadeus Load Id: " + amadeusRecordStaging.getAmadeusLoadId());
			LOGGER.error("Exception" + e);
			exceptionTransactionModel = AmadeusCommonUtils.initExceptionTransactionModel(amadeusRecordStaging,
					documentUniqueid);
			exceptionTransactionModel.setClientId(hostCarrDesigCode);
			exceptionTransactionModel.setExceptionCode(ExceptionCodeConstants.GENERAL_EXCEPTION);
			/*
			 * exceptionTransactionModel.
			 * setResolutionRemarks("General Exception due to wrong data in file");
			 * exceptionTransactionModel.setExceptionDetails(
			 * "Exception Thrown for the amadeus load Id : " +
			 * amadeusRecordStaging.getAmadeusLoadId());
			 */
			parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();
			paramValueModel = new ExceptionParametersValueModel();
			paramValueModel.setParameterName("Reference ID");
			paramValueModel.setParameterValue(String.valueOf(amadeusRecordStaging.getAmadeusLoadId()));
			parametersValueModelList.add(paramValueModel);
			exceptionTransactionModel.setParametersValueList(parametersValueModelList);
			exceptionTxnFeignClient.initExceptionTrasaction(exceptionTransactionModel);
			// Exception logic - end
			amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_ERROR);
			amadeusRecordStagingRepository.saveAndFlush(amadeusRecordStaging);
			return null;
		}
	}

}
