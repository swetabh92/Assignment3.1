import { Component, OnInit, ViewChild, Input, Output, ElementRef, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { Subject } from 'rxjs';
import { AircraftMasterService } from '../../../services/flown/aircraft-master/aircraft-master.service';
import { GeneralService } from '../../../../../commons/services/general.service';
import swal from 'sweetalert2';
import { Router } from '@angular/router';
import { Aircraft } from '../../../models/flown/aircraft';
import { MessageBoxService } from '../../../services/commons/message-box.service';
import { DatepickerOptions } from 'ng2-datepicker';
import { DatePipe } from '@angular/common';
import { PaginationService } from '../../../../../commons/services/pagination/pagination.service';
import { LovService }  from '../../../services/LOV/lov.service';
import { CommonService } from '../../../services/commons/common.service';
import { HotkeysService } from 'angular2-hotkeys/src/hotkeys.service';
import { Hotkey } from 'angular2-hotkeys/src/hotkey.model';
import { MasterHotkeys } from '../../../../../commons/properties/master/master-hotkeys.enum';
import { DateConstant } from 'src/app/commons/properties/date-constant.properties';
@Component({
  selector: 'app-aircraft-master',
  templateUrl: './aircraft-master.component.html',
  styleUrls: ['./aircraft-master.component.css']
})
export class AircraftMasterComponent implements OnInit{

  @ViewChild('closeModalAdd') closeModalAdd: ElementRef;
  @ViewChild('closeModalEdit') closeModalEdit: ElementRef;

  // We use this trigger because fetching the list of persons can be quite long,
  // thus we ensure the data is fetched before rendering
  public renderDT = false;
  createdBy = 'admin';
  lastUpdatedBy = 'admin';
  searchstring: any;
  successresult: any;
  aircraftList: Aircraft[] = [];
  marked = false;
  collapse_search_form = true;
  box_search_status = false;
  addNewAircraftForm: FormGroup;
  addNewsubmitted = false;
  editsubmittedForm: FormGroup;
  editsubmitted = false;
  searchForm: FormGroup;
  searchsubmitted = false;
  searchresult = false;
  resetDate = true;
  formFlag:string="";
  toMinDate:any;
	fromMaxDate:any;
  currentDate : Date = new Date();
  DATE_FORMAT = DateConstant.DATE;
  error: any = { isError: false, errorMessage: '' };
	page: any = this.PaginateService.getPageinateConfig();
  constructor(public lov:LovService,private PaginateService: PaginationService,private generalService: GeneralService, private aircraftService: AircraftMasterService, private formBuilder: FormBuilder, private router: Router,
    private messageBoxService: MessageBoxService, private commonService: CommonService,private hotkeysService: HotkeysService) { 
      this.hotkeysService.add(new Hotkey(MasterHotkeys.save, (event: KeyboardEvent): boolean => {
        if (this.formFlag == 'addAircraft') {
        this.addNewAircraft();
        }else if(this.formFlag == 'editAircraft'){
        this.onUpdate();
        }
        return false; 
      }));
    
      this.hotkeysService.add(new Hotkey(MasterHotkeys.clear, (event: KeyboardEvent): boolean => {
        if (this.formFlag == 'addAircraft'){
          this.onResetAdd();
        }else if(this.formFlag == 'searchAircraft'){
          this.onResetSearch();
          this.getAllAircraft();
        }
        return false; 
      }));
      
      this.hotkeysService.add(new Hotkey(MasterHotkeys.cancel, (event: KeyboardEvent): boolean => {
        if (this.formFlag == 'addAircraft') {
          this.onCancelChange();
        }else if (this.formFlag == 'editAircraft'){
          this.onCancelChange();
        }else if(this.formFlag == 'searchAircraft'){
          this.showSearchBox(event);
        }
        return false; 
      }));
    }

  ngOnInit() {
    this.lov.initLovDDS('air_craft');
    this.getAllAircraft();
    this.addNewAircraftForm = this.formBuilder.group({
      createdBy: ['admin', [Validators.required, Validators.maxLength(15)]],
      aircraftRegistration: ['', [Validators.required, Validators.maxLength(16)]],
      aircraftType: ['', [Validators.required,  Validators.maxLength(16)]],
      accountCode: ['', [Validators.maxLength(20)]],
      aircraftCategory: [''],
      aircraftOperatingCarrier: ['', [Validators.maxLength(3)]],
      aircraftOwner: ['',[Validators.maxLength(50)]],
      businessClassCapacity: [0, [Validators.maxLength(3)]],
      costCenter: ['', [Validators.required, Validators.maxLength(20)]],
      economyClassCapacity: [0, [Validators.maxLength(3)]],
      effectiveFromDate: ['', [Validators.required]],
      effectiveToDate: ['', [Validators.required]],
      hireDate: [''],
      iataCodeAircraftType: ['', [Validators.required, Validators.maxLength(16)]],
      icaoCodeAircraftType: ['', [Validators.required, Validators.maxLength(16)]],
      manufacturer: ['', [Validators.maxLength(50)]],
      mtom: [0, [Validators.maxLength(10)]],
      payload: ['', [Validators.required, Validators.maxLength(10)]],
      premiumEconomyClassCapacity: [0, [Validators.maxLength(3)]],
      profitCenter: ['', [Validators.maxLength(20)]],
      firstClassCapacity: [0, [Validators.maxLength(3)]],
      wakeCategory: [''],
      remarks: ['', [Validators.maxLength(500)]],
      retireDate: [''],
      attribute1:['',[Validators.maxLength(20)]],
      attribute2:['',[Validators.maxLength(20)]],
      clientId: ['']
    });
    this.editsubmittedForm = this.formBuilder.group({
      lastUpdatedBy: ['admin'],
      aircraftId: [''],
      aircraftRegistration: ['', [Validators.required, Validators.maxLength(16)]],
      aircraftType: ['', [Validators.required, Validators.maxLength(16)]],
      accountCode: [''],
      aircraftCategory: [''],
      aircraftOperatingCarrier: [''],
      aircraftOwner: [''],
      businessClassCapacity: [''],
      costCenter: [''],
      economyClassCapacity: [''],
      effectiveFromDate: ['', [Validators.required]],
      effectiveToDate: ['', [Validators.required]],
      hireDate: [''],
      iataCodeAircraftType: ['', [Validators.required, Validators.maxLength(16)]],
      icaoCodeAircraftType: ['', [Validators.required, Validators.maxLength(16)]],
      manufacturer: [''],
      mtom: [''],
      payload: [''],
      premiumEconomyClassCapacity: [''],
      profitCenter: [''],
      firstClassCapacity: [''],
      wakeCategory: [''],
      remarks: [''],
      retireDate: [''],
      attribute1:[''],
      attribute2:[''],
      clientId: ['']
    });
    this.searchForm = this.formBuilder.group({
      aircraftRegistration: ['', [Validators.maxLength(16)]],
      aircraftType: ['', [Validators.maxLength(16)]]
    });
    this.getEffectiveFromDate(this.addNewAircraftForm,'effectiveFromDate');
		this.getEffectiveToDate(this.addNewAircraftForm,'effectiveToDate');
		this.getEffectiveFromDate(this.editsubmittedForm,'effectiveFromDate');
		this.getEffectiveToDate(this.editsubmittedForm,'effectiveToDate');
  }

  closeAlertValidation() {
    var tempThis = this;
    window.setTimeout(function () {
      tempThis.error = { isError: false, errorMessage: '' };
    }, 6000);
  }

  getAllAircraft(): void {
    this.renderDT = false;
    this.aircraftService.getAllAircraft().subscribe((res: any[]) => {
      this.aircraftList = res;
      this.aircraftList = res.map(aircraft => {
        return aircraft;
      });
      setTimeout(() => {
        this.renderDT = true;
      }, 100);
    });
  }


  get f() { return this.addNewAircraftForm.controls; }
  get u() { return this.editsubmittedForm.controls; }
  get s() { return this.searchForm.controls; }

  onSearch(): void {
    this.searchsubmitted = true;
    this.searchstring = 'aircrafts?';
    if (this.searchForm.value.aircraftRegistration) {
      this.searchstring += 'aircraftRegistration=' + this.searchForm.value.aircraftRegistration + '&&';
    }
    if (this.searchForm.value.aircraftType) {
      this.searchstring += 'aircraftType=' + this.searchForm.value.aircraftType + '&&';
    }
    this.aircraftService.searchAircraft(this.searchstring).subscribe(
      response => {
        this.aircraftList = response;
        setTimeout(() => {
          this.renderDT = true;
        }, 100);
      });
  }

  onResetSearch(): void {
    this.searchForm.reset();
    this.renderDT = false;
    this.getAllAircraft();
  }

  showSearchBox(e): void {
    this.box_search_status = !this.box_search_status;
    this.collapse_search_form = true;
  }

  addNewAircraft(){
    this.addNewsubmitted = true;
    if (this.addNewAircraftForm.invalid) {
      return false;
    } else {
      this.addNewAircraftForm.value.clientId = this.commonService.getClientId();
      const data = this.commonService.convertApiObj(this.addNewAircraftForm.value);
      this.aircraftService.addAircraft(data).subscribe(
        res => {
          if (!!res && res.aircraftId) {
            this.updateDataTable(res,'add');
            this.closeModalAdd.nativeElement.click();
            this.error = { isError: true, errorMessage: "Record has been successfully saved" };
            this.closeAlertValidation();
            this.onResetAdd();
          }
        });
    }
  }

  onResetAdd(): void {
    this.addNewAircraftForm.reset();
    this.resetDate = false;
    this.addNewAircraftForm.markAsPristine();
    this.addNewAircraftForm.markAsUntouched();
    this.addNewAircraftForm.updateValueAndValidity();
    this.addNewsubmitted = false;
    this.addNewAircraftForm.patchValue({
      createdBy: 'admin'
    });
    setTimeout(() => {
      this.resetDate = true;
    }, 10)
  }

  onResetEdit(id): void {
    this.editsubmittedForm.reset();
    this.resetDate = false;
    this.editsubmittedForm.markAsPristine();
    this.editsubmittedForm.markAsUntouched();
    this.editsubmittedForm.updateValueAndValidity();
    this.editsubmitted = false;
    this.editsubmittedForm.patchValue({
      lastUpdatedBy: 'admin',
      aircraftId: id,
    });
    setTimeout(() => {
      this.resetDate = true;
    }, 10)
  }

  showEditvalues(getId): void {
    this.editsubmittedForm.get('aircraftCategory').disable();
    this.editsubmittedForm.get('wakeCategory').disable();
    this.aircraftService.getAircraftByAircraftId(getId).subscribe(
      response => {
        if (!!response && response.aircraftId) {
          response.effectiveFromDate = new Date(response.effectiveFromDate);
				  response.effectiveToDate = new Date(response.effectiveToDate);
          response.effectiveFromDate > new Date() ? this.editsubmittedForm.get('effectiveFromDate').enable() : this.editsubmittedForm.get('effectiveFromDate').disable();
          this.editsubmittedForm.patchValue({
            aircraftId: response['aircraftId'],
            accountCode: response['accountCode'],
            aircraftCategory: response['aircraftCategory'],
            aircraftOperatingCarrier: response['aircraftOperatingCarrier'],
            aircraftOwner: response['aircraftOwner'],
            aircraftRegistration: response['aircraftRegistration'],
            aircraftType: response['aircraftType'],
            businessClassCapacity: response['businessClassCapacity'],
            costCenter: response['costCenter'],
            economyClassCapacity: response['economyClassCapacity'],
            effectiveFromDate: response['effectiveFromDate'],
            effectiveToDate: response['effectiveToDate'],
            hireDate: response['hireDate'],
            iataCodeAircraftType: response['iataCodeAircraftType'],
            icaoCodeAircraftType: response['icaoCodeAircraftType'],
            manufacturer: response['manufacturer'],
            mtom: response['mtom'],
            payload: response['payload'],
            premiumEconomyClassCapacity: response['premiumEconomyClassCapacity'],
            profitCenter: response['profitCenter'],
            firstClassCapacity: response['firstClassCapacity'],
            wakeCategory: response['wakeCategory'],
            remarks: response['remarks'],
            retireDate: response['retireDate'],
            attribute1: response['attribute1'],
            attribute2: response['attribute2'],
            updatedBy: response['updatedBy']
          });

          this.box_search_status = false;
        } else {
          this.messageBoxService.showFetchErrorMessage();
        }
      });
  }

  showCopyValues(getId): void {
    this.aircraftService.getAircraftByAircraftId(getId).subscribe(
      response => {
        if (!!response && response.aircraftId) {
          response.effectiveFromDate = new Date(response.effectiveFromDate);
				  response.effectiveToDate = new Date(response.effectiveToDate);
          this.addNewAircraftForm.patchValue({
            accountCode: response['accountCode'],
            aircraftCategory: response['aircraftCategory'],
            aircraftOperatingCarrier: response['aircraftOperatingCarrier'],
            aircraftOwner: response['aircraftOwner'],
            aircraftRegistration: response['aircraftRegistration'],
            aircraftType: response['aircraftType'],
            businessClassCapacity: response['businessClassCapacity'],
            costCenter: response['costCenter'],
            economyClassCapacity: response['economyClassCapacity'],
            effectiveFromDate: response['effectiveFromDate'],
            effectiveToDate: response['effectiveToDate'],
            hireDate: response['hireDate'],
            iataCodeAircraftType: response['iataCodeAircraftType'],
            icaoCodeAircraftType: response['icaoCodeAircraftType'],
            manufacturer: response['manufacturer'],
            mtom: response['mtom'],
            payload: response['payload'],
            premiumEconomyClassCapacity: response['premiumEconomyClassCapacity'],
            profitCenter: response['profitCenter'],
            firstClassCapacity: response['firstClassCapacity'],
            wakeCategory: response['wakeCategory'],
            remarks: response['remarks'],
            retireDate: response['retireDate'],
            attribute1: response['attribute1'],
            attribute2: response['attribute2'],
            clientId: response['clientId'],
            createdBy: 'admin',
          });
          this.box_search_status = false;
        } else {
          this.messageBoxService.showFetchErrorMessage();
        }
      });
  }

  onUpdate(): void {
    this.editsubmitted = true;
    if (this.editsubmittedForm.invalid) {
      return;
    } else {
      const data = this.commonService.convertApiObj(this.editsubmittedForm.getRawValue());
      const aircraft = Object.assign(<any>{}, data);
      delete (aircraft.aircraftId);
      this.aircraftService.updateAircraft(this.editsubmittedForm.value, aircraft).subscribe(
        aircraftService => {
          if (!!aircraftService && aircraftService.aircraftId) {
			      this.updateDataTable(aircraftService,'update');
            this.closeModalEdit.nativeElement.click();
            this.error = { isError: true, errorMessage: "Record has been successfully saved" };
            this.closeAlertValidation();
          }
        });
    }
  }

  collapseSearchform(event): void {
    const targetclass = event.target.className;
    console.log(targetclass);
    if (targetclass === 'btn btn-box-tool fa fa-angle-up') {
      this.collapse_search_form = !this.collapse_search_form;
      event.target.className = 'btn btn-box-tool fa fa-angle-down';
    } else if (targetclass === 'btn btn-box-tool fa fa-angle-down') {
      this.collapse_search_form = !this.collapse_search_form;
      event.target.className = 'btn btn-box-tool fa fa-angle-up';
    }
  }


  toggleVisibility(e): void {
    this.marked = e.target.checked;
  }

  onCancelChange() {
    this.onResetAdd();
    this.onResetEdit(null);
    this.closeModalAdd.nativeElement.click();
	  this.closeModalEdit.nativeElement.click();
  }


  splitDate(date: any) {
    if (date instanceof Date) {
      const datePipe = new DatePipe('en-US');
      return datePipe.transform(date, 'yyyy-MM-dd');
    } else {
      return date.split('T')[0];
    }
  }
  	updateDataTable(data,type){
		if(type == 'add') this.aircraftList.unshift(data);	
		else{
			const ind = this.aircraftList.findIndex((item) => { return data.aircraftId == item.aircraftId;});
			if(ind == -1) return false;if(type =='update')  this.aircraftList[ind] = data;
		}
		this.aircraftList = [...this.aircraftList];
	}

  disableCalendarDatesOnFromDateSelction(){
		let getFromDate = this.editsubmittedForm.get("effectiveFromDate").value;
		if(new Date(getFromDate) < this.currentDate){
			return this.toMinDate = this.currentDate;
		}
		else{
			return this.toMinDate = this.toMinDate;
		}
  }
  getEffectiveFromDate(formName:any,obj:string){
    formName.controls[obj].valueChanges.subscribe((minDate) => {
      return this.toMinDate = minDate;
    });
  }
  getEffectiveToDate(formName:any,obj:string){
    formName.controls[obj].valueChanges.subscribe((maxDate) => {
      return this.fromMaxDate = maxDate;
    });
  }
  validateEffectiveToDate(date) {
    return !(new Date(date) > new Date());
  }
}
