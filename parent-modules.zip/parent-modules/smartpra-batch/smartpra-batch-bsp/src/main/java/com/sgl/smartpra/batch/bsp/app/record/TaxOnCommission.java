package com.sgl.smartpra.batch.bsp.app.record;

import java.util.ArrayList;

import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;
import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;

public class TaxOnCommission extends BSPBaseRecord {

	@Override
	public String getRecordType() {
		return BSPRecordType.TAX_ON_COMMISSION;
	}

	// Layout of Tax On Commission record
	class TaxOnCommissionLayout extends FixedLengthRecordLayout {
		public TaxOnCommissionLayout() {
			fixedLengthFieldLayoutList = new ArrayList<FixedLengthFieldLayout>();

			// entire line
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("line", 1, 136));

			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdMessageIdentifier", 1, 3));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("seqNumber", 4, 11));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdNumericQuaifier", 12, 13));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("dateOfIssue", 14, 19));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("transactionNumber", 20, 25));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("tktDocNumber", 26, 39));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("checkDigit", 40, 40));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("taxOnCommissionType1", 41, 46));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("taxOnCommissionAmount1", 47, 57));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("taxOnCommissionType2", 58, 63));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("taxOnCommissionAmount2", 64, 74));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("taxOnCommissionType3", 75, 80));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("taxOnCommissionAmount3", 81, 91));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("taxOnCommissionType4", 92, 97));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("taxOnCommissionAmount4", 98, 108));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("filler", 109, 132));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("currencyType", 133, 136));
		}
	}

	@Override
	public LineTokenizer lineTokenizer(String handbookRevisionNumber) {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		TaxOnCommissionLayout taxOnCommissionLayout = new TaxOnCommissionLayout();
		tokenizer.setColumns(taxOnCommissionLayout.getColumns());
		tokenizer.setNames(taxOnCommissionLayout.getNames());
		return tokenizer;
	}

	@Override
	public FieldSetMapper<BSPBaseRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<BSPBaseRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<BSPBaseRecord>();
		fieldSetMapper.setTargetType(this.getClass());
		return fieldSetMapper;
	}

	// Variables to hold record values
	private String stdMessageIdentifier;
	private String seqNumber;
	private String stdNumericQuaifier;
	private String dateOfIssue;
	private String transactionNumber;
	private String tktDocNumber;
	private String checkDigit;
	private String taxOnCommissionType1;
	private String taxOnCommissionAmount1;
	private String taxOnCommissionType2;
	private String taxOnCommissionAmount2;
	private String taxOnCommissionType3;
	private String taxOnCommissionAmount3;
	private String taxOnCommissionType4;
	private String taxOnCommissionAmount4;
	private String filler;
	private String currencyType;

	public String getStdMessageIdentifier() {
		return stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getSeqNumber() {
		return seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdNumericQuaifier() {
		return stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getDateOfIssue() {
		return dateOfIssue;
	}

	public void setDateOfIssue(String dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}

	public String getTransactionNumber() {
		return transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

	public String getTktDocNumber() {
		return tktDocNumber;
	}

	public void setTktDocNumber(String tktDocNumber) {
		this.tktDocNumber = tktDocNumber;
	}

	public String getCheckDigit() {
		return checkDigit;
	}

	public void setCheckDigit(String checkDigit) {
		this.checkDigit = checkDigit;
	}

	public String getTaxOnCommissionType1() {
		return taxOnCommissionType1;
	}

	public void setTaxOnCommissionType1(String taxOnCommissionType1) {
		this.taxOnCommissionType1 = taxOnCommissionType1;
	}

	public String getTaxOnCommissionAmount1() {
		return taxOnCommissionAmount1;
	}

	public void setTaxOnCommissionAmount1(String taxOnCommissionAmount1) {
		this.taxOnCommissionAmount1 = taxOnCommissionAmount1;
	}

	public String getTaxOnCommissionType2() {
		return taxOnCommissionType2;
	}

	public void setTaxOnCommissionType2(String taxOnCommissionType2) {
		this.taxOnCommissionType2 = taxOnCommissionType2;
	}

	public String getTaxOnCommissionAmount2() {
		return taxOnCommissionAmount2;
	}

	public void setTaxOnCommissionAmount2(String taxOnCommissionAmount2) {
		this.taxOnCommissionAmount2 = taxOnCommissionAmount2;
	}

	public String getTaxOnCommissionType3() {
		return taxOnCommissionType3;
	}

	public void setTaxOnCommissionType3(String taxOnCommissionType3) {
		this.taxOnCommissionType3 = taxOnCommissionType3;
	}

	public String getTaxOnCommissionAmount3() {
		return taxOnCommissionAmount3;
	}

	public void setTaxOnCommissionAmount3(String taxOnCommissionAmount3) {
		this.taxOnCommissionAmount3 = taxOnCommissionAmount3;
	}

	public String getTaxOnCommissionType4() {
		return taxOnCommissionType4;
	}

	public void setTaxOnCommissionType4(String taxOnCommissionType4) {
		this.taxOnCommissionType4 = taxOnCommissionType4;
	}

	public String getTaxOnCommissionAmount4() {
		return taxOnCommissionAmount4;
	}

	public void setTaxOnCommissionAmount4(String taxOnCommissionAmount4) {
		this.taxOnCommissionAmount4 = taxOnCommissionAmount4;
	}

	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}

	public String getCurrencyType() {
		return currencyType;
	}

	public void setCurrencyType(String currencyType) {
		this.currencyType = currencyType;
	}
}