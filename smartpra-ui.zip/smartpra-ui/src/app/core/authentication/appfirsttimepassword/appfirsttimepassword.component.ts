import {AfterViewInit, Component, OnInit} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { GeneralService } from '../../../commons/services/general.service';
import { PasswordValidator } from '../../../commons/services/validators/password.validator.service';
import { MustMatch } from '../../../commons/services/validators/must-match.validator.service';
import { AuthenticationService } from '../auth-gaurd-service/_services/authentication.service';
import swal from 'sweetalert2';
import { NgSelectConfig } from '@ng-select/ng-select';


@Component({
  selector: 'app-appfirsttimepassword',
  templateUrl: './appfirsttimepassword.component.html',
  styleUrls: ['./appfirsttimepassword.component.css']
})
export class AppfirsttimepasswordComponent implements OnInit,AfterViewInit{
  firstTimePassword: FormGroup;
  key: string;
  submitted = false;
  returnUrl: string;
  passwordViewType = "password";
  error = '';
  questionArray: any = [
    {id: 1, question: 'What was your favorite sport in high school?'},
    {id: 2, question: 'What is your favorite movie?' },
    {id: 3, question: 'What was the make and model of your first car?'},
    {id: 4, question: 'What was your childhood nickname?'},
    {id: 5, question: 'Who is your childhood sports hero?'},
    {id: 6, question: 'What was the name of the company where you had your first job?'},
                      ];
  selectedQuestion1: any;
  selectedQuestion2: any;
  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private authenticationService: AuthenticationService,
    private Gservice: GeneralService
  ) { 
    this.route.params.subscribe(params => {
      if (params.key !== null && params.key !== undefined && params.key !== 'undefined' ) {
        this.key = params.key;
       }
       console.log(this.key);
    });
  }

  ngAfterViewInit() {
    this.Gservice.LoadFormSettingJs();
  }
  ngOnInit() {
    console.log(this.key);
    this.firstTimePassword = this.formBuilder.group({
      mail: ['', [Validators.required, Validators.email]],
      password: ['', Validators.compose([Validators.required, Validators.minLength(8), PasswordValidator.strong])],
      retypepassword: ['', Validators.required],
      // securityquestion1: ['', Validators.required],
      // securityanswer1: ['', Validators.required],
      // securityquestion2: ['', Validators.required],
      // securityanswer2: ['', Validators.required],
    }, {
      validator: MustMatch('password', 'retypepassword')
  });
    this.Gservice.LoadFormSettingJs();

  }
  get f() { return this.firstTimePassword.controls; }
  onSubmit() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.firstTimePassword.invalid) {
      return;
    }
    this.firstTimePassword.value.key = this.key;
    console.log(this.firstTimePassword.value);
    this.authenticationService.firsttimePassword(this.firstTimePassword.value)
      .pipe(first())
      .subscribe(
        data => {
          swal(
            'success',
            'password created',
            'success'
          );
          setTimeout(() => {
            this.router.navigate(['profile']);
          }, 100);
        },
        error => {
          console.log(error);
          const err =  error.error.message || error.error.error_description || error.error.error || 'Could not connect server';
          console.log(err);
          swal(
            'error',
            err,
            'error'
          );
        });
  }

  onClickShowHidePwd(){
    this.passwordViewType = this.passwordViewType == "password" ? "text" : "password";
  }

}
