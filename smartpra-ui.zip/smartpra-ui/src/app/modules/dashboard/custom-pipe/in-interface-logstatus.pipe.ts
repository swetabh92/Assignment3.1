import {Pipe, PipeTransform} from '@angular/core';

@Pipe({name: 'transformLogStatus'})
export class InInterfaceLogstatusPipe implements PipeTransform {

  transform(value: string) {

    if (!value) {
      return 0;
    } else {
      return value;
    }

  }
}
