import { Component, OnInit ,Input} from '@angular/core';
import {PaginationService} from '../../../../../commons/services/pagination/pagination.service';
import {SalesdashboardserviceService} from '../../salesdashboardservice.service';
import { DateFormatService } from '../../../../../commons/services/date-format/date-format.service';
@Component({
  selector: 'app-exchange-refund',
  templateUrl: './exchange-refund.component.html',
  styleUrls: ['./exchange-refund.component.css']
})
export class ExchangeRefundComponent implements OnInit {
  page: any = this.paginateService.setCustomPaginationConfig({'pageSize': 5});
  constructor(private dateFormatService:DateFormatService,private salesService:SalesdashboardserviceService,private paginateService: PaginationService) { }
  exchangeRefund:any = [];
  @Input('value')
  set value(val:any){
      if(val) {
          this.getExchangeRefund(val.documentNumber) 

      }
  }
  ngOnInit() {
  }
  getExchangeRefund(documentNumber): void {
    this.salesService.getExchangeRefund(documentNumber)
      .subscribe(
        (data) => {
          this.exchangeRefund = data;
        }
      );

  }

}
