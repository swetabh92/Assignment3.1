package com.sgl.smartpra.batch.amadeus.app.layout;

import java.util.ArrayList;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;
import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;


public class StagingEMDV1_00Layout extends FixedLengthRecordLayout {

  public StagingEMDV1_00Layout() {

    fixedLengthFieldLayoutList = new ArrayList<FixedLengthFieldLayout>();
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("recordType", 1, 1));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("issAirline", 2, 4));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("documentNumber", 5, 14));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("checkDigit", 15, 15));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("couponNumber", 16, 16));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageType", 17, 17));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("manualIndicator", 18, 18));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usagePerformer", 19, 78));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageMarketingCarrierCode", 79, 80));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageOperatingCarrier", 81, 82));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageOriginCodeEmd", 83, 87));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageDestinationCodeEmd", 88, 92));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("settlementAuthorizationCode", 93, 107));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("inConnectionDocNo", 108, 120));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("inConnectionCouponNo", 121, 121));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("associationStatus", 122, 124));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("soldMarketingCarrier", 125, 126));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("soldOperatingCarrier", 127, 128));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("reasonForIssuanceSubCode", 129, 131));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("soldOriginCode", 132, 136));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("soldDestinationCode", 137, 141));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("ebdTotalNoOfUnits", 142, 156));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("ebdChargeQualifier", 157, 159));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("ebdUnitQualifier", 160, 162));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("ebdChargeQualifier", 163, 165));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("ebdRatePerUnit", 166, 183));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("couponValue", 196, 207));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("reportedFare", 208, 210));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("currencyOfReportedFare", 208, 210));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("equivalentFare", 211, 222));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("paymentCurrency", 223, 225));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("agencyNumber", 226, 233));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("issueDate", 234, 241));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("issuingOfficeLocation", 242, 246));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("bookingReference", 247, 252));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("tourCode", 253, 266));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("passengerName", 267, 306));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("reasonForIssuanceCode", 307, 307));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageDocNumber", 308, 347));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("coupons", 348, 1867));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("emdDocumentAmount", 1868, 1879));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("emdDocumentAmountCurrency", 1880, 1882));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("nonExchangeableAmount", 1883, 1894));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("nonExchangeableAmtCurr", 1895, 1897));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("nonRefundableAmount", 1898, 1909));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("nonRefundableAmountCurr", 1910, 1912));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("transactionTotalAmount", 1913, 1924));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("currencyOfTransTotalAmt", 1925, 1927));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("additionalCollectionTotal", 1928, 1939));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("currencyOfAddlCollection", 1940, 1942));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("fareConstruction", 1943, 2292));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("fareCalcModeIndicator", 2293, 2295));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("commissionRate", 2296, 2300));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("commissionAmount", 2301, 2312));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("currencyOfCommissionAmount", 2313, 2315));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("bankersExchangeRate", 2316, 2327));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("netFare", 2328, 2339));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("currencyOfNetFare", 2340, 2342));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("newTax", 2343, 3728));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("formOfIdentificationType", 5115, 5117));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("formOfIdentificationNumber", 5118, 5152));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("formOfIdentVendorCode", 5153, 5156));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("frequentFlyerAirlineCode", 5157, 5159));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("frequentFlyerCustomerCode", 5160, 5184));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("originalIssueInformation", 5185, 5254));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("originalEmdDocNumber1", 5255, 5267));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("originalEmdDocNumber2", 5268, 5280));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("originalEmdDocNumber3", 5287, 5293));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("originalEmdDocNumber4", 5294, 5306));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("originalEmdDocNumber5", 5307, 5319));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("originalEmdDocNumber6", 5320, 5332));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("originalEmdDocNumber7", 5333, 5345));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("formOfPayment", 5346, 5418));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("formOfPayment2", 5419, 5491));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("formOfPayment3", 5492, 5564));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("oldFormOfPayment", 5565, 5637));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("oldFormOfPayment2", 5638, 5710));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("oldFormOfPayment3", 5711, 5783));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("internationalSaleIndicaor", 5784, 5784));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("endorsementRestrictionText", 5785, 6414));
  //  fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("ticketingModeIndicator", 6415, 6415));
 //  fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("netRemitIndicator", 6416, 6416));
   //fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("nonEndorsableIndicator", 6417, 6417));
    // fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("presentCreditCardIndicator", 6044, 6044));
    fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("filler", 6415, null));

  }
}
