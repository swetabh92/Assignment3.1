package com.sgl.smartpra.allocation.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.allocation.master.app.entity.AllocationMasterEntity;
import com.sgl.smartpra.allocation.master.model.AllocationMasterSearchModel;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface SalesAllocationMapper extends BaseMapper<AllocationMasterSearchModel, AllocationMasterEntity> {

	@Mapping(source = "stationName", target = "allocationKey1")
	@Mapping(source = "fileType", target = "allocationKey2")
	@Mapping(source = "exceptionCreatedFrom", target = "allocationKey3")
	@Mapping(source = "exceptionCreatedTo", target = "allocationKey4")
	@Mapping(source = "salesFromDate", target = "allocationKey5")
	@Mapping(source = "salesToDate", target = "allocationKey6")
	@Mapping(source = "utilizationFromDate", target = "allocationKey7")
	@Mapping(source = "utilizationToDate", target = "allocationKey8")
	AllocationMasterEntity mapToEntity(AllocationMasterSearchModel allocationMasterSearchModel);
	
	

}
