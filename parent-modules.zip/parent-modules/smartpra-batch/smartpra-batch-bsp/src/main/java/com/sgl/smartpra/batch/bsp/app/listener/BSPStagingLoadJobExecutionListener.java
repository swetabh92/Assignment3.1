package com.sgl.smartpra.batch.bsp.app.listener;

import java.math.BigInteger;
import java.sql.Timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.bsp.app.config.FeignConfiguration.BatchGlobalFeignClient;
import com.sgl.smartpra.batch.global.model.FileLogging;
import com.sgl.smartpra.common.util.FileLoggingConstants;

@Component
public class BSPStagingLoadJobExecutionListener extends JobExecutionListenerSupport {

	private static final Logger log = LoggerFactory.getLogger(BSPStagingLoadJobExecutionListener.class);

	@Autowired
	BatchGlobalFeignClient batchGlobalFeignClient;
	
	@Override
	public void afterJob(JobExecution jobExecution) {

		Integer billingAnalysisHeaderCount = null;
		Integer salesFileHeaderStgCount  = null;
		Integer transactionRecordStgCount = null;
		
		for (StepExecution stepExecution : jobExecution.getStepExecutions()) {
			
			 billingAnalysisHeaderCount = (Integer) stepExecution.getExecutionContext().get("billingAnalysisHeaderCount");
			 salesFileHeaderStgCount = (Integer) stepExecution.getExecutionContext().get("salesFileHeaderStgCount");
			 transactionRecordStgCount = (Integer) stepExecution.getExecutionContext().get("transactionRecordStgCount");
		}
		
		// get the fileId to update
		int fileId = jobExecution.getExecutionContext().getInt("fileId");
		FileLogging fileLogging = batchGlobalFeignClient.getFileLogByFileId(BigInteger.valueOf(fileId));
		fileLogging.setEndDateTime(new Timestamp(jobExecution.getEndTime().getTime()));
		
		
		

		Integer headerCounts = (billingAnalysisHeaderCount !=null ? billingAnalysisHeaderCount : 0)
				+ (salesFileHeaderStgCount != null ? salesFileHeaderStgCount : 0);
		fileLogging.setHeaderCounts(headerCounts);
		fileLogging.setDetailCounts(transactionRecordStgCount);
		
		if (jobExecution.getStatus() == BatchStatus.COMPLETED) {
			// updated the file load status as staging load completed
			fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_LOADSTATUS__STAGING_SUCCESS);
			fileLogging = batchGlobalFeignClient.updateFileLog(BigInteger.valueOf(fileId), fileLogging);

			log.info("!!! JOB FINISHED SUCCESSFULLY!");

		} else {
			// updated the file load status as staging load failure
			fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_LOADSTATUS_STAGING_FAILED);
			fileLogging = batchGlobalFeignClient.updateFileLog(BigInteger.valueOf(fileId), fileLogging);

			log.info("!!! JOB FAILED!");
		}

		log.info("!!! FILE NAME = " + fileLogging.getFileName());
		log.info("!!! FILE ID = " + fileLogging.getFileId());
		log.info("!!! START TIME = " + jobExecution.getStartTime());
		log.info("!!! END TIME = " + jobExecution.getEndTime());
		log.info("!!! Time taken = "
				+ ((jobExecution.getEndTime().getTime() - jobExecution.getStartTime().getTime()) / 1000.0)
				+ " seconds");

	}
}
