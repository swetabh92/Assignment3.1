package com.sgl.smartpra.batch.sales.validator.app.exception;



public class SalesValidationException extends RuntimeException {

	@Override
	public String getLocalizedMessage() {
		return super.getLocalizedMessage();
	}

	@Override
	public String getMessage() {
		return super.getMessage();
	}

	@Override
	public void printStackTrace() {
		super.printStackTrace();
	}

	
}