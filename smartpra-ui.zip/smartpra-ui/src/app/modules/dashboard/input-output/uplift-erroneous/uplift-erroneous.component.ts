import {Component, Input, OnInit, ViewChild} from '@angular/core';
import {DatatableComponent} from '@swimlane/ngx-datatable';
import {GeneralService} from '../../../../commons/services/general.service';

@Component({
  selector: 'app-uplift-erroneous',
  templateUrl: './uplift-erroneous.component.html',
  styleUrls: ['./uplift-erroneous.component.css']
})
export class UpliftErroneousComponent implements OnInit {

  currentSort1:any = [{ prop: "", dir: 'asc'}];
  @ViewChild('sortTable') sortTable: DatatableComponent;

  flownStagingData =[{"name":"PAX","key":"pax"},{"name":"EMD","key":"emd"},{"name":"EBT","key":"ebt"},{"name":"MCO","key":"mco"},{"name":"FIM","key":"fim"}];
  flownProductionData =[{"name":"PAX","key":"pax"},{"name":"EMD","key":"emd"},{"name":"EBT","key":"ebt"},{"name":"MCO","key":"mco"},{"name":"FIM","key":"fim"}];

  constructor(private gService:GeneralService) { }

  ngOnInit() {
  }

  @Input() fileUpliftErroneousDetails;
  @Input() page;

  onCustomSort(sortCol: string) {
    let sortDir = 'asc';
    if(this.currentSort1[0].prop === sortCol) sortDir = this.currentSort1[0].dir === 'asc'?'desc':'asc';
    this.currentSort1 = [{ prop: sortCol, dir: sortDir }];
    this.sortTable.onColumnSort({ sorts: this.currentSort1});
  }
}
