package com.sgl.smartpra.batch.bhr.app.repository;

import java.math.BigInteger;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.batch.bhr.app.domain.FlightBatchHeaderStg;

@Repository
public interface FlightBatchHeaderRepository  extends JpaRepository<FlightBatchHeaderStg, BigInteger>{
	
	@Query(value = "SELECT a FROM FlightBatchHeaderStg a  WHERE a.fileId = :fileId")
	public Page<List<FlightBatchHeaderStg>> findByFileId(@Param("fileId") int fileId, @Param("pageable") Pageable pageable);
	
}
