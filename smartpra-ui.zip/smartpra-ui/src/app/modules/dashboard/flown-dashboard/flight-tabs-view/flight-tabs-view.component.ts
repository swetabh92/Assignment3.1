import { Component, OnInit,ElementRef,ViewChild,HostListener, OnDestroy,Input,Output, EventEmitter  } from '@angular/core';
import { FlownService } from '../services/flown.service'
import {FlownListModel,CouponListModel,FlightInfoModel,flownKey} from '../model/flown-model';
@Component({
  selector: 'app-flight-tabs-view',
  templateUrl: './flight-tabs-view.component.html',
  styleUrls: ['./flight-tabs-view.component.css']
})
export class FlightTabsViewComponent implements OnInit {
  viewFlown:FlownListModel;
  couponList:CouponListModel[] = [];
  flightInfo:FlightInfoModel;
  currentTab:string;
  success: any = {
		isSuccess: false,
		successMessage: ''
	};
  @Input('value')
  set value(flown:FlownListModel){
    if(flown && flown.hasOwnProperty(flownKey)){
      this.flownService.viewFlown = this.viewFlown = flown;
      if(!this.currentTab) this.currentTab = 'flight_info';
      this.tabViewRecord(this.currentTab,true);
    }
  }
  @Output() updateFlown = new EventEmitter();
  constructor(private flownService:FlownService) { }
  ngOnInit() {
  }
  tabViewRecord(type,initCall?:boolean){
    if(!initCall && this.currentTab == type) return false;
    this.currentTab = type;
    if(type == 'coupon'){
      this.couponList = undefined;
      this.flownService.getCouponDet(this.viewFlown).subscribe((res:CouponListModel[])=>{
          this.couponList = res;
      })
    } else if(type == 'flight_info')  {
      this.flightInfo = undefined;
      this.flownService.getFlightInfo(this.viewFlown).subscribe((res:FlightInfoModel)=>{
        this.flightInfo = res;
      })
    }
  }
  updateCouponList(obj){
    if(obj["action"] == "add" || obj["action"] == "delete"){
      this.currentTab = '';this.tabViewRecord('coupon');
      (obj["action"] == "add")?this.viewFlown["paxCntsAct"]++:this.viewFlown["paxCntsAct"]=this.viewFlown["paxCntsAct"]-obj["count"]; 
      this.updateFlown.emit(this.viewFlown);
    }
    else if(obj["action"] == "refresh"){
      this.currentTab = '';this.tabViewRecord('coupon');
    }
    this.success = obj;
  }
}
