import {AfterViewChecked, AfterViewInit, Component, OnInit} from '@angular/core';
import {GeneralService} from '../../../commons/services/general.service';
declare var $;

@Component({
  selector: 'app-mail',
  templateUrl: './mail.component.html',
  styleUrls: ['./mail.component.css']
})
export class MailComponent implements OnInit,AfterViewInit{

  constructor(private Gservice: GeneralService) {
   }
  ngOnInit() {
  }
  ngAfterViewInit() {
    this.Gservice.LoadTreeViewJs();
    this.Gservice.LoadProfileSettingJs();
    this.Gservice.LoadFormSettingJs();
    // swal('Any fool can use a computer ');
    $(() => {
      $('.mailbox-messages input[type="checkbox"]').iCheck({
        checkboxClass: 'icheckbox_flat-blue',
        radioClass: 'iradio_flat-blue'
      });
      // Enable check and uncheck all functionality
      $('.checkbox-toggle').click(function () {
        const clicks = $(this).data('clicks');
        if (clicks) {
          // Uncheck all checkboxes
          $('.mailbox-messages input[type="checkbox"]').iCheck('uncheck');
          $('.fa', this).removeClass('fa-check-square-o').addClass('fa-square-o');
        } else {
          // Check all checkboxes
          $('.mailbox-messages input[type="checkbox"]').iCheck('check');
          $('.fa', this).removeClass('fa-square-o').addClass('fa-check-square-o');
        }
        $(this).data('clicks', !clicks);
      });
      // Handle starring for glyphicon and font awesome
      $('.mailbox-star').click(function (e) {
        e.preventDefault();
        // detect type
        const $this = $(this).find('a > i');
        const glyph = $this.hasClass('glyphicon');
        const fa = $this.hasClass('fa');
        // Switch states
        if (glyph) {
          $this.toggleClass('glyphicon-star');
          $this.toggleClass('glyphicon-star-empty');
        }
        if (fa) {
          $this.toggleClass('fa-star');
          $this.toggleClass('fa-star-o');
        }
      });
    });
  }

}
