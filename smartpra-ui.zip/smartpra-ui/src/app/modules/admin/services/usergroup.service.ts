import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import swal from 'sweetalert2';

import { environment } from '../../../../environments/environment';
import { Usergroup } from '../models/usergroup';
import { MessageBoxService } from '../../masters/services/commons/message-box.service';
const httpOptions = {
  // headers: new HttpHeaders({ 'Content-Type': 'multipart/form-data' })
};
const httpOptions1 = {
  headers: new HttpHeaders({ 'Content-Type': 'multipart/form-data' })
};
@Injectable({
  providedIn: 'root'
})
export class UsergroupService {
  globalUrl = environment.apiUrlGlobal;
  masterUrl = environment.apiUrlMaster;
  authUrl = environment.apiUrlauth;
  constructor(private http: HttpClient, private messageBoxService: MessageBoxService) { }
  getUsergroupAll(): Observable<Usergroup[]> {
    return this.http.get<Usergroup[]>(this.authUrl + 'mas-user-groups')
      .pipe(
        tap(_ => this.log('fetched Usergroup details')),
        catchError(this.handleError('getAllUsergroup', []))
      );
  }
  UsergroupByUsergroupId(masUserGroupId: string): Observable<Usergroup> {
    return this.http.get<Usergroup>(this.authUrl + 'mas-user-groups/' + masUserGroupId).pipe(
      tap(_ => this.log(`fetched Usergroup masUserGroupId=${masUserGroupId}`)),
      catchError(this.handleError<Usergroup>(`UsergroupByUsergroupId masUserGroupId=${masUserGroupId}`))
    );
  }
  searchUsergroup(parms: string): Observable<Usergroup> {
    return this.http.get<Usergroup>(this.authUrl + parms).pipe(
      tap(_ => this.log(`search Usergroup masUserGroupId by ${parms}`)),
      catchError(this.handleError<Usergroup>(`search Usergroup masUserGroupId by ${parms}`))
    );
  }
  /** POST: add a new Usergroup to the server */
  addUsergroup(formdata): Observable<Usergroup> {
    // console.log(formdata); return;
    return this.http.post<Usergroup>(this.authUrl + 'mas-user-groups/', formdata, httpOptions).pipe(
      tap(_ => this.log(`added Usergroup masUserGroupId=`)),
      catchError(this.handleError<Usergroup>('addUsergroup'))
    );
  }
  updateUsergroup(usergroup: Usergroup): Observable<any> {
    // console.log(Usergroup.masUserGroupId);
    // console.log(Usergroup);
    return this.http.put<Usergroup>(this.authUrl + 'mas-user-groups/' + usergroup.masUserGroupId, Usergroup, httpOptions).pipe(
      tap(_ => this.log(`updated Usergroup masUserGroupId=${usergroup.masUserGroupId}`)),
      catchError(this.handleError<Usergroup>('addUsergroup'))
    );
  }
  activateUsergroup(masUserGroupId: string): Observable<Usergroup> {
    return this.http.put<Usergroup>(this.authUrl + 'mas-user-groups/activateordeactivate/' + masUserGroupId, httpOptions).pipe(
      tap(_ => this.log(`activate Usergroup masUserGroupId=${masUserGroupId}`)),
      catchError(this.handleError<Usergroup>('activateUsergroup'))
    );
  }
  deactivateUsergroup(masUserGroupId: string): Observable<Usergroup> {
    return this.http.put<Usergroup>(this.authUrl + 'mas-user-groups/activateordeactivate/' + masUserGroupId, httpOptions).pipe(
      tap(_ => this.log(`deactivate Usergroup masUserGroupId=${masUserGroupId}`)),
      catchError(this.handleError<Usergroup>('deactvateUsergroup'))
    );
  }
  private handleError<T>(operation = 'operation', result?: T) {
    return (e: any): Observable<T> => {
      console.log(e);
      const error = e.error.message || e.error.error || e.error.error_description || 'Could not connect server';
      console.log(error);
      this.messageBoxService.getErrorMessage('ERROR', error);
      return of(result as T);
    };
  }
  private log(error: any) {
    console.log(error);
    if (error.message) {
      this.messageBoxService.getErrorMessage('ERROR', error.message);
    }
  }
}

