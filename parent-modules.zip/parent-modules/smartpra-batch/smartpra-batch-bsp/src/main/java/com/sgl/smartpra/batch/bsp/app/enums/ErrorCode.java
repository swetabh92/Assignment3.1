package com.sgl.smartpra.batch.bsp.app.enums;

public enum ErrorCode {
	SALE3001("SALE3001");

	private String value;

	private ErrorCode(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}
