package com.sgl.smartpra.allocation.master.app.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.allocation.master.app.dao.AllocationMasterDao;
import com.sgl.smartpra.allocation.master.app.entity.AllocationMasterEntity;
import com.sgl.smartpra.allocation.master.app.dao.repository.AllocationMasterRepository;

@Component
public class AllocationMasterDaoImpl implements AllocationMasterDao {

    @Autowired
    private AllocationMasterRepository allocationMasterRepository;

    @Override
    public AllocationMasterEntity save(AllocationMasterEntity allocationMasterEntity) {
        return allocationMasterRepository.save(allocationMasterEntity);
    }

    @Override
    public AllocationMasterEntity update(AllocationMasterEntity allocationMasterEntity) {
        return allocationMasterRepository.save(allocationMasterEntity);
    }

    @Override
    public AllocationMasterEntity findById(Integer allocationMasterId) {
        return allocationMasterRepository.getOne(allocationMasterId);
    }

    @Override
    public List<AllocationMasterEntity> findAll(List<Integer> fileMappingId) {
        return null;
    }

    @Override
    public List<AllocationMasterEntity> findByModuleLovId(Integer moduleLovId) {
        return allocationMasterRepository.findByModuleLovId(moduleLovId);
    }

}
