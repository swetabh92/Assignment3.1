import { Component, OnInit ,Input} from '@angular/core';
import {SalesdashboardserviceService} from '../salesdashboardservice.service';
@Component({
  selector: 'app-transcation-account-summary',
  templateUrl: './transcation-account-summary.component.html',
  styleUrls: ['./transcation-account-summary.component.css']
})
export class TranscationAccountSummaryComponent implements OnInit {
  transactionalTotals:any;
  transactionCount:any;
  constructor(private salesService:SalesdashboardserviceService) { }
  @Input('value')
  set value(val:any){
      if(val) {
        this.getTranssactionSummaries(val);
      }
  }
  ngOnInit() {
  }
  getTranssactionSummaries(selectedSale) {
    this.getTransactionsTotals(selectedSale.reportingAgency,selectedSale.agencyCode);
    this.getTransactionsCount(selectedSale.reportingAgency,selectedSale.agencyCode);
  }
  getTransactionsTotals(reportingAgency,agencyCode) {
    /*console.log('THe sales key is  ' + type);*/
    this.salesService.getTransactionsTotals(reportingAgency,agencyCode).subscribe((data) => {
      this.transactionalTotals = data;
     /* console.log(data);*/
      /*this.transactionalTotals.forEach(function (value) {
        console.log(value["paymentType"])
        if(value["paymentType"]=="Taxes"){
          this.taxes=value["total"]
          console.log("IN the for loop"+value["total"])
        }
        else if(value["paymentType"]==="Gross Fare"){
          this.grossFare=value["total"]
          console.log("IN the for loop"+value["total"])

        }
        else if(value["paymentType"]==="fees"){
          this.fees=value["total"+value["total"]]
          console.log("IN the for loop")
        }
        else  if(value["paymentType"]==="Commission"){
          this.commission=value["total"]
          console.log("IN the for loop")
        }
      });*/
    });
  }
  getTransactionsCount(reportingAgency,agencyCode): void {
   /* console.log('THe sales key is  ' + type);*/
    console
    this.salesService.getTransactionsCount(reportingAgency,agencyCode).subscribe(
      data => {
        this.transactionCount = data;
        console.log(data);
      });
  }
  convertDecimal(val){
    if(val == null) val = 0;
    return val.toFixed(2);
  }
  isEmptyReplace(val,replaceString){
    if(val == null || val=="" || val==undefined) return replaceString;
    else return val;
  }
}
