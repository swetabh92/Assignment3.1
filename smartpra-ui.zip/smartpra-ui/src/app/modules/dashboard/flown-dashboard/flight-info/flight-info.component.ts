import { Component, OnInit,Input } from '@angular/core';
import { FormBuilder,FormGroup, Validators } from '@angular/forms';
import {FlightInfoModel} from '../model/flown-model';
import { LovService }  from '../../../masters/services/LOV/lov.service';
import {FlownService} from '../services/flown.service';
import {timer} from 'rxjs';
import { MessageBoxService} from '../../../masters/services/commons/message-box.service'

@Component({
  selector: 'app-flight-info',
  templateUrl: './flight-info.component.html',
  styleUrls: ['./flight-info.component.css']
})
export class FlightInfoComponent implements OnInit {
  infoReadonly:boolean = true;
  readonly:boolean = true;
  flight_tab:boolean = false;
  flight_info:FlightInfoModel;
  constructor(private messageBoxService:MessageBoxService,private flownService:FlownService,private lov:LovService,private formBuilder:FormBuilder) { }
  flightInfo:FormGroup = this.createflightForm();
  @Input('value')
  set values(value:FlightInfoModel){
    if(value){
      this.flight_info = value;
      let status = this.lov.getData('flight_status','flown_dashboard').find((item) => item.fieldValue === this.flight_info["flightStatus"] );
      if(status) value["flightStatus"] = status["label"];
      let category = this.lov.getData('service_type','flown_dashboard').find((item) => item.fieldValue === this.flight_info["flightCatagory"] );
      if(category) value["flightCatagory"] = category["label"];
      this.flightInfo.patchValue(value);
    }
  }
  ngOnInit() {
  }
  
  createflightForm(){
    return this.formBuilder.group({
        flightKey			       : [''],
        aircraftRegistration : [''],
        payloadCapacity		   : [''],
        deadLoadCapacity		 : [''],
        fcabinBlockCapacity	 : [''],
        ccabinBlockCapacity	 : [''],
        wcabinBlockCapacity	 : [''],
        ycabinBlockCapacity	 : [''],
        flyingHours		       : [''],
        flyingDistance		   : [''],
        flightCatagory		   : [''],
        flightStatus		     : [''],
        routeCode		         : [''],
    });
  }
  onEdit(){
    this.infoReadonly = false;
    this.triggerScroll();
  }
  onUpdate(){
    let data = this.flightInfo.value;
    this.flownService.flightInfoUpdate(data).subscribe((res:any)=>{
      if(res && (res["flightKey"] == this.flight_info["flightKey"])){
        this.flightInfo.patchValue(res);
        this.infoReadonly = true;
        this.triggerScroll();
        this.messageBoxService.getSuccessMessage('UPDATE','Successfully updated flight information.');
      }
    })
  }
  onclear(){
    this.infoReadonly = true;
    this.flightInfo.reset();
    this.flightInfo.patchValue(this.flight_info);
    this.triggerScroll();
  }
  triggerScroll(){
    this.flight_tab = true;
    timer(10).subscribe(()=>{
      this.flight_tab = false;
    })
  }
  

}
