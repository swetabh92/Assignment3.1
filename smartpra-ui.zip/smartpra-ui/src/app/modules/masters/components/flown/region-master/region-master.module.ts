import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RegionMasterRoutingModule } from './region-master-routing.module';
import { RegionMasterComponent } from './region-master.component';
import { RegionCountryMasterComponent } from './region-country-master/region-country-master.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { CoreDataModule } from 'src/app/core-data/core-data.module';

@NgModule({
  imports: [
    CommonModule,
    CoreDataModule,
    SharedModule,
    RegionMasterRoutingModule
  ],
  declarations: [
    RegionMasterComponent,
    RegionCountryMasterComponent
  ]
})
export class RegionMasterModule { }
