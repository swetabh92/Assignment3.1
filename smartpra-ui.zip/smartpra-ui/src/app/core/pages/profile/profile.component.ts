import { Component, OnInit, Input, Output, EventEmitter, OnDestroy, ElementRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { GeneralService } from '../../../commons/services/general.service';
import { UserprofileService } from '../../../modules/admin/services/userprofile.service';
// import { UserprofileService } from '../services/userprofile.service';
// import { StandardAreaService } from '../../../masters/services/proration/standard-area-master-service/standard-area.service';
import { StandardAreaService } from '../../../modules/masters/services/proration/standard-area-master-service/standard-area.service';
import { CountryMasterService } from '../../../modules/masters/services/others/country-master/country-master.service';
import { AirportmasterService } from '../../../modules/masters/services/flown/airport-master/airportmasterservice.service';
import { Userprofile } from '../../../modules/admin/models/userprofile';
import { Roleprofile } from '../../../modules/admin/models/roleprofile';
import { Team } from '../../../modules/admin/models/team';
import { Group } from '../../../modules/admin/models/group';
import { RoleprofileService } from '../../../modules/admin/services/roleprofile.service';
import { TeamService } from '../../../modules/admin/services/team.service';
import { GroupService } from '../../../modules/admin/services/group.service';
import { PasswordValidator } from '../../../commons/services/validators/password.validator.service';
import { MustMatch } from '../../../commons/services/validators/must-match.validator.service';
import { Subject } from 'rxjs';
import { first } from 'rxjs/operators';
import swal from 'sweetalert2';
import { DatepickerOptions } from 'ng2-datepicker';
import {CarrierMasterComponent} from "../../../modules/masters/components/others/carrier-master/carrier-master.component";
import {CarrierMasterService} from "../../../modules/masters/services/others/carrier-master/carrier-master.service";
declare var $;



@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit{
  dayPickerConfig : DatepickerOptions = {
    displayFormat: 'MM/DD/YYYY',
    useEmptyBarTitle: false,
    // addClass: 'date-picker',
    // fieldId: 'picker-id',
    addStyle: {'width': '100%'},
  };
  @ViewChild('closeModalAdd') closeModalAdd: ElementRef;
  @ViewChild('closeModalEdit') closeModalEdit: ElementRef;
  dtOptions: any = {};
  // We use this trigger because fetching the list of persons can be quite long,
  // thus we ensure the data is fetched before rendering
  dtTrigger: Subject<any> = new Subject<any>();
  public renderDT = false;
  currentUser = localStorage.getItem('loggedin_email');
  createdBy = 'admin';
  lastUpdatedBy = 'admin';
  collapse_search_form = true;
  box_search_status = true;
  editNewForm: FormGroup;
  editsubmitted = false;
  changePasswordForm: FormGroup;
  changePasswordsubmited = false;
  searchForm: FormGroup;
  searchsubmitted = false;
  searchresult = false;
  searchstring = '';
  checkdata: any;
  usersList$: any;
  userdetail: any;
  previewUrl:any = '';
  selectedFiles: FileList;
  selectedvoiceFiles: FileList;
  countryArray: any = [];
  countryOptions: any = [];
  stateArray: any = [];
  stateOptions: any = [];
  cityArray: any = [];
  cityOptions: any = [];
  langKeyArray: any = [];
  langKeyOptions: any = [];
  preferredLanguageArray: any = [];
  preferredLanguageOptions: any = [];
  isactiveArray: any = [];
  isactiveOptions: any = [];
  groupArray: any = [];
  groupOptions: any = [];
  managerArray: any = [];
  managerOptions: any = [];
  moduleArray: any = [];
  moduleOptions: any = [];
  teamArray: any = [];
  teamOptions: any = [];
  roleArray: any = [];
  roleOptions: any = [];
  airLineCodeArray = [];
  dateOptions: DatepickerOptions = {
    displayFormat: 'MMM-YY',
    useEmptyBarTitle: false,
    addClass: 'currency-date-picker',
    fieldId: 'currency-date-picker-id',
    addStyle: {'width': '100%'},
 };currentPassword: any;
  newPassword: any;
  reTypePassword: any;
  newPasswordFlag: boolean = false;
  currentPasswordFlag: boolean = false;
  reTypePasswordFlag: boolean = false;
  constructor(private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder,
    private generalService: GeneralService,
    private userservice: UserprofileService,
    private roleprofileservice: RoleprofileService,
    private teamservice: TeamService,
    private groupservice: GroupService,
    private countryservice: CountryMasterService,
    private carrierservice : CarrierMasterService,
  ) { }
  ngOnInit() {
    // this.changePasswordValidation();
    this.Getuserdetail();
    this.GetAllairLineCode();
    this.langKeyArray =  [{id: 'en', name: 'English'}];
    this.preferredLanguageArray =  [{id: 'en', name: 'English'}];
    this.isactiveArray =  [{id: '1', name: 'active'}, {id: '0', name: 'inactive'}];
    this.changePasswordForm = this.formBuilder.group({
      lastUpdatedBy: [''], // ['', Validators.required],
      currentPassword: ['', Validators.required],
      newPassword: ['', {
        validators: [
            Validators.required,
            Validators.minLength(8),
            PasswordValidator.strong,        
        ],
        updateOn: 'change'
     }],
     // newPassword: ['', Validators.compose([Validators.required, Validators.minLength(8), PasswordValidator.strong])],
      retypepassword: ['', Validators.required]
      }, {
      validator: MustMatch('newPassword', 'retypepassword'), 
    });

    this.editNewForm = this.formBuilder.group({
      categoryLevel: [''], // ['', Validators.required],
      airLineCode: [''], // ['', Validators.required],
      departmentName: [''], // ['', Validators.required],
      organizationName: [''], // ['', Validators.required],
      displayName: [''], // ['', Validators.required],
      email: [''], // ['', Validators.required],
      firstName: [''], // ['', Validators.required],
      instantOfJoining: [''], // ['', Validators.required],
      // isActive: [''], // ['', Validators.required],
      langKey: [''], // ['', Validators.required],
      lastName: [''], // ['', Validators.required],
      masUsersId: [''], // ['', Validators.required],
      middleName: [''], // ['', Validators.required],
      preferredLanguage: [''], // ['', Validators.required],
      processName: [''], // ['', Validators.required],
      shiftEndTime: [''], // ['', Validators.required],
      shiftStartTime: [''], // ['', Validators.required],
      userAddress1: [''], // ['', Validators.required],
      userAddress2: [''], // ['', Validators.required],
      userAddress3: [''], // ['', Validators.required],
      userEmail: [''], // ['', Validators.required],
      userFullName: [''], // ['', Validators.required],
      userGroupId: [''], // ['', Validators.required],
      userManagerId: [''], // ['', Validators.required],
      //userModuleId: [''], // ['', Validators.required],
      userName: [''], // ['', Validators.required],
      userPhoto: [''], // ['', Validators.required],
      userRemarks: [''], // ['', Validators.required],
      userRoleId: [''], // ['', Validators.required],
      roleId: [''], // ['', Validators.required],
      userTeamId: [''], // ['', Validators.required],
      userTelephone: [''], // ['', Validators.required],
      // voiceProfile: [''], // ['', Validators.required],
      lastUpdatedBy: [''], // ['', Validators.required],
      passwordHash: [''], // ['', Validators.required],
    });
  }

  changePasswordValidation(type){
    if(type == 'old'){
      console.log(this.changePasswordForm.controls['currentPassword'].value);
        this.currentPassword = this.changePasswordForm.controls['currentPassword'].value;
        if(this.currentPassword == this.newPassword || this.currentPassword == this.reTypePassword){
          this.changePasswordForm.controls['currentPassword'].setErrors({mustMatch: true})       
        } 
    }
    if(type == 'new'){
        this.newPassword = this.changePasswordForm.controls['newPassword'].value;
        if(this.newPassword == this.currentPassword){
          this.changePasswordForm.controls['newPassword'].setErrors({mustMatch: true})
        }
    }
    if(type == 'confirm'){
        this.reTypePassword = this.changePasswordForm.controls['retypepassword'].value;
        if(this.reTypePassword == this.currentPassword){
          this.changePasswordForm.controls['reTypePassword'].setErrors({mustMatch: true})    
        } 
    }
  }

  onSelectFile(event) {
    if (event.target.files && event.target.files[0]) {
      const reader = new FileReader();
      this.selectedFiles = event.target.files;
      reader.readAsDataURL(event.target.files[0]); // read file as data url

      reader.onload = (event) => { // called once readAsDataURL is completed
        this.previewUrl = event.target.result;
      };
    }
  }

  GetAllairLineCode(): void {
    this.carrierservice.getAllCarrierList().subscribe((res: any[]) => {
      this.airLineCodeArray = res;
    });
  }
  onSelectVoiceFile(event) {
    if (event.target.files && event.target.files[0]) {
      const reader = new FileReader();
      this.selectedvoiceFiles = event.target.files;
      reader.readAsDataURL(event.target.files[0]); // read file as data url
    }
  }
  Getuserdetail() {
   //  let currentUserId = localStorage.getItem('loggedin_email');
   //  alert(currentUserId);
   // this.searchForm.value.email = localStorage.getItem('loggedin_email');
   // this.userservice.searchUserprofile({ 'email': localStorage.getItem('loggedin_email') }).subscribe(
   //      userservice => {
   //      if (!!userservice && userservice.userId) {
   //        this.userdetail = userservice;
   //      }
   //    });
  }
  onResetChangePassword() {
    this.changePasswordForm.reset();
  }
  onResetChange() {
  }

  OnItemDeSelectGroup(){

  }

  OnItemSelectGroup(){

  }

  onResetAdd() {
  }
  get c() { return this.changePasswordForm.controls; }
  onSubmitChangePassword() {
    this.changePasswordsubmited = true;
    // console.log(this.editNewForm);
    // stop here if form is invalid
    if (this.changePasswordForm.invalid) {
      return;
    } else {
      console.log(this.changePasswordForm.value); // return;
      this.userservice.UserPasswordUpdate(this.changePasswordForm.value)
      .subscribe(
        res => {
          console.log(res);
          if (res === null) {
            swal(
              'Success',
              'successfully updated password',
              'success'
            );
            this.changePasswordForm.reset();
            this.changePasswordsubmited = false;
          }
        });
    }
  }
  onResetUpdateUser() {
  }
  get u() { return this.editNewForm.controls; }
  UpdateUser() {
    this.editsubmitted = true;
    // console.log(this.editNewForm);
    // stop here if form is invalid
    if (this.editNewForm.invalid) {
      swal(
        'Error',
        'sorry error in the form',
        'error'
      );
      return;
    } else {
      // console.log(this.editNewForm.value); return;
      this.userservice.updateUserprofile(this.editNewForm.value).subscribe(
        userservice => {
          if (!!userservice && userservice.userId) {
            swal(
              'Updated!',
              'Userprofile has been Updated.',
              'success'
            );
          }
        });
    }
  }


}
