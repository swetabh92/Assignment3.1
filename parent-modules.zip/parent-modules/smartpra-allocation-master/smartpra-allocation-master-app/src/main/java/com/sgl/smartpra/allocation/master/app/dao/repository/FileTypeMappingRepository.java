package com.sgl.smartpra.allocation.master.app.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.sgl.smartpra.allocation.master.app.entity.FileTypeMappingEntity;

public interface FileTypeMappingRepository
		extends JpaRepository<FileTypeMappingEntity, Integer>, JpaSpecificationExecutor<FileTypeMappingEntity> {

}
