import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {PaginationService} from "../../../../commons/services/pagination/pagination.service";
import {ExceptionManagementModel} from "../models/excpetion-management-model";
import {ExceptionManagementService} from "../../../masters/services/dashboard/exception-management.service";
import {ExceptionTransactionModel} from "../models/excpetion-transaction-model";
import * as _ from "underscore";

@Component({
  selector: 'app-exception-transaction-table',
  templateUrl: './exception-transaction-table.component.html',
  styleUrls: ['../excpetion-management.component.css']
})
export class ExceptionTransactionTableComponent implements OnInit {

  @Output() exceptionModel = new EventEmitter<ExceptionManagementModel>();

  @Input('requestParams')
  set requestParams(requestParams: any) {
    this.getTransactionData(requestParams);
  }

  constructor(private paginateService: PaginationService, private exceptionManagementService: ExceptionManagementService) {
  }

  model: ExceptionManagementModel = new ExceptionManagementModel(this.paginateService);
  page: any = this.paginateService.setCustomPaginationConfig({"pageSize": 5});


  ngOnInit() {

  }

  onPageChange(pageInfo) {
    this.page = _.extend(this.page, pageInfo);
    this.getTransactionData(this.model.searchParams);
  }

  parsePagedResponseObject(resultData: any) {
    this.page.count = resultData.totalCount;
    this.page.totalElements = resultData.totalCount;
    this.page.totalPages = parseInt(String(this.page.totalElements / this.page.size));
  }

  getTransactionData(requestParams: any) {
    if (requestParams) {
      this.model.exceptionStatus = requestParams.exceptionStatus;
      this.model.moduleName = requestParams.moduleName;
      this.exceptionManagementService.getAllExceptions(requestParams, this.page).subscribe((res: ExceptionTransactionModel) => {
        if (res && res.exceptionsViewModelList) {
          this.model['resultData'] = res;
          this.parsePagedResponseObject(res);
          this.exceptionModel.emit(this.model)
        }
      });
    }
  }

  onSelect(selected: any) {
    this.model.selected.splice(0, this.model.selected.length);
    this.model.selected.push(...selected);
  }

}
