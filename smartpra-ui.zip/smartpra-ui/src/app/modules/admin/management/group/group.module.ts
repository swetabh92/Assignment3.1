import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GroupRoutingModule } from './group-routing.module';
import { GroupComponent } from './group.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { CoreDataModule } from 'src/app/core-data/core-data.module';

@NgModule({
  imports: [
    CommonModule,
    CoreDataModule,
    SharedModule,
    GroupRoutingModule
  ],
  declarations: [
    GroupComponent
  ]
})
export class GroupModule { }
