import { Component, OnInit, Input, Output } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';

import { GeneralService } from '../../../commons/services/general.service';
import { AuthenticationService } from '../../../core/authentication/auth-gaurd-service/_services/authentication.service';
import swal from 'sweetalert2';
import { Cookie } from 'ng2-cookies';
import { tokenKey } from '@angular/core/src/view';
import { UserprofileService } from "../../../modules/admin/services/userprofile.service";
import { TranslateService } from "../../../commons/translate/transalation.service";
import { StorageConstants } from "../../../commons/constants/storage-constants";
import { ResourceLoader } from '@angular/compiler';

declare var $;
declare var jQuery: any;
declare var iCheck;

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  error: any;
  userObj: any;

  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private authenticationService: AuthenticationService,
    private gservice: GeneralService,
    private userservice: UserprofileService,
    private translate: TranslateService
  ) {
  }

  ngOnInit() {
    this.displayUsername();
  }

  displayUsername() {
  }

  // logout() {
  //   console.log('logout function called');
  //   this.authenticationService.logout()
  //     .pipe(first())
  //     .subscribe(
  //       data => {      
  //         console.log(data);
  //         localStorage.clear();     
  //         // console.log(localStorage.getItem('token'));
  //         swal(
  //           'success',
  //           'Logged out successfull',
  //           'success'
  //         );
  //         setTimeout(() => {
  //           this.router.navigate(['login']);
  //         }, 100);
  //       },
  //       error => {    
  //         console.log(error);
  //         const err = error.error.message || error.error.error_description || error.error.error || 'Could not connect server';
  //         console.log(err);
  //         swal(
  //           'success',
  //           'Logged out successfull',
  //           'success'
  //         );
  //         setTimeout(() => {
  //           this.router.navigate(['login']);
  //         }, 100);
  //       });

  // }

  logout() {
    this.authenticationService.logout();
    localStorage.clear();
    localStorage.setItem('logout-event', 'logout' + Math.random());
    // Cookie.delete('access_token');
    // Cookie.delete('refresh_token');
    this.router.navigate(['/login'])
    swal(
      'success',
      'Logged out successfull',
      'success'
    );
  }

  chooseLanguage(languageCode: string): void {
    localStorage.setItem(StorageConstants.CURRENT_LANG, languageCode);
    this.translate.use(languageCode);
  }
}
