package com.sgl.smartpra.allocation.master.model;

import com.sgl.smartpra.common.model.BaseModel;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class FileType extends BaseModel {
	
	private static final long serialVersionUID = 8485626047479066519L;

	private Integer fileTypeId;
	private String clientId;
	private String fileTypeName;
}
