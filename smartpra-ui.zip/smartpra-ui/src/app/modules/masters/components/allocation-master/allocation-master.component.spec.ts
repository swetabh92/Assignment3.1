import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllocationMasterComponent } from './allocation-master.component';

describe('AllocationMasterComponent', () => {
  let component: AllocationMasterComponent;
  let fixture: ComponentFixture<AllocationMasterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllocationMasterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllocationMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
