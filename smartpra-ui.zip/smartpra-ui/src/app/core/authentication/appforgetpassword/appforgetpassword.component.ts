import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appforgetpassword',
  templateUrl: './appforgetpassword.component.html',
  styleUrls: ['./appforgetpassword.component.css']
})
export class AppforgetpasswordComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
