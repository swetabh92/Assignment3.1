package com.sgl.smartpra.batch.global.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sgl.smartpra.batch.global.app.entity.InboundFileLogEntity;

@Repository
public interface InboundFileLogRepository extends JpaRepository<InboundFileLogEntity, Integer> {

	@Query("select inboundFileId from InboundFileLogEntity a  where a.inboundFileId = :inboundFileId ")
	public String getInboundFileId(@Param("inboundFileId") Integer inboundFileId);

	@Query("select a from InboundFileLogEntity a  where a.inboundFileName = :inboundFileName ")
	public List<InboundFileLogEntity> getInboundFilesByName(@Param("inboundFileName") String inboundFileName);

}
