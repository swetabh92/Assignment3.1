package com.sgl.smartpra.batch.bsp.app.config;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.support.ClassifierCompositeItemProcessor;
import org.springframework.batch.item.support.ClassifierCompositeItemWriter;
import org.springframework.batch.item.validator.SpringValidator;
import org.springframework.batch.item.validator.Validator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.classify.Classifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

import com.sgl.smartpra.batch.bsp.app.domain.staging.BSPStagingDomainObject;
import com.sgl.smartpra.batch.bsp.app.domain.staging.BillingCycleHeaderStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.BillingCycleTotalsStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.FileHeaderStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.FileTotalsStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.OfficeHeaderWrapperStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.OfficeTotalsStg;
import com.sgl.smartpra.batch.bsp.app.listener.BSPStagingLoadJobExecutionListener;
import com.sgl.smartpra.batch.bsp.app.listener.StepErrorLoggingListener;
import com.sgl.smartpra.batch.bsp.app.processor.BSPBaseItemProcessor;
import com.sgl.smartpra.batch.bsp.app.processor.BillingCycleHeaderProcessor;
import com.sgl.smartpra.batch.bsp.app.processor.BillingCycleTotalsProcessor;
import com.sgl.smartpra.batch.bsp.app.processor.FileHeaderProcessor;
import com.sgl.smartpra.batch.bsp.app.processor.FileTotalsProcessor;
import com.sgl.smartpra.batch.bsp.app.processor.OfficeHeaderProcessor;
import com.sgl.smartpra.batch.bsp.app.processor.OfficeTotalsProcessor;
import com.sgl.smartpra.batch.bsp.app.reader.BSPItemReader;
import com.sgl.smartpra.batch.bsp.app.record.BSPBaseRecord;
import com.sgl.smartpra.batch.bsp.app.record.BillingCycleHeader;
import com.sgl.smartpra.batch.bsp.app.record.BillingCycleTotals;
import com.sgl.smartpra.batch.bsp.app.record.FileHeader;
import com.sgl.smartpra.batch.bsp.app.record.FileTotals;
import com.sgl.smartpra.batch.bsp.app.record.OfficeHeader;
import com.sgl.smartpra.batch.bsp.app.record.OfficeTotals;
import com.sgl.smartpra.batch.bsp.app.service.BSPFileDetailsFinderTasklet;
import com.sgl.smartpra.batch.bsp.app.service.FileLoggerTasklet;
import com.sgl.smartpra.batch.bsp.app.writer.BillingCycleHeaderWriter;
import com.sgl.smartpra.batch.bsp.app.writer.BillingCycleTotalsWriter;
import com.sgl.smartpra.batch.bsp.app.writer.FileHeaderWriter;
import com.sgl.smartpra.batch.bsp.app.writer.FileTotalsWriter;
import com.sgl.smartpra.batch.bsp.app.writer.OfficeHeaderWrapperWriter;
import com.sgl.smartpra.batch.bsp.app.writer.OfficeHeaderWriter;
import com.sgl.smartpra.batch.bsp.app.writer.OfficeTotalsWriter;

@Configuration
@EnableBatchProcessing
public class BSPBatchConfiguration {

	@Autowired
	private JobBuilderFactory jobBuilderFactory;

	@Autowired
	private StepBuilderFactory stepBuilderFactory;

	@Autowired
	private BSPItemReader bspItemReader;

	@Autowired
	private BSPFileDetailsFinderTasklet bspFileDetailsFinderTasklet;

	@Autowired
	private FileLoggerTasklet fileLoggerTasklet;

	@Autowired
	private PlatformTransactionManager transactionManager;

	@Autowired
	private BSPStagingLoadJobExecutionListener jobExecutionListener;

	@Bean
	public Job loadBSPFileDataToStagingJob(Step logFile, Step getFileDetails, Step extractFileDataToStaging) {

		// @formatter:off
		return jobBuilderFactory
				.get("loadBSPFileDataToStagingJob")
				.incrementer(new RunIdIncrementer())
				.start(logFile)
				.next(getFileDetails)
				.next(extractFileDataToStaging)
				.listener(jobExecutionListener)
				.build();
		// @formatter:on
	}

	@Bean
	public Step logFile() {

		// @formatter:off
		return stepBuilderFactory
				.get("logFile")
				.tasklet(fileLoggerTasklet)
				.listener(stepErrorLoggingListener())
				.build();
		// @formatter:on
	}

	@Bean
	public Step getFileDetails() {

		// @formatter:off
		return stepBuilderFactory
				.get("getFileDetails")
				.tasklet(bspFileDetailsFinderTasklet)
				.listener(stepErrorLoggingListener())
				.build();
		// @formatter:on
	}

	@Bean
	public Step extractFileDataToStaging() {

		// @formatter:off
		return stepBuilderFactory
				.get("extractFileDataToStaging")
				.<BSPBaseRecord, BSPStagingDomainObject>chunk(10)
				.reader(bspItemReader)
				.processor(bspItemProcessor())
				.writer(bspItemWriter())
				.transactionManager(transactionManager)
				.listener(stepErrorLoggingListener())
				.build();
		// @formatter:on
	}

	@Bean
	public BSPItemReader bspItemReader() {
		return bspItemReader;
	}

	@Bean
	@StepScope
	public StepErrorLoggingListener stepErrorLoggingListener() {
		return new StepErrorLoggingListener();
	}

	@Bean
	public ItemProcessor<BSPBaseRecord, BSPStagingDomainObject> bspItemProcessor() {
		ClassifierCompositeItemProcessor<BSPBaseRecord, BSPStagingDomainObject> classifierCompositeItemProcessor = new ClassifierCompositeItemProcessor<>();
		classifierCompositeItemProcessor
				.setClassifier(new Classifier<BSPBaseRecord, ItemProcessor<?, ? extends BSPStagingDomainObject>>() {

					private static final long serialVersionUID = 1L;

					@Override
					public ItemProcessor<BSPBaseRecord, ? extends BSPStagingDomainObject> classify(
							BSPBaseRecord classifiable) {
						if (classifiable instanceof FileHeader) {
							return getFileHeaderProcessor();
						} else if (classifiable instanceof FileTotals) {
							return getFileTotalsProcessor();
						} else if (classifiable instanceof BillingCycleHeader) {
							return getBillingCycleHeaderProcessor();
						} else if (classifiable instanceof BillingCycleTotals) {
							return getBillingCycleTotalsProcessor();
						} else if (classifiable instanceof OfficeHeader) {
							return getOfficeHeaderProcessor();
						} else if (classifiable instanceof OfficeTotals) {
							return getOfficeTotalsProcessor();
						}

						return null;
					}

				});

		return classifierCompositeItemProcessor;

	}

	@Bean
	@StepScope
	public ItemWriter<? super BSPStagingDomainObject> bspItemWriter() {

		ClassifierCompositeItemWriter<BSPStagingDomainObject> classifierCompositeItemWriter = new ClassifierCompositeItemWriter<>();
		classifierCompositeItemWriter
				.setClassifier(new Classifier<BSPStagingDomainObject, ItemWriter<? super BSPStagingDomainObject>>() {

					private static final long serialVersionUID = 1L;

					@Override
					public ItemWriter<? super BSPStagingDomainObject> classify(BSPStagingDomainObject classifiable) {
						if (classifiable instanceof FileHeaderStg) {
							return getFileHeaderWriter();
						} else if (classifiable instanceof BillingCycleHeaderStg) {
							return getBillingCycleHeaderWriter();
						} else if (classifiable instanceof OfficeHeaderWrapperStg) {
							return getOfficeHeaderWrapperWriter();
						} else if (classifiable instanceof OfficeTotalsStg) {
							return getOfficeTotalsWriter();
						} else if (classifiable instanceof BillingCycleTotalsStg) {
							return getBillingCycleTotalsWriter();
						} else if (classifiable instanceof FileTotalsStg) {
							return getFileTotalsWriter();
						} else {
							// Not a possible case
							return null;
						}
					}
				});

		return classifierCompositeItemWriter;
	}

	// inject processors

	@Bean
	@StepScope
	public BSPBaseItemProcessor getBillingCycleHeaderProcessor() {
		return new BillingCycleHeaderProcessor();
	}

	@Bean
	@StepScope
	public BSPBaseItemProcessor getBillingCycleTotalsProcessor() {
		return new BillingCycleTotalsProcessor();
	}

	@Bean
	@StepScope
	public BSPBaseItemProcessor getFileHeaderProcessor() {
		return new FileHeaderProcessor();
	}

	@Bean
	@StepScope
	public BSPBaseItemProcessor getFileTotalsProcessor() {
		return new FileTotalsProcessor();
	}

	@Bean
	@StepScope
	public BSPBaseItemProcessor getOfficeHeaderProcessor() {
		return new OfficeHeaderProcessor();
	}

	@Bean
	@StepScope
	public BSPBaseItemProcessor getOfficeTotalsProcessor() {
		return new OfficeTotalsProcessor();
	}

	// inject writers

	@Bean
	@StepScope
	public ItemWriter<? super BSPStagingDomainObject> getFileHeaderWriter() {
		return new FileHeaderWriter();
	}

	@Bean
	@StepScope
	public ItemWriter<? super BSPStagingDomainObject> getBillingCycleHeaderWriter() {
		return new BillingCycleHeaderWriter();
	}

	@Bean
	@StepScope
	public ItemWriter<? super BSPStagingDomainObject> getOfficeHeaderWrapperWriter() {
		return new OfficeHeaderWrapperWriter();
	}

	@Bean
	@StepScope
	public ItemWriter<? super BSPStagingDomainObject> getOfficeHeaderWriter() {
		return new OfficeHeaderWriter();
	}

	@Bean
	@StepScope
	public ItemWriter<? super BSPStagingDomainObject> getOfficeTotalsWriter() {
		return new OfficeTotalsWriter();
	}

	@Bean
	@StepScope
	public ItemWriter<? super BSPStagingDomainObject> getBillingCycleTotalsWriter() {
		return new BillingCycleTotalsWriter();
	}

	@Bean
	@StepScope
	public ItemWriter<? super BSPStagingDomainObject> getFileTotalsWriter() {
		return new FileTotalsWriter();
	}

	@Bean
	public org.springframework.validation.Validator validator() {
		return new org.springframework.validation.beanvalidation.LocalValidatorFactoryBean();
	}

	@Bean
	public Validator<BSPBaseRecord> springValidator() {
		SpringValidator<BSPBaseRecord> springValidator = new SpringValidator<>();
		springValidator.setValidator(validator());
		return springValidator;
	}
}
