import { Component, OnInit, ViewChild, Input, Output, ElementRef, OnDestroy } from '@angular/core';
import { GeneralService } from '../../../../../../commons/services/general.service';
import { ActivatedRoute } from '@angular/router';
import { RegioncountrymasterService } from '../../../../services/flown/region-master/region-country-master/regioncountrymaster.service';
import { CountryMasterService } from '../../../../services/others/country-master/country-master.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Region } from '../../../../models/flown/region.model';
import { MessageBoxService } from '../../../../services/commons/message-box.service';
import { Subject } from 'rxjs';
import swal from 'sweetalert2';
import { RegionCountry } from '../../../../models/flown/region-country.model';


@Component({
  selector: 'app-region-country-master',
  templateUrl: './region-country-master.component.html',
  styleUrls: ['./region-country-master.component.css']
})
export class RegionCountryMasterComponent implements OnInit, OnDestroy {
  @ViewChild('closeModalAdd') closeModalAdd: ElementRef;
  @ViewChild('closeModalEdit') closeModalEdit: ElementRef;
  @Input() regionCode: string;
  dtOptions: DataTables.Settings = {};
  // We use this trigger because fetching the list of persons can be quite long,
  // thus we ensure the data is fetched before rendering
  dtTrigger: Subject<any> = new Subject<any>();
  public renderDT = false;
  createdBy = 'admin';
  lastUpdatedBy = 'admin';
  successresult: any;
  regionDetailsList: RegionCountry[] = [];
  regionDetails: RegionCountry;
  marked = false;
  p: number;
  collapse_add_form = true;
  collapse_edit_form = true;
  box_add_status = false;
  box_edit_status = false;
  addNewRegionCountryForm: FormGroup;
  addNewsubmitted = false;
  editsubmittedForm: FormGroup;
  editsubmitted = false;
  searchForm: FormGroup;
  searchsubmitted = false;
  searchresult = false;
  searchstring: any;
  box_search_status = false;
  collapse_search_form = true;
  countryList: any = [];

  constructor(private Gservice: GeneralService, private regionCountryService: RegioncountrymasterService, private formBuilder: FormBuilder,private activatedRoute: ActivatedRoute,private countryService: CountryMasterService, private messageBoxService: MessageBoxService) { }

  ngOnInit() {
    this.addNewRegionCountryForm = this.formBuilder.group({
      createdBy: ['admin'],
      regionCode: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(3)]],
      countryCode: ['', [Validators.required]],
    });
    this.editsubmittedForm = this.formBuilder.group({
      lastUpdatedBy: ['admin'],
      regionCountryId :['',[Validators.required]],
      regionCode: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(3)]],
      countryCode: ['', [Validators.required]],
    });
    this.searchForm = this.formBuilder.group({
      regionCode: ['',],
      countryCode: [''],
    });
    this.GetAllRegions(this.regionCode);
    this.GetAllCountries();
    let orderFalse =  [-1];
    this.dtOptions = this.Gservice.getDataTableOptionsNew(orderFalse);
  }

  GetAllRegions(regionCode : string): void {
    this.renderDT = false;
    this.regionCode = regionCode;
    this.regionCountryService.getAllRegionCountryList(this.regionCode).subscribe((res: RegionCountry[]) => {
      this.regionDetailsList = res.map(region =>{
        setTimeout(() => {
          this.renderDT = true;
        }, 100);
      return region;
    }); 
    });
  }

  GetAllCountries(): void {
    this.countryService.getAllCountries().subscribe((res: any[]) => {
      this.countryList = res;
    });
  }



  get f() { return this.addNewRegionCountryForm.controls; }
  get u() { return this.editsubmittedForm.controls; }

  onSearch(): void {
    this.searchsubmitted = true;
    this.searchstring = 'regions/' + this.regionCode + '/details?';
    if (this.searchForm.value.countryCode) {
      this.searchstring += 'countryCode=' + this.searchForm.value.countryCode;
    }
    this.renderDT = false;
    this.regionCountryService.searchRegionCountryDetails(this.searchstring).subscribe(
      regionCountryService => {
        this.regionDetailsList = regionCountryService;
        setTimeout(() => {
          this.renderDT = true;
        }, 100);
      });
  }

  onResetSearch() {
    this.searchForm.reset();
    this.searchForm.patchValue({
      regionCode:this.regionCode,
    });
    this.renderDT = false;
    this.GetAllRegions(this.regionCode);
  }

  showSearchBox(e) {
    this.box_search_status = !this.box_search_status;
    this.collapse_search_form = true;
    this.box_add_status = false;
    this.box_edit_status = false;
  }

  addNewRegionCountry(): void {
    this.addNewsubmitted = true;
    // stop here if form is invalid
    if (this.addNewRegionCountryForm.invalid) {
      return;
    } else {
      const region = Object.assign({}, this.addNewRegionCountryForm.value)
      delete(region.regionCode);
      this.closeModalAdd.nativeElement.click();
      this.regionCountryService.addRegionCountry(this.addNewRegionCountryForm.value, region).subscribe(
        regionCountryService => {
          if (!!regionCountryService && regionCountryService.regionCode) {
            this.regionDetailsList.push(regionCountryService);
            swal(
              'Success',
              'New Records Added',
              'success'
            );
            this.onResetAdd();
            this.GetAllRegions(regionCountryService.regionCode);
          }
        });
    }
  }

  onResetAdd():void {
    this.addNewRegionCountryForm.reset();
    this.addNewRegionCountryForm.markAsPristine();
    this.addNewRegionCountryForm.markAsUntouched();
    this.addNewRegionCountryForm.updateValueAndValidity();
    this.addNewsubmitted = false;
    this.addNewRegionCountryForm.patchValue({
      regionCode:this.regionCode,
      createdBy:'admin',
    });
  }

  onResetEdit(code): void {
    this.editsubmittedForm.reset();
    this.editsubmittedForm.markAsPristine();
    this.editsubmittedForm.markAsUntouched();
    this.editsubmittedForm.updateValueAndValidity();
    this.editsubmitted = false;
    this.editsubmittedForm.patchValue({
      lastUpdatedBy: 'admin',
      regionCode: this.regionCode,
      regionCountryId: code
    });
  }

  showEditvalues(getCode, getId) {
    this.regionCountryService.getRegionCountryByRegionCodeAndRegionCountryId(getCode, getId).subscribe(
      regionCountryService => {
        if (!!regionCountryService && regionCountryService.regionCode) {
          this.editsubmittedForm.patchValue({
            regionCountryId: regionCountryService['regionCountryId'],
            regionCode: regionCountryService['regionCode'],
            countryCode: regionCountryService['countryCode'],
            lastUpdatedBy : 'admin',
          });
          this.box_search_status = false;
        } else {
          swal(
            'Error',
            'sorry error fetching record',
            'error'
          );
        }
      });
  }

  showAddValues(){
    this.addNewRegionCountryForm.patchValue({
      regionCode: this.regionCode,
    });
  }

  showCopyValues(regionId,regionCountryId): void {
    this.regionCountryService.getRegionCountryByRegionCodeAndRegionCountryId(regionId,regionCountryId).subscribe(
      response => {
        if (!!response && response.regionCode) {
          this.addNewRegionCountryForm.patchValue({
            regionCountryId: response['regionCountryId'],
            regionCode: response['regionCode'],
            countryCode: response['countryCode'],
            createdBy : 'admin',
          });
          this.box_search_status = false;
        } else {
          this.messageBoxService.showFetchErrorMessage();
        }
      });
  }

  onUpdate():void {
    this.editsubmitted = true;
    if (this.editsubmittedForm.invalid) {
      return;
    } else {
      const regionDetails = Object.assign({}, this.editsubmittedForm.value)
      delete(regionDetails.regionCode);
      delete(regionDetails.regionCountryId);
      this.closeModalEdit.nativeElement.click();
      this.regionCountryService.updateRegionCountry(this.editsubmittedForm.value, regionDetails).subscribe(
        regionCountryService => {
          if (!!regionCountryService && regionCountryService.regionCode) {
            const ix = regionCountryService ? this.regionDetailsList.findIndex(h => h.regionCode === regionCountryService.regionCode) : -1;
            this.closeModalEdit.nativeElement.click();
            if (ix > -1) { this.regionDetailsList[ix] = regionCountryService; }
            this.GetAllRegions(regionCountryService.regionCode);
            swal(
              'Success!',
              'Record has been successfully saved',
              'success'
            );
          }
        });
    }
  }

  collapseSearchform(event) {
    const targetclass = event.target.className;
    console.log(targetclass);
    if (targetclass === 'btn btn-box-tool fa fa-angle-up') {
      this.collapse_search_form = !this.collapse_search_form;
      event.target.className = 'btn btn-box-tool fa fa-angle-down';
    } else if (targetclass === 'btn btn-box-tool fa fa-angle-down') {
      this.collapse_search_form = !this.collapse_search_form;
      event.target.className = 'btn btn-box-tool fa fa-angle-up';
    }
  }

  toggleVisibility(e) {
    this.marked = e.target.checked;
  }
  
  removeafterDeactivate(regionDetails: RegionCountry): void {
    this.regionDetailsList = this.regionDetailsList.filter(h => h !== regionDetails);
  }

  removeRegionCountry(region, e, regionCode: string, regionCountryId: number) {
    swal({
      type: 'warning',
      title: 'Are you sure to delete this region country mapping?',
      text: 'You will not be able to recover the data of Region',
      showCancelButton: true,
      confirmButtonColor: '#049F0C',
      cancelButtonColor: '#ff0000',
      confirmButtonText: 'Yes, deactivate it!',
      cancelButtonText: 'No, keep it as active',
      closeOnClickOutside: false,
      closeOnEsc: false,
      allowOutsideClick: false,
    } as any).then((result) => {
      if (result.value) {
        this.regionCountryService.deleteRegionCountry(regionCode, regionCountryId).subscribe(
          data => {
            console.log('data->' + data);
          }, error => {
            console.log('error->' + error);
          });
        swal(
          'Deactivated!',
          'Region Country has been deactivated.',
          'success'
        );
        this.removeafterDeactivate(region);
      } else if (
        result.dismiss === swal.DismissReason.cancel
      ) {
        e.target.checked = true;
        swal(
          'Cancelled',
          'Region Country status unchanged',
          'error'
        );
      }
    });
  }

  onCancelChange(){
    this.onResetAdd();
    this.onResetEdit(null);
    }

  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }

}
