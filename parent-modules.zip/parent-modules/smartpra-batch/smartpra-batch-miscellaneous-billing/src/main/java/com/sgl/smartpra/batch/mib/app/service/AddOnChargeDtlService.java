/**
 * 
 */
package com.sgl.smartpra.batch.mib.app.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.batch.mib.app.mapper.AddOnChargeDtlMapper;
import com.sgl.smartpra.mib.entity.MiscBillingAddOnChargeDtlEntity;
import com.sgl.smartpra.mib.jaxb.standard.AddOnCharges;
import com.sgl.smartpra.mib.jaxb.standard.InvoiceSummary;

import lombok.extern.slf4j.Slf4j;

/**
 * @author kanprasa
 *
 */
@Service
@Slf4j
public class AddOnChargeDtlService {

	@Autowired
	private AddOnChargeDtlMapper addOnChargeDtlMapper;
	
	public List<AddOnCharges> getAddOnChargeDetails(List<MiscBillingAddOnChargeDtlEntity> addOnChargeDtlEntityList) {
		List<AddOnCharges> addOnChargesList = new ArrayList<>();
		for (MiscBillingAddOnChargeDtlEntity aocEntity : addOnChargeDtlEntityList) {
			AddOnCharges addOnCharges = new AddOnCharges();
			addOnChargeDtlMapper.mapEntityToAddOnChargeDtl(aocEntity, addOnCharges);
			if(aocEntity.getAddOnChargePercentage() != null) {
				addOnCharges.setAddOnChargePercentage(aocEntity.getAddOnChargePercentage().toString());
			}
			addOnChargesList.add(addOnCharges);
		}
		return addOnChargesList;
	}
	public List<InvoiceSummary.AddOnCharges> getAddOnChargeDetailsForInvSummary(List<MiscBillingAddOnChargeDtlEntity> addOnChargeDtlEntityList) {
		List<InvoiceSummary.AddOnCharges> addOnChargesList = new ArrayList<>();
		for (MiscBillingAddOnChargeDtlEntity aocEntity : addOnChargeDtlEntityList) {
			InvoiceSummary.AddOnCharges addOnCharges = new InvoiceSummary.AddOnCharges();
			addOnChargeDtlMapper.mapEntityToAddOnChargeDtlForInvSummary(aocEntity, addOnCharges);
			if(aocEntity.getAddOnChargePercentage() != null) {
				addOnCharges.setAddOnChargePercentage(aocEntity.getAddOnChargePercentage().toString());
			}

			addOnChargesList.add(addOnCharges);
		}
		return addOnChargesList;
	}
}
