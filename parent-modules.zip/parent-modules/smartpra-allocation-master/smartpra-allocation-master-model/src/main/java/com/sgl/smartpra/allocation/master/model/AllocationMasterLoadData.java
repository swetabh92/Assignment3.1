package com.sgl.smartpra.allocation.master.model;

import java.io.Serializable;
import java.util.Map;

import lombok.Data;

@Data
public class AllocationMasterLoadData implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer lovModuleId;
	
	private String moduleName;

	private Map<Integer, String> fileTypes;

	private String referenceTableName;

	private Map<Integer, String> referenceData;
}
