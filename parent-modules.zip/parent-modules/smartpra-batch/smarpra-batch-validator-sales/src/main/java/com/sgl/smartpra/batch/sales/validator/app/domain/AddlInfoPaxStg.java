package com.sgl.smartpra.batch.sales.validator.app.domain;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the addl_info_pax_stg database table.
 * 
 */
@Entity
@Table(name="addl_info_pax_stg")
public class AddlInfoPaxStg extends BSPRecord implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="addl_info_pax_rec_id")
	private int addlInfoPaxRecId;

	@Column(name="check_digit")
	private String checkDigit;

	@Column(name="created_by")
	private String createdBy;

	@Column(name="created_date")
	private Timestamp createdDate;

	@Column(name="date_of_birth")
	private String dateOfBirth;

	@Column(name="date_of_issue")
	private String dateOfIssue;

	private String filler;

	@Column(name="last_updated_by")
	private String lastUpdatedBy;

	@Column(name="last_updated_date")
	private Timestamp lastUpdatedDate;

	@Column(name="passenger_name")
	private String passengerName;

	@Column(name="passenger_specific_data")
	private String passengerSpecificData;

	@Column(name="passenger_type_code")
	private String passengerTypeCode;

	@Column(name="seq_number")
	private String seqNumber;

	@Column(name="std_message_identifier")
	private String stdMessageIdentifier;

	@Column(name="std_numeric_quaifier")
	private String stdNumericQuaifier;

	@Column(name="tkt_doc_number")
	private String tktDocNumber;

	@Column(name="transaction_number")
	private String transactionNumber;

	//bi-directional many-to-one association to TransactionHdrStg
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.MERGE)
	@JoinColumn(name="transaction_hdr_id")
	private TransactionHdrStg transactionHdrStg;

	public AddlInfoPaxStg() {
	}

	public int getAddlInfoPaxRecId() {
		return this.addlInfoPaxRecId;
	}

	public void setAddlInfoPaxRecId(int addlInfoPaxRecId) {
		this.addlInfoPaxRecId = addlInfoPaxRecId;
	}

	public String getCheckDigit() {
		return this.checkDigit;
	}

	public void setCheckDigit(String checkDigit) {
		this.checkDigit = checkDigit;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDateOfBirth() {
		return this.dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getDateOfIssue() {
		return this.dateOfIssue;
	}

	public void setDateOfIssue(String dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}

	public String getFiller() {
		return this.filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}

	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getLastUpdatedDate() {
		return this.lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getPassengerName() {
		return this.passengerName;
	}

	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}

	public String getPassengerSpecificData() {
		return this.passengerSpecificData;
	}

	public void setPassengerSpecificData(String passengerSpecificData) {
		this.passengerSpecificData = passengerSpecificData;
	}

	public String getPassengerTypeCode() {
		return this.passengerTypeCode;
	}

	public void setPassengerTypeCode(String passengerTypeCode) {
		this.passengerTypeCode = passengerTypeCode;
	}

	public String getSeqNumber() {
		return this.seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdMessageIdentifier() {
		return this.stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getStdNumericQuaifier() {
		return this.stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getTktDocNumber() {
		return this.tktDocNumber;
	}

	public void setTktDocNumber(String tktDocNumber) {
		this.tktDocNumber = tktDocNumber;
	}

	public String getTransactionNumber() {
		return this.transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

	public TransactionHdrStg getTransactionHdrStg() {
		return this.transactionHdrStg;
	}

	public void setTransactionHdrStg(TransactionHdrStg transactionHdrStg) {
		this.transactionHdrStg = transactionHdrStg;
	}
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
/*	@Override
	public LineTokenizer lineTokenizer() {

		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		AdditionalInformationPassengerStgLayout additionalInformationPassengerStgLayout = new AdditionalInformationPassengerStgLayout();
		tokenizer.setColumns(additionalInformationPassengerStgLayout.getColumns());
		tokenizer.setNames(additionalInformationPassengerStgLayout.getNames());
		return tokenizer;

	}

	@Override
	public FieldSetMapper<BSPRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<BSPRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<BSPRecord>();
		fieldSetMapper.setTargetType(AddlInfoPaxStg.class);
		return fieldSetMapper;
	}

	@Override
	public ItemProcessor<? extends BSPRecord, ? extends BSPRecord> processor() {
		return new AdditionalInformationPassengerStgProcessor();
	}

	@Override
	public ItemWriter<? super BSPRecord> writer() {
		return new AdditionalInformationPassengerStgWriter();
	}*/

}