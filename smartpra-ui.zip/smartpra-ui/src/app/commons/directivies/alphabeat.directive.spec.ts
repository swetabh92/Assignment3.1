import { AlphabeatDirective } from './alphabeat.directive';

describe('AlphabeatDirective', () => {
  it('should create an instance', () => {
    const directive = new AlphabeatDirective();
    expect(directive).toBeTruthy();
  });
});
