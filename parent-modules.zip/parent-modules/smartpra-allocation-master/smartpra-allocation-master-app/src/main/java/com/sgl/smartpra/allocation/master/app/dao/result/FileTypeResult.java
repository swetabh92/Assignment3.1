package com.sgl.smartpra.allocation.master.app.dao.result;

import java.io.Serializable;

import lombok.Data;

@Data
public class FileTypeResult implements Serializable{

}
