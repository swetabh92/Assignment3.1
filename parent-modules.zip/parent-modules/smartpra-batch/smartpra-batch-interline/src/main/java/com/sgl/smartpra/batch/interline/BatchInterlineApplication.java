package com.sgl.smartpra.batch.interline;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(scanBasePackages = {"com.sgl.smartpra.interline","com.sgl.smartpra.batch.interline"})
@EnableJpaRepositories(basePackages = {"com.sgl.smartpra.interline","com.sgl.smartpra.batch.interline"})
@EntityScan(basePackages = {"com.sgl.smartpra.interline","com.sgl.smartpra.batch.interline"})
@ComponentScan(basePackages = {"com.sgl.smartpra.interline","com.sgl.smartpra.batch.interline"})
@EnableFeignClients
@EnableDiscoveryClient
public class BatchInterlineApplication 
{
    public static void main( String[] args )
    {
    	SpringApplication.run(BatchInterlineApplication.class, args);
    }
}
