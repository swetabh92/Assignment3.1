export class Group {
    isActive: true;
    clientId: number;
    groupManagerId: number;
    groupName: string;
    groupId: number;
    moduleId: number;
      constructor() { }
    }
