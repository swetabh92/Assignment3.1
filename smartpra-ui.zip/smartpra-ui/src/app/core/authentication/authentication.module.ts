import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AuthenticationRoutingModule } from './authentication-routing.module';
import { AppfirsttimepasswordComponent } from './appfirsttimepassword/appfirsttimepassword.component';
import { AppforgetpasswordComponent } from './appforgetpassword/appforgetpassword.component';
import { AppforgetuseridComponent } from './appforgetuserid/appforgetuserid.component';
import { AppregisterComponent } from './appregister/appregister.component';
import { AppresetpasswordfinalComponent } from './appresetpasswordfinal/appresetpasswordfinal.component';
import { AppresetpasswordinitComponent } from './appresetpasswordinit/appresetpassword.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { CoreDataModule } from 'src/app/core-data/core-data.module';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    CoreDataModule,
    AuthenticationRoutingModule
  ],
  declarations: [
    AppfirsttimepasswordComponent,
    AppforgetpasswordComponent,
    AppforgetuseridComponent,
    AppregisterComponent,
    AppresetpasswordfinalComponent,
    AppresetpasswordinitComponent
  ]
})
export class AuthenticationModule { }
