import { Component, OnInit } from '@angular/core';
import { PaginationService } from 'src/app/commons/services/pagination/pagination.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { GeneralService } from 'src/app/commons/services/general.service';
import { LovService } from 'src/app/modules/masters/services/LOV/lov.service';
import { HotkeysService } from 'angular2-hotkeys';
import { CommonService } from 'src/app/modules/masters/services/commons/common.service';
import { MessageBoxService } from 'src/app/modules/masters/services/commons/message-box.service';
import { ChargeCodeService } from 'src/app/modules/masters/services/interline/charge-code/charge-code.service';
import { ChargeCategoryService } from 'src/app/modules/masters/services/interline/charge-category/charge-category.service';
import { ChargeCode } from 'src/app/modules/masters/models/interline/charge-code';
import { ChargeCategory } from 'src/app/modules/masters/models/interline/charge-category';

@Component({
  selector: 'app-charge-code-master',
  templateUrl: './charge-code-master.component.html',
  styleUrls: ['./charge-code-master.component.css']
})
export class ChargeCodeMasterComponent implements OnInit {
  chargeCodeSearch: boolean = false;
  categoryCodeObject: ChargeCategory;
  chargeCodeList: ChargeCode[] = [];
  categoryId: string;
  editing = {};
  searchForm: FormGroup;
  searchsubmitted: boolean = false;
  success: any = { isSuccess: false, successMessage: '' };
  page: any = this.paginateService.getPageinateConfig();

  constructor(public lov: LovService, private paginateService: PaginationService, private generalService: GeneralService,
    private chargeCode: ChargeCodeService, private formBuilder: FormBuilder, private chargeCategoryList: ChargeCategoryService,
    private messageBox: MessageBoxService, private hotkeysService: HotkeysService, private commonService: CommonService) { }

  ngOnInit() {
    this.chargeCategoryList.onDeactivateCategory.subscribe(() => {
      this.getChargeCategoryCode();
    })
    this.searchFormInitialize();
    this.getChargeCategoryCode();
  }


  getChargeCategoryCode() {

    this.chargeCategoryList.onClickCategory.subscribe((chargeCategoryCode) => {
      this.getChargeCodeListById(chargeCategoryCode);
    })

    this.chargeCategoryList.getChargeCategory().subscribe((res: ChargeCategory[]) => {
      if (res != null) {
        this.categoryCodeObject = res[0];
        this.getChargeCodeListById(this.categoryCodeObject.chargeCategoryCode)
      }
    })
  }

  getChargeCodeListById(chargeCategoryCode) {
    this.chargeCode.getChargeCodeList(chargeCategoryCode).subscribe((res: ChargeCode[]) => {
      if (res != null) {
        this.chargeCodeList = res;
        this.categoryId = chargeCategoryCode;
      }
    })
  }

  getSectionMasterList(chargeCode) {
    if (chargeCode) {
      this.chargeCode.onClickChargeCode.emit(chargeCode);
    }
  }

  searchFormInitialize() {
    this.searchForm = this.formBuilder.group({
      chargeCode: ['', [Validators.maxLength(6)]]
    })
  }

  onSearch() {
    this.searchsubmitted = true;
    if (this.searchForm.invalid) return false;
    this.chargeCode.searchChargeCode(this.searchForm.value.chargeCode, this.categoryId).subscribe((res) => {
      this.chargeCodeList = res;
    })
  }

  resetForm() {
    this.searchForm.reset();
    this.searchsubmitted = false;
  }

  onSubmit() {
    this.chargeCode.updateChargeCodeList(this.chargeCodeList).subscribe((res: any) => {
      if (res.message != '' || res.message == null) {
      } else {
        this.success = { isSuccess: true, successMessage: "Record has been successfully updated" }
      }
    })
  }

  onDeactivate(row) {
    if (row.activate == "false") {
      this.chargeCode.onDeactiveChargeCodeObject(row, this.categoryId).subscribe((res: any) => {
        if (res.message != '' || res.message == null) {
          this.getChargeCodeListById(this.categoryId);
        } else {
          this.success = { isSuccess: true, successMessage: "Record has been successfully Deactivated" }
          this.chargeCode.onDeactivateChargeCode.emit(this.categoryId);
          this.getChargeCodeListById(this.categoryId);
        }
      })
    }
  }

  get s() { return this.searchForm.controls }

  updateValue(event, cell, rowIndex) {
    this.editing[rowIndex + '-' + cell] = false;
    this.chargeCodeList[rowIndex][cell] = event.target.value;
    this.onDeactivate(this.chargeCodeList[rowIndex]);
    this.chargeCodeList = [...this.chargeCodeList];
  }

}
