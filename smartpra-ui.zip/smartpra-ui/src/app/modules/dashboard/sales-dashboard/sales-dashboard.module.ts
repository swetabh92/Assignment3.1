import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SalesDashboardRoutingModule } from './sales-dashboard-routing.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { SalesDashboardComponent } from './sales-dashboard.component';
import {TicketqueryModule} from "../../miscellaneous/components/ticketquery/ticketquery.module";
import {SaleBatchSummaryComponent} from './sale-batch-summary/sale-batch-summary.component';
import { ExceptionResolutionModule } from '../../miscellaneous/components/exception-management/exception-resolution.module';
import { FacsimileModule } from '../../miscellaneous/components/ticketquery/facsimile/facsimile.module';
import { CoreDataModule } from 'src/app/core-data/core-data.module';
import { SalesListTableComponent } from './sales-list-table/sales-list-table.component';
import { TranscationAccountSummaryComponent } from './transcation-account-summary/transcation-account-summary.component';
import { ViewSaleComponent } from './view-sale/view-sale.component';
import { ReportedTaxDetailsComponent } from './view-sale/reported-tax-details/reported-tax-details.component';
import { ExchangeRefundComponent } from './view-sale/exchange-refund/exchange-refund.component';
import { FopDetailsComponent } from './view-sale/fop-details/fop-details.component';


@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    CoreDataModule,
    SalesDashboardRoutingModule,
    TicketqueryModule,
    FacsimileModule,
    ExceptionResolutionModule
  ],
  exports: [
    SaleBatchSummaryComponent
  ],
  declarations: [
    SalesDashboardComponent,
    SaleBatchSummaryComponent,
    SalesListTableComponent,
    TranscationAccountSummaryComponent,
    ViewSaleComponent,
    ReportedTaxDetailsComponent,
    ExchangeRefundComponent,
    FopDetailsComponent,
  ]
})
export class SalesDashboardModule { }
