import {Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {GeneralService} from '../../../../commons/services/general.service';
import {InwardDashboardService} from '../inward-dashboard.service';
import {DatePipe} from '@angular/common';
import {PaginationService} from '../../../../commons/services/pagination/pagination.service';
import {CommonService} from '../../../masters/services/commons/common.service';
import { InterlineConstant } from '../constants/interline-constants';
import { MessageBoxService } from '../../../masters/services/commons/message-box.service';


@Component({
  selector: 'app-batches',
  templateUrl: './batches.component.html',
  styleUrls: ['../inward-dashboard.component.css']
})
export class BatchesComponent implements OnInit {
  summarizedDownArrow:boolean = true;
  showSummarizesdDT:boolean = true;
  selectedBatchList:any = [];
  batchRecords:any = [];
  selectedIDs: any[] = [];
  selectedCoupon:any;
  singleSelectIcon:boolean;
  multiSelectIcon:boolean;
  statusExpansion = InterlineConstant.STATUS_EXPANSION;
  batchID:number;
  productionMode:boolean = false;
  page: any = this.paginateService.setCustomPaginationConfig({"pageSize": 5});
  batchParam:any;
  @Output() couponSearchParams = new EventEmitter<any>();
  @Output() batchEmpty = new EventEmitter<any>();

  @Input('batchParams')
  set batchParams(batchParams: any) {
    if (batchParams) {
      this.batchParam = batchParams;
      this.page  = this.paginateService.setCustomPaginationConfig({"pageSize": 5});
      this.loadBatches(batchParams);
    }
  }

  constructor(private paginateService: PaginationService,private generalService: GeneralService, private commonService: CommonService,
    private formBuilder: FormBuilder,private inwardService: InwardDashboardService,private messageService: MessageBoxService) {

  }


  ngOnInit() {
  }

  onSearch(){

  }

  getserverSideData(pageInfo) {
		this.page = this.paginateService.mergePageObj(pageInfo, this.page);
		this.loadBatches(this.batchParam);
  }

  emptyBatches(){
    this.selectedBatchList = [];
    this.batchRecords = [];
    this.selectedCoupon = null;
    this.batchRecords = [...this.batchRecords];
  }

  loadBatches(data: any) {
    this.selectedBatchList = [];
    let paginates = this.paginateService.getQueryObj(this.page);
    this.inwardService.getBatchData(data, paginates).subscribe((response:any)=> {
      if(!this.productionMode) {
				this.page.count = response.totalCount;
        this.batchRecords = response.batchDetailsStg;
        if (this.batchRecords && this.batchRecords.length > 0 && this.batchRecords[0]){
          this.createCouponParams(this.batchParam.area, this.batchRecords[0].batchId);
          this.singleSelectIcon = false;
          this.multiSelectIcon = false;
        } else {
          this.batchEmpty.emit();
        }
      } else {
        //this.batchRecords = response.invoiceDetailsProd;
      }
    });
  }

  createCouponParams(area:string, batchId: string) {
    let params = {
      area: area,
      batchId: batchId
    };
    this.couponSearchParams.emit(params);
  }

  onSelectRow(event, type?:string, inputevent?:any){
    if(type == InterlineConstant.ALL && event.selected) {
      if (event.selected.length > 0) {
        this.selectedBatchList = event.selected;
      } else {
        this.selectedBatchList = [];
      }
    } else {
      if(inputevent && inputevent.target.checked) {
          this.selectedBatchList.push(event);
          this.selectedCoupon = event;
          if(!this.productionMode)
            this.createCouponParams(InterlineConstant.STAGING,event.batchId);
      } else {
        if (this.selectedBatchList.length > 0) {
          let ind:number, index:number;
          if(!this.productionMode) {
            ind = this.selectedBatchList.findIndex(item => item['batchId'] == event['batchId']);
          } else {
            //ind = this.selectedBatchList.findIndex(item => item['idecInvoiceHdrId'] == event['idecInvoiceHdrId']);
          }
          this.selectedBatchList.splice(ind,1);
        }
      }
    }
    if (this.selectedBatchList.length == 1) {
      this.singleSelectIcon = false;
    } else {
      this.singleSelectIcon = true;
    }
    if (this.selectedBatchList.length > 0)
      this.multiSelectIcon = false;
    else
      this.multiSelectIcon = true;
  }

  deleteBatchRecords(){
    if(!this.productionMode) {
      this.selectedIDs = this.selectedBatchList.map(res => res.batchId);
    } else {
      //this.selectedIDs = this.selectedBatchList.map(res => res.idecInvoiceHdrId);
    }
    let ids = this.selectedIDs.toString();
    this.messageService.deleteRecordMessage(this.selectedIDs.length).then((result) => {
			if (result.value) {
        if(!this.productionMode) {
          this.inwardService.deleteBatchStgData(ids).subscribe((response:any)=> {
            this.loadBatches(this.batchParam);
            this.singleSelectIcon = true;
            this.multiSelectIcon = true;
            this.selectedBatchList = [];
            this.messageService.getSuccessMessage(InterlineConstant.SUCCESS,InterlineConstant.DELETEMESSAGE);
          });
        } else {
          /*this.inwardService.deleteInvoiceStgData(ids).subscribe((response:any)=> {
            this.loadBatches(this.invoiceParams);
            this.singleSelectIcon = true;
            this.multiSelectIcon = true;
            this.selectedBatchList = [];
            this.messageService.getSuccessMessage(InterlineConstant.SUCCESS,InterlineConstant.DELETEMESSAGE);
          });*/
        }
      }
    });

  }

  onResetSearch(){}

  cancelSearch(event){}

  showSearchBox(): void {
  }
}

