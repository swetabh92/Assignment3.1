package com.sgl.smartpra.batch.bsp.app.record;

import java.util.ArrayList;

import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;
import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;

public class TicketDocumentIdentification extends BSPBaseRecord {

	@Override
	public String getRecordType() {
		return BSPRecordType.TICKET_DOCUMENT_IDENTIFICATION;
	}

	// Layout of Ticket Document Identification Record
	class TicketDocumentIdentificationLayout extends FixedLengthRecordLayout {
		public TicketDocumentIdentificationLayout() {
			fixedLengthFieldLayoutList = new ArrayList<FixedLengthFieldLayout>();

			// entire line
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("line", 1, 136));

			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdMessageIdentifier", 1, 3));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("seqNumber", 4, 11));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdNumericQuaifier", 12, 13));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("dateOfIssue", 14, 19));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("transactionNumber", 20, 25));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("tktDocNumber", 26, 39));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("checkDigit", 40, 40));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("cpnUseIndicator", 41, 44));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("conjuctionTicketIndicator", 45, 47));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("agentNumericCode", 48, 55));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("reasonForReissuanceCode", 56, 56));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("tourCode", 57, 71));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("transactionCode", 72, 75));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("trueOrgDestCityCode", 76, 85));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("pnrRefAirlineDate", 86, 98));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("timeOfIssue", 99, 102));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("jrnyTurnaroundAptCityCode", 103, 107));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("filler", 108, 136));
		}
	}

	@Override
	public LineTokenizer lineTokenizer(String handbookRevisionNumber) {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		TicketDocumentIdentificationLayout ticketDocumentIdentificationLayout = new TicketDocumentIdentificationLayout();
		tokenizer.setColumns(ticketDocumentIdentificationLayout.getColumns());
		tokenizer.setNames(ticketDocumentIdentificationLayout.getNames());
		return tokenizer;
	}

	@Override
	public FieldSetMapper<BSPBaseRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<BSPBaseRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<BSPBaseRecord>();
		fieldSetMapper.setTargetType(this.getClass());
		return fieldSetMapper;
	}

	// Variables to hold record values
	private String stdMessageIdentifier;
	private String seqNumber;
	private String stdNumericQuaifier;
	private String dateOfIssue;
	private String transactionNumber;
	private String tktDocNumber;
	private String checkDigit;
	private String cpnUseIndicator;
	private String conjuctionTicketIndicator;
	private String agentNumericCode;
	private String reasonForReissuanceCode;
	private String tourCode;
	private String transactionCode;
	private String trueOrgDestCityCode;
	private String pnrRefAirlineDate;
	private String timeOfIssue;
	private String jrnyTurnaroundAptCityCode;
	private String filler;

	public String getStdMessageIdentifier() {
		return stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getSeqNumber() {
		return seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdNumericQuaifier() {
		return stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getDateOfIssue() {
		return dateOfIssue;
	}

	public void setDateOfIssue(String dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}

	public String getTransactionNumber() {
		return transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

	public String getTktDocNumber() {
		return tktDocNumber;
	}

	public void setTktDocNumber(String tktDocNumber) {
		this.tktDocNumber = tktDocNumber;
	}

	public String getCheckDigit() {
		return checkDigit;
	}

	public void setCheckDigit(String checkDigit) {
		this.checkDigit = checkDigit;
	}

	public String getCpnUseIndicator() {
		return cpnUseIndicator;
	}

	public void setCpnUseIndicator(String cpnUseIndicator) {
		this.cpnUseIndicator = cpnUseIndicator;
	}

	public String getConjuctionTicketIndicator() {
		return conjuctionTicketIndicator;
	}

	public void setConjuctionTicketIndicator(String conjuctionTicketIndicator) {
		this.conjuctionTicketIndicator = conjuctionTicketIndicator;
	}

	public String getAgentNumericCode() {
		return agentNumericCode;
	}

	public void setAgentNumericCode(String agentNumericCode) {
		this.agentNumericCode = agentNumericCode;
	}

	public String getReasonForReissuanceCode() {
		return reasonForReissuanceCode;
	}

	public void setReasonForReissuanceCode(String reasonForReissuanceCode) {
		this.reasonForReissuanceCode = reasonForReissuanceCode;
	}

	public String getTourCode() {
		return tourCode;
	}

	public void setTourCode(String tourCode) {
		this.tourCode = tourCode;
	}

	public String getTransactionCode() {
		return transactionCode;
	}

	public void setTransactionCode(String transactionCode) {
		this.transactionCode = transactionCode;
	}

	public String getTrueOrgDestCityCode() {
		return trueOrgDestCityCode;
	}

	public void setTrueOrgDestCityCode(String trueOrgDestCityCode) {
		this.trueOrgDestCityCode = trueOrgDestCityCode;
	}

	public String getPnrRefAirlineDate() {
		return pnrRefAirlineDate;
	}

	public void setPnrRefAirlineDate(String pnrRefAirlineDate) {
		this.pnrRefAirlineDate = pnrRefAirlineDate;
	}

	public String getTimeOfIssue() {
		return timeOfIssue;
	}

	public void setTimeOfIssue(String timeOfIssue) {
		this.timeOfIssue = timeOfIssue;
	}

	public String getJrnyTurnaroundAptCityCode() {
		return jrnyTurnaroundAptCityCode;
	}

	public void setJrnyTurnaroundAptCityCode(String jrnyTurnaroundAptCityCode) {
		this.jrnyTurnaroundAptCityCode = jrnyTurnaroundAptCityCode;
	}

	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}
}