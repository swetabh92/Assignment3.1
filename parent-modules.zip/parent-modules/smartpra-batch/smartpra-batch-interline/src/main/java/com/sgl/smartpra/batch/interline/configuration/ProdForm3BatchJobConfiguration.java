package com.sgl.smartpra.batch.interline.configuration;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.data.RepositoryItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.transaction.PlatformTransactionManager;

import com.sgl.smartpra.batch.interline.common.InterlineBatchConstants;
import com.sgl.smartpra.batch.interline.listener.InterlineForm3CsvProdJobExecutionListener;
import com.sgl.smartpra.batch.interline.listener.InterlineForm3ProdSkipListener;
import com.sgl.smartpra.batch.interline.model.InterlineForm3CompositeModel;
import com.sgl.smartpra.batch.interline.processor.InterlineForm3ProdProcessor;
import com.sgl.smartpra.batch.interline.writer.InterlineForm3DetailsProdWriter;
import com.sgl.smartpra.interline.domain.entity.stg.form3.InterlineForm3CsvStg;
import com.sgl.smartpra.interline.domain.enums.Form3StgStatusEnum;
import com.sgl.smartpra.interline.domain.repository.stg.form3.InterlineForm3CsvStgRepository;

@Configuration
public class ProdForm3BatchJobConfiguration {

	@Autowired
	private JobBuilderFactory jobBuilderFactory;

	@Autowired
	private StepBuilderFactory stepBuilderFactory;

	@Autowired
	private InterlineForm3CsvStgRepository interlineForm3CsvStgRepository;

	@Autowired
	private PlatformTransactionManager transactionManager;

	@Bean
	public Job stg2ProdDataTransferJob(Step stg2ProdDataTransferStep) {
		return jobBuilderFactory.get("stg2ProdDataTransferJob").incrementer(new RunIdIncrementer()).preventRestart()
				.listener(interlineForm3CsvProdJobExecutionListener()).flow(stg2ProdDataTransferStep).end().build();
	}

	@Bean
	public Step stg2ProdDataTransferStep() {
		return stepBuilderFactory.get("stg2ProdDataTransferStep").<InterlineForm3CsvStg, InterlineForm3CompositeModel>chunk(5)
				.reader((ItemReader<? extends InterlineForm3CsvStg>) form3RepositoryItemReader(null))
				.processor((ItemProcessor<InterlineForm3CsvStg, InterlineForm3CompositeModel>) interlineForm3ProdProcessor())
				.writer((ItemWriter<InterlineForm3CompositeModel>) interlineForm3DetailsProdWriter()).faultTolerant()
				.skip(DataIntegrityViolationException.class).skipLimit(100).listener(interlineForm3ProdSkipListener())
				.transactionManager(transactionManager).build();
	}

	@Bean
	@StepScope
	public ItemReader<? extends InterlineForm3CsvStg> form3RepositoryItemReader(
			@Value("#{jobParameters[fileId]}") BigInteger fileId) {
		RepositoryItemReader<InterlineForm3CsvStg> reader = new RepositoryItemReader<>();
		List<Object> arguments = new ArrayList<>();
		if(Objects.nonNull(fileId)) {
			arguments.add(fileId);	
			reader.setMethodName("findAllByFileIdAndStatus");
		}else {
			reader.setMethodName("findByStatus");
		}
		arguments.add(Form3StgStatusEnum.VALIDATED_SUCCESSFULLY.getValue());
		arguments.add(InterlineBatchConstants.N);
		reader.setRepository(interlineForm3CsvStgRepository);
		
		reader.setArguments(arguments);
		Map<String, Direction> map = new HashMap<String, Direction>();
		map.put("interlineForm3CsvId", Direction.ASC);
		reader.setSort(map);
		return reader;
	}

	@Bean
	@StepScope
	ItemProcessor<InterlineForm3CsvStg, InterlineForm3CompositeModel> interlineForm3ProdProcessor() {
		return (ItemProcessor<InterlineForm3CsvStg, InterlineForm3CompositeModel>) new InterlineForm3ProdProcessor();
	}

	@Bean
	public ItemWriter<InterlineForm3CompositeModel> interlineForm3DetailsProdWriter() {
		return new InterlineForm3DetailsProdWriter();
	}

	@Bean
	public InterlineForm3ProdSkipListener interlineForm3ProdSkipListener() {
		return new InterlineForm3ProdSkipListener();
	}
	
	@Bean
	public InterlineForm3CsvProdJobExecutionListener interlineForm3CsvProdJobExecutionListener() {
		return new InterlineForm3CsvProdJobExecutionListener();
	}
}
