package com.sgl.smartpra.batch.bsp.app.record;

import java.util.ArrayList;

import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;
import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;

public class UnticketedPointInfo extends BSPBaseRecord {

	@Override
	public String getRecordType() {
		return BSPRecordType.UNTICKETED_POINT_INFO;
	}

	// Layout of Unticketed Point Information record
	public class UnticketedPointInfoLayout extends FixedLengthRecordLayout {
		public UnticketedPointInfoLayout() {
			fixedLengthFieldLayoutList = new ArrayList<FixedLengthFieldLayout>();

			// entire line
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("line", 1, 136));

			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdMessageIdentifier", 1, 3));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("seqNumber", 4, 11));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdNumericQuaifier", 12, 13));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("dateOfIssue", 14, 19));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("transactionNumber", 20, 25));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("tktDocNumber", 26, 39));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("checkDigit", 40, 40));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("segmentIdentifier", 41, 41));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("unticketedPointAirportCode", 42, 46));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("unticketedPointArrivalDate", 47, 53));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("unticketedPointArrivalTime", 54, 58));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("unticketedPointDepartDate", 59, 65));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("unticketedPointDepartTime", 66, 70));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("unticketedPointDeptEqCode", 71, 73));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("filler", 74, 136));
		}
	}

	@Override
	public LineTokenizer lineTokenizer(String handbookRevisionNumber) {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		UnticketedPointInfoLayout unticketedPointInfoLayout = new UnticketedPointInfoLayout();
		tokenizer.setColumns(unticketedPointInfoLayout.getColumns());
		tokenizer.setNames(unticketedPointInfoLayout.getNames());
		return tokenizer;
	}

	@Override
	public FieldSetMapper<BSPBaseRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<BSPBaseRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<BSPBaseRecord>();
		fieldSetMapper.setTargetType(this.getClass());
		return fieldSetMapper;
	}

	// Variables to hold the record values
	private String stdMessageIdentifier;
	private String seqNumber;
	private String stdNumericQuaifier;
	private String dateOfIssue;
	private String transactionNumber;
	private String tktDocNumber;
	private String checkDigit;
	private String segmentIdentifier;
	private String unticketedPointAirportCode;
	private String unticketedPointArrivalDate;
	private String unticketedPointArrivalTime;
	private String unticketedPointDepartDate;
	private String unticketedPointDepartTime;
	private String unticketedPointDeptEqCode;
	private String filler;

	public String getStdMessageIdentifier() {
		return stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getSeqNumber() {
		return seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdNumericQuaifier() {
		return stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getDateOfIssue() {
		return dateOfIssue;
	}

	public void setDateOfIssue(String dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}

	public String getTransactionNumber() {
		return transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

	public String getTktDocNumber() {
		return tktDocNumber;
	}

	public void setTktDocNumber(String tktDocNumber) {
		this.tktDocNumber = tktDocNumber;
	}

	public String getCheckDigit() {
		return checkDigit;
	}

	public void setCheckDigit(String checkDigit) {
		this.checkDigit = checkDigit;
	}

	public String getSegmentIdentifier() {
		return segmentIdentifier;
	}

	public void setSegmentIdentifier(String segmentIdentifier) {
		this.segmentIdentifier = segmentIdentifier;
	}

	public String getUnticketedPointAirportCode() {
		return unticketedPointAirportCode;
	}

	public void setUnticketedPointAirportCode(String unticketedPointAirportCode) {
		this.unticketedPointAirportCode = unticketedPointAirportCode;
	}

	public String getUnticketedPointArrivalDate() {
		return unticketedPointArrivalDate;
	}

	public void setUnticketedPointArrivalDate(String unticketedPointArrivalDate) {
		this.unticketedPointArrivalDate = unticketedPointArrivalDate;
	}

	public String getUnticketedPointArrivalTime() {
		return unticketedPointArrivalTime;
	}

	public void setUnticketedPointArrivalTime(String unticketedPointArrivalTime) {
		this.unticketedPointArrivalTime = unticketedPointArrivalTime;
	}

	public String getUnticketedPointDepartDate() {
		return unticketedPointDepartDate;
	}

	public void setUnticketedPointDepartDate(String unticketedPointDepartDate) {
		this.unticketedPointDepartDate = unticketedPointDepartDate;
	}

	public String getUnticketedPointDepartTime() {
		return unticketedPointDepartTime;
	}

	public void setUnticketedPointDepartTime(String unticketedPointDepartTime) {
		this.unticketedPointDepartTime = unticketedPointDepartTime;
	}

	public String getUnticketedPointDeptEqCode() {
		return unticketedPointDeptEqCode;
	}

	public void setUnticketedPointDeptEqCode(String unticketedPointDeptEqCode) {
		this.unticketedPointDeptEqCode = unticketedPointDeptEqCode;
	}

	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}
}