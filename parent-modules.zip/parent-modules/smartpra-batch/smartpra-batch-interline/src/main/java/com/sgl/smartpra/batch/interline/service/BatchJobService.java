package com.sgl.smartpra.batch.interline.service;

import java.io.File;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

import com.sgl.smartpra.batch.global.model.FileLogging;
import com.sgl.smartpra.batch.interline.common.ExceptionServiceIntegration;
import com.sgl.smartpra.batch.interline.common.FileErrorConstants;
import com.sgl.smartpra.batch.interline.common.InterlineBatchConstants;
import com.sgl.smartpra.batch.interline.common.InterlineUtils;
import com.sgl.smartpra.batch.interline.configuration.FeignConfiguration.BatchGlobalFeignClient;
import com.sgl.smartpra.batch.interline.configuration.FeignConfiguration.ExceptionTransIntgAppClient;
import com.sgl.smartpra.batch.interline.configuration.FeignConfiguration.SmartpraMasterAppClient;
import com.sgl.smartpra.common.util.FileLoggingConstants;
import com.sgl.smartpra.exception.txn.model.ExceptionParametersValueModel;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.interline.domain.util.InterlineCommonConstants;
import com.sgl.smartpra.interline.domain.util.InterlineExceptionCodes;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class BatchJobService {

	@Value("${batch.form3.path}")
	private String form3Path;

	@Value("${batch.IDEC.path}")
	private String idecPath;

	@Autowired
	BatchGlobalFeignClient batchGlobalFeignClient;

	@Autowired
	SmartpraMasterAppClient smartpraMasterAppClient;

	@Autowired
	ExceptionTransIntgAppClient exceptionTransIntgAppClient;
	
	@Autowired
	ExceptionServiceIntegration exceptionServiceIntegration;

	public FileLogging initFileLogging(FileLogging file) {
		return batchGlobalFeignClient.createFileLog(InterlineUtils.initFileLogging(file));
	}

	public boolean checkFileAlreadyExists(FileLogging file) {
		List<FileLogging> files = batchGlobalFeignClient.getFileLogByFileName(file.getFileName());
		return files.size() > 0;
	}

	public boolean isEmptyFile(Path path) {
		File file = new File(path.toString());
		return file.length() == 0;
	}

	public boolean checkFileStructure(Path path, FileLogging file) throws IOException {
		int i = 1;
		for (String line : Files.readAllLines(path)) {
			line = line.replaceAll(",", "");
			if (!line.matches(InterlineBatchConstants.REGEX_EMPTY)) {
				file.setSkippedRecordCount(i);
				return true;
			}
			i++;
		}
		return false;
	}

	public String getFileSize(String fileName) {
		File fileObj = new File(fileName);
		return FileUtils.byteCountToDisplaySize(fileObj.length());
	}

	public Resource findBatchJobResourceForForm3(String fileName) {
		return new FileSystemResource(form3Path + fileName);
	}

	public Resource findBatchJobResourceForIDEC(String fileName) {
		return new FileSystemResource(idecPath + fileName);
	}

	public boolean validateForm3FileName(FileLogging file) {
		if (!file.getFileName().toUpperCase().startsWith("ICH_STD_")) {
			return true;
		} else if (!file.getFileName().substring(8, 14).matches(InterlineBatchConstants.REGEX_ONLY_NUMBERS)) {
			return true;
		} else if (!file.getFileName().toUpperCase().endsWith("_F3_FINAL_A.CSV")) {
			return true;
		}
		return false;
	}
	
	public boolean checkHostCarrierCode(FileLogging file) {
		if (!file.getFileName().substring(15, 17).equalsIgnoreCase(InterlineUtils.getHostCarrierDesigCode(smartpraMasterAppClient))) {
			return true;
		}
		if (!file.getFileName().substring(17, 20).equalsIgnoreCase(InterlineUtils.getHostCarrierCode(smartpraMasterAppClient))) {
			return true;
		}
		return false;
	}

	public void afterJobConfiguration(JobExecution jobExecution) {
		List<StepExecution> steps = (List<StepExecution>) jobExecution.getStepExecutions();
		BigInteger fileId = (BigInteger) jobExecution.getExecutionContext().get(InterlineBatchConstants.FILE_ID);
		FileLogging fileLogging = batchGlobalFeignClient.getFileLogByFileId(fileId);
		fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_TRANSFERRED);
		fileLogging.setTotalCounts(steps.get(1).getReadCount());
		fileLogging.setDetailCounts(steps.get(1).getReadCount());
		fileLogging.setTransferredCounts(steps.get(1).getWriteCount());
		fileLogging.setErrorCounts(steps.get(1).getReadCount() - steps.get(1).getWriteCount());
		fileLogging.setEndDateTime(new Timestamp(jobExecution.getEndTime().getTime()));
		fileLogging.setClientId(InterlineUtils.getHostCarrierDesigCode(smartpraMasterAppClient));
		log.info("!!!Job Executed Sucessfully for File : "+fileLogging.getFileName()+" File_Id : "+fileLogging.getFileId()+" Record_Count : "+fileLogging.getTotalCounts());
		batchGlobalFeignClient.updateFileLog(fileId, fileLogging);
	}

	public void logError(FileLogging fileLogging) {
		fileLogging = initFileLogging(fileLogging);
		fileLogging.setFileStatus(FileLoggingConstants.FILELOGGING_FILESTATUS_TECHFAILED);
		fileLogging.setClientId(InterlineUtils.getHostCarrierDesigCode(smartpraMasterAppClient));
		log.error("!!!Error Processing File : " + fileLogging.getFileName() + " File_Id : " + fileLogging.getFileId() + " Error Code : " + fileLogging.getRemarks() );
		batchGlobalFeignClient.updateFileLog(fileLogging.getFileId(), fileLogging);
		exceptionTransIntgAppClient.initExceptionTrasaction(prepareExceptionTransactionModel(fileLogging));
	}

	public ExceptionTransactionModel prepareExceptionTransactionModel(FileLogging fileLogging) {
		ExceptionTransactionModel exceptionTransactionModel = new ExceptionTransactionModel();
		exceptionTransactionModel.setExceptionCode(fileLogging.getRemarks());
		exceptionTransactionModel.setFileId(fileLogging.getFileId().longValue());
		exceptionTransactionModel.setClientId(fileLogging.getClientId());
		exceptionTransactionModel.setCreatedBy(InterlineCommonConstants.CREATED_BY);
		exceptionTransactionModel.setEnvironment(InterlineCommonConstants.STAGING_ENVIRONMENT);
		exceptionTransactionModel.setExceptionDate(LocalDateTime.now());
		exceptionTransactionModel.setParametersValueList(setParametersValueList(fileLogging));
		return exceptionTransactionModel;
	}
	
	public ExceptionParametersValueModel setExceptionParametersValueModel(String parameterName, String parameterValue) {
		ExceptionParametersValueModel parametersValueModel = new ExceptionParametersValueModel();
		parametersValueModel.setParameterName(parameterName);
		parametersValueModel.setParameterValue(parameterValue);
		return parametersValueModel;
	}

	public List<ExceptionParametersValueModel> setParametersValueList(FileLogging fileLogging) {
		List<ExceptionParametersValueModel> param = new ArrayList<>();
		param.add(setExceptionParametersValueModel(FileErrorConstants.FILE_NAME, fileLogging.getFileName()));
		if (fileLogging.getRemarks().equalsIgnoreCase(InterlineExceptionCodes.INWD1002)) {
			param.add(setExceptionParametersValueModel(FileErrorConstants.IDEC_FORMAT, fileLogging.getFileName()));
		} else if (fileLogging.getRemarks().equalsIgnoreCase(InterlineExceptionCodes.INWD1046)) {
			param.add(setExceptionParametersValueModel(FileErrorConstants.FORM3_FORMAT, fileLogging.getFileName()));
		} else if (fileLogging.getRemarks().equalsIgnoreCase(InterlineExceptionCodes.INWD1047)) {
			param.add(setExceptionParametersValueModel(FileErrorConstants.ANSI_FORMAT, fileLogging.getFileName()));
		} else if (fileLogging.getRemarks().equalsIgnoreCase(InterlineExceptionCodes.INWD1005)) {
			param.add(setExceptionParametersValueModel("Line Number", fileLogging.getSkippedRecordCount().toString()));
		}else if (fileLogging.getRemarks().equalsIgnoreCase(InterlineExceptionCodes.INWD1006)) {
			List<FileLogging> files = batchGlobalFeignClient.getFileLogByFileName(fileLogging.getFileName());
			param.add(setExceptionParametersValueModel("Previously Downlaoded file ID",	files.get(0).getFileId().toString()));
			param.add(setExceptionParametersValueModel("Previously downloaded date", files.get(0).getCreatedDate().toString()));
		} else if (fileLogging.getRemarks().equalsIgnoreCase(InterlineExceptionCodes.INWD1045)) {
			param.remove(0);
			param.add(setExceptionParametersValueModel(InterlineBatchConstants.CARRIER_ALPHA_CODE, fileLogging.getFileName().substring(15, 17)));
			param.add(setExceptionParametersValueModel(InterlineBatchConstants.CARRIER_NUMERIC_CODE, fileLogging.getFileName().substring(17, 20)));
		}
		return param;
	}

	public boolean checkFileLoggingError(Path path, FileLogging file) throws IOException {
		file.setRemarks(null);
		if (!Files.isReadable(path)) {
			file.setRemarks(InterlineExceptionCodes.INWD1001);
		} else if (validateForm3FileName(file)) {
			file.setRemarks(InterlineExceptionCodes.INWD1046);
		} else if (isEmptyFile(path)) {
			file.setRemarks(InterlineExceptionCodes.INWD1003);
		} else if (checkFileStructure(path, file)) {
			file.setRemarks(InterlineExceptionCodes.INWD1005);
		} else if (checkHostCarrierCode(file)) {
			file.setRemarks(InterlineExceptionCodes.INWD1045);
		} else if (checkFileAlreadyExists(file)) {
			file.setRemarks(InterlineExceptionCodes.INWD1006);
		}
		return file.getRemarks() != null ? true : false;
	}
}
