import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import swal from 'sweetalert2';

import { environment } from '../../../../environments/environment';
import { Userteam } from '../models/userteam';
import { MessageBoxService } from '../../masters/services/commons/message-box.service';
const httpOptions = {
  // headers: new HttpHeaders({ 'Content-Type': 'multipart/form-data' })
};
const httpOptions1 = {
  headers: new HttpHeaders({ 'Content-Type': 'multipart/form-data' })
};
@Injectable({
  providedIn: 'root'
})
export class UserteamService {
  globalUrl = environment.apiUrlGlobal;
  masterUrl = environment.apiUrlMaster;
  authUrl = environment.apiUrlauth;
  constructor(private http: HttpClient, private messageBoxService: MessageBoxService) { }
  getUserteamAll(): Observable<Userteam[]> {
    return this.http.get<Userteam[]>(this.authUrl + 'mas-user-teams')
      .pipe(
        tap(_ => this.log('fetched Userteam details')),
        catchError(this.handleError('getAllUserteam', []))
      );
  }
  UserteamByUserteamId(masUserTeamId: string): Observable<Userteam> {
    return this.http.get<Userteam>(this.authUrl + 'mas-user-teams/' + masUserTeamId).pipe(
      tap(_ => this.log(`fetched Userteam masUserTeamId=${masUserTeamId}`)),
      catchError(this.handleError<Userteam>(`UserteamByUserteamId masUserTeamId=${masUserTeamId}`))
    );
  }

  getUsersByTeamId(teamId: string): Observable<Userteam> {
    return this.http.get<Userteam>(this.authUrl + 'user/team/' + teamId).pipe(
      tap(_ => this.log(`fetched Userteam masUserTeamId=${teamId}`)),
      catchError(this.handleError<Userteam>(`UserteamByUserteamId masUserTeamId=${teamId}`))
    );
  }

  searchUserteam(parms: string): Observable<Userteam> {
    return this.http.get<Userteam>(this.authUrl + parms).pipe(
      tap(_ => this.log(`search Userteam masUserTeamId by ${parms}`)),
      catchError(this.handleError<Userteam>(`search Userteam masUserTeamId by ${parms}`))
    );
  }
  /** POST: add a new Userteam to the server */
  addUserteam(formdata): Observable<Userteam> {
    // console.log(formdata); return;
    return this.http.post<Userteam>(this.authUrl + 'mas-user-teams/', formdata, httpOptions).pipe(
      tap(_ => this.log(`added Userteam masUserTeamId=`)),
      catchError(this.handleError<Userteam>('addUserteam'))
    );
  }
  updateUserteam(userteam: Userteam): Observable<any> {
   // console.log(Userteam.masUserTeamId);
    // console.log(Userteam);
    return this.http.put<Userteam>(this.authUrl + 'mas-user-teams/' + userteam.masUserTeamId, Userteam, httpOptions).pipe(
      tap(_ => this.log(`updated Userteam masUserTeamId=${userteam.masUserTeamId}`)),
      catchError(this.handleError<Userteam>('addUserteam'))
    );
  }
  activateUserteam(masUserTeamId: string): Observable<Userteam> {
    return this.http.put<Userteam>(this.authUrl + 'mas-user-teams/activateordeactivate/' + masUserTeamId , httpOptions).pipe(
      tap(_ => this.log(`activate Userteam masUserTeamId=${masUserTeamId}`)),
      catchError(this.handleError<Userteam>('activateUserteam'))
    );
  }
  deactivateUserteam(masUserTeamId: string): Observable<Userteam> {
    return this.http.put<Userteam>(this.authUrl + 'mas-user-teams/activateordeactivate/' + masUserTeamId , httpOptions).pipe(
      tap(_ => this.log(`deactivate Userteam masUserTeamId=${masUserTeamId}`)),
      catchError(this.handleError<Userteam>('deactvateUserteam'))
    );
  }

  private handleError<T>(operation = 'operation', result?: T) {
    return (e: any): Observable<T> => {
      console.log(e);
      const error = e.error.message || e.error.error || e.error.error_description || 'Could not connect server';
      console.log(error);
      this.messageBoxService.getErrorMessage('ERROR', error);
      return of(result as T);
    };
  }
  private log(error: any) {
    console.log(error);
    if (error.message) {
      this.messageBoxService.getErrorMessage('ERROR', error.message);
    }
  }
}

