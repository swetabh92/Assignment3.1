export class Usergroup {
  isActive: true;
  masGroupId: number;
  masUserGroupId: number;
  masUsersId: number;
    constructor() { }
  }
