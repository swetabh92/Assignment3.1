import {Component, OnInit, ViewChild,Input} from '@angular/core';
import {PaginationService} from '../../../commons/services/pagination/pagination.service';
import {ExceptionManagementService} from '../../masters/services/dashboard/exception-management.service';
import {FormBuilder} from '@angular/forms';
import {exceptionTypes, getModuleCodeMap} from "./models/excpetion-resolution-model";
import {MessageBoxService} from "../../masters/services/commons/message-box.service";
import {ExceptionMasterService} from "../../masters/components/others/exception-master/exception-master-service";
import {ExceptionManagementModel} from "./models/excpetion-management-model";
import {ExceptionManagementUtil} from "./utils/exception-management-util";
import {ExceptionTransactionTableComponent} from "./exception-transaction-table/exception-transaction-table.component";
import {SearchExceptionComponent} from "./search-exception/search-exception.component";

@Component({
  selector: 'app-excpetion-management',
  templateUrl: './excpetion-management.component.html',
  styleUrls: ['./excpetion-management.component.css'],
  providers: [ExceptionManagementModel]
})
export class ExcpetionManagementComponent implements OnInit {
 
  @ViewChild(ExceptionTransactionTableComponent) tableComponent: ExceptionTransactionTableComponent;
  @ViewChild(SearchExceptionComponent) searchExceptionComponent: SearchExceptionComponent;

  model: ExceptionManagementModel = new ExceptionManagementModel(this.paginateService);
  searchParams: any;

  constructor(private exceptionManagementUtil: ExceptionManagementUtil,
              private paginateService: PaginationService, private messageService: MessageBoxService,
              private exceptionManagementService: ExceptionManagementService, public formBuilder: FormBuilder,
              public exceptionMasterService: ExceptionMasterService) {
  }

  ngOnInit() {
    this.model.searchForm = this.formBuilder.group(this.model.exceptionForm);
    this.model.userForm = this.formBuilder.group(this.model.userFormObj);
    this.getAllModules();
    this.getAllGroups();
  }

  getAllModules() {
    this.exceptionMasterService.getAllModules().subscribe(response => {
      this.model['modulesList'] = response;
    });
  }

  tabChange(activeTab) {
    this.model.activeTab = activeTab;
    this.tableComponent.page = this.paginateService.setCustomPaginationConfig({"pageSize": 5});
    if (this.searchParams) {
      this.searchParams = this.searchExceptionComponent.model.searchForm.value;
      this.searchParams.moduleName = getModuleCodeMap(this.model.modulesList, this.searchExceptionComponent.model.searchForm.get('moduleId').value);
      this.searchParams.exceptionStatus = exceptionTypes()[this.model.activeTab];
      this["searchParams"] = {...this.searchParams};
    }
  }

  onSelect({selected}) {
    this.model.selected.splice(0, this.model.selected.length);
    this.model.selected.push(...selected);
  }

  onResetSearch() {
    this.model.searchSubmitted = false;
    this.model.searchForm.reset();
  }

  getAllGroups() {
    this.exceptionManagementService.getGroupAll().subscribe(response => {
      this.model['groupArr'] = response;
    });
  }

  onAssignException(): void {
    this.model.onAssignSelected = true;
    if (this.model.userForm.valid && this.exceptionManagementUtil.isAssignFormValid(this.tableComponent, this.model)) {
      let assignFormObj = this.exceptionManagementUtil.assignException(this.model, this.tableComponent);
      this.exceptionManagementService.assignException(assignFormObj).subscribe((res: any) => {
        if (res&&res.hasOwnProperty("ok") && res.ok == false) {
          this.messageService.getWarningMessage("Error", "Assignment Failed").then();
        } else {
          this.messageService.getSuccessMessage("Success", "Assigned Successfully").then();
          this.tableComponent.getTransactionData(this.searchParams);
          this.tableComponent.model.selected = [];
        }
      });
    }
  }

  onSelectReleaseAndReassign() {
    this.model.onAssignSelected = true;
    if (this.model.userForm.valid &&
      this.exceptionManagementUtil.isReleaseAndAssignFormValid(this.tableComponent, this.model)) {
      let reassignObject = this.exceptionManagementUtil.parseReleaseAndReassignObject(this.model, this.tableComponent);
      this.exceptionManagementService.reassignException(reassignObject).subscribe((res: any) => {
        this.messageService.getSuccessMessage("Success", "Re-Assigned Successfully");
        this.tableComponent.getTransactionData(this.searchParams);
        this.tableComponent.model.selected = [];
      }, (err: any) => {
        this.messageService.getWarningMessage("Error", "Re-Assigned Failed");
        this.tableComponent.model.selected = [];
      });
    }
  }
  onClickTaskStatus() {
      let searchtaskelement = document.getElementById("searchTask");
      if (searchtaskelement)
        searchtaskelement.click();
    } 

  /*
  * This function contains the instance of exception management model
  * Also this function can be removed
  * */
  exceptionInstance(exceptionManagementModel: ExceptionManagementModel) {
    exceptionManagementModel.searchParams = this.searchParams;
  }


  /*
  * This function will be triggered when search form is pressed
  * */
  onSearchParamsChanged(searchFormData) {
    if (searchFormData && 'exceptionStatus' in searchFormData)
      searchFormData.exceptionStatus = exceptionTypes()[this.model.activeTab];
    this.searchParams = searchFormData;
  }

  /*
  * On Selecting the group in user dropdown -> teams will be retrived
  * */
  onSelectGroup(groupId: string) {
    this.exceptionMasterService.getTeamsByGroupId(parseInt(groupId)).subscribe((res: any) => {
      this.model.teamArr = res;
      this.model.userArr = [];
    })
  }

  /*
  * On selecting the teams in team dropdown, users will be retrieved
  * */
  onSelectTeam(teamId: string) {
    this.exceptionMasterService.getUsersByTeamId(parseInt(teamId)).subscribe((res: any) => {
      this.model.userArr = res;
    })
  }

  get s() {
    return this.model.searchForm.controls;
  }


  onClickPendingApproval() {

  }
}
