export class BVSReported {

	salesUniqueKey:String;

	reportingAgency:number;
    agencyCode:number;
    fromPeriod:Date;
	agencyType:String;
	toPeriod:Date;
	cashBAR:String;
	cashreported:String;
    cCBAR:String;
   cCReported:String;
	taxBAR:String;
    tAXReported:String;
	feeBAR:String;
    feeReported:String;
	diffBARReported:String;
    bARVSReportedRecoStatus:String;
     batchaccountingStatus:String;
}
