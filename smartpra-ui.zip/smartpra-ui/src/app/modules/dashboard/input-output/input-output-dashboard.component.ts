import {Component, OnInit, ElementRef, Renderer, Renderer2, HostListener, ViewChild} from '@angular/core';
import {DatepickerOptions} from 'ng2-datepicker';
import {InputOutputService} from '../../masters/services/dashboard/input-output.service';
import {Subject} from 'rxjs';
import {GeneralService} from 'src/app/commons/services/general.service';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import swal from 'sweetalert2';
import {Label} from 'ng2-charts';
import {SaleInterface} from '../../masters/models/dashboard/sale-interface.model';
import {FrequencyType} from '../../masters/models/dashboard/frequency-type.model';
import {ManualUpload} from '../../masters/models/dashboard/manual-upload.model';
import {CommonService} from '../../masters/services/commons/common.service';
import {Observable, forkJoin} from 'rxjs';
import { MessageBoxService } from '../../masters/services/commons/message-box.service';
import {PaginationService} from '../../../commons/services/pagination/pagination.service';

declare var $;
declare var jQuery: any;


@Component({
  selector: 'app-input-output-dashboard',
  templateUrl: './input-output-dashboard.component.html',
  styleUrls: ['./input-output-dashboard.component.css']
})
export class InputOutputDashboardComponent implements OnInit {
  fileUpliftPartiallyTransferDetails: Object | any[];
  renderDTMultierror: boolean = false;
  searchButton: boolean = false;
  resetInInterface: any;
  inInterfaceFileLogStatus: any = '';
  moduleArr: any;
  holidayStatus: any | any[];
  addManualFormValue: any | any[];
  getListOfFilesByModule: any;
  getAllFilesList: any | any[];
  fileSel: any;
  radioSelectedString: string;
  radioSelected: string;
  showFileIcon: boolean = false;

  constructor(private inputService: InputOutputService, private commonService: CommonService, private elementRef: ElementRef, private renderer: Renderer2, private Gservice: GeneralService, private formBuilder: FormBuilder, private messageService: MessageBoxService,private paginateService: PaginationService) {
  }

  currentEvent: any;
  show = true;
  liGenerateCalendar: String = 'Generate Calendar';
  liConfigurationCalendar = 'Congfiguration Calendar';
  buttonName: any = 'Generate';
  showBarChart = false;
  saleTransferTab = false;
  // showFileDataIn_Interface:boolean = true;
  getCalendarForm: FormGroup;
  obj: any;
  objFileStatus: any;
  addManualForm: FormGroup;
  fileStatus: String;
  generateCalendarForm: FormGroup;
  addInInterfaceForm: FormGroup;
  addFileExpOutCount: FormGroup;
  crossVieldValidation = false;
  toMinDate: any;
  fromMaxDate: any;
  monthYear = true;
  fromDateToDate = false;
  calander_toggle = 'month_year';
  generateCalendarDet: any;
  config_calender = true;
  renderInterfaceTab = false;
  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject<any>();
  renderDT = false;
  renderCalender = false;
  multiRecordError = 'techUpliftMultiError';
  currentModuleFileType = '';
  moduleSelectChange = '';
  manualUploadFile: any;
  manualUploadModuleType = '';
  moduleLovId: number;
  // barchart variables
  yaxismaxLength: number;
  currentInTab = '';
  tempObj: any;
  fileSaleErroneousDetails: any = [];
  fileUpliftErroneousDetails:any=[];
  fileInterlineTransferred: Object | any[];
  fileUpliftTransferredDetails: Object | any[];
  fileSaleTransferredDetails: Object | any[];
  fileSalePartiallyTransferred: Object | any[];
  fileUpliftTechFailedDetails: Object | any[];
  fileSaleTechFailedDetails: Object | any[];
  multiRecordData: Object | any[];
  calander_toggle_in = 'month_year';
  statusInd;
  @ViewChild('myInputFile')
  myInputFileReset: ElementRef;
  @ViewChild('statusPopup') statusPopup: ElementRef;
  @ViewChild('actualCount') actualCount: ElementRef;
  @ViewChild('fileLogType')
  fileLogInInterface: ElementRef;
  toggleType = 'gen_cal';
  page: any = this.paginateService.setCustomPaginationConfig({'pageSize': 5});
  private var;
  date = new Date();
  // end of moduleChange of manual upload
  options: DatepickerOptions = {
    displayFormat: 'YYYY/MM/DD',
    useEmptyBarTitle: false,
    addClass: 'currency-date-picker',
    fieldId: 'currency-date-picker-id',
    addStyle: {'width': '100%'},
    maxDate: new Date(this.date.getFullYear(), this.date.getMonth() + 1, 0),
  };


  fileCountExpOut: any = [];
  manualDetails: any = [];
  monthDays: any = [];
  fileTypesArr = [];
  calendarInterfaces: any;
  saleInterface: any;
  frequencyInterfaces: any;
  year: any;
  selectedMonth: any;
  getYear: any = [];
  selectedYear: any;
  currentTab = '';
  moduleName: any = {
    'Sales': ['BSP', 'ARC', 'ASR', 'SITA HOT', 'Amadeus HOT'],
    'Flown': ['Sabre XL', 'VCR', 'AmadeusEtkt', 'Sita E-txt', 'SSIM'],
    'Interline': ['IS-IDEC', 'IS-MISC', 'CodeShare', 'MISC_BILLING'],
    'Others': ['PMP', 'Exch.Rate'],
  };
  months: any = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  public barChartOptions = {
    scaleShowVerticalLines: false,
    responsive: true,
    // maintainAspectRatio: false,
    scales: {
      xAxes: [{
        barPercentage: 0.9
      }],
      yAxes: [{
        ticks: {
          max: 1000,
          min: 0,
          stepSize: 100,
        }
      }],
    },
    legend: {position: 'top'}
  };
  public barChartLabels = ['Jan-19', 'Dec-18', 'Nov-18', 'Oct-18', 'Sep-18', 'Aug-18', 'Jul-18'];
  public barChartType = 'bar';
  public barChartLegend = true;
  public colors: Array<any> = [
    { // first color
      backgroundColor: '#5abae0',
      borderColor: 'red',
      pointBackgroundColor: 'red',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'red'
    },
    { // second color
      backgroundColor: '#0577b3',
      borderColor: 'green',
      pointBackgroundColor: 'green',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'green'
    }];
  public barChartData = [
    {data: [65, 59, 80, 81, 56, 55, 40], label: 'IS-IDEC'},
    {data: [28, 48, 40, 19, 86, 27, 90], label: 'IS-MISC'},
  ];
  showPopUp: boolean = false;
  disable_upload_button: boolean = false;

  statusOpen(e, data, index) {
    this.statusInd = index;
    e.currentTarget.classList.remove('greenBackground');
  }

  @HostListener('document:click', ['$event.target'])
  public outsideClick(targetElement) {
    if (!(this.statusPopup && this.statusPopup.nativeElement.contains(targetElement))) {
      this.statusInd = undefined;
    } else {
    }
  }

  validate_file(item) {
    let file = item;
    console.log(file);

    if (!file) {
      swal(
        this.addManualForm.value.fileType + ' ' + this.addManualForm.value.module + ' ' + 'not found',
        'Failure'
      );
    }

    /*if (file.size/1024/1024>5) {
      document.getElementById('upload_message').innerHTML = '* File size exceeds 5mb';
      this.disable_upload_button =true;
    }else{
      this.disable_upload_button =false;
    }*/
    if (!this.validateFile(file.name)) {
      document.getElementById('upload_message').innerHTML = '* Selected Format is not supported';
      return false;
    }

    console.log(this.manualUploadFile);
    console.log('size', file.size);
    console.log('type', file.type);
  }

  validateFile(name: String) {
    const ext = name.substring(name.lastIndexOf('.') + 1);
    if (ext.toLowerCase() == 'pdf' || ext.toLowerCase() == 'txt' || ext.toLowerCase() == 'prd') {
      return true;
    } else {
      return false;
    }
  }

  reset() {
    console.log(this.myInputFileReset.nativeElement.files);
    this.myInputFileReset.nativeElement.value = '';
    document.getElementById('upload_message').innerHTML = '';
    console.log(this.myInputFileReset.nativeElement.files);
  }

  toggle(type) {
    this.toggleType = type;
    if (type == 'gen_cal') {
      this.buttonName = 'Generate';
    } else {
      this.buttonName = 'Search';
    }
  }

  month_date_change(type) {
    this.calander_toggle = type;
    if (type == 'month_year') {
      this.generateCalendarForm.reset();

    } else if (type == 'from_to_date') {
      this.generateCalendarForm.reset();

    }
  }

  month_date_change_in(type) {
    this.calander_toggle_in = type;

  }

  // start of saleErroneousobjFileStatus


  // end of saleErroneous
  // moduleChange of manual upload
  moduleChange(type) {
    this.moduleSelectChange = type;

  }

  in_interface_tab_change(tab) {
    this.currentInTab = tab;
  }

  manualUploadModuleName(type) {
    console.log(type);
    this.manualUploadModuleType = type;
  }

  ngOnInit() {

    const orderFalse = [-1, -2];
    this.dtOptions = this.Gservice.getDataTableOptionsNew(orderFalse);
    this.getModules();
    // this.initMonthYear();

    // this.getCalendarInfo();
    this.getSalesModule();
    this.getFrequencyTypes();
    this.getCalYear();

    /*
   calendar interface form
  */


    this.getCalendarForm = this.formBuilder.group({
      fromDate: [''],
      toDate: [''],
      moduleName: [''],
      fileType: [''],
      frequencyTypeId: ['']
    });
    this.generateCalendarForm = this.formBuilder.group({
      fromDate: [''],
      toDate: [''],
      month: [''],
      year: [''],
      moduleName: [''],
      fileType: [''],
      frequencyTypeId: ['']
    });


    this.generateCalendarForm.controls['month'].setValue(new Date().getMonth() + 1);
    this.generateCalendarForm.controls['year'].setValue(new Date().getFullYear());


    /*
     calendar interface ends
    */
    // manual upload starts
    this.addManualForm = this.formBuilder.group({
      fileType: [''],
      module: [''],
    });
    this.addManualFormValue = this.addManualForm.value;
    // manual upload ends
    // in interface addForm starts
    this.addFileExpOutCount = this.formBuilder.group({
      month: [''],
      year: [''],
      fromDate: [''],
      toDate: [''],
      lovModuleId: [''],
    });
    this.generateCalendarForm.controls['fromDate'].valueChanges.subscribe((minDate) => {
      this.toMinDate = minDate;
    });
    this.generateCalendarForm.controls['toDate'].valueChanges.subscribe((maxDate) => {
      this.fromMaxDate = maxDate;
    });
    this.addFileExpOutCount.controls['fromDate'].valueChanges.subscribe((minDate) => {
      this.toMinDate = minDate;
    });
    this.addFileExpOutCount.controls['toDate'].valueChanges.subscribe((maxDate) => {
      this.fromMaxDate = maxDate;
    });
    const date = new Date();
    this.addFileExpOutCount.controls['month'].setValue(date.getMonth() + 1);
    this.addFileExpOutCount.controls['year'].setValue(date.getFullYear());


    // in interface addform ends

    // this.dtOptions = {
    //   searching: false,
    //   lengthChange: false,
    //   paging: false,
    //   responsive: true,
    //   //ordering: false,
    //   info: false
    //   // pagingType: 'full_numbers',
    //   // responsive: true,
    //   // lengthMenu: [[5, 10, 25, 50, -1], [5, 10, 25, 50, 'All']],
    // };
  }

  month_year_change() {
    if (this.addFileExpOutCount.get('month').value == new Date().getMonth() + 1 && this.addFileExpOutCount.get('year').value == new Date().getFullYear()) {
      console.log(this.addFileExpOutCount.get('month').value + ' ' + this.addFileExpOutCount.get('year').value);
      this.searchButton = false;
    } else {
      this.searchButton = true;
    }
  }


  tabChange(tab: any) {
    this.currentTab = tab;


    if (this.currentTab == 'Interface') {
      this.fileLogInInterface.nativeElement.click();
    }
  }

  openMultiRecordsError(event, type, fieldData) {
    this.renderDTMultierror = true;
    this.multiRecordError = type;

    this.renderDTMultierror = false;
    this.inputService.getMultiFileRecord(fieldData.fileLogId).subscribe((res) => {
      this.multiRecordData = res;
      setTimeout(() => {
        this.renderDTMultierror = true;
      }, 100);

      console.log(res);

    });

    if (fieldData && fieldData.highlight == true) {
      fieldData.highlight = false;
    } else {
      fieldData['highlight'] = true;
    }


  }

  getModules() {
    this.inputService.getAllModules().subscribe(response => {
      this.moduleArr = response;
    });
  }

  uploadFileByFileTypeAndModuleName() {

    let data = 'fileName=' + this.fileSel + '&fileType=' + this.addManualForm.value.fileType + '&module=' + this.addManualForm.value.module;
    this.inputService.uploadFileByModuleAndFileType(data).subscribe((res) => {
      this.manualDetails = res;
      console.log(this.manualDetails);
      swal(
        'Success',
        this.addManualForm.value.fileType + ' ' + this.addManualForm.value.module + ' ' + 'Batch Job initiated successfully'
      );
    });
  }

  getListOfFilesFromServer(event) {
    let manualUploadObj = {
      'fileType': this.addManualForm.value.fileType,
      'module': this.addManualForm.value.module
    };
    this.inputService.getListOFiles(manualUploadObj).subscribe((response) => {
      this.getAllFilesList = response;
      console.log(this.getAllFilesList);
    });
  }

  getSelectedItem(e) {
    this.showFileIcon = true;
    this.fileSel = this.getAllFilesList.find(item => item === this.radioSelected);
    console.log(this.fileSel);
  }

  onItemListOfFileChange(e) {
    this.getSelectedItem(e);
  }

  onModuleChange(event) {
    const moduleKey = event.currentTarget.value;
    this.fileTypesArr = [];
    const moduleArr = this.moduleName[moduleKey];
    for (let i = 0; i < moduleArr.length; i++) {
      this.fileTypesArr.push(moduleArr[i]);
    }
  }

  getFileExpOutCountByMonthYearDate() {
    // if ((new Date(this.addFileExpOutCount.value.fromPeriod) > new Date(this.addFileExpOutCount.value.toPeriod))) {
    //   this.crossVieldValidation = !this.crossVieldValidation;
    // } else {
    //   this.crossVieldValidation = this.crossVieldValidation;
    //   return false;
    // }
    let fileCount, fileLog;
    if (this.calander_toggle_in == 'from_to_date') {
      fileCount = this.inputService.getFileCountByDate(this.addFileExpOutCount.value);
      fileLog = this.inputService.getFileLogByDate(this.addFileExpOutCount.value);
    } else {
      fileCount = this.inputService.getFileCountByMonth(this.addFileExpOutCount.value);
      fileLog = this.inputService.getFileLogByMonth(this.addFileExpOutCount.value);
    }
    forkJoin([fileCount, fileLog]).subscribe((res) => {
      this.obj = res[0];
      let fileLog = res[1];
     /* console.log(fileLog);
      let moduleKeys = ['sales', 'uplift', 'interline', 'others', 'inward', 'outward'];
      let fileStageKeys = ['transferred', 'erroneous', 'partiallyTransferred', 'technicallyFailed'];
      moduleKeys.forEach((item) => {
        if (!(fileLog.hasOwnProperty(item))) {
          fileLog[item] = {};
        }

        fileStageKeys.forEach((fileStageKeys) => {
          if (fileLog[item] !== null) {
            if (fileLog[item].hasOwnProperty(fileStageKeys)) {
              if (fileLog[item][fileStageKeys] !== null) {
                if (!(fileLog[item][fileStageKeys].hasOwnProperty('count'))) {
                  fileLog[item][fileStageKeys].count = '0';
                }
              } else {
                fileLog[item][fileStageKeys] = {'count': '0'};
              }
            } else {
              fileLog[item][fileStageKeys] = {
                'count': '0'
              };
            }
          } else {
            fileLog[item] = {};
          }

        });
      });*/
      this.objFileStatus = fileLog;
      console.log(res);
    });
  }

  // file log status


  // saleErroneusFileTypeGetByMonth

  salesErroneous(event, type, data) {
    this.renderDTMultierror = false;
    if (this.calander_toggle_in == 'from_to_date') {
      const orderFalse = [-1, -2];
      this.dtOptions = this.Gservice.getDataTableOptionsNew(orderFalse);

      this.currentModuleFileType = type;
      const className = event.currentTarget.className;
      this.removeHighlightedEl();
      if (className.includes('fileTypeColor')) {
        event.currentTarget.classList.remove('fileTypeColor');

      } else {
        this.renderer.addClass(event.target, 'fileTypeColor');

      }
      let tempObj = {
        'lovModuleId': data.sales.moduleLovId
      };
      tempObj = Object.assign({}, this.addFileExpOutCount.value, tempObj);
      console.log(tempObj);
      this.renderDT = false;

      this.inputService.getFileDetailErroneousByDate(tempObj).subscribe((res) => {
        this.fileStatus = 'Sale/Erroneous';
        this.fileSaleErroneousDetails = res;
        setTimeout(() => {
          this.renderDT = true;

        }, 100);


        console.log(res);
      });

    } else {
      const orderFalse = [-1, -2];
      this.dtOptions = this.Gservice.getDataTableOptionsNew(orderFalse);

      this.currentModuleFileType = type;
      const className = event.currentTarget.className;
      this.removeHighlightedEl();
      if (className.includes('fileTypeColor')) {
        event.currentTarget.classList.remove('fileTypeColor');

      } else {
        this.renderer.addClass(event.target, 'fileTypeColor');
      }
      let tempObj = {
        'lovModuleId': data.sales.moduleLovId
      };
      tempObj = Object.assign({}, this.addFileExpOutCount.value, tempObj);
      console.log(tempObj);
      this.renderDT = false;
      this.inputService.getFileDetailErroneousByMonth(tempObj).subscribe((res) => {
        this.fileStatus = 'Sale/Erroneous';
        this.fileSaleErroneousDetails = res;
        setTimeout(() => {
          this.renderDT = true;
        }, 100);

        console.log(res);
      });

    }
  }

  // end of saleErroneusFileTypeGetByMonth
  salesTransferred(event, type, data) {
    this.renderDTMultierror = false;
    if (this.calander_toggle_in == 'from_to_date') {
      const orderFalse = [-1, -2];
      this.dtOptions = this.Gservice.getDataTableOptionsNew(orderFalse);
      this.currentModuleFileType = type;
      const className = event.currentTarget.className;
      this.removeHighlightedEl();
      if (className.includes('fileTypeColor')) {
        event.currentTarget.classList.remove('fileTypeColor');

      } else {
        this.renderer.addClass(event.target, 'fileTypeColor');

      }
      let tempObj = {
        'lovModuleId': data.sales.moduleLovId
      };
      tempObj = Object.assign({}, this.addFileExpOutCount.value, tempObj);
      console.log(tempObj);
      this.renderDT = false;
      this.inputService.getFileDetailsTransferrByDate(tempObj).subscribe((res) => {
        this.fileStatus = 'Sale/Transferred';
        this.fileSaleTransferredDetails = res;
        setTimeout(() => {
          this.renderDT = true;
        }, 100);
        console.log(res);
      });
    } else {
      const orderFalse = [-1, -2];
      this.dtOptions = this.Gservice.getDataTableOptionsNew(orderFalse);
      this.currentModuleFileType = type;
      const className = event.currentTarget.className;
      this.removeHighlightedEl();
      if (className.includes('fileTypeColor')) {
        event.currentTarget.classList.remove('fileTypeColor');

      } else {
        this.renderer.addClass(event.target, 'fileTypeColor');

      }
      let tempObj = {
        'lovModuleId': data.sales.moduleLovId
      };
      tempObj = Object.assign({}, this.addFileExpOutCount.value, tempObj);
      console.log(tempObj);
      this.renderDT = false;
      this.inputService.getFileDetailsTransferrByMonth(tempObj).subscribe((res) => {
        this.fileStatus = 'Sale/Transferred';
        this.fileSaleTransferredDetails = res;
        setTimeout(() => {
          this.renderDT = true;
        }, 100);
        console.log(res);
      });
    }
  }

  /*interlineTransferred*/
  // interlineTransferred(event, type, data) {
  //   this.renderDTMultierror = false;
  //   if (this.calander_toggle_in == 'from_to_date') {
  //     const orderFalse = [-1, -2];
  //     this.dtOptions = this.Gservice.getDataTableOptionsNew(orderFalse);
  //     this.currentModuleFileType = type;
  //     const className = event.currentTarget.className;
  //     this.removeHighlightedEl();
  //     if (className.includes('fileTypeColor')) {
  //       event.currentTarget.classList.remove('fileTypeColor');
  //
  //     } else {
  //       this.renderer.addClass(event.target, 'fileTypeColor');
  //
  //     }
  //     let tempObj = {
  //       'lovModuleId': data.interline.moduleLovId
  //     };
  //     tempObj = Object.assign({}, this.addFileExpOutCount.value, tempObj);
  //     console.log(tempObj);
  //     this.renderDT = false;
  //     this.inputService.getFileDetailsInterlineByDate(tempObj).subscribe((res) => {
  //       this.fileStatus = 'Interline/Transferred';
  //       this.fileInterlineTransferred = res;
  //       setTimeout(() => {
  //         this.renderDT = true;
  //       }, 100);
  //       console.log(res);
  //     });
  //   } else {
  //     const orderFalse = [-1, -2];
  //     this.dtOptions = this.Gservice.getDataTableOptionsNew(orderFalse);
  //     this.currentModuleFileType = type;
  //     const className = event.currentTarget.className;
  //     this.removeHighlightedEl();
  //     if (className.includes('fileTypeColor')) {
  //       event.currentTarget.classList.remove('fileTypeColor');
  //
  //     } else {
  //       this.renderer.addClass(event.target, 'fileTypeColor');
  //
  //     }
  //     let tempObj = {
  //       'lovModuleId': data.interline.moduleLovId
  //     };
  //     tempObj = Object.assign({}, this.addFileExpOutCount.value, tempObj);
  //     console.log(tempObj);
  //     this.renderDT = false;
  //     this.inputService.getFileDetailsInterlineByMonth(tempObj).subscribe((res) => {
  //       this.fileStatus = 'Interline/PartiallyTransferred';
  //       this.fileInterlineTransferred = res;
  //       setTimeout(() => {
  //         this.renderDT = true;
  //       }, 100);
  //       console.log(res);
  //     });
  //   }
  // }

  /*end of interline Transferred*/

  /*sale partially transfered*/
  salesPartiallyTransferred(event, type, data) {
    this.renderDTMultierror = false;
    if (this.calander_toggle_in == 'from_to_date') {
      const orderFalse = [-1, -2];
      this.dtOptions = this.Gservice.getDataTableOptionsNew(orderFalse);
      this.currentModuleFileType = type;
      const className = event.currentTarget.className;
      this.removeHighlightedEl();
      if (className.includes('fileTypeColor')) {
        event.currentTarget.classList.remove('fileTypeColor');

      } else {
        this.renderer.addClass(event.target, 'fileTypeColor');

      }
      let tempObj = {
        'lovModuleId': data.sales.moduleLovId
      };
      tempObj = Object.assign({}, this.addFileExpOutCount.value, tempObj);
      console.log(tempObj);
      this.renderDT = false;
      this.inputService.getFileDetailsPartiallyByDate(tempObj).subscribe((res) => {
        this.fileStatus = 'Sale/PartiallyTransferred';
        this.fileSalePartiallyTransferred = res;
        setTimeout(() => {
          this.renderDT = true;
        }, 100);
        console.log(res);
      });
    } else {
      const orderFalse = [-1, -2];
      this.dtOptions = this.Gservice.getDataTableOptionsNew(orderFalse);
      this.currentModuleFileType = type;
      const className = event.currentTarget.className;
      this.removeHighlightedEl();
      if (className.includes('fileTypeColor')) {
        event.currentTarget.classList.remove('fileTypeColor');

      } else {
        this.renderer.addClass(event.target, 'fileTypeColor');

      }
      let tempObj = {
        'lovModuleId': data.sales.moduleLovId
      };
      tempObj = Object.assign({}, this.addFileExpOutCount.value, tempObj);
      console.log(tempObj);
      this.renderDT = false;
      this.inputService.getFileDetailsPartiallyByMonth(tempObj).subscribe((res) => {
        this.fileStatus = 'Sale/PartiallyTransferred';
        this.fileSalePartiallyTransferred = res;
        setTimeout(() => {
          this.renderDT = true;
        }, 100);
        console.log(res);
      });
    }
  }

  /*end of sale partially transferred*/
  upliftErroneous(event, type, data) {
    if (this.calander_toggle_in == 'from_to_date') {
      this.currentModuleFileType = type;
      const className = event.currentTarget.className;
      this.removeHighlightedEl();
      if (className.includes('fileTypeColor')) {
        event.currentTarget.classList.remove('fileTypeColor');
      } else {
        this.renderer.addClass(event.target, 'fileTypeColor');
      }

      let tempObj = {
        'lovModuleId': data.uplift.moduleLovId
      };
      tempObj = Object.assign({}, this.addFileExpOutCount.value, tempObj);
      console.log(tempObj);
      this.renderDT = false;
      this.inputService.getFileDetailErroneousByDate(tempObj).subscribe((res) => {
        this.fileUpliftErroneousDetails = res;
        setTimeout(() => {
          this.renderDT = true;
        }, 100);
        this.fileStatus = 'Uplift/Erroneous';
        console.log(res);
      });
    } else {
      this.currentModuleFileType = type;
      const className = event.currentTarget.className;

      this.removeHighlightedEl();

      if (className.includes('fileTypeColor')) {
        event.currentTarget.classList.remove('fileTypeColor');

      } else {
        this.renderer.addClass(event.target, 'fileTypeColor');

      }

      let tempObj = {
        'lovModuleId': data.uplift.moduleLovId
      };
      tempObj = Object.assign({}, this.addFileExpOutCount.value, tempObj);
      console.log(tempObj);
      this.renderDT = false;
      this.inputService.getFileDetailErroneousByMonth(tempObj).subscribe((res) => {
        this.fileUpliftErroneousDetails = res;
        setTimeout(() => {
          this.renderDT = true;
        }, 100);
        this.fileStatus = 'Uplift/Erroneous';
        console.log(res);
      });
    }
  }

  upliftTransferred(event, type, data) {
    this.renderDTMultierror = false;
    if (this.calander_toggle_in == 'from_to_date') {
      const orderFalse = [-1, -2];
      this.dtOptions = this.Gservice.getDataTableOptionsNew(orderFalse);
      this.currentModuleFileType = type;
      console.log(type);
      const className = event.currentTarget.className;
      this.removeHighlightedEl();
      if (className.includes('fileTypeColor')) {
        event.currentTarget.classList.remove('fileTypeColor');

      } else {
        this.renderer.addClass(event.target, 'fileTypeColor');

      }
      let tempObj = {
        'lovModuleId': data.uplift.moduleLovId
      };
      tempObj = Object.assign({}, this.addFileExpOutCount.value, tempObj);
      console.log(tempObj);
      this.renderDT = false;
      this.inputService.getFileDetailsTransferrByDate(tempObj).subscribe((res) => {
        this.fileUpliftTransferredDetails = res;
        this.fileStatus = 'Uplift/Transferred';
        setTimeout(() => {
          this.renderDT = true;
        }, 100);
        console.log(res);
      });
    } else {
      const orderFalse = [-1, -2];
      this.dtOptions = this.Gservice.getDataTableOptionsNew(orderFalse);
      this.currentModuleFileType = type;
      console.log(type);
      const className = event.currentTarget.className;
      this.removeHighlightedEl();
      if (className.includes('fileTypeColor')) {
        event.currentTarget.classList.remove('fileTypeColor');

      } else {
        this.renderer.addClass(event.target, 'fileTypeColor');

      }
      let tempObj = {
        'lovModuleId': data.uplift.moduleLovId
      };
      tempObj = Object.assign({}, this.addFileExpOutCount.value, tempObj);
      console.log(tempObj);
      this.renderDT = false;
      this.inputService.getFileDetailsTransferrByMonth(tempObj).subscribe((res) => {
        this.fileUpliftTransferredDetails = res;
        this.fileStatus = 'Uplift/Transferred';
        setTimeout(() => {
          this.renderDT = true;
        }, 100);
        console.log(res);
      });
    }
  }

  /*saleTechFailed*/
  saleTechFailed(event, type, data) {
    this.renderDTMultierror = false;
    if (this.calander_toggle_in == 'from_to_date') {
      const orderFalse = [-1, -2];
      this.dtOptions = this.Gservice.getDataTableOptionsNew(orderFalse);
      this.currentModuleFileType = type;
      const className = event.currentTarget.className;
      this.removeHighlightedEl();
      if (className.includes('fileTypeColor')) {
        event.currentTarget.classList.remove('fileTypeColor');

      } else {
        this.renderer.addClass(event.target, 'fileTypeColor');

      }
      let tempObj = {
        'lovModuleId': data.sales.moduleLovId
      };
      tempObj = Object.assign({}, this.addFileExpOutCount.value, tempObj);
      console.log(tempObj);
      this.renderDT = false;
      this.inputService.getFileDetailsTechFailedByDate(tempObj).subscribe((res) => {
        this.fileSaleTechFailedDetails = res;
        this.fileStatus = 'Sale/Tech.Failed';
        setTimeout(() => {
          this.renderDT = true;
        }, 100);
        console.log(res);
      });
    } else {
      const orderFalse = [-1, -2];
      this.dtOptions = this.Gservice.getDataTableOptionsNew(orderFalse);
      this.currentModuleFileType = type;
      const className = event.currentTarget.className;
      this.removeHighlightedEl();
      if (className.includes('fileTypeColor')) {
        event.currentTarget.classList.remove('fileTypeColor');

      } else {
        this.renderer.addClass(event.target, 'fileTypeColor');

      }
      let tempObj = {
        'lovModuleId': data.sales.moduleLovId
      };
      tempObj = Object.assign({}, this.addFileExpOutCount.value, tempObj);
      console.log(tempObj);
      this.renderDT = false;
      this.inputService.getFileDetailsTechFailedByMonth(tempObj).subscribe((res) => {
        this.fileSaleTechFailedDetails = res;
        this.fileStatus = 'Sale/Tech.Failed';
        setTimeout(() => {
          this.renderDT = true;
        }, 100);
        console.log(res);
      });
    }
  }

  /*saletechfaliedends*/
  upliftPartiallyTransferred(event, type, data) {
    this.renderDTMultierror = false;
    if (this.calander_toggle_in == 'from_to_date') {
      const orderFalse = [-1, -2];
      this.dtOptions = this.Gservice.getDataTableOptionsNew(orderFalse);
      this.currentModuleFileType = type;
      console.log(type);
      const className = event.currentTarget.className;
      this.removeHighlightedEl();
      if (className.includes('fileTypeColor')) {
        event.currentTarget.classList.remove('fileTypeColor');

      } else {
        this.renderer.addClass(event.target, 'fileTypeColor');

      }
      let tempObj = {
        'lovModuleId': data.uplift.moduleLovId
      };
      tempObj = Object.assign({}, this.addFileExpOutCount.value, tempObj);
      console.log(tempObj);
      this.renderDT = false;
      this.inputService.getFileDetailsPartiallyByDate(tempObj).subscribe((res) => {
        this.fileUpliftPartiallyTransferDetails = res;
        this.fileStatus = 'Uplift/PartiallyFailed';
        setTimeout(() => {
          this.renderDT = true;
        }, 100);
        console.log(res);
      });
    } else {

      const orderFalse = [-1, -2];
      this.dtOptions = this.Gservice.getDataTableOptionsNew(orderFalse);
      this.currentModuleFileType = type;
      console.log(type);
      const className = event.currentTarget.className;
      this.removeHighlightedEl();
      if (className.includes('fileTypeColor')) {
        event.currentTarget.classList.remove('fileTypeColor');

      } else {
        this.renderer.addClass(event.target, 'fileTypeColor');

      }
      let tempObj = {
        'lovModuleId': data.uplift.moduleLovId
      };
      tempObj = Object.assign({}, this.addFileExpOutCount.value, tempObj);
      console.log(tempObj);
      this.renderDT = false;
      this.inputService.getFileDetailsPartiallyByMonth(tempObj).subscribe((res) => {
        this.fileUpliftPartiallyTransferDetails = res;
        this.fileStatus = 'Uplift/PartiallyFailed';
        setTimeout(() => {
          this.renderDT = true;
        }, 100);
        console.log(res);
      });
    }
  }

  /*uplift tech-failed*/
  upliftTechFailed(event, type, data) {
    this.renderDTMultierror = false;
    if (this.calander_toggle_in == 'from_to_date') {
      const orderFalse = [-1, -2];
      this.dtOptions = this.Gservice.getDataTableOptionsNew(orderFalse);
      this.currentModuleFileType = type;
      console.log(type);
      const className = event.currentTarget.className;
      this.removeHighlightedEl();
      if (className.includes('fileTypeColor')) {
        event.currentTarget.classList.remove('fileTypeColor');

      } else {
        this.renderer.addClass(event.target, 'fileTypeColor');

      }
      let tempObj = {
        'lovModuleId': data.uplift.moduleLovId
      };
      tempObj = Object.assign({}, this.addFileExpOutCount.value, tempObj);
      console.log(tempObj);
      this.renderDT = false;

      this.inputService.getFileDetailsTechFailedByDate(tempObj).subscribe((res) => {
        this.fileUpliftTechFailedDetails = res;
        this.fileStatus = 'Uplift/Tech.Failed';
        setTimeout(() => {
          this.renderDT = true;

        }, 100);
        console.log(res);
      });
    } else {

      const orderFalse = [-1, -2];
      this.dtOptions = this.Gservice.getDataTableOptionsNew(orderFalse);
      this.currentModuleFileType = type;
      console.log(type);
      const className = event.currentTarget.className;
      this.removeHighlightedEl();
      if (className.includes('fileTypeColor')) {
        event.currentTarget.classList.remove('fileTypeColor');

      } else {
        this.renderer.addClass(event.target, 'fileTypeColor');

      }
      let tempObj = {
        'lovModuleId': data.uplift.moduleLovId
      };
      tempObj = Object.assign({}, this.addFileExpOutCount.value, tempObj);
      console.log(tempObj);
      this.renderDT = false;

      this.inputService.getFileDetailsTechFailedByMonth(tempObj).subscribe((res) => {
        this.fileUpliftTechFailedDetails = res;
        this.fileStatus = 'Uplift/Tech.Failed';
        setTimeout(() => {
          this.renderDT = true;

        }, 100);
        console.log(res);
      });
    }
  }

  /* delete tech-failed file */
  deleteTechFailed(fileID: number) {
    this.inputService.deleteTechFailedFile(fileID).subscribe((res) => {
      this.messageService.getSuccessMessage("Success", "Deleted Successfully").then();
    });
  }

  /*uplift tech-failed ends  */
  getCalendarFiles() {


    if ((new Date(this.getCalendarForm.value.fromPeriod) > new Date(this.getCalendarForm.value.toPeriod))) {
      this.crossVieldValidation = !this.crossVieldValidation;
    } else {
      this.crossVieldValidation = this.crossVieldValidation;
    }
  }

  // onGenerateCalendar
  onGenerateCalendar() {
    console.log(this.calander_toggle);
    if (this.calander_toggle == 'from_to_date') {
      console.log(this.generateCalendarForm.value);
      console.log('year' + this.generateCalendarForm.value.year);
      if (this.generateCalendarForm.invalid) {
        swal(
          'Error',
          'sorry error in the form',
          'error'
        );
      } else {
        this.generateCalendarDet = [];
        this.inputService.generateCalendarFile(this.generateCalendarForm.value).subscribe((res) => {
          this.generateCalendarDet = res;
          this.initMonthYear(res);
          this.getFileCount(res);
          this.getDaysMonth();
          this.renderCalender = true;
          console.log(res);
        });

      }
    } else {
      if (this.generateCalendarForm.invalid) {
        swal(
          'Error',
          'sorry error in the form',
          'error'
        );
      } else {
        this.generateCalendarDet = [];
        this.inputService.generateCalendarByMonthAndYear(this.generateCalendarForm.value).subscribe((res) => {
          this.generateCalendarDet = res;
          this.initMonthYear(res);
          this.getFileCount(res);
          this.getDaysMonth();
          this.renderCalender = true;
          console.log(res);
        });

      }
    }
  }

  // end of onGenerateCalendar


  // get Calendar interface
  // getCalendarInfo(){
  // this.inputService.getCalendar().subscribe((res:CalendarInterface[])=>{
  // this.calendarInterfaces = res;
  // console.log(this.calendarInterfaces);
  // this.initMonthYear(res);
  // this.getDaysMonth();
  // this.getFileCount(res)

  // });
  // }
  // end of get Calendar interface
  // fetching frequency
  getFrequencyTypes() {
    this.inputService.getFrequencyType().subscribe((res: FrequencyType[]) => {
      this.frequencyInterfaces = res;
      console.log(this.frequencyInterfaces);
    });
  }

  // end of frequency
  // start of get sale Module
  getSalesModule() {
    this.inputService.getSaleModule().subscribe((res: SaleInterface[]) => {
      this.saleInterface = res;
      console.log(this.saleInterface);
    });
  }

  // end of get sale module
  getFileCount(res) {
    const len = res.length;

    this.calendarInterfaces = [];

    for (let i = 0; i < len; i++) {
      const tempObj = {
        'actualCount': res[i].actualCount,
        'stationCode': res[i].stationCode,
        'interfaceCalendarId': res[i].interfaceCalendarId,
        'calendarDate': res[i].calendarDate,
        'initialExpectedCount': res[i].initialExpectedCount,
        'revisedExpectedCount': res[i].revisedExpectedCount,
        'calenderDateString': res[i].calenderDateString,
        'stationId': res[i].stationId,
        'calendarGenerationId': res[i].calendarGenerationId
      };
      const date = new Date(res[i].calendarDate);
      this.selectedMonth = this.months[date.getMonth()];
      // console.log(this.selectedMonth);
      if (res[i].holidayFlag == true && this.selectedMonth == 'May') {
        tempObj.actualCount = 0;
      } else {
        tempObj.actualCount = res[i].actualCount;
      }

      this.calendarInterfaces.push(tempObj);
    }
    console.log(this.calendarInterfaces);

  }

  /*mark holiday*/
  markHoliday(data, i) {


    const tempObj = {
      'actualCount': data.actualCount,
      'calendarDate': new Date(data.calendarDate),
      'holidayFlag': true,
      'initialExpectedCount': data.initialExpectedCount - 1,
      'interfaceCalendarId': data.interfaceCalendarId,
      'revisedExpectedCount': data.revisedExpectedCount,
      'stationCode': data.stationCode,
      'calendarGenerationId': data.calendarGenerationId

    };
    console.log('data-->' + data);
    // console.log(this.calendarInterfaces[index]);
    this.inputService.markHoliday(tempObj).subscribe((res: any) => {
      if (res) {
        this.calendarInterfaces[i].holidayFlag = res.holidayFlag;
        this.calendarInterfaces[i].initialExpectedCount = res.initialExpectedCount;
        this.calendarInterfaces[i].actualCount = res.actualCount;
      }
      console.log(this.holidayStatus);
    });

  }

  /*end of mark holiday*/

  /*revoke holiday*/
  revokeHoliday(data, i) {


    const tempObj = {
      'actualCount': data.actualCount,
      'calendarDate': new Date(data.calendarDate),
      'holidayFlag': false,
      'initialExpectedCount': data.initialExpectedCount + 1,
      'interfaceCalendarId': data.interfaceCalendarId,
      'revisedExpectedCount': data.revisedExpectedCount,
      'stationCode': data.stationCode,
      'calendarGenerationId': data.calendarGenerationId

    };
    console.log('data-->' + data);
    // console.log(this.calendarInterfaces[index]);
    this.inputService.markHoliday(tempObj).subscribe((res: any) => {

      this.calendarInterfaces[i].holidayFlag = res.holidayFlag;
      this.calendarInterfaces[i].initialExpectedCount = res.initialExpectedCount;
      this.calendarInterfaces[i].actualCount = res.actualCount;
    });

  }

  /*end of revoke holiday*/
  // initMonthYear(){
  //   let date = new Date();
  //   console.log(date);
  //   this.selectedMonth = this.months[date.getMonth()];
  //   this.selectedYear  = date.getFullYear();
  // }

  getCalYear() {
    const date = new Date();
    this.selectedYear = date.getFullYear();
    this.getYear.push(this.selectedYear);
    for (let i = 1; i < 10; i++) {
      this.getYear.push(this.selectedYear + i);
    }
  }

  initMonthYear(res) {
    const len = res.length;
    for (let i = 0; i < len; i++) {
      const date = new Date(res[i].calendarDate);
      this.selectedMonth = this.months[date.getMonth()];
      this.selectedYear = date.getFullYear();
      // console.log(this.selectedMonth);
      // console.log(this.selectedYear);
    }

  }

  changeCalMonth(type) {
    if (type == 'next') {
      if (this.months.indexOf(this.selectedMonth) >= 11) {
        this.selectedYear = this.selectedYear + 1;
        this.selectedMonth = this.months[0];
      } else {
        this.selectedMonth = this.months[(this.months.indexOf(this.selectedMonth) + 1)];
      }

    } else if (type == 'prev') {
      if (this.months.indexOf(this.selectedMonth) <= 0) {
        this.selectedYear = this.selectedYear - 1;
        this.selectedMonth = this.months[11];
      } else {
        this.selectedMonth = this.months[(this.months.indexOf(this.selectedMonth) - 1)];
      }

    }
    this.getDaysMonth();
  }

  getDaysMonth() {
    this.monthDays = [];
    const year = this.selectedYear;
    const month = this.months.indexOf(this.selectedMonth);
    const daysLen = new Date(year, month + 1, 0).getDate();
    let ind = 0;
    for (let i = 0; i < daysLen; i++) {
      ind = i + 1;
      const tempObj = {
        'dayIndex': ind < 10 ? '0' + ind : ind,
        'day': this.getDay(ind)
      };
      this.monthDays.push(tempObj);
    }
  }

  getDay(day) {
    const weekday = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const year = this.selectedYear;
    const month = this.months.indexOf(this.selectedMonth);
    return weekday[new Date(year, month, day).getDay()];
  }


  openGraph() {
    this.showBarChart = !this.showBarChart;
    // this.showFileDataIn_Interface =  ! this.showFileDataIn_Interface;
  }

  removeHighlightedEl() {
    const tableEl = document.getElementById('fileTable');
    const td = tableEl.getElementsByTagName('td');

    for (let i = 0; i <= td.length; i++) {

      if ($(td[i]).hasClass('fileTypeColor')) {
        $(td[i]).removeClass();
      }


    }

  }


  // onSaleError(event) {
  //   console.log(event.target);

  //   this.renderer.addClass(event.target, 'saleErrorInterface');
  //   this.renderer.removeClass(this.elementRef.nativeElement.querySelector('.saleTransferred'), 'saleTransferInterface');
  //   this.renderer.removeClass(this.elementRef.nativeElement.querySelector('.salePartiallyTransferred'), 'salesPartiallyInterface');
  //   // this.renderer.removeClass(event.target,'saleTransferInterface');
  //   this.fileStatus = 'Sale/Erroneous';

  // }
  // onUpliftErroneousTransfer(event){
  //   console.log(event.target);
  //   this.renderer.addClass(event.target, 'upliftErroneous');
  //   this.fileStatus='Uplift/Erroneous';
  // }
  // onSaleTransfer(event) {
  //   console.log(event.target);
  //   this.renderer.addClass(event.target, 'saleTransferInterface');
  //   this.renderer.removeClass(this.elementRef.nativeElement.querySelector('.saleError'), 'saleErrorInterface');
  //   this.renderer.removeClass(this.elementRef.nativeElement.querySelector('.salePartiallyTransferred'), 'salesPartiallyInterface');
  //   // this.renderer.removeClass(event.target,'saleErrorInterface');
  //   this.fileStatus = 'Sale/Transferred';

  // }
  // onSalePartiallyTransfer(event) {
  //   console.log(event.target);
  //   this.renderer.addClass(event.target, 'salesPartiallyInterface');
  //   this.renderer.removeClass(this.elementRef.nativeElement.querySelector('.saleError'), 'saleErrorInterface');
  //   this.renderer.removeClass(this.elementRef.nativeElement.querySelector('.saleTransferred'), 'saleTransferInterface');
  //   this.fileStatus = 'Sale/Partially Transferred';
  // }


  // onClickHolidayTracker(data) {
  //   let td = document.getElementById("#interface_calendar");
  //   for(let i=0;i<data.actualCount.length;i++){
  //        $(td[i]).addClass('tooltip1');
  //   }
  // }

}

// function valid_form()
// {
// return valid;
// }
// $(document).ready(function () {
//   $(".tbtn").click(function () {
//     $(this).parents(".custom-table").find(".toggler1").removeClass("toggler1");
//     $(this).parents("tbody").find(".toggler").addClass("toggler1");
//     $(this).parents(".custom-table").find(".fa-minus-circle").removeClass("fa-minus-circle");
//     $(this).parents("tbody").find(".fa-plus-circle").addClass("fa-minus-circle");
//   });

// });



