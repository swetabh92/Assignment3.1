import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AircraftMasterRoutingModule } from './aircraft-master-routing.module';
import { AircraftMasterComponent } from './aircraft-master.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { CoreDataModule } from 'src/app/core-data/core-data.module';

@NgModule({
  imports: [
    CommonModule,
    CoreDataModule,
    SharedModule,
    AircraftMasterRoutingModule
  ],
  declarations: [
    AircraftMasterComponent
  ]
})
export class AircraftMasterModule { }
