package com.sgl.smartpra.batch.fdr.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.batch.fdr.app.service.FDRService;

@RestController
public class FDRController {

	@Autowired
	private FDRService fdrService;

	@RequestMapping("/fdr/invoke-job")
	public String handle(@RequestParam("fileName") String fileName) throws Exception {

		return fdrService.executeFDRStgInboundJob(fileName, "Manual");
	}
}
