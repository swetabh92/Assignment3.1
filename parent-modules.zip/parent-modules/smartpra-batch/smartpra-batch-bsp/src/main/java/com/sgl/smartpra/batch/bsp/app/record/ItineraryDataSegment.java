package com.sgl.smartpra.batch.bsp.app.record;

import java.util.ArrayList;

import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;
import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;

public class ItineraryDataSegment extends BSPBaseRecord {

	@Override
	public String getRecordType() {
		return BSPRecordType.ITINERARY_DATA_SEGMENT;
	}

	// Layout of Itinerary Data Segment Record
	public class ItineraryDataSegmentLayout extends FixedLengthRecordLayout {
		public ItineraryDataSegmentLayout(String handbookRevisionNumber) {
			fixedLengthFieldLayoutList = new ArrayList<FixedLengthFieldLayout>();

			// entire line
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("line", 1, 136));

			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdMessageIdentifier", 1, 3));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("seqNumber", 4, 11));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdNumericQuaifier", 12, 13));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("dateOfIssue", 14, 19));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("transactionNumber", 20, 25));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("tktDocNumber", 26, 39));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("checkDigit", 40, 40));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("segmentIdentifier", 41, 41));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stopoverCode", 42, 42));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("notValidBeforeDate", 43, 47));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("notValidAfterDate", 48, 52));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("orginAirportCityCode", 53, 57));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("destAirportCityCode", 58, 62));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("carrier", 63, 65));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("soldPassengerCabin", 66, 66));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("flightNumber", 67, 71));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("reservationBookingDesignator", 72, 73));

			switch (handbookRevisionNumber) {

			case "220":
			case "223":
				fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("flightDate", 74, 78));
				fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("flightDepartTime", 79, 83));
				fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("flightBookingStatus", 84, 85));
				fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("baggageAllowance", 86, 87));
				fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("fareBasisTktDesignator", 89, 103));
				fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("frequentFlyerReference", 104, 123));
				fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("fareComProcesPassTypeCode", 124, 126));
				break;
			default:
				fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("flightDate", 74, 80));
				fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("flightDepartTime", 81, 85));
				fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("flightBookingStatus", 86, 87));
				fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("baggageAllowance", 88, 90));
				fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("fareBasisTktDesignator", 91, 105));
				fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("frequentFlyerReference", 106, 125));
				fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("fareComProcesPassTypeCode", 126, 128));
			}

			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("changeOfGuageIndicator", 129, 129));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("equipmentCode", 130, 132));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("filler", 133, 136));

		}
	}

	@Override
	public LineTokenizer lineTokenizer(String handbookRevisionNumber) {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		ItineraryDataSegmentLayout itineraryDataSegmentLayout = new ItineraryDataSegmentLayout(handbookRevisionNumber);
		tokenizer.setColumns(itineraryDataSegmentLayout.getColumns());
		tokenizer.setNames(itineraryDataSegmentLayout.getNames());
		return tokenizer;
	}

	@Override
	public FieldSetMapper<BSPBaseRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<BSPBaseRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<BSPBaseRecord>();
		fieldSetMapper.setTargetType(this.getClass());
		return fieldSetMapper;
	}

	// Variables to hold the record values
	private String stdMessageIdentifier;
	private String seqNumber;
	private String stdNumericQuaifier;
	private String dateOfIssue;
	private String transactionNumber;
	private String tktDocNumber;
	private String checkDigit;
	private String segmentIdentifier;
	private String stopoverCode;
	private String notValidBeforeDate;
	private String notValidAfterDate;
	private String orginAirportCityCode;
	private String destAirportCityCode;
	private String carrier;
	private String soldPassengerCabin;
	private String flightNumber;
	private String reservationBookingDesignator;
	private String flightDate;
	private String flightDepartTime;
	private String flightBookingStatus;
	private String baggageAllowance;
	private String fareBasisTktDesignator;
	private String frequentFlyerReference;
	private String fareComProcesPassTypeCode;
	private String changeOfGuageIndicator;
	private String equipmentCode;
	private String filler;

	public String getStdMessageIdentifier() {
		return stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getSeqNumber() {
		return seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdNumericQuaifier() {
		return stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getDateOfIssue() {
		return dateOfIssue;
	}

	public void setDateOfIssue(String dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}

	public String getTransactionNumber() {
		return transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

	public String getTktDocNumber() {
		return tktDocNumber;
	}

	public void setTktDocNumber(String tktDocNumber) {
		this.tktDocNumber = tktDocNumber;
	}

	public String getCheckDigit() {
		return checkDigit;
	}

	public void setCheckDigit(String checkDigit) {
		this.checkDigit = checkDigit;
	}

	public String getSegmentIdentifier() {
		return segmentIdentifier;
	}

	public void setSegmentIdentifier(String segmentIdentifier) {
		this.segmentIdentifier = segmentIdentifier;
	}

	public String getStopoverCode() {
		return stopoverCode;
	}

	public void setStopoverCode(String stopoverCode) {
		this.stopoverCode = stopoverCode;
	}

	public String getNotValidBeforeDate() {
		return notValidBeforeDate;
	}

	public void setNotValidBeforeDate(String notValidBeforeDate) {
		this.notValidBeforeDate = notValidBeforeDate;
	}

	public String getNotValidAfterDate() {
		return notValidAfterDate;
	}

	public void setNotValidAfterDate(String notValidAfterDate) {
		this.notValidAfterDate = notValidAfterDate;
	}

	public String getOrginAirportCityCode() {
		return orginAirportCityCode;
	}

	public void setOrginAirportCityCode(String orginAirportCityCode) {
		this.orginAirportCityCode = orginAirportCityCode;
	}

	public String getDestAirportCityCode() {
		return destAirportCityCode;
	}

	public void setDestAirportCityCode(String destAirportCityCode) {
		this.destAirportCityCode = destAirportCityCode;
	}

	public String getCarrier() {
		return carrier;
	}

	public void setCarrier(String carrier) {
		this.carrier = carrier;
	}

	public String getSoldPassengerCabin() {
		return soldPassengerCabin;
	}

	public void setSoldPassengerCabin(String soldPassengerCabin) {
		this.soldPassengerCabin = soldPassengerCabin;
	}

	public String getFlightNumber() {
		return flightNumber;
	}

	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}

	public String getReservationBookingDesignator() {
		return reservationBookingDesignator;
	}

	public void setReservationBookingDesignator(String reservationBookingDesignator) {
		this.reservationBookingDesignator = reservationBookingDesignator;
	}

	public String getFlightDate() {
		return flightDate;
	}

	public void setFlightDate(String flightDate) {
		this.flightDate = flightDate;
	}

	public String getFlightDepartTime() {
		return flightDepartTime;
	}

	public void setFlightDepartTime(String flightDepartTime) {
		this.flightDepartTime = flightDepartTime;
	}

	public String getFlightBookingStatus() {
		return flightBookingStatus;
	}

	public void setFlightBookingStatus(String flightBookingStatus) {
		this.flightBookingStatus = flightBookingStatus;
	}

	public String getBaggageAllowance() {
		return baggageAllowance;
	}

	public void setBaggageAllowance(String baggageAllowance) {
		this.baggageAllowance = baggageAllowance;
	}

	public String getFareBasisTktDesignator() {
		return fareBasisTktDesignator;
	}

	public void setFareBasisTktDesignator(String fareBasisTktDesignator) {
		this.fareBasisTktDesignator = fareBasisTktDesignator;
	}

	public String getFrequentFlyerReference() {
		return frequentFlyerReference;
	}

	public void setFrequentFlyerReference(String frequentFlyerReference) {
		this.frequentFlyerReference = frequentFlyerReference;
	}

	public String getFareComProcesPassTypeCode() {
		return fareComProcesPassTypeCode;
	}

	public void setFareComProcesPassTypeCode(String fareComProcesPassTypeCode) {
		this.fareComProcesPassTypeCode = fareComProcesPassTypeCode;
	}

	public String getChangeOfGuageIndicator() {
		return changeOfGuageIndicator;
	}

	public void setChangeOfGuageIndicator(String changeOfGuageIndicator) {
		this.changeOfGuageIndicator = changeOfGuageIndicator;
	}

	public String getEquipmentCode() {
		return equipmentCode;
	}

	public void setEquipmentCode(String equipmentCode) {
		this.equipmentCode = equipmentCode;
	}

	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}
}