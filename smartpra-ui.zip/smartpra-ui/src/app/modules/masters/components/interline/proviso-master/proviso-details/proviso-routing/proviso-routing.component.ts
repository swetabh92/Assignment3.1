import { Component, OnInit, ViewChild, Input, Output, ElementRef, OnDestroy, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { GeneralService } from '../../../../../../../commons/services/general.service';
import swal from 'sweetalert2';
import { ProvisoRouting } from '../../../../../models/interline/proviso-routing';
import { MessageBoxService } from '../../../../../services/commons/message-box.service';
import { PaginationService } from '../../../../../../../commons/services/pagination/pagination.service';
import { ProvisoRoutingService } from 'src/app/modules/masters/services/interline/proviso-master-main/proviso-routing.service';
import { UserDefinedAreaMasterComponent } from '../../../../proration/user-defined-area-master/user-defined-area-master.component';

@Component({
  selector: 'app-proviso-routing',
  templateUrl: './proviso-routing.component.html',
  styleUrls: ['./proviso-routing.component.css']
})
export class ProvisoRoutingComponent implements OnInit {

  @Input('triggerProvisoRouting')
  set triggerProvisoRouting(val: any) {
    if (val != undefined) {
      this.provisoRoute = val;
    }
  }
  @ViewChild(UserDefinedAreaMasterComponent) userDefinedAreaView: UserDefinedAreaMasterComponent;
  successResult: any;
  provisoRoute: ProvisoRouting[]=[];
  provisoRouting: any;
  marked = false;
  provisoID: number;
  editProvisoRouting: FormGroup;
  formObj = {
		carrierNumCode: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(3)]],
    provisoSeqNumber: ['', [Validators.required]],
    detailRecNumber: [''],
    routingRecNumber: [''],
    areaTypeFlag: [''],
    areaCheckType: [''],
    areaFrom: [''],
    areaTo: [''],
    clientId: [''],
  };
  error: any = { isError: false, errorMessage: '' };
  page: any = this.paginateService.getPageinateConfig();
  constructor(private paginateService: PaginationService,private generalService: GeneralService, private provisoRoutingService: ProvisoRoutingService,
    private formBuilder: FormBuilder, private router: Router, private messageBoxService: MessageBoxService) { }

  ngOnInit() {

    let editForm = Object.assign({}, this.formObj);
		editForm['provisoMainId'] = "";
    this.editProvisoRouting = this.formBuilder.group(editForm);

  }

  showEditValues(id, type) {
		//if(type == 'update')this.resetForm('edit');else if(type=='add')this.resetForm('add');
		this.provisoRoutingService.getProvisoRouteRecordById(id).subscribe((res:any) => {
			if (type == 'update') {
				let result = Object.assign({}, res);
				this.editProvisoRouting.patchValue(result);
			//	this['setProvisoObj']['provisoMainId'] = res['provisoMainId'];
				this['setProvisoObj']['clientId'] = res['clientId'];
			}
			else {
				let result = Object.assign({}, res);
			}
		})
  }

  viewFromAndToArea(value, row, flag) {
    if (parseInt(value.substring(0, 1), 0) === 1) {
      this.userDefinedAreaView.viewCityFromAndToArea(value);
    } else if (parseInt(value.substring(0, 1), 0) === 2) {
      this.userDefinedAreaView.viewCountryFromAndToArea(value);
    } else if (parseInt(value.substring(0, 1), 0) === 3) {
      this.userDefinedAreaView.viewStandardFromAndToArea(value);
    } else if (parseInt(value.substring(0, 1), 0) === 4) {
      this.userDefinedAreaView.viewUserDefFromAndToArea(value, row);
    } else if (parseInt(value.substring(0, 1), 0) === 5) {
      this.userDefinedAreaView.viewStateFromAndToArea(value);
    }
  }

}
