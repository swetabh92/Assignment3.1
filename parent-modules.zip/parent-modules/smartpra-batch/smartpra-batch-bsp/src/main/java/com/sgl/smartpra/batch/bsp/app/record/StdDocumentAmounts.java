package com.sgl.smartpra.batch.bsp.app.record;

import java.util.ArrayList;

import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;
import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;

public class StdDocumentAmounts extends BSPBaseRecord {

	@Override
	public String getRecordType() {
		return BSPRecordType.STD_DOCUMENT_AMOUNTS;
	}

	// Layout of Standard Document Amounts record
	public class StdDocumentAmountsLayout extends FixedLengthRecordLayout {
		public StdDocumentAmountsLayout() {
			fixedLengthFieldLayoutList = new ArrayList<FixedLengthFieldLayout>();

			// entire line
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("line", 1, 136));

			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdMessageIdentifier", 1, 3));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("seqNumber", 4, 11));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("stdNumericQuaifier", 12, 13));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("dateOfIssue", 14, 19));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("transactionNumber", 20, 25));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("tktDocNumber", 26, 39));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("checkDigit", 40, 40));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("commissionableAmount", 41, 51));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("netFareAmount", 52, 62));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("taxMiscFeeType1", 63, 70));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("taxMiscFeeAmount1", 71, 81));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("taxMiscFeeType2", 82, 89));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("taxMiscFeeAmount2", 90, 100));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("taxMiscFeeType3", 101, 108));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("taxMiscFeeAmount3", 109, 119));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("tktDocAmount", 120, 130));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("filler", 131, 132));
			fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("currencyType", 133, 136));
		}
	}

	@Override
	public LineTokenizer lineTokenizer(String handbookRevisionNumber) {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		StdDocumentAmountsLayout stdDocumentAmountsLayout = new StdDocumentAmountsLayout();
		tokenizer.setColumns(stdDocumentAmountsLayout.getColumns());
		tokenizer.setNames(stdDocumentAmountsLayout.getNames());
		return tokenizer;
	}

	@Override
	public FieldSetMapper<BSPBaseRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<BSPBaseRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<BSPBaseRecord>();
		fieldSetMapper.setTargetType(this.getClass());
		return fieldSetMapper;
	}

	// Variables to hold record values
	private String stdMessageIdentifier;
	private String seqNumber;
	private String stdNumericQuaifier;
	private String dateOfIssue;
	private String transactionNumber;
	private String tktDocNumber;
	private String checkDigit;
	private String commissionableAmount;
	private String netFareAmount;
	private String taxMiscFeeType1;
	private String taxMiscFeeAmount1;
	private String taxMiscFeeType2;
	private String taxMiscFeeAmount2;
	private String taxMiscFeeType3;
	private String taxMiscFeeAmount3;
	private String tktDocAmount;
	private String filler;
	private String currencyType;

	public String getStdMessageIdentifier() {
		return stdMessageIdentifier;
	}

	public void setStdMessageIdentifier(String stdMessageIdentifier) {
		this.stdMessageIdentifier = stdMessageIdentifier;
	}

	public String getSeqNumber() {
		return seqNumber;
	}

	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}

	public String getStdNumericQuaifier() {
		return stdNumericQuaifier;
	}

	public void setStdNumericQuaifier(String stdNumericQuaifier) {
		this.stdNumericQuaifier = stdNumericQuaifier;
	}

	public String getDateOfIssue() {
		return dateOfIssue;
	}

	public void setDateOfIssue(String dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}

	public String getTransactionNumber() {
		return transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

	public String getTktDocNumber() {
		return tktDocNumber;
	}

	public void setTktDocNumber(String tktDocNumber) {
		this.tktDocNumber = tktDocNumber;
	}

	public String getCheckDigit() {
		return checkDigit;
	}

	public void setCheckDigit(String checkDigit) {
		this.checkDigit = checkDigit;
	}

	public String getCommissionableAmount() {
		return commissionableAmount;
	}

	public void setCommissionableAmount(String commissionableAmount) {
		this.commissionableAmount = commissionableAmount;
	}

	public String getNetFareAmount() {
		return netFareAmount;
	}

	public void setNetFareAmount(String netFareAmount) {
		this.netFareAmount = netFareAmount;
	}

	public String getTaxMiscFeeType1() {
		return taxMiscFeeType1;
	}

	public void setTaxMiscFeeType1(String taxMiscFeeType1) {
		this.taxMiscFeeType1 = taxMiscFeeType1;
	}

	public String getTaxMiscFeeAmount1() {
		return taxMiscFeeAmount1;
	}

	public void setTaxMiscFeeAmount1(String taxMiscFeeAmount1) {
		this.taxMiscFeeAmount1 = taxMiscFeeAmount1;
	}

	public String getTaxMiscFeeType2() {
		return taxMiscFeeType2;
	}

	public void setTaxMiscFeeType2(String taxMiscFeeType2) {
		this.taxMiscFeeType2 = taxMiscFeeType2;
	}

	public String getTaxMiscFeeAmount2() {
		return taxMiscFeeAmount2;
	}

	public void setTaxMiscFeeAmount2(String taxMiscFeeAmount2) {
		this.taxMiscFeeAmount2 = taxMiscFeeAmount2;
	}

	public String getTaxMiscFeeType3() {
		return taxMiscFeeType3;
	}

	public void setTaxMiscFeeType3(String taxMiscFeeType3) {
		this.taxMiscFeeType3 = taxMiscFeeType3;
	}

	public String getTaxMiscFeeAmount3() {
		return taxMiscFeeAmount3;
	}

	public void setTaxMiscFeeAmount3(String taxMiscFeeAmount3) {
		this.taxMiscFeeAmount3 = taxMiscFeeAmount3;
	}

	public String getTktDocAmount() {
		return tktDocAmount;
	}

	public void setTktDocAmount(String tktDocAmount) {
		this.tktDocAmount = tktDocAmount;
	}

	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}

	public String getCurrencyType() {
		return currencyType;
	}

	public void setCurrencyType(String currencyType) {
		this.currencyType = currencyType;
	}
}