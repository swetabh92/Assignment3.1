import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UserroleRoutingModule } from './userrole-routing.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { UserroleComponent } from './userrole.component';
import { CoreDataModule } from 'src/app/core-data/core-data.module';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    CoreDataModule,
    UserroleRoutingModule
  ],
  declarations: [
    UserroleComponent
  ]
})
export class UserroleModule { }
