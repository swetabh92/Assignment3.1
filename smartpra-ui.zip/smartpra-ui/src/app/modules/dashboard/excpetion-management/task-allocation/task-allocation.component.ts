import {Component, OnInit, HostListener, ViewChild} from '@angular/core';
import {FormBuilder, FormGroup, FormArray, Validators} from '@angular/forms';
import {PaginationService} from '../../../../commons/services/pagination/pagination.service';
import {ExceptionManagementModel} from "../models/excpetion-management-model";
import {MessageBoxService} from "../../../masters/services/commons/message-box.service";

@Component({
  selector: 'app-task-allocation',
  templateUrl: './task-allocation.component.html',
  styleUrls: ['./task-allocation.component.css'],
  providers: [ExceptionManagementModel]
})
export class TaskAllocationComponent implements OnInit {

    @ViewChild('closeModalAdd') closeModal;
    model: ExceptionManagementModel = new ExceptionManagementModel(this.paginateService);

    constructor(public formBuilder: FormBuilder, private messageService: MessageBoxService, private paginateService: PaginationService) {}
  
    ngOnInit() {
        this.newTask();
    }

    @HostListener('document:keydown.escape', ['$event']) onKeydownHandler(event: KeyboardEvent) {
        this.closeModal.nativeElement.click();
    }

    createTask(): FormGroup {
        return this.formBuilder.group({
            name: [null, Validators.compose([Validators.required])],
        });
    }

    get taskFormGroup() {
        return this.model.taskForm.get('tasks') as FormArray;
    }

    getTasksFormGroup(index: number): FormGroup {
        this.model.taskList = this.model.taskForm.get('tasks') as FormArray;
        const formGroup = this.model.taskList.controls[index] as FormGroup;
        return formGroup;
    }

    onSubmitTask() {
        this.model.taskSubmitted = true;
        if (this.model.taskForm.valid) {
            this.newTask();
            this.closeModal.nativeElement.click();
            this.messageService.getSuccessMessage("Success", "Task has been successfully saved");
        }
    }

    newTask() {
        this.model.taskSubmitted = false;
        this.model.taskForm = this.formBuilder.group({
            tasks: this.formBuilder.array([this.createTask()])
        });
        this.model.taskList = this.model.taskForm.get('tasks') as FormArray;
    }

    addTask() {
        this.model.taskList.push(this.createTask());
    }

    removeTask(index: number) {
        this.model.taskList.removeAt(index);
    }
}