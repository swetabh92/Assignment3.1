package com.sgl.smartpra.batch.bsp.app.writer;

import java.util.List;

import org.springframework.batch.core.StepExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.sgl.smartpra.batch.bsp.app.domain.staging.AdditionalCardInfoStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.AdditionalItineraryDataStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.AddlInfoFormOfPaymentStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.AddlInfoPassengerStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.AddlTaxesInfoStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.AgentRegisterStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.BSPStagingDomainObject;
import com.sgl.smartpra.batch.bsp.app.domain.staging.CardAuthInfoStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.CommissionStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.CouponTaxInformationStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.DocumentAmountsStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.EMDCouponDetailStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.EMDRemarksStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.FareCalculationStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.FormOfPaymentStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.ItineraryDataSegmentStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.NettingValuesStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.OfficeHeaderStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.OfficeHeaderWrapperStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.OfficeSubtotalsStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.QualIssueInfoStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.RelatedTicketDocumentInfoStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.StdDocumentAmountsStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TDSCardAuthInfoStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TaxOnCommissionStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TicketDocumentIdentificationStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TransactionHeaderStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.TransactionRecordStg;
import com.sgl.smartpra.batch.bsp.app.domain.staging.UnticketedPointInfoStg;
import com.sgl.smartpra.batch.bsp.app.repository.staging.AdditionalCardInfoStgRepository;
import com.sgl.smartpra.batch.bsp.app.repository.staging.AdditionalItineraryDataStgRepository;
import com.sgl.smartpra.batch.bsp.app.repository.staging.AddlInfoFormOfPaymentStgRepository;
import com.sgl.smartpra.batch.bsp.app.repository.staging.AddlInfoPassengerStgRepository;
import com.sgl.smartpra.batch.bsp.app.repository.staging.AddlTaxesInfoStgRepository;
import com.sgl.smartpra.batch.bsp.app.repository.staging.AgentRegisterStgRepository;
import com.sgl.smartpra.batch.bsp.app.repository.staging.CardAuthInfoStgRepository;
import com.sgl.smartpra.batch.bsp.app.repository.staging.CommissionStgRepository;
import com.sgl.smartpra.batch.bsp.app.repository.staging.CouponTaxInformationStgRepository;
import com.sgl.smartpra.batch.bsp.app.repository.staging.DocumentAmountsStgRepository;
import com.sgl.smartpra.batch.bsp.app.repository.staging.EMDCouponDetailStgRepository;
import com.sgl.smartpra.batch.bsp.app.repository.staging.EMDRemarksStgRepository;
import com.sgl.smartpra.batch.bsp.app.repository.staging.FareCalculationStgRepository;
import com.sgl.smartpra.batch.bsp.app.repository.staging.FormOfPaymentStgRepository;
import com.sgl.smartpra.batch.bsp.app.repository.staging.ItineraryDataSegmentStgRepository;
import com.sgl.smartpra.batch.bsp.app.repository.staging.NettingValuesStgRepository;
import com.sgl.smartpra.batch.bsp.app.repository.staging.OfficeHeaderStgRepository;
import com.sgl.smartpra.batch.bsp.app.repository.staging.OfficeSubtotalsStgRepository;
import com.sgl.smartpra.batch.bsp.app.repository.staging.QualIssueInfoStgRepository;
import com.sgl.smartpra.batch.bsp.app.repository.staging.RelatedTicketDocumentInfoStgRepository;
import com.sgl.smartpra.batch.bsp.app.repository.staging.StdDocumentAmountsStgRepository;
import com.sgl.smartpra.batch.bsp.app.repository.staging.TDSCardAuthInfoStgRepository;
import com.sgl.smartpra.batch.bsp.app.repository.staging.TaxOnCommissionStgRepository;
import com.sgl.smartpra.batch.bsp.app.repository.staging.TicketDocumentIdentificationStgRepository;
import com.sgl.smartpra.batch.bsp.app.repository.staging.TransactionHeaderStgRepository;
import com.sgl.smartpra.batch.bsp.app.repository.staging.UnticketedPointInfoStgRepository;

public class OfficeHeaderWrapperWriter extends BSPBaseItemWriter {

	@Value("#{stepExecution}")
	private StepExecution stepExecution;

	@Autowired
	private OfficeHeaderStgRepository officeHeaderStgRepository;

	@Autowired
	private TransactionHeaderStgRepository transactionHeaderStgRepository;

	@Autowired
	private TicketDocumentIdentificationStgRepository ticketDocumentIdentificationStgRepository;

	@Autowired
	private StdDocumentAmountsStgRepository stdDocumentAmountsStgRepository;

	@Autowired
	private CouponTaxInformationStgRepository couponTaxInformationStgRepository;

	@Autowired
	private CommissionStgRepository commissionStgRepository;

	@Autowired
	private TaxOnCommissionStgRepository taxOnCommissionStgRepository;

	@Autowired
	private RelatedTicketDocumentInfoStgRepository relatedTicketDocumentInfoStgRepository;

	@Autowired
	private QualIssueInfoStgRepository qualIssueInfoStgRepository;

	@Autowired
	private NettingValuesStgRepository nettingValuesStgRepository;

	@Autowired
	private UnticketedPointInfoStgRepository unticketedPointInfoStgRepository;

	@Autowired
	private AdditionalItineraryDataStgRepository additionalItineraryDataStgRepository;

	@Autowired
	private ItineraryDataSegmentStgRepository itineraryDataSegmentStgRepository;

	@Autowired
	private DocumentAmountsStgRepository documentAmountsStgRepository;

	@Autowired
	private AddlInfoPassengerStgRepository addlInfoPassengerStgRepository;

	@Autowired
	private AddlInfoFormOfPaymentStgRepository addlInfoFormOfPaymentStgRepository;

	@Autowired
	private AddlTaxesInfoStgRepository addlTaxesInfoStgRepository;

	@Autowired
	private EMDCouponDetailStgRepository emdCouponDetailStgRepository;

	@Autowired
	private EMDRemarksStgRepository emdRemarksStgRepository;

	@Autowired
	private FareCalculationStgRepository fareCalculationStgRepository;

	@Autowired
	private AdditionalCardInfoStgRepository additionalCardInfoStgRepository;

	@Autowired
	private CardAuthInfoStgRepository cardAuthInfoStgRepository;

	@Autowired
	private TDSCardAuthInfoStgRepository tdsCardAuthInfoStgRepository;

	@Autowired
	private FormOfPaymentStgRepository formOfPaymentStgRepository;

	@Autowired
	private OfficeSubtotalsStgRepository officeSubtotalsStgRepository;

	@Autowired
	private AgentRegisterStgRepository agentRegisterStgRepository;

	private int transactionHdrId;

	@Override
	public void write(List<? extends BSPStagingDomainObject> items) throws Exception {
		items.forEach(item -> {
			OfficeHeaderWrapperStg officeHeaderWrapperStg = (OfficeHeaderWrapperStg) item;
			writeOfficeHeader(officeHeaderWrapperStg.getOfficeHeaderStg());
			writeTransactionRecord(officeHeaderWrapperStg.getTransactionRecordStgList());
			writeOfficeSubtotals(officeHeaderWrapperStg.getOfficeSubtotalsStgList());
			writeAgentRegister(officeHeaderWrapperStg.getAgentRegisterStgList());
		});
	}

	public void writeOfficeHeader(OfficeHeaderStg officeHeaderStg) {

		officeHeaderStg.setFileHdrId(stepExecution.getJobExecution().getExecutionContext().getInt("fileHeaderId"));
		officeHeaderStg.setFileId(stepExecution.getJobExecution().getExecutionContext().getInt("fileId"));
		officeHeaderStg.setBillingCycleId(stepExecution.getExecutionContext().getInt("billingCycleId"));
		super.setCreateAuditValues(officeHeaderStg);

		officeHeaderStg = officeHeaderStgRepository.save(officeHeaderStg);

		// store office header id for other records
		stepExecution.getExecutionContext().putInt("officeHeaderId", officeHeaderStg.getOfficeHdrId());
	}

	public void writeTransactionRecord(List<TransactionRecordStg> items) {
		items.forEach(item -> {
			TransactionRecordStg transactionRecordStg = (TransactionRecordStg) item;
			writeTransactionHeader(transactionRecordStg.getTransactionHeaderStg());
			writeTicketDocumentIdentification(transactionRecordStg.getTicketDocumentIdentificationStgList());
			writeStdDocumentAmounts(transactionRecordStg.getStdDocumentAmountsStgList());
			writeCouponTaxInformation(transactionRecordStg.getCouponTaxInformationStgList());
			writeCommission(transactionRecordStg.getCommissionStgList());
			writeTaxOnCommission(transactionRecordStg.getTaxOnCommissionStgList());
			writeRelatedTicketDocumentInfo(transactionRecordStg.getRelatedTicketDocumentInfoStgList());
			writeQualIssueInfo(transactionRecordStg.getQualIssueInfoStgList());
			writeNettingValues(transactionRecordStg.getNettingValuesStgList());
			writeUnticketedPointInfo(transactionRecordStg.getUnticketedPointStgInfo());
			writeAdditionalItineraryData(transactionRecordStg.getAdditionalItineraryDataStgList());
			writeItineraryDataSegment(transactionRecordStg.getItineraryDataSegmentStgList());
			writeDocumentAmounts(transactionRecordStg.getDocumentAmountsStg());
			writeAddlInfoPassenger(transactionRecordStg.getAddlInfoPassengerStg());
			writeAddlInfoFormOfPayment(transactionRecordStg.getAddlInfoFormOfPaymentStgList());
			writeAddlTaxesInfo(transactionRecordStg.getAddlTaxesInfoStgList());
			writeEMDCouponDetail(transactionRecordStg.getEmdCouponDetailStgList());
			writeEMDRemarks(transactionRecordStg.getEmdRemarksStgList());
			writeFareCalculation(transactionRecordStg.getFareCalculationStgList());
			writeAdditionalCardInfo(transactionRecordStg.getAdditionalCardInfoStgList());
			writeCardAuthInfo(transactionRecordStg.getCardAuthInfoStgList());
			writeTDSCardAuthInfo(transactionRecordStg.getTdsCardAuthInfoStgList());
			writeFormOfPayment(transactionRecordStg.getFormOfPaymentStgList());
		});
		
		stepExecution.getExecutionContext().put("transactionRecordStgCount", items.size());
	}

	private void writeTransactionHeader(TransactionHeaderStg transactionHeaderStg) {
		if (transactionHeaderStg == null) {
			return;
		}

		transactionHeaderStg.setOfficeHdrId(stepExecution.getExecutionContext().getInt("officeHeaderId"));
		transactionHeaderStg.setFileHdrId(stepExecution.getJobExecution().getExecutionContext().getInt("fileHeaderId"));
		transactionHeaderStg.setFileId(stepExecution.getJobExecution().getExecutionContext().getInt("fileId"));
		super.setCreateAuditValues(transactionHeaderStg);
		setCreateAuditValues(transactionHeaderStg);

		transactionHeaderStg = transactionHeaderStgRepository.save(transactionHeaderStg);

		// store the transaction header id
		transactionHdrId = transactionHeaderStg.getTransactionHdrId();

	}

	private void writeTicketDocumentIdentification(
			List<TicketDocumentIdentificationStg> ticketDocumentIdentificationStgList) {
		if (ticketDocumentIdentificationStgList == null) {
			return;
		}

		ticketDocumentIdentificationStgList.forEach(item -> {
			TicketDocumentIdentificationStg ticketDocumentIdentificationStg = (TicketDocumentIdentificationStg) item;
			ticketDocumentIdentificationStg.setTransactionHdrId(transactionHdrId);
			ticketDocumentIdentificationStg
					.setFileHdrId(stepExecution.getJobExecution().getExecutionContext().getInt("fileHeaderId"));
			ticketDocumentIdentificationStg
					.setFileId(stepExecution.getJobExecution().getExecutionContext().getInt("fileId"));
			setCreateAuditValues(ticketDocumentIdentificationStg);
		});

		ticketDocumentIdentificationStgRepository.saveAll(ticketDocumentIdentificationStgList);
	}

	private void writeStdDocumentAmounts(List<StdDocumentAmountsStg> stdDocumentAmountsStgList) {

		if (stdDocumentAmountsStgList == null) {
			return;
		}

		stdDocumentAmountsStgList.forEach(item -> {
			StdDocumentAmountsStg stdDocumentAmountsStg = (StdDocumentAmountsStg) item;
			stdDocumentAmountsStg.setTransactionHdrId(transactionHdrId);
			stdDocumentAmountsStg
					.setFileHdrId(stepExecution.getJobExecution().getExecutionContext().getInt("fileHeaderId"));
			stdDocumentAmountsStg.setFileId(stepExecution.getJobExecution().getExecutionContext().getInt("fileId"));
			setCreateAuditValues(stdDocumentAmountsStg);
		});

		stdDocumentAmountsStgRepository.saveAll(stdDocumentAmountsStgList);
	}

	private void writeCouponTaxInformation(List<CouponTaxInformationStg> couponTaxInformationStgList) {
		if (couponTaxInformationStgList == null) {
			return;
		}

		couponTaxInformationStgList.forEach(item -> {
			CouponTaxInformationStg couponTaxInformationStg = (CouponTaxInformationStg) item;
			couponTaxInformationStg.setTransactionHdrId(transactionHdrId);
			couponTaxInformationStg
					.setFileHdrId(stepExecution.getJobExecution().getExecutionContext().getInt("fileHeaderId"));
			couponTaxInformationStg.setFileId(stepExecution.getJobExecution().getExecutionContext().getInt("fileId"));
			setCreateAuditValues(couponTaxInformationStg);
		});

		couponTaxInformationStgRepository.saveAll(couponTaxInformationStgList);
	}

	private void writeCommission(List<CommissionStg> commissionStgList) {
		if (commissionStgList == null) {
			return;
		}

		commissionStgList.forEach(item -> {
			CommissionStg commissionStg = (CommissionStg) item;
			commissionStg.setTransactionHdrId(transactionHdrId);
			commissionStg.setFileHdrId(stepExecution.getJobExecution().getExecutionContext().getInt("fileHeaderId"));
			commissionStg.setFileId(stepExecution.getJobExecution().getExecutionContext().getInt("fileId"));
			setCreateAuditValues(commissionStg);
		});

		commissionStgRepository.saveAll(commissionStgList);
	}

	private void writeTaxOnCommission(List<TaxOnCommissionStg> taxOnCommissionStgList) {
		if (taxOnCommissionStgList == null) {
			return;
		}

		taxOnCommissionStgList.forEach(item -> {
			TaxOnCommissionStg taxOnCommissionStg = (TaxOnCommissionStg) item;
			taxOnCommissionStg.setTransactionHdrId(transactionHdrId);
			taxOnCommissionStg
					.setFileHdrId(stepExecution.getJobExecution().getExecutionContext().getInt("fileHeaderId"));
			taxOnCommissionStg.setFileId(stepExecution.getJobExecution().getExecutionContext().getInt("fileId"));
			setCreateAuditValues(taxOnCommissionStg);
		});

		taxOnCommissionStgRepository.saveAll(taxOnCommissionStgList);
	}

	private void writeRelatedTicketDocumentInfo(List<RelatedTicketDocumentInfoStg> relatedTicketDocumentInfoStgList) {
		if (relatedTicketDocumentInfoStgList == null) {
			return;
		}

		relatedTicketDocumentInfoStgList.forEach(item -> {
			RelatedTicketDocumentInfoStg relatedTicketDocumentInfoStg = (RelatedTicketDocumentInfoStg) item;
			relatedTicketDocumentInfoStg.setTransactionHdrId(transactionHdrId);
			relatedTicketDocumentInfoStg
					.setFileHdrId(stepExecution.getJobExecution().getExecutionContext().getInt("fileHeaderId"));
			relatedTicketDocumentInfoStg
					.setFileId(stepExecution.getJobExecution().getExecutionContext().getInt("fileId"));
			setCreateAuditValues(relatedTicketDocumentInfoStg);
		});

		relatedTicketDocumentInfoStgRepository.saveAll(relatedTicketDocumentInfoStgList);
	}

	private void writeQualIssueInfo(List<QualIssueInfoStg> qualIssueInfoStgList) {
		if (qualIssueInfoStgList == null) {
			return;
		}

		qualIssueInfoStgList.forEach(item -> {
			QualIssueInfoStg qualIssueInfoStg = (QualIssueInfoStg) item;
			qualIssueInfoStg.setTransactionHdrId(transactionHdrId);
			qualIssueInfoStg.setFileHdrId(stepExecution.getJobExecution().getExecutionContext().getInt("fileHeaderId"));
			qualIssueInfoStg.setFileId(stepExecution.getJobExecution().getExecutionContext().getInt("fileId"));
			setCreateAuditValues(qualIssueInfoStg);
		});

		qualIssueInfoStgRepository.saveAll(qualIssueInfoStgList);
	}

	private void writeNettingValues(List<NettingValuesStg> nettingValuesStgList) {

		if (nettingValuesStgList == null) {
			return;
		}

		nettingValuesStgList.forEach(item -> {
			NettingValuesStg nettingValuesStg = (NettingValuesStg) item;
			nettingValuesStg.setTransactionHdrId(transactionHdrId);
			nettingValuesStg.setFileHdrId(stepExecution.getJobExecution().getExecutionContext().getInt("fileHeaderId"));
			nettingValuesStg.setFileId(stepExecution.getJobExecution().getExecutionContext().getInt("fileId"));
			setCreateAuditValues(nettingValuesStg);
		});

		nettingValuesStgRepository.saveAll(nettingValuesStgList);
	}

	private void writeUnticketedPointInfo(List<UnticketedPointInfoStg> unticketedPointInfoStgList) {

		if (unticketedPointInfoStgList == null) {
			return;
		}

		unticketedPointInfoStgList.forEach(item -> {
			UnticketedPointInfoStg unticketedPointInfoStg = (UnticketedPointInfoStg) item;
			unticketedPointInfoStg.setTransactionHdrId(transactionHdrId);
			unticketedPointInfoStg
					.setFileHdrId(stepExecution.getJobExecution().getExecutionContext().getInt("fileHeaderId"));
			unticketedPointInfoStg.setFileId(stepExecution.getJobExecution().getExecutionContext().getInt("fileId"));
			setCreateAuditValues(unticketedPointInfoStg);
		});

		unticketedPointInfoStgRepository.saveAll(unticketedPointInfoStgList);
	}

	private void writeAdditionalItineraryData(List<AdditionalItineraryDataStg> additionalItineraryDataStgList) {
		if (additionalItineraryDataStgList == null) {
			return;
		}

		additionalItineraryDataStgList.forEach(item -> {
			AdditionalItineraryDataStg additionalItineraryDataStg = (AdditionalItineraryDataStg) item;
			additionalItineraryDataStg.setTransactionHdrId(transactionHdrId);
			additionalItineraryDataStg
					.setFileHdrId(stepExecution.getJobExecution().getExecutionContext().getInt("fileHeaderId"));
			additionalItineraryDataStg
					.setFileId(stepExecution.getJobExecution().getExecutionContext().getInt("fileId"));
			setCreateAuditValues(additionalItineraryDataStg);
		});

		additionalItineraryDataStgRepository.saveAll(additionalItineraryDataStgList);
	}

	private void writeItineraryDataSegment(List<ItineraryDataSegmentStg> itineraryDataSegmentStgList) {
		if (itineraryDataSegmentStgList == null) {
			return;
		}

		itineraryDataSegmentStgList.forEach(item -> {
			ItineraryDataSegmentStg itineraryDataSegmentStg = (ItineraryDataSegmentStg) item;
			itineraryDataSegmentStg.setTransactionHdrId(transactionHdrId);
			itineraryDataSegmentStg
					.setFileHdrId(stepExecution.getJobExecution().getExecutionContext().getInt("fileHeaderId"));
			itineraryDataSegmentStg.setFileId(stepExecution.getJobExecution().getExecutionContext().getInt("fileId"));
			setCreateAuditValues(itineraryDataSegmentStg);
		});

		itineraryDataSegmentStgRepository.saveAll(itineraryDataSegmentStgList);
	}

	private void writeDocumentAmounts(DocumentAmountsStg documentAmountsStg) {
		if (documentAmountsStg == null) {
			return;
		}
		setCreateAuditValues(documentAmountsStg);
		documentAmountsStg.setTransactionHdrId(transactionHdrId);
		documentAmountsStg.setFileHdrId(stepExecution.getJobExecution().getExecutionContext().getInt("fileHeaderId"));
		documentAmountsStg.setFileId(stepExecution.getJobExecution().getExecutionContext().getInt("fileId"));
		documentAmountsStgRepository.save(documentAmountsStg);
	}

	private void writeAddlInfoPassenger(AddlInfoPassengerStg addlInfoPassengerStg) {
		if (addlInfoPassengerStg == null) {
			return;
		}

		setCreateAuditValues(addlInfoPassengerStg);
		addlInfoPassengerStg.setTransactionHdrId(transactionHdrId);
		addlInfoPassengerStg.setFileHdrId(stepExecution.getJobExecution().getExecutionContext().getInt("fileHeaderId"));
		addlInfoPassengerStg.setFileId(stepExecution.getJobExecution().getExecutionContext().getInt("fileId"));
		addlInfoPassengerStgRepository.save(addlInfoPassengerStg);
	}

	private void writeAddlInfoFormOfPayment(List<AddlInfoFormOfPaymentStg> addlInfoFormOfPaymentStgList) {
		if (addlInfoFormOfPaymentStgList == null) {
			return;
		}

		addlInfoFormOfPaymentStgList.forEach(item -> {
			AddlInfoFormOfPaymentStg addlInfoFormOfPaymentStg = (AddlInfoFormOfPaymentStg) item;
			addlInfoFormOfPaymentStg.setTransactionHdrId(transactionHdrId);
			addlInfoFormOfPaymentStg
					.setFileHdrId(stepExecution.getJobExecution().getExecutionContext().getInt("fileHeaderId"));
			addlInfoFormOfPaymentStg.setFileId(stepExecution.getJobExecution().getExecutionContext().getInt("fileId"));
			setCreateAuditValues(addlInfoFormOfPaymentStg);
		});

		addlInfoFormOfPaymentStgRepository.saveAll(addlInfoFormOfPaymentStgList);
	}

	private void writeAddlTaxesInfo(List<AddlTaxesInfoStg> addlTaxesInfoStgList) {
		if (addlTaxesInfoStgList == null) {
			return;
		}

		addlTaxesInfoStgList.forEach(item -> {
			AddlTaxesInfoStg addlTaxesInfoStg = (AddlTaxesInfoStg) item;
			addlTaxesInfoStg.setTransactionHdrId(transactionHdrId);
			addlTaxesInfoStg.setFileHdrId(stepExecution.getJobExecution().getExecutionContext().getInt("fileHeaderId"));
			addlTaxesInfoStg.setFileId(stepExecution.getJobExecution().getExecutionContext().getInt("fileId"));
			setCreateAuditValues(addlTaxesInfoStg);
		});

		addlTaxesInfoStgRepository.saveAll(addlTaxesInfoStgList);
	}

	private void writeEMDCouponDetail(List<EMDCouponDetailStg> emdCouponDetailStgList) {
		if (emdCouponDetailStgList == null) {
			return;
		}

		emdCouponDetailStgList.forEach(item -> {
			EMDCouponDetailStg emdCouponDetailStg = (EMDCouponDetailStg) item;
			emdCouponDetailStg.setTransactionHdrId(transactionHdrId);
			emdCouponDetailStg
					.setFileHdrId(stepExecution.getJobExecution().getExecutionContext().getInt("fileHeaderId"));
			emdCouponDetailStg.setFileId(stepExecution.getJobExecution().getExecutionContext().getInt("fileId"));
			setCreateAuditValues(emdCouponDetailStg);
		});

		emdCouponDetailStgRepository.saveAll(emdCouponDetailStgList);
	}

	private void writeEMDRemarks(List<EMDRemarksStg> emdRemarksStgList) {
		if (emdRemarksStgList == null) {
			return;
		}

		emdRemarksStgList.forEach(item -> {
			EMDRemarksStg emdRemarksStg = (EMDRemarksStg) item;
			emdRemarksStg.setTransactionHdrId(transactionHdrId);
			emdRemarksStg.setFileHdrId(stepExecution.getJobExecution().getExecutionContext().getInt("fileHeaderId"));
			emdRemarksStg.setFileId(stepExecution.getJobExecution().getExecutionContext().getInt("fileId"));
			setCreateAuditValues(emdRemarksStg);
		});

		emdRemarksStgRepository.saveAll(emdRemarksStgList);
	}

	private void writeFareCalculation(List<FareCalculationStg> fareCalculationStgList) {
		if (fareCalculationStgList == null) {
			return;
		}

		fareCalculationStgList.forEach(item -> {
			FareCalculationStg fareCalculationStg = (FareCalculationStg) item;
			fareCalculationStg.setTransactionHdrId(transactionHdrId);
			fareCalculationStg
					.setFileHdrId(stepExecution.getJobExecution().getExecutionContext().getInt("fileHeaderId"));
			fareCalculationStg.setFileId(stepExecution.getJobExecution().getExecutionContext().getInt("fileId"));
			setCreateAuditValues(fareCalculationStg);
		});

		fareCalculationStgRepository.saveAll(fareCalculationStgList);
	}

	private void writeAdditionalCardInfo(List<AdditionalCardInfoStg> additionalCardInfoStgList) {
		if (additionalCardInfoStgList == null) {
			return;
		}

		additionalCardInfoStgList.forEach(item -> {
			AdditionalCardInfoStg additionalCardInfoStg = (AdditionalCardInfoStg) item;
			additionalCardInfoStg.setTransactionHdrId(transactionHdrId);
			additionalCardInfoStg
					.setFileHdrId(stepExecution.getJobExecution().getExecutionContext().getInt("fileHeaderId"));
			additionalCardInfoStg.setFileId(stepExecution.getJobExecution().getExecutionContext().getInt("fileId"));
			setCreateAuditValues(additionalCardInfoStg);
		});

		additionalCardInfoStgRepository.saveAll(additionalCardInfoStgList);
	}

	private void writeCardAuthInfo(List<CardAuthInfoStg> cardAuthInfoStgList) {
		if (cardAuthInfoStgList == null) {
			return;
		}

		cardAuthInfoStgList.forEach(item -> {
			CardAuthInfoStg cardAuthInfoStg = (CardAuthInfoStg) item;
			cardAuthInfoStg.setTransactionHdrId(transactionHdrId);
			cardAuthInfoStg.setFileHdrId(stepExecution.getJobExecution().getExecutionContext().getInt("fileHeaderId"));
			cardAuthInfoStg.setFileId(stepExecution.getJobExecution().getExecutionContext().getInt("fileId"));
			setCreateAuditValues(cardAuthInfoStg);
		});

		cardAuthInfoStgRepository.saveAll(cardAuthInfoStgList);
	}

	private void writeTDSCardAuthInfo(List<TDSCardAuthInfoStg> tdsCardAuthInfoStgList) {
		if (tdsCardAuthInfoStgList == null) {
			return;
		}

		tdsCardAuthInfoStgList.forEach(item -> {
			TDSCardAuthInfoStg tdsCardAuthInfoStg = (TDSCardAuthInfoStg) item;
			tdsCardAuthInfoStg.setTransactionHdrId(transactionHdrId);
			tdsCardAuthInfoStg
					.setFileHdrId(stepExecution.getJobExecution().getExecutionContext().getInt("fileHeaderId"));
			tdsCardAuthInfoStg.setFileId(stepExecution.getJobExecution().getExecutionContext().getInt("fileId"));
			setCreateAuditValues(tdsCardAuthInfoStg);
		});

		tdsCardAuthInfoStgRepository.saveAll(tdsCardAuthInfoStgList);
	}

	private void writeFormOfPayment(List<FormOfPaymentStg> formOfPaymentStgList) {
		if (formOfPaymentStgList == null) {
			return;
		}

		formOfPaymentStgList.forEach(item -> {
			FormOfPaymentStg formOfPaymentStg = (FormOfPaymentStg) item;
			formOfPaymentStg.setTransactionHdrId(transactionHdrId);
			formOfPaymentStg.setFileHdrId(stepExecution.getJobExecution().getExecutionContext().getInt("fileHeaderId"));
			formOfPaymentStg.setFileId(stepExecution.getJobExecution().getExecutionContext().getInt("fileId"));
			setCreateAuditValues(formOfPaymentStg);
		});

		formOfPaymentStgRepository.saveAll(formOfPaymentStgList);
	}

	private void writeOfficeSubtotals(List<OfficeSubtotalsStg> items) {

		items.forEach(item -> {
			((OfficeSubtotalsStg) item).setOfficeHdrId(stepExecution.getExecutionContext().getInt("officeHeaderId"));
			((OfficeSubtotalsStg) item)
					.setFileHdrId(stepExecution.getJobExecution().getExecutionContext().getInt("fileHeaderId"));
			((OfficeSubtotalsStg) item)
					.setFileId(stepExecution.getJobExecution().getExecutionContext().getInt("fileId"));
			setCreateAuditValues(item);

		});

		officeSubtotalsStgRepository.saveAll((Iterable<OfficeSubtotalsStg>) items);
	}

	private void writeAgentRegister(List<AgentRegisterStg> items) {

		items.forEach(item -> {
			((AgentRegisterStg) item).setOfficeHdrId(stepExecution.getExecutionContext().getInt("officeHeaderId"));
			((AgentRegisterStg) item)
					.setFileHdrId(stepExecution.getJobExecution().getExecutionContext().getInt("fileHeaderId"));
			((AgentRegisterStg) item).setFileId(stepExecution.getJobExecution().getExecutionContext().getInt("fileId"));
			setCreateAuditValues(item);
		});

		agentRegisterStgRepository.saveAll((Iterable<AgentRegisterStg>) items);
	}
}
