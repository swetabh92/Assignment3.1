import {AfterViewInit, Component, OnInit} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';

import { GeneralService } from '../../../commons/services/general.service';
import { PasswordValidator } from '../../../commons/services/validators/password.validator.service';
import { MustMatch } from '../../../commons/services/validators/must-match.validator.service';
import { AuthenticationService } from '../auth-gaurd-service/_services/authentication.service';
import swal from 'sweetalert2';
declare var $;
declare var jQuery: any;
declare var iCheck;

@Component({
  selector: 'app-appresetpasswordfinal',
  templateUrl: './appresetpasswordfinal.component.html',
  styleUrls: ['./appresetpasswordfinal.component.css']
})
export class AppresetpasswordfinalComponent implements OnInit,AfterViewInit{

  resetPasswordFinalForm: FormGroup;
  submitted = false;
  returnUrl: string;
  error = '';
  key: string;
  passwordViewType = "password";
  questionArray: any = [
    {id: 1, question: 'What was your favorite sport in high school?'},
    {id: 2, question: 'What is your favorite movie?' },
    {id: 3, question: 'What was the make and model of your first car?'},
    {id: 4, question: 'What was your childhood nickname?'},
    {id: 5, question: 'Who is your childhood sports hero?'},
    {id: 6, question: 'What was the name of the company where you had your first job?'},
                      ];
  selectedQuestion1: any;
  selectedQuestion2: any;
  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private authenticationService: AuthenticationService,
    private Gservice: GeneralService
  ) {
    this.route.params.subscribe(params => {
      if (params.key !== null && params.key !== undefined && params.key !== 'undefined' ) {
        this.key = params.key;
       }
       console.log(this.key);
    });
  }

  ngAfterViewInit() {
    this.Gservice.LoadFormSettingJs();
  }
  ngOnInit() {
  console.log(this.key);
    this.resetPasswordFinalForm = this.formBuilder.group({
      newPassword: ['', Validators.compose([Validators.required, Validators.minLength(8), PasswordValidator.strong])],
      retypepassword: ['', Validators.required]
      }, {
      validator: MustMatch('newPassword', 'retypepassword')
    });
  }
  get f() { return this.resetPasswordFinalForm.controls; }
  onSubmit() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.resetPasswordFinalForm.invalid) {
      return;
    }
    this.resetPasswordFinalForm.value.key = this.key;
     console.log(this.resetPasswordFinalForm.value); // return;
    this.authenticationService.resetPasswordFinal(this.resetPasswordFinalForm.value)
      .pipe(first())
      .subscribe(
        data => {
          swal(
            'successfully saved your new password',
             data,
            'success'
          );
          setTimeout(() => {
            this.router.navigate(['profile']);
          }, 100);
        },
        error => {
          swal(
            'error',
            error,
            'error'
          );
        });
  }
  onClickShowHidePwd(){
    this.passwordViewType = this.passwordViewType == "password" ? "text" : "password";
  }
}
