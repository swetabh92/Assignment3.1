import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InputOutputDashboardComponent } from './input-output-dashboard.component';

describe('InputOutputDashboardComponent', () => {
  let component: InputOutputDashboardComponent;
  let fixture: ComponentFixture<InputOutputDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InputOutputDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InputOutputDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
