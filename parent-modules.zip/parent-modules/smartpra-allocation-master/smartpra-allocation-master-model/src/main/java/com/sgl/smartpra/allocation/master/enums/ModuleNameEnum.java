package com.sgl.smartpra.allocation.master.enums;

public enum ModuleNameEnum {

	SALE, FLOWN, INWARD, OUTWARD
}
