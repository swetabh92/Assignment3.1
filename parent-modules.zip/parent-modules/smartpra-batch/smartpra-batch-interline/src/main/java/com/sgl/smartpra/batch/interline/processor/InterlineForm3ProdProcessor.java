package com.sgl.smartpra.batch.interline.processor;

import java.time.LocalDate;

import org.springframework.batch.item.ItemProcessor;

import com.sgl.smartpra.batch.interline.model.InterlineForm3CompositeModel;
import com.sgl.smartpra.interline.domain.entity.common.Auditable;
import com.sgl.smartpra.interline.domain.entity.prod.form3.InterlineForm3Details;
import com.sgl.smartpra.interline.domain.entity.stg.form3.InterlineForm3CsvStg;
import com.sgl.smartpra.interline.domain.enums.Form3ProdSourceType;
import com.sgl.smartpra.interline.domain.enums.Form3ProdStatusEnum;
import com.sgl.smartpra.interline.domain.util.InterlineCommonConstants;
import com.sgl.smartpra.interline.domain.util.InterlineCommonUtil;

public class InterlineForm3ProdProcessor implements ItemProcessor<InterlineForm3CsvStg, InterlineForm3CompositeModel> {

	@Override
	public InterlineForm3CompositeModel process(InterlineForm3CsvStg item) throws Exception {
		InterlineForm3Details interlineForm3Details = new InterlineForm3Details();
	
		interlineForm3Details.setCarrierGroup(item.getZoneCode());
		interlineForm3Details.setClientId(item.getClientId());
		interlineForm3Details.setBilledAirlineNumCode(item.getBilledCarrierNumericCode());
		interlineForm3Details.setBillingAirlineNumCode(item.getBillingCarrierNumericCode());
		interlineForm3Details.setBillingMonth(InterlineCommonUtil.billingMonthConversion(item.getBillingMonth()));
		interlineForm3Details.setInvoiceCurrency(item.getCurrencyClearance());
		interlineForm3Details.setSourceType(Form3ProdSourceType.AUTOMATED.getValue());
		interlineForm3Details.setBillingPeriod(Integer.valueOf(item.getBillingPeriod()));
		interlineForm3Details.setBalanceAmount(InterlineCommonUtil.parseNumber(item.getTotalBalance()));
		interlineForm3Details.setCargoAmount(InterlineCommonUtil.parseNumber(item.getCargoAmount()));
		interlineForm3Details.setCreditAmount(InterlineCommonUtil.parseNumber(item.getTotalCreditAmount()));
		interlineForm3Details.setDebitAmount(InterlineCommonUtil.parseNumber(item.getTotalDebitAmount()));
		interlineForm3Details.setMiscellaneousAmount(InterlineCommonUtil.parseNumber(item.getMiscAmount()));
		interlineForm3Details.setPaxAmount(InterlineCommonUtil.parseNumber(item.getPaxAmount()));
		interlineForm3Details.setUatpAmount(InterlineCommonUtil.parseNumber(item.getUatpAmount()));
		interlineForm3Details.setInterlineForm3CsvId(item.getInterlineForm3CsvId());
		Auditable auditable = new Auditable();
		auditable.setCreatedBy(InterlineCommonConstants.CREATED_BY);
		auditable.setCreatedDate(LocalDate.now());
		interlineForm3Details.setStatus(Form3ProdStatusEnum.OPEN.getValue());
		interlineForm3Details.setFileId(item.getFileId());
		interlineForm3Details.setAuditable(auditable);
		InterlineForm3CompositeModel interlineForm3TransferModel = new InterlineForm3CompositeModel(item,interlineForm3Details);
		return interlineForm3TransferModel;
	}
	
}
