/*<<<<<<< Updated upstream:parent-modules/smartpra-allocation-master/smartpra-allocation-master-app/src/main/java/com/sgl/smartpra/allocation/master/app/entity/FlownAllocationEntity.java
package com.sgl.smartpra.allocation.master.app.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@EqualsAndHashCode(callSuper = false)
@Data
@DynamicInsert
@DynamicUpdate
@Table(schema = "SmartPRAException", name = "exception_flown_allocation")
public class FlownAllocationEntity extends BaseEntity {

	private static final long serialVersionUID = 569209850982872558L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "excep_flown_allocation_id")
	private Integer allocationMasterId;

	@NotNull
	@Column(name = "client_id")	
	private String clientId;

	@NotNull
	@Column(name = "filetype_mapping")
	private String fileTypeMapping;

	@NotNull
	@Column(name = "region_code")
	private String regionCode;

	@NotNull
	@Column(name = "exception_from_period")
	private LocalDateTime exceptionFromDate;

	@NotNull
	@Column(name = "exception_to_period")
	private LocalDateTime exceptionToDate;

	@NotNull
	@Column(name = "key_1")
	private String flightStatus;

	@NotNull
	@Column(name = "key_2")
	private String flightCategory;

	@NotNull
	@Column(name = "key_3")
	private LocalDateTime flightFromDate;

	@NotNull
	@Column(name = "key_4")
	private LocalDateTime flightToDate;

	@NotNull
	@Column(name = "key_5")
	private String oal;

	@NotNull
	@Column(name = "key_6")
	private String routeCode;
	
	@NotNull
	@Column(name = "group_id")
	private Integer groupId;

	@NotNull
	@Column(name = "team_id")
	private Integer teamId;

}
=======
package com.sgl.smartpra.allocation.master.app.dao.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.Id;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@EqualsAndHashCode(callSuper = false)
@Data
@DynamicInsert
@DynamicUpdate
public class FlownAllocationEntity extends BaseEntity {

	private static final long serialVersionUID = 569209850982872558L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "excep_flown_allocation_id")
	private Integer allocationMasterId;

	@NotNull
	@Column(name = "key_1")
	private String key1;

	@NotNull
	@Column(name = "key_2")
	private String key2;

	@NotNull
	@Column(name = "key_3")
	private String key3;

	@NotNull
	@Column(name = "key_4")
	private String key4;

	@NotNull
	@Column(name = "key_5")
	private String key5;

	@NotNull
	@Column(name = "key_6")
	private String key6;

	@NotNull
	@Column(name = "group_id")
	private Integer groupId;

	@NotNull
	@Column(name = "team_id")
	private Integer teamId;

}

>>>>>>> Stashed changes:parent-modules/smartpra-allocation-master/smartpra-allocation-master-app/src/main/java/com/sgl/smartpra/allocation/master/app/dao/entity/FlownAllocationEntity.java
*/