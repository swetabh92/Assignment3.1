package com.sgl.smartpra.batch.bsp.app.processor;

import org.springframework.batch.item.ItemProcessor;

import com.sgl.smartpra.batch.bsp.app.domain.staging.BSPStagingDomainObject;
import com.sgl.smartpra.batch.bsp.app.record.BSPBaseRecord;

public abstract class BSPBaseItemProcessor implements ItemProcessor<BSPBaseRecord, BSPStagingDomainObject> {

}
