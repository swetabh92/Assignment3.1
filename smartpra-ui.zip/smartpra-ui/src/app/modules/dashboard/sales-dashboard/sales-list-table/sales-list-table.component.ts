import { Component, OnInit,Input } from '@angular/core';
import {PaginationService} from '../../../../commons/services/pagination/pagination.service';
import {SalesdashboardserviceService} from '../salesdashboardservice.service';
import { DateFormatService } from '../../../../commons/services/date-format/date-format.service';
@Component({
  selector: 'app-sales-list-table',
  templateUrl: './sales-list-table.component.html',
  styleUrls: ['./sales-list-table.component.css']
})
export class SalesListTableComponent implements OnInit {
  page: any = this.paginateService.setCustomPaginationConfig({'pageSize': 5});
  systemDateFormat = this.dateFormatService.getAngularPipeDateFormat();
  selectedSale:any; 
  bVSReported:any = [];
  searhSalesParams:any;
  selectedTab:any; 
  @Input('searchParams')
  set searchParams(data:any){
      if(data) {
        this.searhSalesParams = data;
        this.searchSales();
      }
  }
  constructor(private dateFormatService:DateFormatService,private salesService:SalesdashboardserviceService,private paginateService: PaginationService) { }
  ngOnInit() {
  }
  searchSales(){
    this.salesService.getAll(this.searhSalesParams).subscribe((res:any)=>{
      this.bVSReported = res.filter(item=>item != null);
    })
  }
  onSelect(data) {
    this.selectedSale =  data;
  }
  tabChange(tab){
    this.selectedTab = tab;
  }
  convertDecimal(val){
    if(val == null) val = 0;
    val = Number(val);
    return val.toFixed(this.salesService.currencyDecimalPression);
  }
}
