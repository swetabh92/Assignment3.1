﻿import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { Cookie } from 'ng2-cookies';
import { environment } from '../../../../../environments/environment';
import swal from 'sweetalert2';
const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8',
                               'Authorization': 'Basic ' + btoa('smartpra-client:smartpra-secret') })
  };

@Injectable({ providedIn: 'root' })
export class AuthenticationService {
  globalUrl = environment.apiUrlGlobal;
  masterUrl = environment.apiUrlMaster;
  authurl = environment.apiUrlauth;
  tokenurl = environment.apiUrltoken;
  constructor(private http: HttpClient) { }

    login(username: string, password: string) {
        const params = new URLSearchParams();
        params.append('username', username);
        params.append('password', password);
        params.append('grant_type', 'password');
       //  console.log(params);
        return this.http.post<any>(this.tokenurl, params.toString(), httpOptions)
            .pipe(map(token => {
                // console.log(token);
                // login successful if there's a jwt token in the response
                if (token) {
                    // store user details and jwt token in local storage to keep user logged in between page refreshes
                    // localStorage.setItem('token', JSON.stringify(token));
                    // localStorage.setItem('refresh_token', token.refresh_token);
                    // const expireDate = new Date().getTime() + (1000 * token.expires_in);
                    // Cookie.set('expireDate', expireDate);
                    Cookie.set('access_token', token.access_token);
                    Cookie.set('refresh_token', token.refresh_token);
                    // localStorage.setItem('oauthtoken', token.access_token);
                    console.log(Cookie.getAll());
                    console.log(Cookie.get('access_token'));
                    console.log(Cookie.get('refresh_token'));
                    // this.refreshToken();
                }
                return token;
            }));
    }
    refreshToken() {
      const params = new URLSearchParams();
      params.append('client_id', 'smartpra-client');
      params.append('client_secret', 'smartpra_secret');
      params.append('grant_type', 'refresh_token');
      params.append('refresh_token', localStorage.getItem('refresh_token'));
      console.log('refresh token subscribed' + params.toString());
      return this.http.post<any>(this.tokenurl, params.toString(), httpOptions)
          .pipe(map(refresh_token => {
            console.log('refresh token subscribed');
              // login successful if there's a jwt token in the response
              if (refresh_token) {
                  // store user details and jwt token in local storage to keep user logged in between page refreshes
                  localStorage.setItem('refresh_token', JSON.stringify(refresh_token));
                  console.log(refresh_token);
              }
              return refresh_token;
          }));
  }

    logout() {
        // remove user from local storage to log user out
        return this.http.delete<any>(this.tokenurl);
    }
    resetPasswordFinal(formdata): Observable<any> {
      return this.http.post<any>( this.authurl + 'profile/reset-password/finish/' , formdata).
      pipe(map(res => {
        // console.log(res);
          return res;
      }));
    }
    resetPasswordInit(formdata): Observable<any> {
     // const mail = formdata.mail;
     // console.log(formdata);
      return this.http.post<any>( this.authurl + 'profile/reset-password/init/', formdata).
      pipe(map(res => {
        // console.log(res);
          return res;
      }));
    }
    firsttimePassword(formdata): Observable<any> {
      return this.http.post<any>( this.authurl + 'profile/firsttime-password/init/' , formdata).
      pipe(map(res => {
        // console.log(res);
          return res;
      }));
    }
    forgetUserid(formdata): Observable<any> {
      return this.http.get<any>( this.authurl + 'profile/forgetuserid/', formdata)
      .pipe(map(res => {
        // console.log(res);
          return res;
      }));
    }
}
