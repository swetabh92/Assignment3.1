import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MailRoutingModule } from './mail-routing.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { MailComponent } from './mail.component';
import { CoreDataModule } from 'src/app/core-data/core-data.module';

@NgModule({
  imports: [
    CommonModule,
    CoreDataModule,
    SharedModule,
    MailRoutingModule
  ],
  declarations: [
    MailComponent
  ]
})
export class MailModule { }
