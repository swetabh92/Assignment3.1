package com.sgl.smartpra.batch.fdr.app.config;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManagerFactory;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.mapping.PatternMatchingCompositeLineMapper;
import org.springframework.batch.item.file.transform.LineTokenizer;
import org.springframework.batch.item.support.ClassifierCompositeItemProcessor;
import org.springframework.batch.item.support.ClassifierCompositeItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.classify.Classifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.transaction.PlatformTransactionManager;

import com.sgl.smartpra.batch.fdr.app.domain.CurrencyHeader;
import com.sgl.smartpra.batch.fdr.app.domain.CurrencyRate;
import com.sgl.smartpra.batch.fdr.app.domain.CurrencyRecord;
import com.sgl.smartpra.batch.fdr.app.listener.JobCompletionNotificationListener;

@Configuration
@EnableBatchProcessing
public class FDRConfiguration {

	@Autowired
	public JobBuilderFactory jobBuilderFactory;

	@Autowired
	public StepBuilderFactory stepBuilderFactory;

	@Autowired
	EntityManagerFactory emf;

	@Value("${max-threads}")
	private int maxThreads;

	@Value("${batch.directory.fdr.input}")
	private String batchInputDir;

	@Autowired
	private PlatformTransactionManager transactionManager;

	@Bean
	public TaskExecutor taskExecutor() {
		SimpleAsyncTaskExecutor taskExecutor = new SimpleAsyncTaskExecutor();
		taskExecutor.setConcurrencyLimit(maxThreads);
		return taskExecutor;
	}

	@Bean
	public Job importFdrJob(JobCompletionNotificationListener listener, Step importData) {

		// @formatter:off
		return jobBuilderFactory.get("importFdrJob").incrementer(new RunIdIncrementer()).listener(listener)
				.flow(importData).end().build();
		// @formatter:on
	}

	@SuppressWarnings("unchecked")
	@Bean
	public Step importData() {

		// @formatter:off
		return stepBuilderFactory.get("FDR").<CurrencyRecord, CurrencyRecord>chunk(1).reader(fdrReader(null))
				.processor((ItemProcessor<? super CurrencyRecord, ? extends CurrencyRecord>) fdrRecordProcessor(
						fdrHeaderProcessor(), fdrProcessor()))
				.writer((ItemWriter<? super CurrencyRecord>) fdrRecordWriter(fdrHeaderWriter(), fdrWriter()))
				.faultTolerant().skipLimit(100).skip(DataIntegrityViolationException.class)
				.transactionManager(transactionManager).taskExecutor(taskExecutor()).throttleLimit(maxThreads).build();
		// @formatter:on
	}

	@Bean
	@StepScope
	public FlatFileItemReader<CurrencyRecord> fdrReader(@Value("#{jobParameters[fileName]}") String fileName) {

		FlatFileItemReader<CurrencyRecord> reader = new FlatFileItemReader<CurrencyRecord>();
		reader.setResource(new FileSystemResource(batchInputDir + File.separator + fileName));
		reader.setLineMapper(lineMapper());
		return reader;
	}

	@Bean
	public LineMapper<CurrencyRecord> lineMapper() {

		PatternMatchingCompositeLineMapper<CurrencyRecord> mapper = new PatternMatchingCompositeLineMapper<>();

		Map<String, LineTokenizer> tokenizers = new HashMap<String, LineTokenizer>(10);
		tokenizers.put("1*", (new CurrencyHeader()).lineTokenizer());
		tokenizers.put("2*", (new CurrencyRate()).lineTokenizer());
		mapper.setTokenizers(tokenizers);

		Map<String, FieldSetMapper<CurrencyRecord>> mappers = new HashMap<String, FieldSetMapper<CurrencyRecord>>();
		mappers.put("1*", (new CurrencyHeader()).fieldSetMapper());
		mappers.put("2*", (new CurrencyRate()).fieldSetMapper());

		BeanWrapperFieldSetMapper<CurrencyRate> fieldSetMapper = new BeanWrapperFieldSetMapper<>();
		fieldSetMapper.setTargetType(CurrencyRate.class);

		mapper.setFieldSetMappers(mappers);
		return mapper;

	}

	@Bean
	@StepScope
	public ItemWriter<? super CurrencyRecord> fdrHeaderWriter() {
		return new CurrencyHeader().writer();
	}

	@Bean
	@StepScope
	public ItemWriter<? super CurrencyRecord> fdrWriter() {
		return new CurrencyRate().writer();
	}

	@SuppressWarnings("serial")
	@Bean
	@StepScope
	public ClassifierCompositeItemWriter<? extends CurrencyRecord> fdrRecordWriter(
			ItemWriter<? super CurrencyRecord> fdrHeaderWriter, ItemWriter<? super CurrencyRecord> fdrWriter

	) {
		ClassifierCompositeItemWriter<CurrencyRecord> classifierCompositeItemWriter = new ClassifierCompositeItemWriter<>();
		classifierCompositeItemWriter
				.setClassifier(new Classifier<CurrencyRecord, ItemWriter<? super CurrencyRecord>>() {

					@Override
					public ItemWriter<? super CurrencyRecord> classify(CurrencyRecord classifiable) {
						if (classifiable instanceof CurrencyHeader) {
							return fdrHeaderWriter;
						} else if (classifiable instanceof CurrencyRate) {
							return fdrWriter;
						}
						return null;
					}

				});
		return classifierCompositeItemWriter;
	}

	@Bean
	@StepScope
	public ItemProcessor<? extends CurrencyRecord, ? extends CurrencyRecord> fdrHeaderProcessor() {
		return new CurrencyHeader().processor();
	}

	@Bean
	@StepScope
	public ItemProcessor<? extends CurrencyRecord, ? extends CurrencyRecord> fdrProcessor() {
		return new CurrencyRate().processor();
	}

	@Bean
	@StepScope
	public ClassifierCompositeItemProcessor<? extends CurrencyRecord, ? extends CurrencyRecord> fdrRecordProcessor(
			ItemProcessor<? extends CurrencyRecord, ? extends CurrencyRecord> fdrHeaderProcessor,
			ItemProcessor<? extends CurrencyRecord, ? extends CurrencyRecord> fdrProcessor

	) {
		ClassifierCompositeItemProcessor<CurrencyRecord, CurrencyRecord> classifierCompositeItemProcessor = new ClassifierCompositeItemProcessor<>();
		classifierCompositeItemProcessor
				.setClassifier(new Classifier<CurrencyRecord, ItemProcessor<?, ? extends CurrencyRecord>>() {

					@Override
					public ItemProcessor<?, ? extends CurrencyRecord> classify(CurrencyRecord classifiable) {
						if (classifiable instanceof CurrencyHeader) {
							return fdrHeaderProcessor;
						} else if (classifiable instanceof CurrencyRate) {
							return fdrProcessor;
						}
						return null;

					}

				});
		return classifierCompositeItemProcessor;

	}
}