package com.sgl.smartpra.allocation.master.app.entity;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import com.sgl.smartpra.common.util.BooleanToStringConverter;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@EqualsAndHashCode(callSuper = false)
@Data
@DynamicInsert
@DynamicUpdate
@Table(schema = "SmartPRAMaster", name = "mas_file_type")
public class FileTypeEntity extends BaseEntity {
	
	private static final long serialVersionUID = 6233634896584715760L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "file_type_id")
	private Integer fileTypeId;
	
	@Column(name = "file_type_name")
	private String fileTypeName;
	
	@Column(name = "client_id")
	private String clientId;
	
	@Column(name = "is_active")
	@Convert(converter = BooleanToStringConverter.class)
	private Boolean activate;
	
	@OneToOne(mappedBy = "fileType")
    private FileTypeMappingEntity fileTypeMappingEntity;

}
