package com.sgl.smartpra.batch.sales.validator.app.processor;

import java.util.List;

import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.sales.validator.app.config.FeignConfiguration.SmartpraExceptionMasterAppClient;
import com.sgl.smartpra.batch.sales.validator.app.domain.DocumentAmountStg;
import com.sgl.smartpra.batch.sales.validator.app.domain.SalesFileHeaderStg;
import com.sgl.smartpra.batch.sales.validator.app.domain.StandaredAmountStg;
import com.sgl.smartpra.batch.sales.validator.app.domain.TicketIdentificationStg;
import com.sgl.smartpra.batch.sales.validator.app.domain.TransactionHdrStg;
import com.sgl.smartpra.batch.sales.validator.app.domain.TransactionInfoStg;
import com.sgl.smartpra.batch.sales.validator.app.enums.ErrorCode;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;

/**
 * 
 * @author mansound1
 *
 */
@StepScope
@Component
public class SalesValidatorProcessor implements ItemProcessor<SalesFileHeaderStg, SalesFileHeaderStg> {

	@Autowired
	SalesRules salesRules;

	String pnrRegex = "^[a-zA-Z0-9 ,/*]$";
	
	@Autowired
	SmartpraExceptionMasterAppClient smartpraExceptionMasterAppClient;

	@Override
	public SalesFileHeaderStg process(SalesFileHeaderStg salesFileHeaderStg) throws Exception {

		ExceptionTransactionModel exceptionTransactionModel = new ExceptionTransactionModel();
		smartpraExceptionMasterAppClient.initExceptionTrasaction(exceptionTransactionModel);

		
		List<TransactionHdrStg> transactionHdrStgs = salesFileHeaderStg.getTransactionHdrStgs();

		for (TransactionHdrStg transactionHdrStg : transactionHdrStgs) {
			List<TicketIdentificationStg> ticketIdentificationStgs = transactionHdrStg.getTicketIdentificationStgs();
			for (TicketIdentificationStg ticketIdentificationStg : ticketIdentificationStgs) {
				// validating issue airline
				boolean isValidAirportCode = salesRules
						.validateAirportCode(ticketIdentificationStg.getTktDocNumber().substring(0, 3));
				if (!isValidAirportCode) {
					ErrorCode s1 = ErrorCode.SALE1001;
					//TODO : we need to call the following method for placing exception messages into exception transaction 
					/*ExceptionTransactionModel exceptionTransactionModel = new ExceptionTransactionModel();
					smartpraExceptionMasterAppClient.initExceptionTrasaction(exceptionTransactionModel);
*/
				
					
				}

				// PNR validation
				boolean matches = ticketIdentificationStg.getPnrRefAirlineDate().matches(pnrRegex);
				if (!matches) {
					ErrorCode s1 = ErrorCode.SALE1003;

				}
				// Place of issue Validation
				boolean validPlaceOfIssue = salesRules
						.validateCityCode(ticketIdentificationStg.getTrueOrgDestCityCode());
				if (!validPlaceOfIssue) {
					ErrorCode s1 = ErrorCode.SALE1004;
				}
				// place of sale validation not setup because it not setting in ticketmainstg

				// validation of agentcode is done. System Parameter auto creation is pending
				boolean validAgentCode = salesRules.validateAgentCode(ticketIdentificationStg.getAgentNumericCode());
				if (!validAgentCode) {
					ErrorCode s1 = ErrorCode.SALE1005;
				}

				// ReportingAgentCode is setting Hardcodes so no validation now

				// validation OriginalIssueDate
				/*
				 * ticketMainStg.setOriginalDateOfIssue(transactionInfoStg.getOriginalIssueDate(
				 * )); validation OriginalPlaceOfIssue
				 * ticketMainStg.setOriginalPlaceOfIssue(transactionInfoStg.
				 * getOriginalIssueLocCityCode()); Validation OriginalAgentCode
				 * ticketMainStg.setOriginalAgentCode(transactionInfoStg.
				 * getOriginalIssueAgentCode());
				 */
				ticketIdentificationStg.getConjuctionTicketIndicator();

				List<DocumentAmountStg> documentAmountStgs = transactionHdrStg.getDocumentAmountStgs();
				for (DocumentAmountStg documentAmountStg : documentAmountStgs) {
					// validate Currency Of sale

					boolean validCurrencyOfSale = salesRules
							.validateCurrencyCode(documentAmountStg.getFare().substring(0, 3));
					if (!validCurrencyOfSale) {
						ErrorCode s = ErrorCode.SALE1006;
						ErrorCode s1 = ErrorCode.SALE1007;

					}

					// validate equvivalent currency of sale
					boolean validEquivalentCurrencyOfSale = salesRules
							.validateCurrencyCode(documentAmountStg.getEquivalentFarePaid().substring(0, 3));

					if (!validEquivalentCurrencyOfSale) {
						ErrorCode s = ErrorCode.SALE1006;
						ErrorCode s1 = ErrorCode.SALE1007;
					}

				}

				List<StandaredAmountStg> standaredAmountStgs = transactionHdrStg.getStandaredAmountStgs();
				for (StandaredAmountStg standaredAmountStg : standaredAmountStgs) {

					standaredAmountStg.getTktDocNumber().substring(0, 11);
					standaredAmountStg.getNetFareAmount();
					// validate netfare currency

					// validate NetFare currency
					boolean validNetfareCurreny = salesRules
							.validateCurrencyCode(standaredAmountStg.getCurrencyType().substring(0, 3));
					if (!validNetfareCurreny) {

						ErrorCode s1 = ErrorCode.SALE1006;
						ErrorCode s = ErrorCode.SALE1007;

					}

				}

				List<TransactionInfoStg> transactionInfoStgs = transactionHdrStg.getTransactionInfoStgs();
				for (TransactionInfoStg transactionInfoStg : transactionInfoStgs) {

					// Endorsement Validation is pending
					// ticketMainStg.setEndorsements(transactionInfoStg.getEndorsementRestriction());

				}
			}

			return null;
		}
		return salesFileHeaderStg;
	}

	/*
	 * @Autowired SalesBatchValidator batchValidator;
	 * 
	 * public SalesValidatorProcessor() { super(); }
	 * 
	 * 
	 * 
	 * @Override public void afterPropertiesSet() throws Exception {
	 * super.afterPropertiesSet(); }
	 * 
	 * @Override public SalesFileHeaderStg process(SalesFileHeaderStg arg0) throws
	 * ValidationException { return super.process(arg0); }
	 * 
	 * @SuppressWarnings("unchecked")
	 * 
	 * @Override public void setValidator(Validator<? super SalesFileHeaderStg>
	 * validator) { super.setValidator((Validator<? super SalesFileHeaderStg>)
	 * batchValidator); }
	 * 
	 * 
	 * public SalesValidatorProcessor(org.springframework.validation.Validator
	 * batchValidator) { this.batchValidator = validator(); }
	 * 
	 * 
	 * @Bean public org.springframework.validation.Validator validator() { // see
	 * https://docs.spring.io/spring/docs/current/spring-framework-reference/core.
	 * html#validation-beanvalidation-spring return new
	 * org.springframework.validation.beanvalidation.LocalValidatorFactoryBean(); }
	 * 
	 * @Override public SalesFileHeaderStg process(SalesFileHeaderStg arg0) throws
	 * ValidationException { // TODO Auto-generated method stub return
	 * super.process(arg0); }
	 * 
	 * @Override public void setValidator(Validator<? super SalesFileHeaderStg>
	 * validator) { // TODO Auto-generated method stub
	 * super.setValidator((Validator<? super SalesFileHeaderStg>) validator()); }
	 */

}
