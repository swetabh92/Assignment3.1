package com.sgl.smartpra.batch.fdr.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients
public class FDRLoadApplication {

	public static void main(String[] args) throws Exception {
		SpringApplication.run(FDRLoadApplication.class, args);
	}

}