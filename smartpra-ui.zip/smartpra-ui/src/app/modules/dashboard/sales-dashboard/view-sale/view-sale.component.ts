import {Component, Input, OnInit} from '@angular/core';
import {PaginationService} from '../../../../commons/services/pagination/pagination.service';
import {SalesdashboardserviceService} from '../salesdashboardservice.service';
import {DateFormatService} from '../../../../commons/services/date-format/date-format.service';
import {MessageBoxService} from '../../../masters/services/commons/message-box.service';
import swal from 'sweetalert2';

@Component({
  selector: 'app-view-sale',
  templateUrl: './view-sale.component.html',
  styleUrls: ['./view-sale.component.css']
})
export class ViewSaleComponent implements OnInit {
  page: any = this.paginateService.setCustomPaginationConfig({'pageSize': 5});

  constructor(private dateFormatService: DateFormatService, private salesService: SalesdashboardserviceService, private paginateService: PaginationService, private messageService: MessageBoxService) {
  }

  salesTaxNo: any = [];
  selectedTab: any;
  selectedSale: any;
  status: boolean = false;
  systemDateFormat = this.dateFormatService.getAngularPipeDateFormat();

  @Input('value')
  set value(val: any) {
    if (val) {
      this.selectedTab = undefined;
      let salesKey = val;
      this.getSalesTaxNo(salesKey.agencyCode, salesKey.reportingAgency);
    }
  }

  ngOnInit() {
  }

  getSalesTaxNo(agencyCode, reportAgency): void {
    this.salesService.viewSaleTxNo(agencyCode, reportAgency)
      .subscribe(
        data => {
          this.salesTaxNo = data,
            error => console.log(error);
        }
      );
  }

  onSelect(data,e) {
    if (this.selectedTab == 'edit_ticket') {
      if (e) {
        e.preventDefault();
        swal({
          type: 'warning',
          title: 'Do you want to save the ticket?',
          showCancelButton: true,
          confirmButtonColor: '#ff0000',
          cancelButtonColor: '#049F0C',
          confirmButtonText: 'Yes',
          cancelButtonText: 'No',
          closeOnClickOutside: false,
          closeOnEsc: false,
          allowOutsideClick: false,
          customClass: 'Custom_Cancel',
        } as any).then(result => {
          if (result.value === true) {
              e.target.checked =false;
          } else {
            e.target.checked = true;
            this.selectedInput(data);
          }
        });
      }
    }
    else{
      this.selectedInput(data);
    }

  }

    selectedInput(data) {
    this.selectedSale = data;
    this.selectedSale['mainDocument'] = data['documentNumber'];
    this.selectedSale['issueAirline'] = data['issueAirLine'];
    console.log(this.selectedSale);
  }

  tabChange(tab) {
    this.selectedTab = tab;
  }


}

