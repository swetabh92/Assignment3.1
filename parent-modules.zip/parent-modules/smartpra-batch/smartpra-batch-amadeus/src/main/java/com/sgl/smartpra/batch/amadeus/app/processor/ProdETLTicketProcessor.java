package com.sgl.smartpra.batch.amadeus.app.processor;

import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.sgl.smartpra.batch.amadeus.app.common.AppConstants;
import com.sgl.smartpra.batch.amadeus.app.config.FeignConfiguration.CarrierMasterFeignClient;
import com.sgl.smartpra.batch.amadeus.app.config.FeignConfiguration.ExceptionTxnFeignClient;
import com.sgl.smartpra.batch.amadeus.app.config.FeignConfiguration.FlownFeignClient;
import com.sgl.smartpra.batch.amadeus.app.config.FeignConfiguration.MasterFeignClient;
import com.sgl.smartpra.batch.amadeus.app.config.FeignConfiguration.PaxFeignClient;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusNewTaxStaging;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusRecordDetailStaging;
import com.sgl.smartpra.batch.amadeus.app.domain.AmadeusRecordStaging;
import com.sgl.smartpra.batch.amadeus.app.domain.ProdTicketModel;
import com.sgl.smartpra.batch.amadeus.app.repository.AmadeusRecordStagingRepository;
import com.sgl.smartpra.batch.amadeus.app.utils.AmadeusCommonUtils;
import com.sgl.smartpra.common.model.ValidatorResponse;
import com.sgl.smartpra.common.util.ExceptionCodeConstants;
import com.sgl.smartpra.common.util.OptionalUtil;
import com.sgl.smartpra.common.util.SmartPRACommonUtil;
import com.sgl.smartpra.common.validator.EntityValidator;
import com.sgl.smartpra.exception.txn.model.ExceptionParametersValueModel;
import com.sgl.smartpra.exception.txn.model.ExceptionTransactionModel;
import com.sgl.smartpra.flown.model.FlightDataDetails;
import com.sgl.smartpra.global.master.model.Carrier;
import com.sgl.smartpra.master.model.AgencyMaster;
import com.sgl.smartpra.master.model.BookingClassModel;
import com.sgl.smartpra.master.model.FormCode;
import com.sgl.smartpra.sales.domain.TicketCoupon;
import com.sgl.smartpra.sales.domain.TicketMain;
import com.sgl.smartpra.sales.domain.TicketTax;
import com.sgl.smartpra.sales.model.PAXTypeModel;
import com.sgl.smartpra.sales.repository.TicketMainRepository;

@SuppressWarnings("serial")
public class ProdETLTicketProcessor extends AmadeusProcessor
		implements ItemProcessor<AmadeusRecordStaging, ProdTicketModel> {

	private static final Logger LOGGER = LoggerFactory.getLogger(ProdETLTicketProcessor.class);

	@Autowired
	MasterFeignClient masterFeignClient;

	@Autowired
	FlownFeignClient flownFeignClient;

	@Autowired
	PaxFeignClient paxTypeFeignClient;

	@Autowired
	private TicketMainRepository ticketMainRepository;

	@Autowired
	private AmadeusRecordStagingRepository amadeusRecordStagingRepository;

	@Autowired
	private ExceptionTxnFeignClient exceptionTxnFeignClient;

	@Autowired
	CarrierMasterFeignClient carrierMasterFeignClient;

	@Value("#{jobParameters['careerDesignatorCode']}")
	public String hostCarrDesigCode;

	@Value("#{jobParameters['carrieNumericCode']}")
	public Integer hostCarrNumericCode;

	@Value("#{jobParameters['flightNoLen']}")
	public String sysParamFlightLen;

	@Value("#{stepExecution}")
	private StepExecution stepExecution;

	private Integer errorCount;

	private Integer transferredCount;

	private List<ValidatorResponse> failedPropertyList;

	private EntityValidator entityValidator;

	private Set<String> docUniqueIdsLoaded = new HashSet<String>();

	@Override
	public ProdTicketModel process(AmadeusRecordStaging amadeusRecordStaging) throws Exception {

		JobExecution jobExecution = this.stepExecution.getJobExecution();
		ExecutionContext jobExecutionContext = jobExecution.getExecutionContext();

		LOGGER.info("ProdETLTicketProcessor.process -- Start");
		Class<?> classVar = Class.forName("com.sgl.smartpra.batch.amadeus.app.domain.AmadeusRecordStaging");
		Method method;
		String errMsg;
		String[] errMsgArr;
		ExceptionTransactionModel exceptionTransactionModel;
		List<ExceptionParametersValueModel> parametersValueModelList;
		ExceptionParametersValueModel paramValueModel;
		ProdTicketModel prodTicketModel = new ProdTicketModel();
		DateTimeFormatter dtFormatter = DateTimeFormatter.ofPattern("ddMMyy");
		SimpleDateFormat format = new SimpleDateFormat("ddMMyy");
		SimpleDateFormat format1 = new SimpleDateFormat("ddMMMyy");
		String reportingAgency = null;
		String agencyType = null;
		String areaOfOperation = null;
		String reportingAgencyType = null;
		String carrierCode = null;
		String carrierName1 = null;
		String carrierName2 = null;
		List<FormCode> formcodeList = null;
		List<FlightDataDetails> flightKeyList = null;
		FlightDataDetails flightDataDetails = null;
		List<AgencyMaster> agencyMasterList = null;
		List<AgencyMaster> agencyMasterListForOriginalissue = null;
		List<Carrier> carrierMasterList = null;
		List<TicketMain> ticketMainList = new ArrayList<TicketMain>();

		try {
			/*
			 * String dateString = amadeusRecordStaging.getUsageLocalFlightDate();
			 * System.out.println("----------dateString"+dateString+"---------------");
			 * LocalDate localDate = LocalDate.parse(dateString, dtFormatter);
			 * System.out.println("----------LocalDate"+localDate+"---------------");
			 */
			int i = 0;
			int j = 0;
			Integer count = (Integer) jobExecutionContext.get("errorCount");

			if (count != null) {
				errorCount = count;
			} else {
				jobExecutionContext.put("errorCount", 0);
				errorCount = 0;
			}

			count = (Integer) jobExecutionContext.get("transferredCount");
			LOGGER.info("Transfered Count --->" + jobExecutionContext.get("transferredCount"));

			if (count != null) {
				transferredCount = count;
			} else {
				LOGGER.info("Transfered Count status--->" + jobExecutionContext.get("transferredCount"));
				jobExecutionContext.put("transferredCount", 0);
				transferredCount = 0;
			}

			// Unique columns for all ticket / coupon tables
			String issueAirline = amadeusRecordStaging.getIssAirline();
			String mainDocumentNo = amadeusRecordStaging.getUsageDocNumber().substring(0, 10);
			String documentNumberstr = amadeusRecordStaging.getUsageDocNumber();
			String documentUniqueidString = null;
			String documentUniqueid = null;
			String updatedDocNumber = null;
			String originalDocumentUniqueid = null;
			Date originalIssueDate = null;
			String numberOfCoupon = null;
			TicketMain ticketMain = null;
			int documentCount = documentNumberstr.length() / 10;
			List<String> documentNumberList = new ArrayList<String>();
			int docClassCount;
			for (int k = 0; k < documentCount; k++) {
				docClassCount = 0;
				updatedDocNumber = documentNumberstr.substring((k * 10), (k * 10) + 10);
				documentNumberList.add(updatedDocNumber);
				documentUniqueid = hostCarrDesigCode + issueAirline + updatedDocNumber
						+ amadeusRecordStaging.getIssueDate();
				if (docUniqueIdsLoaded.contains(documentUniqueid)) {
					LOGGER.debug("DocumentUniqueId " + documentUniqueid
							+ " already exists in ticketMain table or multiple flown coupon's found in the current file");
					amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_ERROR);
					amadeusRecordStagingRepository.saveAndFlush(amadeusRecordStaging);
					return null;
				}
				// Duplicate record check
				Optional<TicketMain> ticketMainOpt = ticketMainRepository.findByDocumentUniqueId(documentUniqueid);
				if (ticketMainOpt.isPresent()) {
					LOGGER.debug("DocumentUniqueId " + documentUniqueid
							+ " already exists in ticketMain table or multiple flown coupon's found in the current file");
					amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_ERROR);
					amadeusRecordStagingRepository.saveAndFlush(amadeusRecordStaging);
					return null;
				} else {
					// Reference data check - start
					// 1. formCodeList
					formcodeList = masterFeignClient.getAllFormCode(
							amadeusRecordStaging.getDocumentNumber().substring(0, 3), null, numberOfCoupon, null, null);
					if (formcodeList.isEmpty()) {
						LOGGER.info("Error Count in formcode  master list---------->" + errorCount);
						errorCount++;
						jobExecutionContext.put("errorCount", errorCount);
						LOGGER.info("Error Count after in formcode master list----------->"
								+ jobExecution.getExecutionContext().get("errorCount"));

						// Exception logic - start
						exceptionTransactionModel = AmadeusCommonUtils
								.initExceptionTransactionModel(amadeusRecordStaging, documentUniqueid);
						exceptionTransactionModel.setClientId(hostCarrDesigCode);
						exceptionTransactionModel.setExceptionCode(ExceptionCodeConstants.ERRORCODE_DOCTYPE);
						/*
						 * exceptionTransactionModel
						 * .setResolutionRemarks("Form code details need to be added in formcode master"
						 * ); exceptionTransactionModel.
						 * setExceptionDetails("Formcode details not found for formCode : " +
						 * amadeusRecordStaging.getDocumentNumber().substring(0, 3));
						 */
						parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();

						paramValueModel = new ExceptionParametersValueModel();
						paramValueModel.setParameterName("Document No.");
						paramValueModel.setParameterValue(amadeusRecordStaging.getDocumentNumber());
						parametersValueModelList.add(paramValueModel);

						paramValueModel = new ExceptionParametersValueModel();
						paramValueModel.setParameterName("Carrier Numeric Code");
						paramValueModel.setParameterValue(issueAirline);
						parametersValueModelList.add(paramValueModel);

						exceptionTransactionModel.setParametersValueList(parametersValueModelList);

						amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_ERROR);
						amadeusRecordStagingRepository.saveAndFlush(amadeusRecordStaging);

						exceptionTxnFeignClient.initExceptionTrasaction(exceptionTransactionModel);
						// Exception logic - end
						return null;
					}

					// 2. agencyMasterList
					agencyMasterList = masterFeignClient.getAllAgency(amadeusRecordStaging.getAgencyNumber(),
							reportingAgency, agencyType, areaOfOperation, reportingAgencyType, null);

					// 3. flightKeyList - Require for Flown Coupon (ProdETLCouponProcessor) \
					String derivedFlightNo = SmartPRACommonUtil
							.deriveFlightNo(amadeusRecordStaging.getUsageOperatingFlightNumber(), sysParamFlightLen);

					/*
					 * flightKeyList = flownFeignClient.getAllFlightDataDetails(derivedFlightNo,
					 * amadeusRecordStaging.getUsageOriginCode(),
					 * amadeusRecordStaging.getUsageDestinationCode(), null);
					 */

					/*
					 * flightDataDetails = flownFeignClient.getFlightDataDetails(derivedFlightNo,
					 * amadeusRecordStaging.getUsageOriginCode(),
					 * amadeusRecordStaging.getUsageDestinationCode(), localDate, null);
					 */

					/*
					 * if (flightDataDetails == null || flightDataDetails.equals("")) {
					 * 
					 * errorCount++; jobExecutionContext.put("errorCount", errorCount);
					 * LOGGER.info("flightDataDetails is empty....");
					 * LOGGER.info("Actual Operating flight number" +
					 * amadeusRecordStaging.getUsageOperatingFlightNumber());
					 * LOGGER.info("Derived Operating flight number" + derivedFlightNo); //
					 * Exception logic - start exceptionTransactionModel = AmadeusCommonUtils
					 * .initExceptionTransactionModel(amadeusRecordStaging, documentUniqueid);
					 * exceptionTransactionModel.setClientId(hostCarrDesigCode);
					 * exceptionTransactionModel.setExceptionCode(ExceptionCodeConstants.
					 * ERRORCODE_FLIGHTKEYNOTFOUND);
					 * 
					 * exceptionTransactionModel.
					 * setResolutionRemarks("Flight data details need to be updated..");
					 * exceptionTransactionModel
					 * .setExceptionDetails("Flight data details not found for flight number : " +
					 * derivedFlightNo + ", usage orgincode: " +
					 * amadeusRecordStaging.getUsageOriginCode() + ", usage desgination code: " +
					 * amadeusRecordStaging.getUsageDestinationCode());
					 * 
					 * parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();
					 * 
					 * paramValueModel = new ExceptionParametersValueModel();
					 * paramValueModel.setParameterName("Flight no");
					 * paramValueModel.setParameterValue(derivedFlightNo);
					 * parametersValueModelList.add(paramValueModel);
					 * 
					 * paramValueModel = new ExceptionParametersValueModel();
					 * paramValueModel.setParameterName("From sector");
					 * paramValueModel.setParameterValue(amadeusRecordStaging.getUsageOriginCode());
					 * parametersValueModelList.add(paramValueModel);
					 * 
					 * paramValueModel = new ExceptionParametersValueModel();
					 * paramValueModel.setParameterName("To sector");
					 * paramValueModel.setParameterValue(amadeusRecordStaging.
					 * getUsageDestinationCode()); parametersValueModelList.add(paramValueModel);
					 * 
					 * paramValueModel = new ExceptionParametersValueModel();
					 * paramValueModel.setParameterName("Depart date");
					 * paramValueModel.setParameterValue(amadeusRecordStaging.getLocalDepartureDate(
					 * )); parametersValueModelList.add(paramValueModel);
					 * 
					 * exceptionTransactionModel.setParametersValueList(parametersValueModelList);
					 * 
					 * exceptionTxnFeignClient.initExceptionTrasaction(exceptionTransactionModel);
					 * // Exception logic - end
					 * 
					 * amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_ERROR);
					 * amadeusRecordStagingRepository.saveAndFlush(amadeusRecordStaging); return
					 * null; }
					 */
					// 4. Booking class master check - Require for Flown Coupon
					// (ProdETLCouponProcessor)
					List<BookingClassModel> bookingClassModelList = masterFeignClient
							.getListOfBookingClassByUtilizationEffectiveDate(null,
									amadeusRecordStaging.getSellingClass(), null, null, null, null, null);
					if (bookingClassModelList.isEmpty()) {
						LOGGER.info("Error Count before---------->" + errorCount);
						errorCount++;
						jobExecutionContext.put("errorCount", errorCount);
						LOGGER.info(
								"Error Count after----------->" + jobExecution.getExecutionContext().get("errorCount"));
						// Exception logic - start
						exceptionTransactionModel = AmadeusCommonUtils
								.initExceptionTransactionModel(amadeusRecordStaging, documentUniqueid);
						exceptionTransactionModel.setClientId(hostCarrDesigCode);
						exceptionTransactionModel.setExceptionCode(ExceptionCodeConstants.ERRORCODE_DOCCLASS);
						/*
						 * exceptionTransactionModel
						 * .setResolutionRemarks("Cabin details need to be added in Booking Class Master"
						 * ); exceptionTransactionModel.setExceptionDetails(
						 * "BookingClass details not found for rbd : " +
						 * amadeusRecordStaging.getSellingClass());
						 */
						if (amadeusRecordStaging.getCouponNumber() != null)
							exceptionTransactionModel
									.setCouponNumber(Integer.parseInt(amadeusRecordStaging.getCouponNumber()));
						parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();

						paramValueModel = new ExceptionParametersValueModel();
						paramValueModel.setParameterName("Document No.");
						paramValueModel.setParameterValue(amadeusRecordStaging.getDocumentNumber());
						parametersValueModelList.add(paramValueModel);

						paramValueModel = new ExceptionParametersValueModel();
						paramValueModel.setParameterName("Carrier Numeric Code");
						paramValueModel.setParameterValue(issueAirline);
						parametersValueModelList.add(paramValueModel);

						paramValueModel = new ExceptionParametersValueModel();
						paramValueModel.setParameterName("Doc Class");
						paramValueModel.setParameterValue(amadeusRecordStaging.getSellingClass());
						parametersValueModelList.add(paramValueModel);

						exceptionTransactionModel.setParametersValueList(parametersValueModelList);
						amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_ERROR);
						amadeusRecordStagingRepository.saveAndFlush(amadeusRecordStaging);
						exceptionTxnFeignClient.initExceptionTrasaction(exceptionTransactionModel);
						// Exception logic - end
						return null;
					}

					// Reference data check - end

					// Data type validation login - begin

					/*
					 * failedPropertyList = new ArrayList<ValidatorResponse>(); entityValidator =
					 * new EntityValidator(); failedPropertyList =
					 * entityValidator.validateEntity(amadeusRecordStaging); if
					 * (!failedPropertyList.isEmpty()) {
					 * LOGGER.info("Data Type Validation occurs----------->");
					 * prodTicketModel.getTicketMain().get(0).setStatus(AppConstants.
					 * STATUS_PRODUCTION_ERROR); for (ValidatorResponse validatorResponse :
					 * failedPropertyList) { errMsg = validatorResponse.getFieldErrorMessage(); if
					 * (errMsg != null && errMsg.length() > 0) { errMsgArr = errMsg.split("#"); if
					 * (errMsgArr.length > 1) { // Exception logic - start exceptionTransactionModel
					 * = AmadeusCommonUtils .initExceptionTransactionModel(amadeusRecordStaging,
					 * documentUniqueid); exceptionTransactionModel.setClientId(hostCarrDesigCode);
					 * exceptionTransactionModel
					 * .setExceptionCode(ExceptionCodeConstants.ERRORCODE_INCORRECTDATA);
					 * 
					 * exceptionTransactionModel.setResolutionRemarks(
					 * "Data error need to be corrected in the production tables..");
					 * exceptionTransactionModel.
					 * setExceptionDetails("errMsgArr[0] [DocumentuniqueID : " + documentUniqueid +
					 * ", Invalid Field : " + errMsgArr[0] + "]");
					 * 
					 * 
					 * parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();
					 * paramValueModel = new ExceptionParametersValueModel();
					 * paramValueModel.setParameterName("Check Digit");
					 * paramValueModel.setParameterValue("0");
					 * parametersValueModelList.add(paramValueModel);
					 * 
					 * paramValueModel = new ExceptionParametersValueModel();
					 * paramValueModel.setParameterName("Line No.");
					 * paramValueModel.setParameterValue(errMsgArr[0]);
					 * parametersValueModelList.add(paramValueModel);
					 * 
					 * paramValueModel = new ExceptionParametersValueModel();
					 * paramValueModel.setParameterName("Start Position");
					 * paramValueModel.setParameterValue("0");
					 * parametersValueModelList.add(paramValueModel);
					 * 
					 * paramValueModel = new ExceptionParametersValueModel();
					 * paramValueModel.setParameterName("End Position");
					 * paramValueModel.setParameterValue("0");
					 * parametersValueModelList.add(paramValueModel);
					 * 
					 * exceptionTransactionModel.setParametersValueList(parametersValueModelList);
					 * exceptionTxnFeignClient.initExceptionTrasaction(exceptionTransactionModel);
					 * // Exception logic - end
					 * 
					 * method = classVar.getDeclaredMethod(errMsgArr[0], String.class); if
					 * (errMsgArr[1].equalsIgnoreCase("SYSDATE")) {
					 * method.invoke(amadeusRecordStaging, LocalDateTime.now().toString()); } else
					 * if (errMsgArr[1].equalsIgnoreCase("EMPTY")) {
					 * method.invoke(amadeusRecordStaging, ""); } else {
					 * method.invoke(amadeusRecordStaging, errMsgArr[1]); } }
					 * 
					 * } } }
					 */

					// Data type validation login - end

					ticketMain = new TicketMain();

					// Original document unique id
					String OriginalIssueAirline = null;
					String originalDocumentNumber = null;
					SimpleDateFormat formatter = new SimpleDateFormat("dd/MMM/yyyy");

					ticketMain.setIssueAirline(amadeusRecordStaging.getIssAirline());
					ticketMain.setDocumentNumber(updatedDocNumber);

					LOGGER.info("Reported Fare   :{}", amadeusRecordStaging.getReportedFare());
					if (amadeusRecordStaging.getReportedFare().equals(AppConstants.REPORTED_FARE_BL)) {
						ticketMain.setGrossFare(new BigDecimal(0));
					} else if (amadeusRecordStaging.getReportedFare().equals(AppConstants.REPORTED_FARE_BT)) {
						ticketMain.setGrossFare(new BigDecimal(0));
					} else if (amadeusRecordStaging.getReportedFare().equals(AppConstants.REPORTED_FARE_IT)) {
						ticketMain.setGrossFare(new BigDecimal(0));
					} else if (amadeusRecordStaging.getReportedFare().equals(AppConstants.REPORTED_FARE_NO_FARE)) {
						ticketMain.setGrossFare(new BigDecimal(0));
					} else if (amadeusRecordStaging.getReportedFare().equals(AppConstants.REPORTED_FARE_BULK)) {
						ticketMain.setGrossFare(new BigDecimal(0));
					} else {
						ticketMain.setGrossFare(new BigDecimal(amadeusRecordStaging.getReportedFare()));
					}
					ticketMain.setCurrencyOfSale(amadeusRecordStaging.getCurrencyOfReportedFare());

					ticketMain.setTicketingModeIndicator(amadeusRecordStaging.getTicketingModeIndicator());
					ticketMain.setIsValidated(AppConstants.IS_VALIDATED);
					ticketMain.setFareCalcModeIndicator(amadeusRecordStaging.getFareCalcModeIndicator());
					ticketMain.setSalesProcessIndicator(AppConstants.SALES_PROCESS_INDICATOR_N);
					/*
					 * if (amadeusRecordStaging.getEquivalentFare() == null ||
					 * amadeusRecordStaging.getEquivalentFare().length() == 0)
					 * amadeusRecordStaging.setEquivalentFare("0");
					 */

					ticketMain.setEquivalentCurrencyOfSale(amadeusRecordStaging.getPaymentCurrency());
					if (amadeusRecordStaging.getIssueDate() != null && !amadeusRecordStaging.getIssueDate().isEmpty()) {
						LOGGER.info("Issue Date   :{}", amadeusRecordStaging.getIssueDate());
						ticketMain.setDateOfIssue(format.parse(amadeusRecordStaging.getIssueDate()));
						LOGGER.info("Date of issue   :{}", amadeusRecordStaging.getIssueDate());
					}
					if (amadeusRecordStaging.getBookingReference() != null
							&& !amadeusRecordStaging.getIssueDate().isEmpty()) {
						ticketMain.setPnr(amadeusRecordStaging.getBookingReference());
					}
					LOGGER.info("TourCode :{}" + amadeusRecordStaging.getTourCode());
					if (amadeusRecordStaging.getTourCode() != null && !amadeusRecordStaging.getTourCode().isEmpty()) {
						ticketMain.setTourCode(amadeusRecordStaging.getTourCode());
					}
					ticketMain.setFca(amadeusRecordStaging.getFareConstruction());
					ticketMain.setPassengerName(amadeusRecordStaging.getPassengerName());
					ticketMain.setNetRemitIndicator(amadeusRecordStaging.getNetRemitIndicator());
					ticketMain.setCreatedBy(amadeusRecordStaging.getCreatedBy());
					ticketMain.setCreatedDate(new Timestamp(new Date().getTime()));
					ticketMain.setClientId(hostCarrDesigCode);
					ticketMain.setFileId(amadeusRecordStaging.getFileId());

					if (formcodeList != null && !formcodeList.isEmpty()) {
						ticketMain.setDocType(OptionalUtil.getValue(formcodeList.get(0).getDocumentType()));
					}
					if (formcodeList.get(0).getNumberOfCoupon().get() != "0") {
						ticketMain.setDocClass(formcodeList.get(0).getDocumentType().get().substring(0, 2)
								+ formcodeList.get(0).getNumberOfCoupon().get());
					} else {
						ticketMain.setDocClass(formcodeList.get(0).getDocumentType().get().substring(0, 2));
					}

					// Agency Creation Logic
					if (agencyMasterList.isEmpty()) {
						LOGGER.info("Agency is not available in Agency Master");
						AgencyMaster agencyMaster = new AgencyMaster();
						agencyMaster.setAgencyCode(Optional.of(amadeusRecordStaging.getAgencyNumber()));
						LOGGER.info(
								"Equivalent Fare reported in file------->" + amadeusRecordStaging.getEquivalentFare());
						if (amadeusRecordStaging.getEquivalentFare().isEmpty()
								|| amadeusRecordStaging.getEquivalentFare() == "") {

							String areaOfoperation_cityCode = amadeusRecordStaging.getAmadeusRecordDetailStgs().stream()
									.filter(x -> x.getSaleCouponNumber().equals(AppConstants.COUPON_NUMBER_01))
									.map(AmadeusRecordDetailStaging::getOrigin).findAny().get().trim();
							agencyMaster.setAreaOfOperation(Optional.of(areaOfoperation_cityCode));
							LOGGER.info("Area of operation  :{}" + agencyMaster.getAreaOfOperation());
							agencyMaster.setCityCode(Optional.of(areaOfoperation_cityCode));
							LOGGER.info("City Code  :{}" + agencyMaster.getCityCode());

						} else {

							LOGGER.info("Equivalent Fare is available  in AmadeusEtl file");
							agencyMaster.setAreaOfOperation(Optional.of(AppConstants.DEFAULTY_CITY_CODE));
							agencyMaster.setCityCode(Optional.of(AppConstants.DEFAULTY_CITY_CODE));
						}
						agencyMaster.setClientId(Optional.of(hostCarrDesigCode));
						agencyMaster.setReportingAgency(Optional.of(AppConstants.REPORTING_TYPE_AGENCY));
						agencyMaster.setReportingAgencyType(Optional.of(AppConstants.REPORTING_TYPE_AGENCY_TYPE));
						agencyMaster.setCreatedBy(Optional.of(amadeusRecordStaging.getCreatedBy()));

						AgencyMaster agencyMasterCreate = masterFeignClient.createAgencyMaster(agencyMaster);
						LOGGER.info("Agency Creation Details " + agencyMasterCreate.toString());
						if (agencyMasterCreate != null) {
							LOGGER.info("Agency is Created in Agency Master :{}");
							ticketMain.setReportingAgentCode(agencyMasterCreate.getReportingAgency().get());
							ticketMain.setPlaceOfIssue(agencyMasterCreate.getCityCode().get());
							ticketMain.setPlaceOfSale(agencyMasterCreate.getCityCode().get());
							LOGGER.info("Reporting Agency type" + ticketMain.getReportingAgentCode());
						}

						/*
						 * LOGGER.info("Error Count in agency master list---------->" + errorCount);
						 * errorCount++; jobExecutionContext.put("errorCount", errorCount);
						 * LOGGER.info("Error Count after in agency master list----------->" +
						 * jobExecution.getExecutionContext().get("errorCount"));
						 * amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_ERROR);
						 * amadeusRecordStagingRepository.saveAndFlush(amadeusRecordStaging); //
						 * Exception logic - start exceptionTransactionModel = AmadeusCommonUtils
						 * .initExceptionTransactionModel(amadeusRecordStaging, documentUniqueid);
						 * exceptionTransactionModel.setClientId(hostCarrDesigCode);
						 * exceptionTransactionModel.setExceptionCode(ExceptionCodeConstants.
						 * ERRORCODE_AGENCYMASTER);
						 * 
						 * exceptionTransactionModel
						 * .setResolutionRemarks("Agency details need to be added in agency master");
						 * exceptionTransactionModel.
						 * setExceptionDetails("Agench details not found for agency number : " +
						 * amadeusRecordStaging.getAgencyNumber());
						 * 
						 * parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();
						 * 
						 * paramValueModel = new ExceptionParametersValueModel();
						 * paramValueModel.setParameterName("Agency Code");
						 * paramValueModel.setParameterValue(amadeusRecordStaging.getAgencyNumber());
						 * parametersValueModelList.add(paramValueModel);
						 * 
						 * paramValueModel = new ExceptionParametersValueModel();
						 * paramValueModel.setParameterName("Effective Date");
						 * paramValueModel.setParameterValue(LocalDateTime.now().toString());
						 * parametersValueModelList.add(paramValueModel);
						 * 
						 * exceptionTransactionModel.setParametersValueList(parametersValueModelList);
						 * 
						 * exceptionTxnFeignClient.initExceptionTrasaction(exceptionTransactionModel);
						 * // Exception logic - end
						 * amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_ERROR);
						 * amadeusRecordStagingRepository.saveAndFlush(amadeusRecordStaging); return
						 * null;
						 */
					}

					ticketMain.setMainDocument(mainDocumentNo);
					if (agencyMasterList != null && !agencyMasterList.isEmpty()) {
						LOGGER.info("Agency is Available in Agency Master :{}");
						ticketMain.setReportingAgentCode(agencyMasterList.get(0).getReportingAgency().get());
						ticketMain.setPlaceOfIssue(agencyMasterList.get(0).getCityCode().get());
						ticketMain.setPlaceOfSale(agencyMasterList.get(0).getCityCode().get());
					}

					if (amadeusRecordStaging.getEquivalentFare().matches("\\d*\\.?\\d+")) {
						ticketMain.setEquivalentFare(new BigDecimal(amadeusRecordStaging.getEquivalentFare()));
					} else if (amadeusRecordStaging.getEquivalentFare() == null
							|| amadeusRecordStaging.getEquivalentFare().length() == 0) {
						amadeusRecordStaging.setEquivalentFare("0");
					} else {
						amadeusRecordStaging.setEquivalentFare("0");
					}

					LOGGER.info("Document Number Derived from Original Issue Information   :{}",
							amadeusRecordStaging.getOriginalIssueInformation());
					if (amadeusRecordStaging.getOriginalIssueInformation() != null
							&& !amadeusRecordStaging.getOriginalIssueInformation().isEmpty()) {
						String originalIssueInformation = amadeusRecordStaging.getOriginalIssueInformation()
								.replaceAll("\\s+", "");
						if (originalIssueInformation.length() == 31 || originalIssueInformation.length() == 30) {
							LOGGER.info("Original Issue Information having length 30 / 31 :{}");
							OriginalIssueAirline = originalIssueInformation.substring(0, 3);
							originalDocumentNumber = originalIssueInformation.substring(3, 13);
							ticketMain.setOriginalIssueAirline(OriginalIssueAirline);
							ticketMain.setOriginalDocumentNumber(originalDocumentNumber);
							ticketMain.setOriginalPlaceOfIssue(originalIssueInformation.substring(13, 16));
							ticketMain
									.setOriginalDateOfIssue(format1.parse(originalIssueInformation.substring(16, 23)));
							ticketMain.setOriginalAgentCode(originalIssueInformation.substring(23, 30));
							originalIssueDate = format1.parse(originalIssueInformation.substring(16, 23));
							originalDocumentUniqueid = hostCarrDesigCode + OriginalIssueAirline + originalDocumentNumber
									+ originalIssueInformation.substring(16, 23);
							ticketMain.setOriginalDocumentUniqueId(originalDocumentUniqueid);
							LOGGER.info("original Document Id" + originalDocumentUniqueid);

						} else if (originalIssueInformation.length() == 28) {
							// agencyMasterListfor originalIssueInformation
							agencyMasterListForOriginalissue = masterFeignClient.getAllAgency(
									originalIssueInformation.substring(20, 27), reportingAgency, agencyType,
									areaOfOperation, reportingAgencyType, null);

							if (agencyMasterListForOriginalissue.isEmpty()) {
								LOGGER.info("Error Count in agency master list---------->" + errorCount);
								errorCount++;
								jobExecutionContext.put("errorCount", errorCount);
								LOGGER.info(
										"Error Count after in agency master list for original issuer information----------->"
												+ jobExecution.getExecutionContext().get("errorCount"));
								amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_ERROR);
								amadeusRecordStagingRepository.saveAndFlush(amadeusRecordStaging);
								// Exception logic - start
								exceptionTransactionModel = AmadeusCommonUtils
										.initExceptionTransactionModel(amadeusRecordStaging, documentUniqueid);
								exceptionTransactionModel.setClientId(hostCarrDesigCode);
								exceptionTransactionModel
										.setExceptionCode(ExceptionCodeConstants.ERRORCODE_AGENCYMASTER);
								/*
								 * exceptionTransactionModel.
								 * setResolutionRemarks("Agency details need to be added in agency master");
								 * exceptionTransactionModel.setExceptionDetails(
								 * "Agench details not found for agency number : " +
								 * amadeusRecordStaging.getAgencyNumber());
								 */
								parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();

								paramValueModel = new ExceptionParametersValueModel();
								paramValueModel.setParameterName("Agency Code");
								paramValueModel.setParameterValue(amadeusRecordStaging.getAgencyNumber());
								parametersValueModelList.add(paramValueModel);

								paramValueModel = new ExceptionParametersValueModel();
								paramValueModel.setParameterName("Effective Date");
								paramValueModel.setParameterValue(LocalDateTime.now().toString());
								parametersValueModelList.add(paramValueModel);

								exceptionTransactionModel.setParametersValueList(parametersValueModelList);
								amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_ERROR);
								amadeusRecordStagingRepository.saveAndFlush(amadeusRecordStaging);
								exceptionTxnFeignClient.initExceptionTrasaction(exceptionTransactionModel);
								// Exception logic - end
								return null;
							}
							LOGGER.info("Original Issue Information having length 28 :{}");
							OriginalIssueAirline = originalIssueInformation.substring(0, 3);
							originalDocumentNumber = originalIssueInformation.substring(3, 13);
							originalIssueDate = format1.parse(originalIssueInformation.substring(13, 20));
							ticketMain.setOriginalIssueAirline(OriginalIssueAirline);
							ticketMain.setOriginalDocumentNumber(originalDocumentNumber);
							ticketMain.setOriginalPlaceOfIssue(
									agencyMasterListForOriginalissue.get(0).getCityCode().get());
							LOGGER.info("Original Agent Code to derive original place of issue from  Agency Masterr -->"
									+ originalIssueInformation.substring(20, 27));
							ticketMain.setOriginalDateOfIssue(originalIssueDate);
							ticketMain.setOriginalAgentCode(originalIssueInformation.substring(20, 27));
							originalDocumentUniqueid = hostCarrDesigCode + OriginalIssueAirline + originalDocumentNumber
									+ originalIssueInformation.substring(13, 20);
							ticketMain.setOriginalDocumentUniqueId(originalDocumentUniqueid);
							LOGGER.info("original Document Id" + originalDocumentUniqueid);

						} else if (originalIssueInformation.length() == 22 && originalIssueInformation.contains("XX")) {

							LOGGER.info("Original Issue Information having length 22 :{}");
							OriginalIssueAirline = originalIssueInformation.substring(0, 3);
							originalIssueDate = format1.parse(originalIssueInformation.substring(8, 15));
							ticketMain.setOriginalIssueAirline(OriginalIssueAirline);
							ticketMain.setOriginalDocumentNumber(originalDocumentNumber);
							ticketMain.setOriginalPlaceOfIssue(originalIssueInformation.substring(5, 8));
							ticketMain.setOriginalDateOfIssue(originalIssueDate);
							ticketMain.setOriginalAgentCode(originalIssueInformation.substring(15, 22));
							ticketMain.setOriginalDocumentUniqueId(originalDocumentUniqueid);

						}

						else {
							LOGGER.info("Error in Original Issue Information having length greater than 31 :{}");
						}

						ticketMain.setPrimeReissue(AppConstants.PRIME_REISSUE_R);
					} else {
						ticketMain.setPrimeReissue(AppConstants.PRIME_REISSUE_P);
					}
					if (amadeusRecordStaging.getEndorsementRestrictionText() != null
							&& !amadeusRecordStaging.getEndorsementRestrictionText().isEmpty()) {
						if (amadeusRecordStaging.getEndorsementRestrictionText().length() <= 200) {
							LOGGER.info("Endorsenment Text Lenght less than 200 ---->"
									+ amadeusRecordStaging.getEndorsementRestrictionText().length());
							ticketMain.setEndorsements(amadeusRecordStaging.getEndorsementRestrictionText());
						} else if (amadeusRecordStaging.getEndorsementRestrictionText().length() > 200) {
							LOGGER.info("Endorsenment Text Lenght having more than 200---->"
									+ amadeusRecordStaging.getEndorsementRestrictionText().length());
							ticketMain.setEndorsements(
									amadeusRecordStaging.getEndorsementRestrictionText().substring(0, 199));
						}

					}
					ticketMain.setEticketInd(AppConstants.ETICKET_INDICATOR_DEFAULT);
					ticketMain.setFfyIndicator(AppConstants.FF_INDICATOR_DEFAULT);
					ticketMain.setCodeShareIndicator(AppConstants.CODE_SHARE_INDICATOR_DEFAULT);
					ticketMain.setReportedDate(new Timestamp(new Date().getTime()));
					ticketMain.setFirstTimeProcessed(AppConstants.FIRST_TIME_PROCESSED_DEFAULT);
					ticketMain.setRevenueFlag(AppConstants.REVENUE_FLAG_DEFAULT);
					ticketMain.setProrationMethod(AppConstants.PRORATION_METHOD_DEFAULT);

					if (amadeusRecordStaging.getUsageDocNumber().length() > 10) {
						LOGGER.info(
								"Conjuction Ticket is available :{}" + amadeusRecordStaging.getUsageDocNumber().length()
										+ amadeusRecordStaging.getUsageDocNumber());

						if (ticketMain.getDocumentNumber().equals(ticketMain.getMainDocument())) {
							ticketMain.setConjTicketIndicator(AppConstants.CONJ_TICKET_INDICATOR_NO);
						} else {
							ticketMain.setConjTicketIndicator(AppConstants.CONJ_TICKET_INDICATOR_YES);
						}

					} else {
						LOGGER.info("Conjuction Ticket not available :{}"
								+ amadeusRecordStaging.getUsageDocNumber().length()
								+ amadeusRecordStaging.getUsageDocNumber());
						ticketMain.setConjTicketIndicator(AppConstants.CONJ_TICKET_INDICATOR_NO);
					}

					ticketMain.setMigratedTicket(AppConstants.MIGRATED_TICKET_DEFAULT);
					if (amadeusRecordStaging.getReportedFare().equals(AppConstants.REPORTED_FARE_BL)) {
						ticketMain.setBtItIndicator(amadeusRecordStaging.getReportedFare());
					} else if (amadeusRecordStaging.getReportedFare().equals(AppConstants.REPORTED_FARE_BT)) {
						ticketMain.setBtItIndicator(amadeusRecordStaging.getReportedFare());
					} else if (amadeusRecordStaging.getReportedFare().equals(AppConstants.REPORTED_FARE_IT)) {
						ticketMain.setBtItIndicator(amadeusRecordStaging.getReportedFare());
					}
					ticketMain.setCouponUseIndicator(amadeusRecordStaging.getUsageType());
					ticketMain.setFileSource(amadeusRecordStaging.getFileSource());
					ticketMain.setDataSource(amadeusRecordStaging.getFileSource());
					ticketMain.setStatus(AppConstants.STATUS_PRODUCTION);
					if (amadeusRecordStaging.getAmadeusRecordDetailStgs().get(0) != null) {
						if (amadeusRecordStaging.getAmadeusRecordDetailStgs().get(0)
								.getInvoluntaryIndicator() != null) {
							ticketMain.setInvolIndicator(
									amadeusRecordStaging.getAmadeusRecordDetailStgs().get(0).getInvoluntaryIndicator());
						}

					}
					ticketMain.setAgentCode(amadeusRecordStaging.getAgencyNumber());
					ticketMain.setDocumentUniqueId(documentUniqueid);

					List<TicketCoupon> ticketCouponList = new ArrayList<TicketCoupon>();
					TicketCoupon ticketCoupon;

					for (AmadeusRecordDetailStaging recordDetailStaging : amadeusRecordStaging
							.getAmadeusRecordDetailStgs()) {
						Integer saleCoupon = Integer.parseInt(recordDetailStaging.getSaleCouponNumber());
						if (saleCoupon > (k * 4) && saleCoupon < ((k * 4) + 5)) {
							docClassCount++;
							bookingClassModelList = masterFeignClient.getListOfBookingClassByUtilizationEffectiveDate(
									null, recordDetailStaging.getSellingClass(), null, null, null, null, null);
							LOGGER.info("Selling Class:{}" + recordDetailStaging.getSellingClass());
							LOGGER.info("bookingClassModelList  Lists are:{}" + bookingClassModelList);
							ticketCoupon = new TicketCoupon();
							ticketCoupon.setDocumentUniqueId(documentUniqueid);
							ticketCoupon.setIssueAirline(issueAirline);
							ticketCoupon.setDocumentNumber(updatedDocNumber);
							ticketCoupon.setMainDocument(mainDocumentNo);
							if (recordDetailStaging.getSaleCouponNumber() != null
									&& !recordDetailStaging.getSaleCouponNumber().isEmpty()) {

								if (saleCoupon % 4 == 0) {
									ticketCoupon.setCouponNumber(AppConstants.COUPON_NUMBER);
								} else {
									ticketCoupon.setCouponNumber(saleCoupon % AppConstants.COUPON_NUMBER);
								}

							}
							if (recordDetailStaging.getOrigin() != null && !recordDetailStaging.getOrigin().isEmpty()) {
								ticketCoupon.setFromAirport(recordDetailStaging.getOrigin());
							}

							if (recordDetailStaging.getDestination() != null
									&& !recordDetailStaging.getDestination().isEmpty()) {
								ticketCoupon.setToAirport(recordDetailStaging.getDestination());
							}

							if (recordDetailStaging.getSaleFlightNumber() != null
									&& !recordDetailStaging.getSaleFlightNumber().isEmpty()) {
								if (recordDetailStaging.getSaleFlightNumber().equals(AppConstants.REPORTED_FARE_BL)) {
									ticketCoupon.setMarketingFlightNumber(AppConstants.MARKETING_FLIGHT_NUMBER_DEFAULT);
								} else if (recordDetailStaging.getSaleFlightNumber()
										.equals(AppConstants.REPORTED_FARE_BT)) {
									ticketCoupon.setMarketingFlightNumber(AppConstants.MARKETING_FLIGHT_NUMBER_DEFAULT);
								} else if (recordDetailStaging.getSaleFlightNumber()
										.equals(AppConstants.REPORTED_FARE_IT)) {
									ticketCoupon.setMarketingFlightNumber(AppConstants.MARKETING_FLIGHT_NUMBER_DEFAULT);
								} else if (recordDetailStaging.getSaleFlightNumber().contains(AppConstants.OPEN)) {
									LOGGER.info("Flight Number Open---------->"
											+ recordDetailStaging.getSaleFlightNumber());
									ticketCoupon.setMarketingFlightNumber(AppConstants.OPEN);

								} else {
									ticketCoupon.setMarketingFlightNumber(SmartPRACommonUtil.deriveFlightNo(
											recordDetailStaging.getSaleFlightNumber(), sysParamFlightLen));
								}

							}

							String airlineCodeOpt = (recordDetailStaging.getAirlineCode().trim());

							// carrierMasterList
							carrierMasterList = carrierMasterFeignClient.getAllCarrier(null, airlineCodeOpt, null, null,
									null);

							if (carrierMasterList.isEmpty()) {
								LOGGER.info(
										"Carrier Code Not Available for the Career Designator Code" + airlineCodeOpt);
								LOGGER.info("Error Count before---------->" + errorCount);
								errorCount++;
								jobExecutionContext.put("errorCount", errorCount);
								LOGGER.info("Error Count after----------->"
										+ jobExecution.getExecutionContext().get("errorCount"));
								// Exception logic - start
								exceptionTransactionModel = AmadeusCommonUtils
										.initExceptionTransactionModel(amadeusRecordStaging, documentUniqueid);
								exceptionTransactionModel.setClientId(hostCarrDesigCode);
								exceptionTransactionModel
										.setExceptionCode(ExceptionCodeConstants.ERRORCODE_INVALIDCARRIERCODE);
								/*
								 * exceptionTransactionModel
								 * .setResolutionRemarks("Airline Code need to be added in Carrier  Master");
								 * exceptionTransactionModel
								 * .setExceptionDetails("Carrier  details not found for airline code : " +
								 * recordDetailStaging.getAirlineCode());
								 */
								if (amadeusRecordStaging.getCouponNumber() != null)
									exceptionTransactionModel
											.setCouponNumber(Integer.parseInt(amadeusRecordStaging.getCouponNumber()));
								parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();

								paramValueModel = new ExceptionParametersValueModel();
								paramValueModel.setParameterName("Document No.");
								paramValueModel.setParameterValue(amadeusRecordStaging.getDocumentNumber());
								parametersValueModelList.add(paramValueModel);

								paramValueModel = new ExceptionParametersValueModel();
								paramValueModel.setParameterName("Carrier Code");
								paramValueModel.setParameterValue(recordDetailStaging.getAirlineCode());
								parametersValueModelList.add(paramValueModel);

								paramValueModel = new ExceptionParametersValueModel();
								paramValueModel.setParameterName("Carrier Numeric Code");
								paramValueModel.setParameterValue("Exception");
								parametersValueModelList.add(paramValueModel);

								exceptionTransactionModel.setParametersValueList(parametersValueModelList);
								amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_ERROR);
								amadeusRecordStagingRepository.saveAndFlush(amadeusRecordStaging);
								exceptionTxnFeignClient.initExceptionTrasaction(exceptionTransactionModel);
								// Exception logic - end
								return null;
							}

							ticketCoupon.setMarketingCarrierAlphaCode(recordDetailStaging.getAirlineCode());
							LOGGER.info("Marketing Numeric Code" + carrierMasterList.get(0).getCarrierCode());
							ticketCoupon.setMarketingCarrierNumCode(
									OptionalUtil.getValue(carrierMasterList.get(0).getCarrierCode()));

							// if(recordDetailStaging.getSaleLocalFlightDate().equals(AppConstants ))

							if (recordDetailStaging.getSaleLocalFlightDate() != null) {
								if (recordDetailStaging.getSaleLocalFlightDate().trim()
										.equals(AppConstants.FLIGHT_DATE_OPEN)) {
									LOGGER.info("Flight Date Open-->"
											+ recordDetailStaging.getSaleLocalFlightDate().trim());
									ticketCoupon.setMarketingFlightDate(null);
								} else {
									ticketCoupon.setMarketingFlightDate(
											LocalDate.parse(recordDetailStaging.getSaleLocalFlightDate(), dtFormatter));
								}

							}

							ticketCoupon.setTicketedRbd(recordDetailStaging.getSellingClass());
							ticketCoupon.setFareBasis(recordDetailStaging.getFareBasis());
							ticketCoupon.setBookingStatus(recordDetailStaging.getReservationStatus());
							ticketCoupon.setSectorNumber(String.valueOf(saleCoupon));
							LOGGER.info("Sector Number-->" + saleCoupon);
							ticketCoupon.setNotValidBefore(recordDetailStaging.getNotValidBeforeDate());
							ticketCoupon.setNotValidAfter(recordDetailStaging.getNotValidAfterDate());
							ticketCoupon.setCreatedBy(recordDetailStaging.getCreatedBy());
							ticketCoupon.setCreatedDate(new Timestamp(new Date().getTime()));

							if (bookingClassModelList.isEmpty()) {
								LOGGER.info("Error Count before---------->" + errorCount);
								errorCount++;
								jobExecutionContext.put("errorCount", errorCount);
								LOGGER.info("Error Count after----------->"
										+ jobExecution.getExecutionContext().get("errorCount"));
								// Exception logic - start
								exceptionTransactionModel = AmadeusCommonUtils
										.initExceptionTransactionModel(amadeusRecordStaging, documentUniqueid);
								exceptionTransactionModel.setClientId(hostCarrDesigCode);
								exceptionTransactionModel.setExceptionCode(ExceptionCodeConstants.ERRORCODE_DOCCLASS);
								/*
								 * exceptionTransactionModel
								 * .setResolutionRemarks("Cabin details need to be added in Booking Class Master"
								 * ); exceptionTransactionModel
								 * .setExceptionDetails("BookingClass details not found for rbd : " +
								 * recordDetailStaging.getSellingClass());
								 */
								exceptionTransactionModel.setCouponNumber(ticketCoupon.getCouponNumber());
								parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();

								paramValueModel = new ExceptionParametersValueModel();
								paramValueModel.setParameterName("Document No.");
								paramValueModel.setParameterValue(amadeusRecordStaging.getDocumentNumber());
								parametersValueModelList.add(paramValueModel);

								paramValueModel = new ExceptionParametersValueModel();
								paramValueModel.setParameterName("Carrier Numeric Code");
								paramValueModel.setParameterValue(issueAirline);
								parametersValueModelList.add(paramValueModel);

								paramValueModel = new ExceptionParametersValueModel();
								paramValueModel.setParameterName("Doc Class");
								paramValueModel.setParameterValue(recordDetailStaging.getSellingClass());
								parametersValueModelList.add(paramValueModel);

								exceptionTransactionModel.setParametersValueList(parametersValueModelList);
								amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_ERROR);
								amadeusRecordStagingRepository.saveAndFlush(amadeusRecordStaging);

								exceptionTxnFeignClient.initExceptionTrasaction(exceptionTransactionModel);
								// Exception logic - end
								return null;
							} else {
								ticketCoupon.setTicketedCabin(
										OptionalUtil.getValue(bookingClassModelList.get(0).getCabin()));
							}
							ticketCoupon.setTicketMain(ticketMain);
							ticketCouponList.add(ticketCoupon);
							LOGGER.info("ProdETLTicketProcessor.process -- End");
						}
					}
					// Surface sector - begin
					Map<Integer, String[]> couponMap = new HashMap<Integer, String[]>();
					String[] airportStr = null;
					Integer maxCouponNo = 0;
					for (AmadeusRecordDetailStaging recordDetailStaging : amadeusRecordStaging
							.getAmadeusRecordDetailStgs()) {
						Integer saleCoupon = Integer.parseInt(recordDetailStaging.getSaleCouponNumber());
						airportStr = new String[2];
						airportStr[0] = recordDetailStaging.getOrigin();
						airportStr[1] = recordDetailStaging.getDestination();
						couponMap.put(saleCoupon, airportStr);
						if (maxCouponNo < saleCoupon) {
							maxCouponNo = saleCoupon;
						}
					}
					Integer[] flagArr = new Integer[maxCouponNo];
					for (int nbr = 1; nbr < maxCouponNo + 1; nbr++) {
						if (((String[]) couponMap.get(nbr)) == null) {
							if (nbr > (k * 4) && nbr < ((k * 4) + 5)) {
								docClassCount++;
								String[] prefRec = couponMap.get(nbr - 1);
								String[] afteRec = couponMap.get(nbr + 1);
								TicketCoupon tktCoupon = new TicketCoupon();

								tktCoupon.setFromAirport(prefRec[1]);
								tktCoupon.setToAirport(afteRec[0]);
								tktCoupon.setMarketingCarrierAlphaCode(AppConstants.SURSECTOR_MARKETTING_CARRIER);
								tktCoupon.setDocumentUniqueId(documentUniqueid);
								tktCoupon.setIssueAirline(issueAirline);
								tktCoupon.setDocumentNumber(updatedDocNumber);
								tktCoupon.setMainDocument(mainDocumentNo);
								if (nbr % 4 == 0) {
									tktCoupon.setCouponNumber(AppConstants.COUPON_NUMBER);
								} else {
									tktCoupon.setCouponNumber(nbr % AppConstants.COUPON_NUMBER);
								}
								tktCoupon.setSectorNumber(String.valueOf(nbr));
								tktCoupon.setCreatedBy(ticketMain.getCreatedBy());
								tktCoupon.setCreatedDate(new Timestamp(new Date().getTime()));
								tktCoupon.setTicketMain(ticketMain);
								ticketCouponList.add(tktCoupon);
							}

							LOGGER.info("ProdETLTicketProcessor.process -- End");
						}
					}
					// Surface sector - end
					ticketMain.setTicketCoupons(ticketCouponList);
					if (updatedDocNumber.equals(mainDocumentNo)) {
						List<TicketTax> ticketTaxList = new ArrayList<TicketTax>();
						TicketTax ticketTax;
						for (AmadeusNewTaxStaging newTaxStaging : amadeusRecordStaging.getAmadeusNewTaxStgs()) {
							ticketTax = new TicketTax();
							ticketTax.setDocumentUniqueId(documentUniqueid);
							ticketTax.setIssueAirline(issueAirline);
							ticketTax.setDocumentNumber(updatedDocNumber);
							ticketTax.setMainDocument(mainDocumentNo);

							ticketTax.setTaxCode(newTaxStaging.getNewTaxCode());
							BigDecimal txAmt = new BigDecimal(0);
							if (newTaxStaging.getNewTaxValue() != null && !newTaxStaging.getNewTaxValue().isEmpty()) {
								String newTax = newTaxStaging.getNewTaxValue().trim();
								txAmt = new BigDecimal(newTax);
								ticketTax.setTaxAmount(txAmt);
							}
							ticketTax.setSerialNo(++j);
							LOGGER.info("Serial Number fox Tax-->" + j);

							ticketTax.setTaxCurrency(amadeusRecordStaging.getCurrencyOfReportedFare());
							ticketTax.setCreatedBy(amadeusRecordStaging.getCreatedBy());
							ticketTax.setCreatedDate(new Timestamp(new Date().getTime()));
							ticketTax.setTicketMain(ticketMain);
							ticketTaxList.add(ticketTax);
						}
						ticketMain.setTicketTaxs(ticketTaxList);
					}

					// pax type integeration
					PAXTypeModel paxTypeModel = new PAXTypeModel();
					paxTypeModel.setBookingStatus(ticketMain.getTicketCoupons().get(0).getBookingStatus());
					paxTypeModel.setPassengerName(ticketMain.getPassengerName());
					paxTypeModel.setPast(ticketMain.getPaxTypeReceived());
					paxTypeModel.setPassengerDob(ticketMain.getPassengerDob());

					ticketMain.setPaxType(paxTypeFeignClient.getPaxTypeFromTicketMain(paxTypeModel));
					LOGGER.info("PAX TYPE Derivation-----------" + ticketMain.getPaxType());
					ticketMainList.add(ticketMain);
					prodTicketModel.setTicketMain(ticketMainList);
					docUniqueIdsLoaded.add(documentUniqueid);
				}
			}
			transferredCount++;
			jobExecutionContext.put("transferredCount", transferredCount);
			LOGGER.info("Transfered Count-----------" + transferredCount);
			return prodTicketModel;

		} catch (Exception e) {
			LOGGER.error("Exception Thrown for the amadeus Load Id: " + amadeusRecordStaging.getAmadeusLoadId());
			LOGGER.error("Exception" + e);
			exceptionTransactionModel = AmadeusCommonUtils.initExceptionTransactionModel(amadeusRecordStaging,
					amadeusRecordStaging.getDocumentNumber());
			exceptionTransactionModel.setClientId(hostCarrDesigCode);
			exceptionTransactionModel.setExceptionCode(ExceptionCodeConstants.GENERAL_EXCEPTION);
			/*
			 * exceptionTransactionModel.
			 * setResolutionRemarks("General Exception due to wrong data in file");
			 * exceptionTransactionModel.setExceptionDetails(
			 * "Exception Thrown for the amadeus load Id : " +
			 * amadeusRecordStaging.getAmadeusLoadId());
			 */
			parametersValueModelList = new ArrayList<ExceptionParametersValueModel>();
			paramValueModel = new ExceptionParametersValueModel();
			paramValueModel.setParameterName("Reference ID");
			paramValueModel.setParameterValue(String.valueOf(amadeusRecordStaging.getAmadeusLoadId()));
			parametersValueModelList.add(paramValueModel);
			exceptionTransactionModel.setParametersValueList(parametersValueModelList);
			amadeusRecordStaging.setStatus(AppConstants.STG_STATUS_ERROR);
			amadeusRecordStagingRepository.saveAndFlush(amadeusRecordStaging);
			exceptionTxnFeignClient.initExceptionTrasaction(exceptionTransactionModel);
			// Exception logic - end
			return null;
		}
	}
}
