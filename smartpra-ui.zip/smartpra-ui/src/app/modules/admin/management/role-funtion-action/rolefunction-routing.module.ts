import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {RoleFuntionActionComponent} from "./role-funtion-action.component";

const routes: Routes = [
  {path:'',component:RoleFuntionActionComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RolefunctionRoutingModule { }
