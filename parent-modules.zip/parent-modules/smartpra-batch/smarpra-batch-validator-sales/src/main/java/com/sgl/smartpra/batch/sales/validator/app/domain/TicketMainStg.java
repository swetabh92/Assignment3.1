package com.sgl.smartpra.batch.sales.validator.app.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.batch.item.ItemWriter;

import com.sgl.smartpra.batch.sales.validator.app.writer.TicketMainStgWriter;



/**
 * The persistent class for the ticket_main_stg database table.
 * 
 */
@Entity
@Table(name="ticket_main_stg")
public class TicketMainStg implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="trn_tkt_id")
	private int trnTktId;

	@Column(name="agent_code")
	private String agentCode;

	@Column(name="airline_issuing_agent")
	private String airlineIssuingAgent;

	@Column(name="archive_flag")
	private String archiveFlag;

	@Column(name="atbp_currency")
	private String atbpCurrency;

	@Column(name="billing_airline")
	private String billingAirline;

	@Column(name="bt_it_indicator")
	private String btItIndicator;

	@Column(name="client_id")
	private String clientId;

	@Column(name="conj_ticket_indicator")
	private String conjTicketIndicator;

	@Column(name="created_by")
	private String createdBy;

	@Column(name="created_date")
	private Timestamp createdDate;

	@Column(name="currency_adjustment")
	private String currencyAdjustment;

	@Column(name="currency_of_sale")
	private String currencyOfSale;

	@Column(name="data_source")
	private String dataSource;

	@Column(name="date_of_issue")
	private String dateOfIssue;

	@Column(name="doc_class")
	private String docClass;

	@Column(name="doc_type")
	private String docType;

	@Column(name="document_number")
	private String documentNumber;

	@Column(name="document_unique_id")
	private String documentUniqueId;

	@Column(name="dom_int_indicator")
	private String domIntIndicator;

	@Column(name="emd_indicator")
	private String emdIndicator;

	private String endorsements;

	@Column(name="enroute_indicator")
	private String enrouteIndicator;

	@Column(name="equivalent_currency_of_sale")
	private String equivalentCurrencyOfSale;

	@Column(name="equivalent_fare")
	private String equivalentFare;

	@Column(name="eticket_ind")
	private String eticketInd;

	@Column(name="excess_weight")
	private String excessWeight;

	@Column(name="exchange_rate_month")
	private String exchangeRateMonth;

	@Column(name="fare_comp_currency")
	private String fareCompCurrency;

	private String fca;

	@Column(name="fdr_used")
	private String fdrUsed;

	@Column(name="file_id")
	private String fileId;

	@Column(name="file_source")
	private String fileSource;

	@Column(name="free_award_ticket_indicator")
	private String freeAwardTicketIndicator;

	@Column(name="gross_fare")
	private String grossFare;

	@Column(name="ignore_fca")
	private String ignoreFca;

	@Column(name="invol_indicator")
	private String involIndicator;

	@Column(name="is_validated")
	private String isValidated;

	private String isi;

	@Column(name="issue_airline")
	private String issueAirline;

	@Column(name="journey_tournaround_airport")
	private String journeyTournaroundAirport;

	@Column(name="journey_type")
	private String journeyType;

	@Column(name="last_updated_by")
	private String lastUpdatedBy;

	@Column(name="last_updated_date")
	private Timestamp lastUpdatedDate;

	@Column(name="main_document")
	private String mainDocument;

	@Column(name="migrated_ticket")
	private String migratedTicket;

	@Column(name="mpr_percentage")
	private BigDecimal mprPercentage;

	@Column(name="net_fare_amount")
	private String netFareAmount;

	@Column(name="net_fare_currency")
	private String netFareCurrency;

	@Column(name="non_revenue_flag")
	private String nonRevenueFlag;

	private String nrid;

	@Column(name="online_destination")
	private String onlineDestination;

	@Column(name="online_interline_offline")
	private String onlineInterlineOffline;

	@Column(name="online_origin")
	private String onlineOrigin;

	@Column(name="online_pot")
	private String onlinePot;

	@Column(name="order_id")
	private String orderId;

	@Column(name="original_agent_code")
	private String originalAgentCode;

	@Column(name="original_date_of_issue")
	private String originalDateOfIssue;

	@Column(name="original_doc_class")
	private String originalDocClass;

	@Column(name="original_document_number")
	private String originalDocumentNumber;

	@Column(name="original_document_unique_id")
	private String originalDocumentUniqueId;

	@Column(name="original_issue_airline")
	private String originalIssueAirline;

	@Column(name="original_place_of_issue")
	private String originalPlaceOfIssue;

	@Column(name="outdate_flag")
	private String outdateFlag;

	@Column(name="passenger_dob")
	private String passengerDob;

	@Column(name="passenger_name")
	private String passengerName;

	@Column(name="passenger_type")
	private String passengerType;

	@Column(name="piece_weight_indicator")
	private String pieceWeightIndicator;

	@Column(name="place_of_issue")
	private String placeOfIssue;

	@Column(name="place_of_sale")
	private String placeOfSale;

	private String pnr;

	@Column(name="prime_reissue")
	private String primeReissue;

	@Column(name="pror_src_ind")
	private String prorSrcInd;

	@Column(name="reporting_agent_code")
	private String reportingAgentCode;

	private String rfic;

	@Column(name="roe_used")
	private String roeUsed;

	private String rpsi;

	@Column(name="sale_currency_ind")
	private String saleCurrencyInd;

	@Column(name="sales_process_indicator")
	private String salesProcessIndicator;

	@Column(name="sales_process_month")
	private String salesProcessMonth;

	@Column(name="side_trip")
	private String sideTrip;

	private String status;

	@Column(name="tax_process_indicator")
	private String taxProcessIndicator;

	private String tdam;

	@Column(name="ticket_level_information")
	private String ticketLevelInformation;

	@Column(name="time_of_issue")
	private String timeOfIssue;

	@Column(name="tour_code")
	private String tourCode;

	@Column(name="transaction_code")
	private String transactionCode;

	@Column(name="transaction_type")
	private String transactionType;

	@Column(name="transfer_flag")
	private String transferFlag;

	@Column(name="travel_commencement_date")
	private String travelCommencementDate;

	@Column(name="true_destination")
	private String trueDestination;

	@Column(name="true_origin")
	private String trueOrigin;

	@Column(name="true_pot")
	private String truePot;

	@Column(name="uatp_flag")
	private String uatpFlag;

	@Column(name="utilization_coupon")
	private String utilizationCoupon;

	@Column(name="utilization_doc")
	private String utilizationDoc;

	@Column(name="utilization_type")
	private String utilizationType;

	@Column(name="voucher_reason_code")
	private String voucherReasonCode;

	//bi-directional many-to-one association to StgReportedTaxDetail
	@OneToMany(mappedBy="ticketMainStg", cascade = CascadeType.ALL)
	private List<StgReportedTaxDetail> stgReportedTaxDetails;

	//bi-directional many-to-one association to TicketCommissionStg
	@OneToMany(mappedBy="ticketMainStg", cascade = CascadeType.ALL)
	private List<TicketCommissionStg> ticketCommissionStgs;

	//bi-directional many-to-one association to TicketCouponStg
	@OneToMany(mappedBy="ticketMainStg", cascade = CascadeType.ALL)
	private List<TicketCouponStg> ticketCouponStgs;

	//bi-directional many-to-one association to TicketCpnTaxStg
	@OneToMany(mappedBy="ticketMainStg", cascade = CascadeType.ALL)
	private List<TicketCpnTaxStg> ticketCpnTaxStgs;

	//bi-directional many-to-one association to TicketOrginStg
	@OneToMany(mappedBy="ticketMainStg", cascade = CascadeType.ALL)
	private List<TicketOrginStg> ticketOrginStgs;

	//bi-directional many-to-one association to TicketPaymentDetailsStg
	@OneToMany(mappedBy="ticketMainStg", cascade = CascadeType.ALL)
	private List<TicketPaymentDetailsStg> ticketPaymentDetailsStgs;

	//bi-directional many-to-one association to TicketSalesDataStg
	@OneToMany(mappedBy="ticketMainStg", cascade = CascadeType.ALL)
	private List<TicketSalesDataStg> ticketSalesDataStgs;

	//bi-directional many-to-one association to TicketTaxStg
	@OneToMany(mappedBy="ticketMainStg", cascade = CascadeType.ALL)
	private List<TicketTaxStg> ticketTaxStgs;

	public TicketMainStg() {
	}

	public int getTrnTktId() {
		return this.trnTktId;
	}

	public void setTrnTktId(int trnTktId) {
		this.trnTktId = trnTktId;
	}

	public String getAgentCode() {
		return this.agentCode;
	}

	public void setAgentCode(String agentCode) {
		this.agentCode = agentCode;
	}

	public String getAirlineIssuingAgent() {
		return this.airlineIssuingAgent;
	}

	public void setAirlineIssuingAgent(String airlineIssuingAgent) {
		this.airlineIssuingAgent = airlineIssuingAgent;
	}

	public String getArchiveFlag() {
		return this.archiveFlag;
	}

	public void setArchiveFlag(String archiveFlag) {
		this.archiveFlag = archiveFlag;
	}

	public String getAtbpCurrency() {
		return this.atbpCurrency;
	}

	public void setAtbpCurrency(String atbpCurrency) {
		this.atbpCurrency = atbpCurrency;
	}

	public String getBillingAirline() {
		return this.billingAirline;
	}

	public void setBillingAirline(String billingAirline) {
		this.billingAirline = billingAirline;
	}

	public String getBtItIndicator() {
		return this.btItIndicator;
	}

	public void setBtItIndicator(String btItIndicator) {
		this.btItIndicator = btItIndicator;
	}

	public String getClientId() {
		return this.clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getConjTicketIndicator() {
		return this.conjTicketIndicator;
	}

	public void setConjTicketIndicator(String conjTicketIndicator) {
		this.conjTicketIndicator = conjTicketIndicator;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getCurrencyAdjustment() {
		return this.currencyAdjustment;
	}

	public void setCurrencyAdjustment(String currencyAdjustment) {
		this.currencyAdjustment = currencyAdjustment;
	}

	public String getCurrencyOfSale() {
		return this.currencyOfSale;
	}

	public void setCurrencyOfSale(String currencyOfSale) {
		this.currencyOfSale = currencyOfSale;
	}

	public String getDataSource() {
		return this.dataSource;
	}

	public void setDataSource(String dataSource) {
		this.dataSource = dataSource;
	}

	public String getDateOfIssue() {
		return this.dateOfIssue;
	}

	public void setDateOfIssue(String dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}

	public String getDocClass() {
		return this.docClass;
	}

	public void setDocClass(String docClass) {
		this.docClass = docClass;
	}

	public String getDocType() {
		return this.docType;
	}

	public void setDocType(String docType) {
		this.docType = docType;
	}

	public String getDocumentNumber() {
		return this.documentNumber;
	}

	public void setDocumentNumber(String documentNumber) {
		this.documentNumber = documentNumber;
	}

	public String getDocumentUniqueId() {
		return this.documentUniqueId;
	}

	public void setDocumentUniqueId(String documentUniqueId) {
		this.documentUniqueId = documentUniqueId;
	}

	public String getDomIntIndicator() {
		return this.domIntIndicator;
	}

	public void setDomIntIndicator(String domIntIndicator) {
		this.domIntIndicator = domIntIndicator;
	}

	public String getEmdIndicator() {
		return this.emdIndicator;
	}

	public void setEmdIndicator(String emdIndicator) {
		this.emdIndicator = emdIndicator;
	}

	public String getEndorsements() {
		return this.endorsements;
	}

	public void setEndorsements(String endorsements) {
		this.endorsements = endorsements;
	}

	public String getEnrouteIndicator() {
		return this.enrouteIndicator;
	}

	public void setEnrouteIndicator(String enrouteIndicator) {
		this.enrouteIndicator = enrouteIndicator;
	}

	public String getEquivalentCurrencyOfSale() {
		return this.equivalentCurrencyOfSale;
	}

	public void setEquivalentCurrencyOfSale(String equivalentCurrencyOfSale) {
		this.equivalentCurrencyOfSale = equivalentCurrencyOfSale;
	}

	public String getEquivalentFare() {
		return this.equivalentFare;
	}

	public void setEquivalentFare(String equivalentFare) {
		this.equivalentFare = equivalentFare;
	}

	public String getEticketInd() {
		return this.eticketInd;
	}

	public void setEticketInd(String eticketInd) {
		this.eticketInd = eticketInd;
	}

	public String getExcessWeight() {
		return this.excessWeight;
	}

	public void setExcessWeight(String excessWeight) {
		this.excessWeight = excessWeight;
	}

	public String getExchangeRateMonth() {
		return this.exchangeRateMonth;
	}

	public void setExchangeRateMonth(String exchangeRateMonth) {
		this.exchangeRateMonth = exchangeRateMonth;
	}

	public String getFareCompCurrency() {
		return this.fareCompCurrency;
	}

	public void setFareCompCurrency(String fareCompCurrency) {
		this.fareCompCurrency = fareCompCurrency;
	}

	public String getFca() {
		return this.fca;
	}

	public void setFca(String fca) {
		this.fca = fca;
	}

	public String getFdrUsed() {
		return this.fdrUsed;
	}

	public void setFdrUsed(String fdrUsed) {
		this.fdrUsed = fdrUsed;
	}

	public String getFileId() {
		return this.fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	public String getFileSource() {
		return this.fileSource;
	}

	public void setFileSource(String fileSource) {
		this.fileSource = fileSource;
	}

	public String getFreeAwardTicketIndicator() {
		return this.freeAwardTicketIndicator;
	}

	public void setFreeAwardTicketIndicator(String freeAwardTicketIndicator) {
		this.freeAwardTicketIndicator = freeAwardTicketIndicator;
	}

	public String getGrossFare() {
		return this.grossFare;
	}

	public void setGrossFare(String grossFare) {
		this.grossFare = grossFare;
	}

	public String getIgnoreFca() {
		return this.ignoreFca;
	}

	public void setIgnoreFca(String ignoreFca) {
		this.ignoreFca = ignoreFca;
	}

	public String getInvolIndicator() {
		return this.involIndicator;
	}

	public void setInvolIndicator(String involIndicator) {
		this.involIndicator = involIndicator;
	}

	public String getIsValidated() {
		return this.isValidated;
	}

	public void setIsValidated(String isValidated) {
		this.isValidated = isValidated;
	}

	public String getIsi() {
		return this.isi;
	}

	public void setIsi(String isi) {
		this.isi = isi;
	}

	public String getIssueAirline() {
		return this.issueAirline;
	}

	public void setIssueAirline(String issueAirline) {
		this.issueAirline = issueAirline;
	}

	public String getJourneyTournaroundAirport() {
		return this.journeyTournaroundAirport;
	}

	public void setJourneyTournaroundAirport(String journeyTournaroundAirport) {
		this.journeyTournaroundAirport = journeyTournaroundAirport;
	}

	public String getJourneyType() {
		return this.journeyType;
	}

	public void setJourneyType(String journeyType) {
		this.journeyType = journeyType;
	}

	public String getLastUpdatedBy() {
		return this.lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getLastUpdatedDate() {
		return this.lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getMainDocument() {
		return this.mainDocument;
	}

	public void setMainDocument(String mainDocument) {
		this.mainDocument = mainDocument;
	}

	public String getMigratedTicket() {
		return this.migratedTicket;
	}

	public void setMigratedTicket(String migratedTicket) {
		this.migratedTicket = migratedTicket;
	}

	public BigDecimal getMprPercentage() {
		return this.mprPercentage;
	}

	public void setMprPercentage(BigDecimal mprPercentage) {
		this.mprPercentage = mprPercentage;
	}

	public String getNetFareAmount() {
		return this.netFareAmount;
	}

	public void setNetFareAmount(String netFareAmount) {
		this.netFareAmount = netFareAmount;
	}

	public String getNetFareCurrency() {
		return this.netFareCurrency;
	}

	public void setNetFareCurrency(String netFareCurrency) {
		this.netFareCurrency = netFareCurrency;
	}

	public String getNonRevenueFlag() {
		return this.nonRevenueFlag;
	}

	public void setNonRevenueFlag(String nonRevenueFlag) {
		this.nonRevenueFlag = nonRevenueFlag;
	}

	public String getNrid() {
		return this.nrid;
	}

	public void setNrid(String nrid) {
		this.nrid = nrid;
	}

	public String getOnlineDestination() {
		return this.onlineDestination;
	}

	public void setOnlineDestination(String onlineDestination) {
		this.onlineDestination = onlineDestination;
	}

	public String getOnlineInterlineOffline() {
		return this.onlineInterlineOffline;
	}

	public void setOnlineInterlineOffline(String onlineInterlineOffline) {
		this.onlineInterlineOffline = onlineInterlineOffline;
	}

	public String getOnlineOrigin() {
		return this.onlineOrigin;
	}

	public void setOnlineOrigin(String onlineOrigin) {
		this.onlineOrigin = onlineOrigin;
	}

	public String getOnlinePot() {
		return this.onlinePot;
	}

	public void setOnlinePot(String onlinePot) {
		this.onlinePot = onlinePot;
	}

	public String getOrderId() {
		return this.orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getOriginalAgentCode() {
		return this.originalAgentCode;
	}

	public void setOriginalAgentCode(String originalAgentCode) {
		this.originalAgentCode = originalAgentCode;
	}

	public String getOriginalDateOfIssue() {
		return this.originalDateOfIssue;
	}

	public void setOriginalDateOfIssue(String originalDateOfIssue) {
		this.originalDateOfIssue = originalDateOfIssue;
	}

	public String getOriginalDocClass() {
		return this.originalDocClass;
	}

	public void setOriginalDocClass(String originalDocClass) {
		this.originalDocClass = originalDocClass;
	}

	public String getOriginalDocumentNumber() {
		return this.originalDocumentNumber;
	}

	public void setOriginalDocumentNumber(String originalDocumentNumber) {
		this.originalDocumentNumber = originalDocumentNumber;
	}

	public String getOriginalDocumentUniqueId() {
		return this.originalDocumentUniqueId;
	}

	public void setOriginalDocumentUniqueId(String originalDocumentUniqueId) {
		this.originalDocumentUniqueId = originalDocumentUniqueId;
	}

	public String getOriginalIssueAirline() {
		return this.originalIssueAirline;
	}

	public void setOriginalIssueAirline(String originalIssueAirline) {
		this.originalIssueAirline = originalIssueAirline;
	}

	public String getOriginalPlaceOfIssue() {
		return this.originalPlaceOfIssue;
	}

	public void setOriginalPlaceOfIssue(String originalPlaceOfIssue) {
		this.originalPlaceOfIssue = originalPlaceOfIssue;
	}

	public String getOutdateFlag() {
		return this.outdateFlag;
	}

	public void setOutdateFlag(String outdateFlag) {
		this.outdateFlag = outdateFlag;
	}

	public String getPassengerDob() {
		return this.passengerDob;
	}

	public void setPassengerDob(String passengerDob) {
		this.passengerDob = passengerDob;
	}

	public String getPassengerName() {
		return this.passengerName;
	}

	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}

	public String getPassengerType() {
		return this.passengerType;
	}

	public void setPassengerType(String passengerType) {
		this.passengerType = passengerType;
	}

	public String getPieceWeightIndicator() {
		return this.pieceWeightIndicator;
	}

	public void setPieceWeightIndicator(String pieceWeightIndicator) {
		this.pieceWeightIndicator = pieceWeightIndicator;
	}

	public String getPlaceOfIssue() {
		return this.placeOfIssue;
	}

	public void setPlaceOfIssue(String placeOfIssue) {
		this.placeOfIssue = placeOfIssue;
	}

	public String getPlaceOfSale() {
		return this.placeOfSale;
	}

	public void setPlaceOfSale(String placeOfSale) {
		this.placeOfSale = placeOfSale;
	}

	public String getPnr() {
		return this.pnr;
	}

	public void setPnr(String pnr) {
		this.pnr = pnr;
	}

	public String getPrimeReissue() {
		return this.primeReissue;
	}

	public void setPrimeReissue(String primeReissue) {
		this.primeReissue = primeReissue;
	}

	public String getProrSrcInd() {
		return this.prorSrcInd;
	}

	public void setProrSrcInd(String prorSrcInd) {
		this.prorSrcInd = prorSrcInd;
	}

	public String getReportingAgentCode() {
		return this.reportingAgentCode;
	}

	public void setReportingAgentCode(String reportingAgentCode) {
		this.reportingAgentCode = reportingAgentCode;
	}

	public String getRfic() {
		return this.rfic;
	}

	public void setRfic(String rfic) {
		this.rfic = rfic;
	}

	public String getRoeUsed() {
		return this.roeUsed;
	}

	public void setRoeUsed(String roeUsed) {
		this.roeUsed = roeUsed;
	}

	public String getRpsi() {
		return this.rpsi;
	}

	public void setRpsi(String rpsi) {
		this.rpsi = rpsi;
	}

	public String getSaleCurrencyInd() {
		return this.saleCurrencyInd;
	}

	public void setSaleCurrencyInd(String saleCurrencyInd) {
		this.saleCurrencyInd = saleCurrencyInd;
	}

	public String getSalesProcessIndicator() {
		return this.salesProcessIndicator;
	}

	public void setSalesProcessIndicator(String salesProcessIndicator) {
		this.salesProcessIndicator = salesProcessIndicator;
	}

	public String getSalesProcessMonth() {
		return this.salesProcessMonth;
	}

	public void setSalesProcessMonth(String salesProcessMonth) {
		this.salesProcessMonth = salesProcessMonth;
	}

	public String getSideTrip() {
		return this.sideTrip;
	}

	public void setSideTrip(String sideTrip) {
		this.sideTrip = sideTrip;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTaxProcessIndicator() {
		return this.taxProcessIndicator;
	}

	public void setTaxProcessIndicator(String taxProcessIndicator) {
		this.taxProcessIndicator = taxProcessIndicator;
	}

	public String getTdam() {
		return this.tdam;
	}

	public void setTdam(String tdam) {
		this.tdam = tdam;
	}

	public String getTicketLevelInformation() {
		return this.ticketLevelInformation;
	}

	public void setTicketLevelInformation(String ticketLevelInformation) {
		this.ticketLevelInformation = ticketLevelInformation;
	}

	public String getTimeOfIssue() {
		return this.timeOfIssue;
	}

	public void setTimeOfIssue(String timeOfIssue) {
		this.timeOfIssue = timeOfIssue;
	}

	public String getTourCode() {
		return this.tourCode;
	}

	public void setTourCode(String tourCode) {
		this.tourCode = tourCode;
	}

	public String getTransactionCode() {
		return this.transactionCode;
	}

	public void setTransactionCode(String transactionCode) {
		this.transactionCode = transactionCode;
	}

	public String getTransactionType() {
		return this.transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getTransferFlag() {
		return this.transferFlag;
	}

	public void setTransferFlag(String transferFlag) {
		this.transferFlag = transferFlag;
	}

	public String getTravelCommencementDate() {
		return this.travelCommencementDate;
	}

	public void setTravelCommencementDate(String travelCommencementDate) {
		this.travelCommencementDate = travelCommencementDate;
	}

	public String getTrueDestination() {
		return this.trueDestination;
	}

	public void setTrueDestination(String trueDestination) {
		this.trueDestination = trueDestination;
	}

	public String getTrueOrigin() {
		return this.trueOrigin;
	}

	public void setTrueOrigin(String trueOrigin) {
		this.trueOrigin = trueOrigin;
	}

	public String getTruePot() {
		return this.truePot;
	}

	public void setTruePot(String truePot) {
		this.truePot = truePot;
	}

	public String getUatpFlag() {
		return this.uatpFlag;
	}

	public void setUatpFlag(String uatpFlag) {
		this.uatpFlag = uatpFlag;
	}

	public String getUtilizationCoupon() {
		return this.utilizationCoupon;
	}

	public void setUtilizationCoupon(String utilizationCoupon) {
		this.utilizationCoupon = utilizationCoupon;
	}

	public String getUtilizationDoc() {
		return this.utilizationDoc;
	}

	public void setUtilizationDoc(String utilizationDoc) {
		this.utilizationDoc = utilizationDoc;
	}

	public String getUtilizationType() {
		return this.utilizationType;
	}

	public void setUtilizationType(String utilizationType) {
		this.utilizationType = utilizationType;
	}

	public String getVoucherReasonCode() {
		return this.voucherReasonCode;
	}

	public void setVoucherReasonCode(String voucherReasonCode) {
		this.voucherReasonCode = voucherReasonCode;
	}

	public List<StgReportedTaxDetail> getStgReportedTaxDetails() {
		return this.stgReportedTaxDetails;
	}

	public void setStgReportedTaxDetails(List<StgReportedTaxDetail> stgReportedTaxDetails) {
		this.stgReportedTaxDetails = stgReportedTaxDetails;
	}

	public StgReportedTaxDetail addStgReportedTaxDetail(StgReportedTaxDetail stgReportedTaxDetail) {
		List<StgReportedTaxDetail> couponList2 = getStgReportedTaxDetails();
		if(couponList2 == null) this.stgReportedTaxDetails = new ArrayList<StgReportedTaxDetail>();
		getStgReportedTaxDetails().add(stgReportedTaxDetail);
		return stgReportedTaxDetail;
	}
	

	public StgReportedTaxDetail removeStgReportedTaxDetail(StgReportedTaxDetail stgReportedTaxDetail) {
		getStgReportedTaxDetails().remove(stgReportedTaxDetail);
		stgReportedTaxDetail.setTicketMainStg(null);

		return stgReportedTaxDetail;
	}

	public List<TicketCommissionStg> getTicketCommissionStgs() {
		return this.ticketCommissionStgs;
	}

	public void setTicketCommissionStgs(List<TicketCommissionStg> ticketCommissionStgs) {
		this.ticketCommissionStgs = ticketCommissionStgs;
	}

	public TicketCommissionStg addTicketCommissionStg(TicketCommissionStg ticketCommissionStg) {
		List<TicketCommissionStg> couponList2 = getTicketCommissionStgs();
		if(couponList2 == null) this.ticketCommissionStgs = new ArrayList<TicketCommissionStg>();
		getTicketCommissionStgs().add(ticketCommissionStg);
		return ticketCommissionStg;
	}

	public TicketCommissionStg removeTicketCommissionStg(TicketCommissionStg ticketCommissionStg) {
		getTicketCommissionStgs().remove(ticketCommissionStg);
		ticketCommissionStg.setTicketMainStg(null);

		return ticketCommissionStg;
	}

	public List<TicketCouponStg> getTicketCouponStgs() {
		return this.ticketCouponStgs;
	}

	public void setTicketCouponStgs(List<TicketCouponStg> ticketCouponStgs) {
		this.ticketCouponStgs = ticketCouponStgs;
	}

	public TicketCouponStg addTicketCouponStg(TicketCouponStg ticketCouponStg) {
		List<TicketCouponStg> couponList2 = getTicketCouponStgs();
		if(couponList2 == null) this.ticketCouponStgs = new ArrayList<TicketCouponStg>();
		getTicketCouponStgs().add(ticketCouponStg);
		return ticketCouponStg;
	}

	public TicketCouponStg removeTicketCouponStg(TicketCouponStg ticketCouponStg) {
		getTicketCouponStgs().remove(ticketCouponStg);
		ticketCouponStg.setTicketMainStg(null);

		return ticketCouponStg;
	}

	public List<TicketCpnTaxStg> getTicketCpnTaxStgs() {
		return this.ticketCpnTaxStgs;
	}

	public void setTicketCpnTaxStgs(List<TicketCpnTaxStg> ticketCpnTaxStgs) {
		this.ticketCpnTaxStgs = ticketCpnTaxStgs;
	}

	public TicketCpnTaxStg addTicketCpnTaxStg(TicketCpnTaxStg ticketCpnTaxStg) {
		List<TicketCpnTaxStg> couponList2 = getTicketCpnTaxStgs();
		if(couponList2 == null) this.ticketCpnTaxStgs = new ArrayList<TicketCpnTaxStg>();
		getTicketCpnTaxStgs().add(ticketCpnTaxStg);
		return ticketCpnTaxStg;
	}

	public TicketCpnTaxStg removeTicketCpnTaxStg(TicketCpnTaxStg ticketCpnTaxStg) {
		getTicketCpnTaxStgs().remove(ticketCpnTaxStg);
		ticketCpnTaxStg.setTicketMainStg(null);

		return ticketCpnTaxStg;
	}

	public List<TicketOrginStg> getTicketOrginStgs() {
		return this.ticketOrginStgs;
	}

	public void setTicketOrginStgs(List<TicketOrginStg> ticketOrginStgs) {
		this.ticketOrginStgs = ticketOrginStgs;
	}

	public TicketOrginStg addTicketOrginStg(TicketOrginStg ticketOrginStg) {
		List<TicketOrginStg> couponList2 = getTicketOrginStgs();
		if(couponList2 == null) this.ticketOrginStgs = new ArrayList<TicketOrginStg>();
		getTicketOrginStgs().add(ticketOrginStg);
		return ticketOrginStg;
	}

	public TicketOrginStg removeTicketOrginStg(TicketOrginStg ticketOrginStg) {
		getTicketOrginStgs().remove(ticketOrginStg);
		ticketOrginStg.setTicketMainStg(null);

		return ticketOrginStg;
	}

	public List<TicketPaymentDetailsStg> getTicketPaymentDetailsStgs() {
		return this.ticketPaymentDetailsStgs;
	}

	public void setTicketPaymentDetailsStgs(List<TicketPaymentDetailsStg> ticketPaymentDetailsStgs) {
		this.ticketPaymentDetailsStgs = ticketPaymentDetailsStgs;
	}

	public TicketPaymentDetailsStg addTicketPaymentDetailsStg(TicketPaymentDetailsStg ticketPaymentDetailsStg) {
		List<TicketPaymentDetailsStg> couponList2 = getTicketPaymentDetailsStgs();
		if(couponList2 == null) this.ticketPaymentDetailsStgs = new ArrayList<TicketPaymentDetailsStg>();
		getTicketPaymentDetailsStgs().add(ticketPaymentDetailsStg);
		return ticketPaymentDetailsStg;
	}

	public TicketPaymentDetailsStg removeTicketPaymentDetailsStg(TicketPaymentDetailsStg ticketPaymentDetailsStg) {
		getTicketPaymentDetailsStgs().remove(ticketPaymentDetailsStg);
		ticketPaymentDetailsStg.setTicketMainStg(null);

		return ticketPaymentDetailsStg;
	}

	public List<TicketSalesDataStg> getTicketSalesDataStgs() {
		return this.ticketSalesDataStgs;
	}

	public void setTicketSalesDataStgs(List<TicketSalesDataStg> ticketSalesDataStgs) {
		this.ticketSalesDataStgs = ticketSalesDataStgs;
	}

	public TicketSalesDataStg addTicketSalesDataStg(TicketSalesDataStg ticketSalesDataStg) {
		List<TicketSalesDataStg> couponList2 = getTicketSalesDataStgs();
		if(couponList2 == null) this.ticketSalesDataStgs = new ArrayList<TicketSalesDataStg>();
		getTicketSalesDataStgs().add(ticketSalesDataStg);
		return ticketSalesDataStg;
	}

	public TicketSalesDataStg removeTicketSalesDataStg(TicketSalesDataStg ticketSalesDataStg) {
		getTicketSalesDataStgs().remove(ticketSalesDataStg);
		ticketSalesDataStg.setTicketMainStg(null);

		return ticketSalesDataStg;
	}

	public List<TicketTaxStg> getTicketTaxStgs() {
		return this.ticketTaxStgs;
	}

	public void setTicketTaxStgs(List<TicketTaxStg> ticketTaxStgs) {
		this.ticketTaxStgs = ticketTaxStgs;
	}

	public TicketTaxStg addTicketTaxStg(TicketTaxStg ticketTaxStg) {
		List<TicketTaxStg> couponList2 = getTicketTaxStgs();
		if(couponList2 == null) this.ticketTaxStgs = new ArrayList<TicketTaxStg>();
		getTicketTaxStgs().add(ticketTaxStg);
		return ticketTaxStg;
	}

	public TicketTaxStg removeTicketTaxStg(TicketTaxStg ticketTaxStg) {
		getTicketTaxStgs().remove(ticketTaxStg);
		ticketTaxStg.setTicketMainStg(null);

		return ticketTaxStg;
	}




	@SuppressWarnings("unchecked")
	public ItemWriter<List<TicketMainStg>> writer() {
		return (ItemWriter<List<TicketMainStg>>) new TicketMainStgWriter();
	}
}