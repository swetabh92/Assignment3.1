import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CoreDataModule } from 'src/app/core-data/core-data.module';
import { SharedModule } from '../../..//shared/shared.module';
import { OutwardBillingProcessRoutingModule } from './outward-billing-process-routing.module';
import { OutwardDashboardSearchComponent } from './outward-dashboard-search/outward-dashboard-search.component';

@NgModule({
  imports: [
    CommonModule,
    OutwardBillingProcessRoutingModule,
    CoreDataModule,
    SharedModule
  ],
  declarations: [OutwardDashboardSearchComponent]
})
export class OutwardBillingProcessModule { }
