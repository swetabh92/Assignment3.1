package com.sgl.smartpra.allocation.master.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.NullValueCheckStrategy;
import org.mapstruct.NullValuePropertyMappingStrategy;

import com.sgl.smartpra.allocation.master.app.entity.AllocationMasterEntity;
import com.sgl.smartpra.allocation.master.model.AllocationMasterSearchModel;

@Mapper(componentModel = "spring", nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface OutwardAllocationMapper extends BaseMapper<AllocationMasterSearchModel, AllocationMasterEntity>  {

	@Mapping(source = "billingMonth", target = "allocationKey1")
	@Mapping(source = "billingCurrency", target = "allocationKey2")
	@Mapping(source = "sourceCode", target = "allocationKey3")
	@Mapping(source = "listingCurrency", target = "allocationKey4")
	@Mapping(source = "zones", target = "allocationKey5")
	@Mapping(source = "billedCarrier", target = "allocationKey6")
	@Mapping(source = "allianceName", target = "allocationKey7")
	AllocationMasterEntity mapToEntity(AllocationMasterSearchModel allocationMasterSearchModel);

}
