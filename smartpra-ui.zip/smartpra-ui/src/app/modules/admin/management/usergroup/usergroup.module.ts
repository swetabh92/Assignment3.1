import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UsergroupRoutingModule } from './usergroup-routing.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { UsergroupComponent } from './usergroup.component';
import { CoreDataModule } from 'src/app/core-data/core-data.module';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    CoreDataModule,
    UsergroupRoutingModule
  ],
  declarations: [
    UsergroupComponent
  ]
})
export class UsergroupModule { }
