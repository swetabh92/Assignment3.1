package com.sgl.smartpra.batch.mmr.app.layout;

import java.util.ArrayList;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;
import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;

public class MMRLayout extends FixedLengthRecordLayout {

	public MMRLayout() {
		
		fixedLengthFieldLayoutList = new ArrayList<FixedLengthFieldLayout>();
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("currencyFromCode", 40, 42));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("eurExchangeRate", 43, 54));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("gbpExchangeRate", 55, 66));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usdExchangeRate", 67, null));	
	}
}
