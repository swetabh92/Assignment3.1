import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AppforgetpasswordComponent } from './appforgetpassword.component';

describe('AppforgetpasswordComponent', () => {
  let component: AppforgetpasswordComponent;
  let fixture: ComponentFixture<AppforgetpasswordComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppforgetpasswordComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppforgetpasswordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
