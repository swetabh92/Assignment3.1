import {AfterViewInit, Component, OnInit} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';

import { GeneralService } from '../../../commons/services/general.service';
import { AuthenticationService } from '../auth-gaurd-service/_services/authentication.service';
import swal from 'sweetalert2';
declare var $;
declare var jQuery: any;
declare var iCheck;

@Component({
  selector: 'app-appresetpassword',
  templateUrl: './appresetpassword.component.html',
  styleUrls: ['./appresetpassword.component.css']
})
export class AppresetpasswordinitComponent implements  OnInit,AfterViewInit{
  resetPasswordInit: FormGroup;
  submitted = false;
  returnUrl: string;
  error = '';
  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private authenticationService: AuthenticationService,
    private Gservice: GeneralService
  ) { }

  ngAfterViewInit() {
    this.Gservice.LoadFormSettingJs();
  }
  ngOnInit() {
    this.resetPasswordInit = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]]
    });

  }
  get f() { return this.resetPasswordInit.controls; }
  onSubmit() {
    this.submitted = true;
    // stop here if form is invalid
    // console.log(this.resetPasswordInit.value);
    if (this.resetPasswordInit.invalid) {
      return;
    }
    this.authenticationService.resetPasswordInit(this.resetPasswordInit.value)
      .pipe(first())
      .subscribe(
        result => {
          // Handle result
          swal(
            'success',
            'A reset password link is sent to your email address. Please use the link to reset your password and login to the application',
            'success'
          );
        },
        error => {
          swal(
            'error',
            'Email entered does not exist in the system',
            'error'
          );
        },
        () => {
          // 'onCompleted' callback.
          // No errors, route to new page here
        });
  }
}
