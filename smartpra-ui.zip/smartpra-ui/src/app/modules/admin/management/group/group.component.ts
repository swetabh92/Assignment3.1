import { Component, OnInit, Input, Output, EventEmitter, OnDestroy, ElementRef, ViewChild, Renderer2 } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { GeneralService } from '../../../../commons/services/general.service';
import { GroupService } from '../../services/group.service';
import { UserprofileService } from '../../services/userprofile.service';
import { Group } from '../../models/group';
import { Subject } from 'rxjs';
import swal from 'sweetalert2';
import { TeamService } from '../../services/team.service';
import * as _ from 'underscore';

@Component({
  selector: 'app-group',
  templateUrl: './group.component.html',
  styleUrls: ['./group.component.css']
})
export class GroupComponent implements OnInit, OnDestroy {
  @ViewChild('closeModalAdd') closeModalAdd: ElementRef;
  @ViewChild('closeModalEdit') closeModalEdit: ElementRef;
  dtOptions: any = {};
  // We use this trigger because fetching the list of persons can be quite long,
  // thus we ensure the data is fetched before rendering
  dtTrigger: Subject<any> = new Subject<any>();
  public renderDT = false;
  createdBy = 'admin';
  lastUpdatedBy = 'admin';
  defaultisActive = true;
  collapse_search_form = true;
  box_search_status = true;
  addNewForm: FormGroup;
  addNewsubmitted = false;
  editNewForm: FormGroup;
  editsubmitted = false;
  searchForm: FormGroup;
  searchsubmitted = false;
  searchresult = false;
  searchstring = '';
  checkdata: any;
  groupsList$: any;
  groupdetail: any;
  previewUrl = '';
  isactiveArray: any;
  managerArray: any;
  managerSelected: any;
  moduleArray: any;
  moduleSelected: any;
  availableTeams = [];
  allTeams = [];
  assignedTeams = [];
  tempAvailableTeams = [];
  tempAssignedTeams = [];
  currentTeam: any;
  constructor(private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder,
    private generalService: GeneralService,
    private userservice: UserprofileService,
    private groupservice: GroupService,
    private teamService: TeamService,
    private render: Renderer2,
  ) { }

  ngOnInit() {
    this.GetAllmanager();
    this.GetAllmodule();
    this.GetAllgroups();
    this.getAllTeams();
    this.isactiveArray =  [{id: 'true', name: 'active'}, {id: 'false', name: 'inactive'}];
    this.dtOptions = {
      searching: false, // to hide the search field in the data table top
      pagingType: 'full_numbers',
      lengthMenu: [[5, 10, 25, 50, -1], [5, 10, 25, 50, 'All']], // used to display records size( no of rows)
      language: {
        lengthMenu: 'Page size _MENU_',
        paginate: {
          next: '<i style="color:#0079c1" class="fa fa-angle-right fa-lg"></i>',
          previous: '<i style="color:#0079c1" class="fa fa-angle-left fa-lg"></i>',
          first: '<i style="color:#0079c1" class="fa fa-step-backward"></i>',
          last: '<i style="color:#0079c1" class="fa fa-step-forward"></i>'
        }
      },
      dom: 'tflrp<"datatableclass"i>',
      // used for fixed columns
      // scrollX: true,
      // scrollY: 'auto',
      // scrollCollapse: true,
      // fixedColumns:   {
      //   leftColumns: 2,
      //   rightColumns: 2
      // },
      // end of fixed columns
      // disable search and order
      // aoColumnDefs: [{ bSortable: false, aTargets: [0, 4, 5] }],
      columnDefs: [
        {
          'searchable': false,
          'orderable': false,
          'targets': [-1, -2]
        }
      ],
      // end of disable search and order
    };
    this.addNewForm = this.formBuilder.group({
      createdBy: [''] , // Validators.required],
      groupManagerId: [''] , // Validators.required],
      groupName: [''] , // Validators.required],
      moduleId: [''] , // Validators.required],
      isActive: ['true'] , // Validators.required],
    });
    this.editNewForm = this.formBuilder.group({
      lastUpdatedBy: [''],
      groupManagerId: [''] , // Validators.required],
      groupName: [''] , // Validators.required],
      moduleId: [''] , // Validators.required],
      isActive: ['true'] , // Validators.required],
    });
    this.searchForm = this.formBuilder.group({
      active: ['', ],
    });
  }
  getAllTeams() {
    this.teamService.getTeamAll().subscribe((res: any) => {
      this.availableTeams = res;
      this.allTeams = res;
    });
  }
  GetAllmanager() {
    this.userservice.UserprofileByUserRoleName('Manager').subscribe((res: any[]) => {
      this.managerArray = res;
    });
  }
  GetAllmodule() {
    const clientId = 'QR';
    const tableName = 'General';
    const columnName = 'Module';
    this.groupservice.getAllModules(clientId,tableName,columnName).subscribe((res : any) =>{
      this.moduleArray = res;
    });
  }
  showSearchBox(e) {
    this.box_search_status = !this.box_search_status;
    this.collapse_search_form = true;
  }
  collapseSearchform(event) {
    const targetclass = event.target.className;
    // console.log(targetclass);
    // this.collapse_search_form = !this.collapse_search_form;
    if (targetclass === 'btn btn-box-tool fa fa-angle-up') {
      this.collapse_search_form = !this.collapse_search_form;
      event.target.className = 'btn btn-box-tool fa fa-angle-down';
    } else if (targetclass === 'btn btn-box-tool fa fa-angle-down') {
      this.collapse_search_form = !this.collapse_search_form;
      event.target.className = 'btn btn-box-tool fa fa-angle-up';
    }
  }
  onResetSearch() {
    this.searchForm.reset();
    this.renderDT = false;
    this.GetAllgroups();
  }
  onSearch() {

  }
  GetAllgroups() {
    this.renderDT = false;
    this.groupservice.getGroupAll().subscribe((res: any[]) => {
      this.groupsList$ = res;
      setTimeout(() => {
        this.renderDT = true;
      }, 100);
    });
  }
  get f() { return this.addNewForm.controls; }

  onResetAdd() {
    this.addNewForm.reset();
    this.addNewForm.patchValue({isActive: true});
  }


  addNewgroup(): void {
    this.addNewsubmitted = true;
    // stop here if form is invalid
    if (this.addNewForm.invalid) {
      return;
    } else {
      this.groupservice.addGroup(this.addNewForm.value).subscribe(
        groupservice => {
          // console.log(groupservice);
          if (!!groupservice && groupservice.groupId) {
            this.GetAllgroups();
            this.closeModalAdd.nativeElement.click();
            swal(
              'Success',
              'New Records Addeded',
              'success'
            );
            this.onResetAdd();
          }
        });
    }
  }
  get u() { return this.editNewForm.controls; }
  showEditvalues(getId) {
    this.groupservice.GroupByGroupId(getId).subscribe(
      groupservice => {
        if (!!groupservice && groupservice.groupId) {
          this.groupdetail = groupservice;
          this.managerSelected = groupservice.groupManagerId;
          this.moduleSelected = groupservice.moduleId;
          this.editNewForm.patchValue({  moduleId: groupservice.moduleId,})
        } else {
          swal(
            'Error',
            'Error fetching record',
            'error'
          );
        }
      });
  }
  onResetEdit() {
  }
  editNewgroup() {
    this.editsubmitted = true;
    // console.log(this.editNewForm);
    // stop here if form is invalid
    if (this.editNewForm.invalid) {
      swal(
        'Error',
        'sorry error in the form',
        'error'
      );
      return;
    } else {
      // console.log(this.editNewForm.value); return;
      this.groupservice.updateGroup(this.editNewForm.value).subscribe(
        groupservice => {
          if (!!groupservice && groupservice.groupId) {
            this.GetAllgroups();
            this.closeModalEdit.nativeElement.click();
            swal(
              'Updated!',
              'Group has been Updated.',
              'success'
            );
          }
        });
    }
  }

  onSelectTeam(team) {
    this.currentTeam = team;
    this.teamService.getTeamByGroupId(team.groupId).subscribe((res: any) => {
      this.assignedTeams = res;
      this.filterCommonTeam();
    });
  }

  filterCommonTeam() {
    const assignTeam = this.assignedTeams;
    let availAbleTeamObj = this.availableTeams;
    _.each(assignTeam, function (assignTeamObj) {
      availAbleTeamObj = _.without(availAbleTeamObj, _.findWhere(availAbleTeamObj, { teamId: assignTeamObj.teamId}));
    });

    this.availableTeams = availAbleTeamObj;
  }

  onSelectAvailableTeams(event, data) {
    // AV -> Available Roles
    const className = event.currentTarget.className;

    if (className.includes('active')) {
      event.currentTarget.classList.remove('active');
      this.filterTeasmByType(data, 'AV');
    } else {
      this.render.addClass(event.target, 'active');
      this.tempAvailableTeams.push(data);
    }
  }
  onSelectAssignedTeams(event, data) {
    const className = event.currentTarget.className;

    // AS -> Assigned Roles
    if (className.includes('active')) {
      event.currentTarget.classList.remove('active');
      this.filterTeasmByType(data, 'AS');
    } else {
      this.render.addClass(event.target, 'active');
      this.tempAssignedTeams.push(data);
    }
  }
  filterTeasmByType(data, arrayType) {
    if (arrayType === 'AS') {
      const index = this.tempAssignedTeams.indexOf(data);
      if (index > -1) {
        this.tempAssignedTeams.splice(index, 1);
      }
    } else {
      const index = this.tempAvailableTeams.indexOf(data);
      if (index > -1) {
        this.tempAvailableTeams.splice(index, 1);
      }
    }
  }

  updateAssignedTeam() {
    for (let i = 0; i < this.tempAssignedTeams.length; i++) {
      this.availableTeams.push(this.tempAssignedTeams[i]);
    }

    this.assignedTeams = this.assignedTeams.filter(val => !this.tempAssignedTeams.includes(val));
    this.tempAssignedTeams = [];
  }

  updateAvailableTeams() {
    for (let i = 0; i < this.tempAvailableTeams.length; i++) {
      this.assignedTeams.push(this.tempAvailableTeams[i]);
    }

    this.availableTeams = this.availableTeams.filter(val => !this.tempAvailableTeams.includes(val));
    this.tempAvailableTeams = [];
  }

  updateTeamRequest() {

     // TODO Need api to update role

    // this.assignedTeams = _.each(this.assignedTeams, function(data) {data.masRoleId = data.roleId; });
    // this.currentTeam.masUserRoles = this.assignedTeams;
    // this.groupservice.updateGroup("group").subscribe(
    //   groupservice => {
    //     if (!!groupservice && groupservice.groupId) {
    //       this.GetAllgroups();
    //       swal(
    //         'Activated!',
    //         'group has been activated.',
    //         'success'
    //       );
    //     }
    //   });
  }

  // when modal dismissed arrays are resetted
  onCloseTeamModal() {
    this.availableTeams = [];
    this.assignedTeams = [];
    this.availableTeams = this.allTeams;
  }


  removeafterDeactivate(group: Group): void {
    this.groupsList$ = this.groupsList$.filter(h => h !== group);
  }
  deleteRole(groupId) {
    this.groupservice.deleteGroup(groupId).subscribe(
      data => {
        swal(
          'Deleted!',
          'Group has been deleted.',
          'success'
        );
      }, error => {
        swal(
          'Error!',
          'Could not delete',
          'error'
        );
      });
  }
  changeStatusgroup(group, e, Id) {
    if (e.target.checked) {
      swal({
        type: 'warning',
        title: 'Are you sure to activate this group?',
        text: 'You will not be able to recover the data of group',
        showCancelButton: true,
        confirmButtonColor: '#049F0C',
        cancelButtonColor: '#ff0000',
        confirmButtonText: 'Yes, activate it!',
        cancelButtonText: 'No, keep it deactivated',
        closeOnClickOutside: false,
        closeOnEsc: false,
        allowOutsideClick: false,
      } as any).then((result) => {
        if (result.value) {
          group.isActive = 'true';
          this.groupservice.updateGroup(group).subscribe(
            groupservice => {
              if (!!groupservice && groupservice.groupId) {
                this.GetAllgroups();
                swal(
                  'Activated!',
                  'group has been activated.',
                  'success'
                );
              }
            });
        } else if (
          // Read more about handling dismissals
          result.dismiss === swal.DismissReason.cancel
        ) {
          e.target.checked = false;
          swal(
            'Cancelled',
            'group status unchanged',
            'error'
          );
        }
      });
    } else {
      swal({
        type: 'warning',
        title: 'Are you sure to deactivate this group?',
        text: 'You will not be able to recover the data of group',
        showCancelButton: true,
        confirmButtonColor: '#049F0C',
        cancelButtonColor: '#ff0000',
        confirmButtonText: 'Yes, deactivate it!',
        cancelButtonText: 'No, keep it as active',
        closeOnClickOutside: false,
        closeOnEsc: false,
        allowOutsideClick: false,
      } as any).then((result) => {
        if (result.value) {
          group.isActive = 'false';
          this.groupservice.updateGroup(group).subscribe(
            groupservice => {
              if (!!groupservice && groupservice.groupId) {
                this.GetAllgroups();
                swal(
                  'Deactivated!',
                  'group has been deactivated.',
                  'success'
                );
              }
            });
          // this.removeafterDeactivate(group);
        } else if (
          // Read more about handling dismissals
          result.dismiss === swal.DismissReason.cancel
        ) {
          e.target.checked = true;
          swal(
            'Cancelled',
            'group status unchanged',
            'error'
          );
        }
      });
    }
  }

  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }

}

