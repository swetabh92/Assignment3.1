    export class Usermodule {
    isActive: true;
    masModuleId: number;
    masUserModuleId: number;
    masUsersId: number;
        constructor() { }
      }
