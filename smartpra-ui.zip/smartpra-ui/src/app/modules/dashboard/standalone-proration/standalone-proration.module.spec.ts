import { StandaloneProrationModule } from './standalone-proration.module';

describe('StandaloneProrationModule', () => {
  let standaloneProrationModule: StandaloneProrationModule;

  beforeEach(() => {
    standaloneProrationModule = new StandaloneProrationModule();
  });

  it('should create an instance', () => {
    expect(standaloneProrationModule).toBeTruthy();
  });
});
