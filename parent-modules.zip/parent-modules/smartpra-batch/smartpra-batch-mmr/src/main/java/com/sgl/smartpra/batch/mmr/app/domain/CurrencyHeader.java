package com.sgl.smartpra.batch.mmr.app.domain;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.sgl.smartpra.batch.mmr.app.layout.MMRHeaderLayout;
import com.sgl.smartpra.batch.mmr.app.processor.MMRHeaderProcessor;
import com.sgl.smartpra.batch.mmr.app.writer.MMRHeaderWriter;

public class CurrencyHeader extends CurrencyRecord{
		
	private transient String effectiveDate;
	private transient String value;
	private transient String variationTo;

	
	//getter and setter
	public String getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(String effectiveDate) {
		String dateStr=effectiveDate.substring(0, 8);
		this.effectiveDate = dateStr;
	}
	
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getVariationTo() {
		return variationTo;
	}
	public void setVariationTo(String variationTo) {
		this.variationTo = variationTo;
	}
	
	@Override
	public LineTokenizer lineTokenizer() {

		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		MMRHeaderLayout roeHeaderLayout = new MMRHeaderLayout();
		tokenizer.setColumns(roeHeaderLayout.getColumns());
		tokenizer.setNames(roeHeaderLayout.getNames());
		return tokenizer;

	}
	@Override
	public FieldSetMapper<CurrencyRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<CurrencyRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<CurrencyRecord>();
		fieldSetMapper.setTargetType(CurrencyHeader.class);
		return fieldSetMapper;
	}
	@Override
	public ItemProcessor<? extends CurrencyRecord, ? extends CurrencyRecord> processor() {
		return new MMRHeaderProcessor();
	}
	@Override
	public ItemWriter<? super CurrencyRecord> writer() {
		return new MMRHeaderWriter();
	}

}
