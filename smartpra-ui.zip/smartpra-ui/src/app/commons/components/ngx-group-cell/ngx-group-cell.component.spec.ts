import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NgxGroupCellComponent } from './ngx-group-cell.component';

describe('NgxGroupCellComponent', () => {
  let component: NgxGroupCellComponent;
  let fixture: ComponentFixture<NgxGroupCellComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NgxGroupCellComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NgxGroupCellComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
