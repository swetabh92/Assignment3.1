import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from 'src/app/shared/shared.module';
import {TabsprofileRoutingModule} from "./tabsprofile-routing.module";
import {TabsComponent} from "./tabs.component";
import { CoreDataModule } from 'src/app/core-data/core-data.module';

@NgModule({
  imports: [
    CommonModule,
    CoreDataModule,
    SharedModule,
    TabsprofileRoutingModule
  ],
  declarations: [
    TabsComponent
  ]
})
export class TabsProfileModule { }
