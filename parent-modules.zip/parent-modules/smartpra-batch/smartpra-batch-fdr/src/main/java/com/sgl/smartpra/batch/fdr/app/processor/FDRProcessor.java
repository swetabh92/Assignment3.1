package com.sgl.smartpra.batch.fdr.app.processor;

import java.sql.Timestamp;
import java.util.Date;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.fdr.app.domain.CurrencyRate;

@Component
@Scope(value = "Prototype")
public class FDRProcessor implements ItemProcessor<CurrencyRate, CurrencyRate> {

	@Value("#{jobParameters['fileId']}")
	public Integer inboundFileId;

	public Integer getInboundFileId() {
		return inboundFileId;
	}

	public void setInboundFileId(Integer inboundFileId) {
		this.inboundFileId = inboundFileId;
	}

	public CurrencyRate process(CurrencyRate roe) {
		roe.setInboundFileId(inboundFileId);
		roe.setCreatedBy("Admin Batch Job");
		roe.setCreatedDate(new Timestamp(new Date().getTime()));
		return roe;

	}
}
