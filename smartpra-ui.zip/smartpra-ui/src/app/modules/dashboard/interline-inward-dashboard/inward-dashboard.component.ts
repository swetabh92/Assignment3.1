import {Component, OnInit, ViewChild} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {GeneralService} from '../../../commons/services/general.service';
import {InwardDashboardService} from './inward-dashboard.service';
import {DatePipe} from '@angular/common';
import {PaginationService} from '../../../commons/services/pagination/pagination.service';
import {CommonService} from '../../masters/services/commons/common.service';
import { InterlineConstant } from './constants/interline-constants';
import { SummarizedDataComponent } from "./summarized-data/summarized-data.component";
import { InvoicesComponent } from "./invoices/invoices.component";
import { BatchesComponent } from "./batches/batches.component";
import { TransactionsComponent } from "./transactions/transactions.component";
//@ViewChild(SummarizedDataComponent) form3;

@Component({
  selector: 'app-inward-dashboard',
  templateUrl: './inward-dashboard.component.html',
  styleUrls: ['./inward-dashboard.component.css']
})
export class InwardDashboardComponent implements OnInit {
  productionMode:boolean = false;
  searchParams: any;
  searchParamsInvoices:any;
  batchSearchParams:any;
  couponSearchParams:any;
  batchID:number;
  couponID:number;
  carrierList:any;
  airline:string;
  period:string;
  airlineListUpdateFlag:boolean = true;
  @ViewChild(InvoicesComponent) invoice;
  @ViewChild(BatchesComponent) batch;
  @ViewChild(TransactionsComponent) coupon;
  constructor(private paginateService: PaginationService,private generalService: GeneralService, private commonService: CommonService, private formBuilder: FormBuilder,private inwardService: InwardDashboardService) {

  }


  ngOnInit() {
  }

  onSearchParamsChanged(searchData: any) {

    this.searchParams = searchData;
    if (searchData.area && searchData.area == InterlineConstant.PRODUCTION) {
      this.productionMode = true;
    } else {
      this.productionMode = false;
    }
  }

  invoiceSearchParamsChanged(searchData: any) {
    this.airlineListUpdateFlag = true;
    this.searchParamsInvoices = searchData;
    if (searchData.area && searchData.area == InterlineConstant.PRODUCTION) {
      this.productionMode = true;
    } else {
      this.productionMode = false;
    }
  }

  batchSearchParamsChanged(params: any) {
    this.batchSearchParams = params;
  }

  couponSearchParamsChanged(params: any) {
    this.couponSearchParams = params;
  }

  emptyForm3(){
    this.invoice.emptyInvoices();
    this.batch.emptyBatches();
    this.coupon.emptyCoupons();
  }

  emptyInvoice(){
    this.batch.emptyBatches();
    this.coupon.emptyCoupons();
  }

  emptyBatch(){
    this.coupon.emptyCoupons();
  }


  getCarriers(data:any) {
    this.carrierList = data;
  }

  searchParamChanged(event) {
    this.searchParams = {...this.searchParams};
  }


  searchParamCodeChanged(event) {
    this.searchParams = {...this.searchParams};
    this.airlineListUpdateFlag = false;
  }
}

